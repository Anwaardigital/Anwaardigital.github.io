SafeBox (Windows, basic concept version)
=========================================

WHAT IT IS
A password-protected vault for your files. Set a master password, add
files to the vault (they are stored under scrambled names in the local
"vault" folder), list them, restore them back with their original names,
or delete them permanently.

FEATURES
- Master password protection (min 4 characters)
- Add files to the vault (stored under scrambled names)
- List vault files with size and date added
- Restore a file to any folder with its ORIGINAL name
- Delete vault files permanently
- Change master password / lock the vault

REQUIREMENTS
- Windows 7 / 10 / 11
- Python 3.8 or newer
  Download from https://www.python.org/downloads/
  IMPORTANT: during install, tick "Add python.exe to PATH".

HOW TO RUN
1. Double-click run.bat
   (or open a terminal in this folder and run:  python main.py)
2. First run: choose a master password and confirm it.
3. Click "Add files", pick one or more files - they go into the vault.
4. Select a file and click "Restore", choose a folder - the file comes
   back with its original name.

YOUR DATA
- The password is stored as salted SHA-256 (never plain text) in
  vault/config.json. The name mapping lives in vault/index.json.
- Everything stays on your own computer. Nothing is uploaded anywhere.

HONEST PRIVACY NOTE (concept version)
This is basic obfuscation (files renamed to scrambled names), NOT
encryption. It keeps casual snoopers out, but anyone with full access to
your computer could still find the files. It is concept-level privacy,
not military-grade security.
