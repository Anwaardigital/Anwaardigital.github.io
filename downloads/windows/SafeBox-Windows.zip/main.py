#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SafeBox (Windows, basic concept version)
========================================
A master password (salted SHA-256 via hashlib) protects a local "vault"
folder. Files added to the vault are copied into the vault folder under
scrambled names; the app keeps a private index that maps scrambled names
back to the original file names. "Restore" copies a file back out with its
original name.

100% local - nothing ever leaves your computer.

Honest note: this is basic obfuscation (renaming), NOT encryption. Anyone
with full access to the computer could still find the files. Concept-level
privacy, not military-grade.
"""

import hashlib
import json
import os
import secrets
import shutil
import tkinter as tk
from datetime import datetime, timezone
from tkinter import filedialog, messagebox

APP_TITLE = "SafeBox"
BRANDING = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VAULT_DIR = os.path.join(BASE_DIR, "vault")
FONT = "Segoe UI"
PRIVACY_NOTE = (
    "Privacy note (concept version): files are stored locally under scrambled "
    "names. This is basic obfuscation, NOT encryption. Anyone with full access "
    "to this computer could still find them. No data ever leaves your device."
)


# ------------------------------------------------------------------ core logic
def _vdir(vault_dir=None):
    return vault_dir or VAULT_DIR


def _cfg_path(vault_dir=None):
    return os.path.join(_vdir(vault_dir), "config.json")


def _idx_path(vault_dir=None):
    return os.path.join(_vdir(vault_dir), "index.json")


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def ensure_vault(vault_dir=None):
    """Create the vault folder + empty config/index if missing."""
    d = _vdir(vault_dir)
    os.makedirs(d, exist_ok=True)
    if not os.path.exists(_cfg_path(d)):
        _write_json(_cfg_path(d), {"salt": None, "hash": None})
    if not os.path.exists(_idx_path(d)):
        _write_json(_idx_path(d), {})
    return d


def _hash(pw, salt):
    return hashlib.sha256((salt + pw).encode("utf-8")).hexdigest()


def password_is_set(vault_dir=None):
    cfg = _read_json(_cfg_path(vault_dir), {})
    return bool(cfg.get("hash")) and bool(cfg.get("salt"))


def set_password(password, vault_dir=None):
    """Set (or reset) the master password. Raises ValueError if too short."""
    password = str(password)
    if len(password) < 4:
        raise ValueError("Password must be at least 4 characters.")
    salt = secrets.token_hex(16)
    _write_json(_cfg_path(vault_dir),
                {"salt": salt, "hash": _hash(password, salt)})


def verify_password(password, vault_dir=None):
    cfg = _read_json(_cfg_path(vault_dir), {})
    if not cfg.get("hash") or not cfg.get("salt"):
        return False
    return _hash(str(password), cfg["salt"]) == cfg["hash"]


def add_file(src_path, vault_dir=None):
    """Copy a file into the vault under a scrambled name. Returns the key."""
    d = ensure_vault(vault_dir)
    key = secrets.token_hex(16)
    shutil.copy2(src_path, os.path.join(d, key))
    index = _read_json(_idx_path(d), {})
    index[key] = {
        "name": os.path.basename(src_path),
        "size": os.path.getsize(src_path),
        "added": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    }
    _write_json(_idx_path(d), index)
    return key


def list_files(vault_dir=None):
    """Return {scrambled_key: {"name","size","added",...}} for vault files."""
    d = _vdir(vault_dir)
    index = _read_json(_idx_path(d), {})
    # drop stale entries whose stored file disappeared
    live = {k: v for k, v in index.items()
            if os.path.exists(os.path.join(d, k))}
    if len(live) != len(index):
        _write_json(_idx_path(d), live)
    return live


def restore_file(key, dest_dir, vault_dir=None, overwrite=False):
    """Copy a vault file back out with its ORIGINAL name. Returns dest path."""
    d = _vdir(vault_dir)
    index = _read_json(_idx_path(d), {})
    if key not in index:
        raise KeyError("Unknown vault entry.")
    stored = os.path.join(d, key)
    if not os.path.exists(stored):
        raise FileNotFoundError("Stored file is missing.")
    dest = os.path.join(dest_dir, index[key]["name"])
    if os.path.exists(dest) and not overwrite:
        raise FileExistsError("A file with that name already exists: %s"
                              % dest)
    shutil.copy2(stored, dest)
    return dest


def delete_file(key, vault_dir=None):
    """Permanently delete a vault entry (stored file + index record)."""
    d = _vdir(vault_dir)
    stored = os.path.join(d, key)
    if os.path.exists(stored):
        os.remove(stored)
    index = _read_json(_idx_path(d), {})
    index.pop(key, None)
    _write_json(_idx_path(d), index)


# ------------------------------------------------------------------------ GUI
def brand_footer(parent):
    tk.Label(parent, text=BRANDING, font=(FONT, 8), fg="#777777").pack(
        side="bottom", fill="x", pady=(10, 6))


def privacy_label(parent):
    tk.Label(parent, text=PRIVACY_NOTE, font=(FONT, 8), fg="#885500",
             wraplength=520, justify="left").pack(fill="x", pady=(6, 2))


class PasswordDialog(tk.Toplevel):
    """Modal master-password prompt. `.result` is the password or None."""

    def __init__(self, parent, title="SafeBox", prompt="Enter master password:"):
        super().__init__(parent)
        self.title(title)
        self.result = None
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)
        tk.Label(self, text=prompt, font=(FONT, 10)).pack(padx=24, pady=(18, 4))
        self.entry = tk.Entry(self, show="*", width=30, font=(FONT, 12),
                              justify="center")
        self.entry.pack(padx=24, pady=6)
        self.entry.focus_set()
        row = tk.Frame(self)
        row.pack(pady=8)
        tk.Button(row, text="OK", width=10, command=self._ok).pack(
            side="left", padx=6)
        tk.Button(row, text="Cancel", width=10,
                  command=self.destroy).pack(side="left", padx=6)
        self.bind("<Return>", lambda _e: self._ok())
        self.bind("<Escape>", lambda _e: self.destroy())
        tk.Label(self, text=BRANDING, font=(FONT, 7),
                 fg="#999999").pack(pady=(4, 8))
        self.wait_window()

    def _ok(self):
        self.result = self.entry.get()
        self.destroy()


class SafeBoxGUI:
    def __init__(self, root):
        self.root = root
        ensure_vault()
        root.title(APP_TITLE)
        root.geometry("600x500")
        root.resizable(False, False)
        self.body = tk.Frame(root)
        self.body.pack(fill="both", expand=True)
        brand_footer(root)
        if password_is_set():
            self.show_login()
        else:
            self.show_setup()

    def _clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    # ------------------------------------------------------------------ setup
    def show_setup(self):
        self._clear()
        f = tk.Frame(self.body, padx=30, pady=24)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="Welcome to SafeBox", font=(FONT, 16, "bold")).pack(
            pady=(8, 6))
        tk.Label(f, text="Choose a master password (min 4 characters).\n"
                         "It protects access to your vault.",
                 font=(FONT, 10), justify="center").pack(pady=4)
        tk.Label(f, text="New password:", font=(FONT, 10)).pack(pady=(12, 2))
        e1 = tk.Entry(f, show="*", width=30, font=(FONT, 12), justify="center")
        e1.pack()
        tk.Label(f, text="Confirm password:", font=(FONT, 10)).pack(pady=(8, 2))
        e2 = tk.Entry(f, show="*", width=30, font=(FONT, 12), justify="center")
        e2.pack()
        e1.focus_set()

        def save():
            p1, p2 = e1.get(), e2.get()
            if p1 != p2:
                messagebox.showerror("Mismatch", "Passwords do not match.")
                return
            try:
                set_password(p1)
            except ValueError as exc:
                messagebox.showerror("Too short", str(exc))
                return
            messagebox.showinfo("Done", "Master password saved.")
            self.show_main()

        tk.Button(f, text="Create vault", width=18, font=(FONT, 11),
                  command=save).pack(pady=16)
        privacy_label(f)

    # ------------------------------------------------------------------ login
    def show_login(self):
        self._clear()
        f = tk.Frame(self.body, padx=30, pady=24)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="SafeBox", font=(FONT, 18, "bold")).pack(pady=(20, 6))
        tk.Label(f, text="Enter your master password to open the vault.",
                 font=(FONT, 10)).pack(pady=4)
        entry = tk.Entry(f, show="*", width=30, font=(FONT, 12),
                         justify="center")
        entry.pack(pady=10)
        entry.focus_set()

        def unlock(_event=None):
            if verify_password(entry.get()):
                self.show_main()
            else:
                messagebox.showerror("Wrong password",
                                     "Incorrect master password.")
                entry.delete(0, tk.END)

        entry.bind("<Return>", unlock)
        tk.Button(f, text="Unlock", width=18, font=(FONT, 11),
                  command=unlock).pack(pady=10)
        privacy_label(f)

    # ------------------------------------------------------------------- main
    def show_main(self):
        self._clear()
        f = tk.Frame(self.body, padx=20, pady=14)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="Your vault", font=(FONT, 14, "bold")).pack(
            anchor="w", pady=(0, 8))

        list_frame = tk.Frame(f)
        list_frame.pack(fill="both", expand=True)
        self.listbox = tk.Listbox(list_frame, font=(FONT, 10), height=10)
        scroll = tk.Scrollbar(list_frame, command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.keys = []
        self.refresh_list()

        btns = tk.Frame(f)
        btns.pack(pady=10)
        tk.Button(btns, text="Add files", width=12,
                  command=self.add_files).pack(side="left", padx=4)
        tk.Button(btns, text="Restore", width=12,
                  command=self.restore_selected).pack(side="left", padx=4)
        tk.Button(btns, text="Delete", width=12,
                  command=self.delete_selected).pack(side="left", padx=4)
        tk.Button(btns, text="Change password", width=14,
                  command=self.change_password).pack(side="left", padx=4)
        tk.Button(btns, text="Lock", width=8,
                  command=self.show_login).pack(side="left", padx=4)
        privacy_label(f)

    def refresh_list(self):
        files = list_files()
        self.keys = sorted(files.keys(),
                           key=lambda k: files[k]["name"].lower())
        self.listbox.delete(0, tk.END)
        for k in self.keys:
            meta = files[k]
            size_kb = meta.get("size", 0) / 1024
            self.listbox.insert(
                tk.END, "%s   (%s KB, added %s)" %
                (meta["name"], int(size_kb), meta.get("added", "?")))
        if not self.keys:
            self.listbox.insert(tk.END, "(vault is empty - click 'Add files')")

    def _selected_key(self):
        sel = self.listbox.curselection()
        if not sel or not self.keys:
            return None
        return self.keys[sel[0]]

    def add_files(self):
        paths = filedialog.askopenfilenames(title="Add files to vault")
        added = 0
        for p in paths:
            try:
                add_file(p)
                added += 1
            except Exception as exc:  # noqa: BLE001 - report per-file errors
                messagebox.showerror("Add failed",
                                     "%s\n%s" % (os.path.basename(p), exc))
        if added:
            self.refresh_list()
            messagebox.showinfo("Added", "%d file(s) added to the vault."
                                % added)

    def restore_selected(self):
        key = self._selected_key()
        if key is None:
            messagebox.showinfo("No selection", "Select a file first.")
            return
        dest_dir = filedialog.askdirectory(title="Restore to folder")
        if not dest_dir:
            return
        try:
            dest = restore_file(key, dest_dir)
        except FileExistsError:
            meta = list_files()[key]
            if messagebox.askyesno(
                    "Overwrite?",
                    "'%s' already exists in that folder.\nOverwrite it?"
                    % meta["name"]):
                dest = restore_file(key, dest_dir, overwrite=True)
            else:
                return
        except Exception as exc:  # noqa: BLE001 - show any restore error
            messagebox.showerror("Restore failed", str(exc))
            return
        messagebox.showinfo("Restored", "File restored to:\n%s" % dest)

    def delete_selected(self):
        key = self._selected_key()
        if key is None:
            messagebox.showinfo("No selection", "Select a file first.")
            return
        meta = list_files()[key]
        if messagebox.askyesno("Delete permanently",
                               "Permanently delete '%s' from the vault?\n"
                               "This cannot be undone." % meta["name"]):
            delete_file(key)
            self.refresh_list()

    def change_password(self):
        dlg = PasswordDialog(self.root, title="Change password",
                             prompt="Enter current password:")
        if dlg.result is None:
            return
        if not verify_password(dlg.result):
            messagebox.showerror("Wrong password",
                                 "Incorrect current password.")
            return
        dlg2 = PasswordDialog(self.root, title="Change password",
                              prompt="Enter NEW password (min 4 chars):")
        if dlg2.result is None:
            return
        try:
            set_password(dlg2.result)
        except ValueError as exc:
            messagebox.showerror("Too short", str(exc))
            return
        messagebox.showinfo("Done", "Master password changed.")


def main():
    root = tk.Tk()
    SafeBoxGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
