==============================================
 IMAGE RESIZER v1.0 (Windows)
==============================================
Resize images by width/height or percentage,
and convert between PNG and JPG formats.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Open a Command Prompt in this folder and run:
       pip install -r requirements.txt
3. Double-click run.bat (or run: python main.py)

FEATURES
--------
- Open any common image (PNG, JPG, BMP, GIF, WebP)
- Resize by exact width x height (with optional aspect lock)
  or by percentage (e.g. 50%)
- Live before/after dimension display
- Format conversion: keep original, PNG, or JPG
- High-quality resizing (LANCZOS)

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
