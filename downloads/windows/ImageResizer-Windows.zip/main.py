"""
Image Resizer Windows v1.0
Open an image, resize by width/height or percentage, convert format (PNG/JPG), save.
Dependencies: Pillow (pip install Pillow)
Runs on Windows with Python 3: python main.py
"""
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    Image = ImageTk = None
    PIL_AVAILABLE = False

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
GOLD = "#D4AF37"
CREAM = "#FAF8F0"
TEXT_DARK = "#1E2B26"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

PREVIEW_MAX = 300  # preview box size in px


def calc_resize(orig_w, orig_h, mode, val_w, val_h, pct, keep_aspect):
    """Return (new_w, new_h) for the resize options. mode: 'wh' or 'pct'."""
    if mode == "pct":
        return max(1, round(orig_w * pct / 100.0)), \
               max(1, round(orig_h * pct / 100.0))
    w, h = int(val_w), int(val_h)
    if keep_aspect:
        scale = min(w / orig_w, h / orig_h)
        return max(1, round(orig_w * scale)), max(1, round(orig_h * scale))
    return max(1, w), max(1, h)


def resize_image(src_path, dst_path, size, out_format):
    """Resize with high-quality LANCZOS and save. Returns output path."""
    img = Image.open(src_path)
    resized = img.resize(size, Image.LANCZOS)
    fmt = out_format.upper()
    if fmt == "JPG":
        if resized.mode in ("RGBA", "LA", "P"):
            resized = resized.convert("RGB")
        resized.save(dst_path, "JPEG", quality=95)
    elif fmt == "PNG":
        resized.save(dst_path, "PNG")
    else:  # keep original extension
        ext = os.path.splitext(dst_path)[1].lower()
        if ext in (".jpg", ".jpeg"):
            if resized.mode in ("RGBA", "LA", "P"):
                resized = resized.convert("RGB")
            resized.save(dst_path, "JPEG", quality=95)
        else:
            resized.save(dst_path)
    return dst_path


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Image Resizer - Malik Muhammad Anwaar")
        self.geometry("720x640")
        self.configure(bg=CREAM)
        self.resizable(False, False)

        self.img_path = None
        self.orig_w = self.orig_h = 0
        self.photo = None  # keep reference

        header = tk.Frame(self, bg=DEEP_EMERALD, height=64)
        header.pack(fill="x")
        tk.Label(header, text="IMAGE RESIZER", font=("Segoe UI", 18, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=16, pady=12)
        tk.Label(header, text="Resize  •  Convert PNG / JPG",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                 side="left", padx=8, pady=12)

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=12, pady=8)

        # ---- preview area ----
        prev = tk.LabelFrame(body, text="Preview", bg=CREAM, fg=TEXT_DARK,
                             font=("Segoe UI", 10, "bold"))
        prev.pack(fill="x", pady=(0, 8))
        self.preview_lbl = tk.Label(prev, bg="#E9EFEB", width=80, height=16,
                                    text="No image loaded",
                                    font=("Segoe UI", 10), fg=TEXT_DARK)
        self.preview_lbl.pack(padx=10, pady=10)

        dims = tk.Frame(prev, bg=CREAM)
        dims.pack(pady=(0, 8))
        self.before_lbl = tk.Label(dims, text="Before: -", bg=CREAM,
                                   fg=TEXT_DARK, font=("Segoe UI", 10, "bold"))
        self.before_lbl.pack(side="left", padx=20)
        tk.Label(dims, text="→", bg=CREAM, fg=GOLD,
                 font=("Segoe UI", 14, "bold")).pack(side="left")
        self.after_lbl = tk.Label(dims, text="After: -", bg=CREAM,
                                  fg=EMERALD, font=("Segoe UI", 10, "bold"))
        self.after_lbl.pack(side="left", padx=20)

        # ---- options ----
        opts = tk.LabelFrame(body, text="Resize options", bg=CREAM,
                             fg=TEXT_DARK, font=("Segoe UI", 10, "bold"))
        opts.pack(fill="x", pady=(0, 8))

        self.mode = tk.StringVar(value="wh")
        r1 = tk.Frame(opts, bg=CREAM)
        r1.pack(fill="x", padx=10, pady=4)
        tk.Radiobutton(r1, text="Width × Height:", variable=self.mode,
                       value="wh", bg=CREAM, fg=TEXT_DARK,
                       font=("Segoe UI", 10)).pack(side="left")
        self.width_var = tk.IntVar(value=800)
        self.height_var = tk.IntVar(value=600)
        tk.Spinbox(r1, from_=1, to=10000, width=7, textvariable=self.width_var,
                   font=("Segoe UI", 10)).pack(side="left", padx=4)
        tk.Label(r1, text="×", bg=CREAM, fg=TEXT_DARK,
                 font=("Segoe UI", 10)).pack(side="left")
        tk.Spinbox(r1, from_=1, to=10000, width=7, textvariable=self.height_var,
                   font=("Segoe UI", 10)).pack(side="left", padx=4)
        tk.Label(r1, text="px", bg=CREAM, fg=TEXT_DARK,
                 font=("Segoe UI", 10)).pack(side="left")
        self.keep_aspect = tk.BooleanVar(value=True)
        tk.Checkbutton(r1, text="Keep aspect ratio", variable=self.keep_aspect,
                       bg=CREAM, fg=TEXT_DARK, font=("Segoe UI", 10)
                       ).pack(side="left", padx=16)

        r2 = tk.Frame(opts, bg=CREAM)
        r2.pack(fill="x", padx=10, pady=4)
        tk.Radiobutton(r2, text="Scale by percent:", variable=self.mode,
                       value="pct", bg=CREAM, fg=TEXT_DARK,
                       font=("Segoe UI", 10)).pack(side="left")
        self.pct_var = tk.IntVar(value=50)
        tk.Spinbox(r2, from_=1, to=1000, width=7, textvariable=self.pct_var,
                   font=("Segoe UI", 10)).pack(side="left", padx=4)
        tk.Label(r2, text="%", bg=CREAM, fg=TEXT_DARK,
                 font=("Segoe UI", 10)).pack(side="left")

        r3 = tk.Frame(opts, bg=CREAM)
        r3.pack(fill="x", padx=10, pady=6)
        tk.Label(r3, text="Output format:", bg=CREAM, fg=TEXT_DARK,
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        self.format_var = tk.StringVar(value="KEEP")
        ttk.Combobox(r3, textvariable=self.format_var, width=14,
                     values=["KEEP", "PNG", "JPG"], state="readonly",
                     font=("Segoe UI", 10)).pack(side="left", padx=8)

        # ---- action buttons ----
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(pady=6)
        style = ttk.Style(self)
        style.configure("Emerald.TButton", font=("Segoe UI", 10, "bold"))
        ttk.Button(btns, text="Open Image…", command=self.open_image,
                   style="Emerald.TButton").pack(side="left", padx=8)
        ttk.Button(btns, text="Preview Size", command=self.update_preview,
                   style="Emerald.TButton").pack(side="left", padx=8)
        ttk.Button(btns, text="SAVE AS…", command=self.save_image,
                   style="Emerald.TButton").pack(side="left", padx=8)

        footer = tk.Frame(self, bg=DEEP_EMERALD)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 9, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

        if not PIL_AVAILABLE:
            messagebox.showwarning(
                "Missing dependency",
                "Pillow is not installed.\n"
                "Run: pip install -r requirements.txt")

    def open_image(self):
        path = filedialog.askopenfilename(
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.webp"),
                       ("All files", "*.*")])
        if not path:
            return
        try:
            img = Image.open(path)
            self.orig_w, self.orig_h = img.size
            self.img_path = path
        except Exception as e:
            return messagebox.showerror("Open failed", str(e))
        self.width_var.set(self.orig_w)
        self.height_var.set(self.orig_h)
        self._show_preview(path)
        self.before_lbl.configure(
            text="Before: %d × %d px" % (self.orig_w, self.orig_h))
        self.update_preview()

    def _show_preview(self, path):
        img = Image.open(path)
        img.thumbnail((PREVIEW_MAX, PREVIEW_MAX), Image.LANCZOS)
        self.photo = ImageTk.PhotoImage(img)
        self.preview_lbl.configure(image=self.photo, text="")

    def _current_target(self):
        try:
            return calc_resize(self.orig_w, self.orig_h, self.mode.get(),
                               self.width_var.get(), self.height_var.get(),
                               self.pct_var.get(), self.keep_aspect.get())
        except Exception:
            return None

    def update_preview(self):
        if not self.img_path:
            return messagebox.showinfo("Resize", "Open an image first.")
        size = self._current_target()
        if not size:
            return messagebox.showerror(
                "Invalid input", "Check the width/height/percent values.")
        self.after_lbl.configure(text="After: %d × %d px" % size)

    def save_image(self):
        if not self.img_path:
            return messagebox.showinfo("Save", "Open an image first.")
        if not PIL_AVAILABLE:
            return messagebox.showerror(
                "Error", "Pillow is not installed. Run: pip install Pillow")
        size = self._current_target()
        if not size:
            return messagebox.showerror(
                "Invalid input", "Check the width/height/percent values.")
        fmt = self.format_var.get()
        ext = ".png" if fmt == "PNG" else ".jpg" if fmt == "JPG" \
            else os.path.splitext(self.img_path)[1] or ".png"
        default = os.path.splitext(os.path.basename(self.img_path))[0] \
            + "_resized" + ext
        out = filedialog.asksaveasfilename(
            defaultextension=ext, initialfile=default,
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg *.jpeg"),
                       ("All files", "*.*")])
        if not out:
            return
        try:
            resize_image(self.img_path, out, size, fmt)
            messagebox.showinfo(
                "Done", "Saved %d × %d px image to:\n%s" % (size[0], size[1], out))
        except Exception as e:
            messagebox.showerror("Save failed", str(e))


if __name__ == "__main__":
    App().mainloop()
