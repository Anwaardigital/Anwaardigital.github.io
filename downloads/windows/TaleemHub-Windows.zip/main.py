# -*- coding: utf-8 -*-
"""
Taleem Hub v2.0 — Windows Desktop App
590 chapters | 1265 MCQs | 274 formulas | 3518 vocabulary | 61 grammar sections
Theme: deep emerald + gold. Python 3 + Tkinter only (no extra deps).
App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math
import random

import data

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#0A3D2E"
BG_DARK = "#062B20"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
ACCENT = "#0E5C44"

N_CH = sum(len(v) for v in data.CHAPTERS.values())
N_MCQ = sum(len(v) for v in data.BANKS.values())


class TaleemHub(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Taleem Hub v2.0 — Study App")
        self.geometry("980x680")
        self.configure(bg=BG)

        hdr = tk.Frame(self, bg=BG_DARK, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📚 Taleem Hub v2.0", font=("Segoe UI", 22, "bold"),
                 fg=GOLD, bg=BG_DARK).pack()
        tk.Label(hdr, text=f"{N_CH} chapters  •  {N_MCQ} MCQs  •  {len(data.FORMULAS)} formulas  •  "
                           f"{len(data.VOCAB)} words  •  {sum(len(v) for v in data.GRAMMAR.values())} grammar",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG_DARK).pack()

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab_ch = tk.Frame(self.nb, bg=WHITE)
        self.tab_quiz = tk.Frame(self.nb, bg=WHITE)
        self.tab_form = tk.Frame(self.nb, bg=WHITE)
        self.tab_dict = tk.Frame(self.nb, bg=WHITE)
        self.tab_gram = tk.Frame(self.nb, bg=WHITE)
        self.tab_calc = tk.Frame(self.nb, bg=BG_DARK)

        self.nb.add(self.tab_ch, text="  📝 Chapters  ")
        self.nb.add(self.tab_quiz, text="  ❓ MCQ Quiz  ")
        self.nb.add(self.tab_form, text="  🧪 Formulas  ")
        self.nb.add(self.tab_dict, text="  📖 Dictionary  ")
        self.nb.add(self.tab_gram, text="  📜 Grammar  ")
        self.nb.add(self.tab_calc, text="  🧮 Calculator  ")

        self.build_chapters()
        self.build_quiz()
        self.build_formulas()
        self.build_dict()
        self.build_grammar()
        self.build_calc()

        ftr = tk.Frame(self, bg=BG_DARK, pady=8)
        ftr.pack(fill="x")
        tk.Label(ftr, text=DEVELOPER_LINE + "  |  " + WHATSAPP_LINE,
                 font=("Segoe UI", 9), fg=GOLD, bg=BG_DARK).pack()

    # ---------------- chapters ----------------
    def build_chapters(self):
        top = tk.Frame(self.tab_ch, bg=WHITE)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Class:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        self.cls_var = tk.StringVar(value=list(data.SUBJECTS.keys())[0])
        cb1 = ttk.Combobox(top, textvariable=self.cls_var, values=list(data.SUBJECTS.keys()),
                           state="readonly", width=12)
        cb1.pack(side="left", padx=6)
        tk.Label(top, text="Subject:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        self.sub_var = tk.StringVar()
        self.cb2 = ttk.Combobox(top, textvariable=self.sub_var, state="readonly", width=22)
        self.cb2.pack(side="left", padx=6)
        cb1.bind("<<ComboboxSelected>>", self.ch_subjects)
        self.cb2.bind("<<ComboboxSelected>>", self.ch_list)
        tk.Label(top, text="Chapter:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        self.ch_var = tk.StringVar()
        self.cb3 = ttk.Combobox(top, textvariable=self.ch_var, state="readonly", width=30)
        self.cb3.pack(side="left", padx=6)
        self.cb3.bind("<<ComboboxSelected>>", self.ch_show)

        self.ch_text = tk.Text(self.tab_ch, wrap="word", font=("Segoe UI", 11),
                               bg=CREAM, fg="#1a1a1a", padx=12, pady=12)
        self.ch_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.ch_subjects()

    def ch_subjects(self, *_):
        subs = data.SUBJECTS.get(self.cls_var.get(), [])
        self.cb2.config(values=subs)
        if subs:
            self.sub_var.set(subs[0])
        self.ch_list()

    def ch_list(self, *_):
        key = self.cls_var.get() + "|" + self.sub_var.get()
        chs = data.CHAPTERS.get(key, [])
        self.cb3.config(values=chs)
        if chs:
            self.ch_var.set(chs[0])
        self.ch_show()

    def ch_show(self, *_):
        key = self.cls_var.get() + "|" + self.sub_var.get() + "|" + self.ch_var.get()
        pts = data.NOTES.get(key, [])
        self.ch_text.config(state="normal")
        self.ch_text.delete("1.0", "end")
        self.ch_text.insert("end", self.ch_var.get() + "\n\n", "head")
        if pts:
            for p in pts:
                self.ch_text.insert("end", "  • " + p + "\n\n")
        else:
            self.ch_text.insert("end", "Key points coming soon for this chapter.\n")
        self.ch_text.tag_config("head", font=("Segoe UI", 14, "bold"), foreground=BG)
        self.ch_text.config(state="disabled")

    # ---------------- quiz ----------------
    def build_quiz(self):
        top = tk.Frame(self.tab_quiz, bg=WHITE)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Bank:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        keys = sorted(data.BANKS.keys())
        self.bank_var = tk.StringVar(value=keys[0] if keys else "")
        titles = [data.BANK_TITLES.get(k, k) for k in keys]
        self.bank_map = dict(zip(titles, keys))
        cb = ttk.Combobox(top, textvariable=self.bank_var, values=titles,
                          state="readonly", width=30)
        cb.pack(side="left", padx=6)
        cb.bind("<<ComboboxSelected>>", lambda e: self.quiz_reset())
        tk.Button(top, text="Start 🔄", command=self.quiz_reset,
                  font=("Segoe UI", 11, "bold"), bg=GOLD, fg=BG_DARK).pack(side="left", padx=6)

        self.q_label = tk.Label(self.tab_quiz, text="", font=("Segoe UI", 13, "bold"),
                                bg=WHITE, fg=BG, wraplength=850, justify="left")
        self.q_label.pack(pady=14)
        self.opt_var = tk.IntVar(value=-1)
        self.opt_btns = []
        for i in range(4):
            rb = tk.Radiobutton(self.tab_quiz, variable=self.opt_var, value=i,
                                font=("Segoe UI", 12), bg=WHITE, anchor="w",
                                wraplength=800, justify="left")
            rb.pack(fill="x", padx=40, pady=3)
            self.opt_btns.append(rb)
        self.expl_label = tk.Label(self.tab_quiz, text="", font=("Segoe UI", 10, "italic"),
                                   bg=WHITE, fg=ACCENT, wraplength=850, justify="left")
        self.expl_label.pack(pady=4)
        btnrow = tk.Frame(self.tab_quiz, bg=WHITE)
        btnrow.pack(pady=10)
        tk.Button(btnrow, text="Answer ➜", command=self.quiz_next,
                  font=("Segoe UI", 12, "bold"), bg=GOLD, fg=BG_DARK, width=12).pack()
        self.quiz_info = tk.Label(self.tab_quiz, text="", font=("Segoe UI", 11),
                                  bg=WHITE, fg=BG)
        self.quiz_info.pack(pady=6)
        self.quiz_reset()

    def quiz_reset(self):
        key = self.bank_map.get(self.bank_var.get(), self.bank_var.get())
        self.mcqs = list(data.BANKS.get(key, []))
        random.shuffle(self.mcqs)
        self.quiz_idx, self.quiz_score = 0, 0
        self.quiz_show()

    def quiz_show(self):
        if self.quiz_idx >= len(self.mcqs):
            messagebox.showinfo("Quiz Complete",
                                f"Your score: {self.quiz_score}/{len(self.mcqs)}")
            self.quiz_reset()
            return
        m = self.mcqs[self.quiz_idx]
        self.q_label.config(text=f"Q{self.quiz_idx + 1}. {m['q']}")
        for i, b in enumerate(self.opt_btns):
            b.config(text=m["opts"][i] if i < len(m["opts"]) else "")
        self.opt_var.set(-1)
        self.expl_label.config(text="")
        self.quiz_info.config(
            text=f"Question {self.quiz_idx + 1} of {len(self.mcqs)}  |  Score: {self.quiz_score}")

    def quiz_next(self):
        if self.opt_var.get() == -1:
            messagebox.showwarning("No answer", "Please select an option first.")
            return
        m = self.mcqs[self.quiz_idx]
        if self.opt_var.get() == m["correct"]:
            self.quiz_score += 1
            self.expl_label.config(text="✅ Correct!" + (("  " + m["expl"]) if m["expl"] else ""))
        else:
            right = m["opts"][m["correct"]] if m["correct"] < len(m["opts"]) else ""
            self.expl_label.config(text=f"❌ Wrong. Correct: {right}" + (("  " + m["expl"]) if m["expl"] else ""))
        self.quiz_idx += 1
        self.after(1200, self.quiz_show)

    # ---------------- formulas ----------------
    def build_formulas(self):
        top = tk.Frame(self.tab_form, bg=WHITE)
        top.pack(fill="x", padx=12, pady=10)
        tk.Label(top, text="Search:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        self.f_var = tk.StringVar()
        ent = tk.Entry(top, textvariable=self.f_var, font=("Segoe UI", 12), width=32)
        ent.pack(side="left", padx=8)
        ent.bind("<KeyRelease>", lambda e: self.form_show())
        self.f_text = tk.Text(self.tab_form, wrap="word", font=("Segoe UI", 11),
                              bg=CREAM, fg="#1a1a1a", padx=12, pady=12)
        self.f_text.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.form_show()

    def form_show(self):
        q = self.f_var.get().strip().lower()
        self.f_text.config(state="normal")
        self.f_text.delete("1.0", "end")
        n = 0
        for sub, name, form in data.FORMULAS:
            if q and q not in (sub + " " + name + " " + form).lower():
                continue
            self.f_text.insert("end", f"[{sub}] {name}\n", "head")
            self.f_text.insert("end", f"    {form}\n\n")
            n += 1
            if n >= 400:
                self.f_text.insert("end", f"... and more (refine search, {len(data.FORMULAS)} total)\n")
                break
        if n == 0:
            self.f_text.insert("end", "No formulas found.\n")
        self.f_text.tag_config("head", font=("Segoe UI", 12, "bold"), foreground=BG)
        self.f_text.config(state="disabled")

    # ---------------- dictionary ----------------
    def build_dict(self):
        top = tk.Frame(self.tab_dict, bg=WHITE)
        top.pack(fill="x", padx=12, pady=10)
        tk.Label(top, text="English word:", font=("Segoe UI", 11, "bold"),
                 bg=WHITE, fg=BG).pack(side="left")
        self.d_var = tk.StringVar()
        ent = tk.Entry(top, textvariable=self.d_var, font=("Segoe UI", 12), width=30)
        ent.pack(side="left", padx=8)
        ent.bind("<KeyRelease>", lambda e: self.dict_search())
        self.d_text = tk.Text(self.tab_dict, wrap="word", font=("Segoe UI", 12),
                              bg=CREAM, fg="#1a1a1a", padx=12, pady=12)
        self.d_text.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.dict_search()

    def dict_search(self):
        q = self.d_var.get().strip().lower()
        self.d_text.config(state="normal")
        self.d_text.delete("1.0", "end")
        n = 0
        for en, ur in data.VOCAB:
            if q and not en.lower().startswith(q):
                continue
            self.d_text.insert("end", f"{en}  →  {ur}\n")
            n += 1
            if n >= 300:
                self.d_text.insert("end", f"\n... {len(data.VOCAB)} words total — keep typing to narrow down.\n")
                break
        if n == 0:
            self.d_text.insert("end", "No matches. Try another spelling.\n")
        self.d_text.config(state="disabled")

    # ---------------- grammar ----------------
    def build_grammar(self):
        top = tk.Frame(self.tab_gram, bg=WHITE)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Section:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        modes = list(data.GRAMMAR.keys())
        self.g_mode = tk.StringVar(value=modes[0])
        cbm = ttk.Combobox(top, textvariable=self.g_mode, values=modes, state="readonly", width=12)
        cbm.pack(side="left", padx=6)
        cbm.bind("<<ComboboxSelected>>", self.g_list)
        tk.Label(top, text="Topic:", font=("Segoe UI", 11, "bold"), bg=WHITE, fg=BG).pack(side="left")
        self.g_var = tk.StringVar()
        self.g_cb = ttk.Combobox(top, textvariable=self.g_var, state="readonly", width=32)
        self.g_cb.pack(side="left", padx=6)
        self.g_cb.bind("<<ComboboxSelected>>", self.g_show)
        self.g_text = tk.Text(self.tab_gram, wrap="word", font=("Segoe UI", 11),
                              bg=CREAM, fg="#1a1a1a", padx=12, pady=12)
        self.g_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.g_list()

    def g_list(self, *_):
        secs = data.GRAMMAR.get(self.g_mode.get(), [])
        titles = [s["title"] for s in secs]
        self.g_cb.config(values=titles)
        if titles:
            self.g_var.set(titles[0])
        self.g_show()

    def g_show(self, *_):
        secs = data.GRAMMAR.get(self.g_mode.get(), [])
        body = ""
        for s in secs:
            if s["title"] == self.g_var.get():
                body = s["body"]
                break
        self.g_text.config(state="normal")
        self.g_text.delete("1.0", "end")
        self.g_text.insert("end", self.g_var.get() + "\n\n", "head")
        self.g_text.insert("end", body)
        self.g_text.tag_config("head", font=("Segoe UI", 14, "bold"), foreground=BG)
        self.g_text.config(state="disabled")

    # ---------------- calculator ----------------
    def build_calc(self):
        self.calc_expr = tk.StringVar()
        disp = tk.Entry(self.tab_calc, textvariable=self.calc_expr,
                        font=("Segoe UI", 20), justify="right",
                        bg=WHITE, fg=BG_DARK)
        disp.pack(fill="x", padx=14, pady=14)
        disp.bind("<Return>", lambda e: self.calc_eq())
        grid = tk.Frame(self.tab_calc, bg=BG_DARK)
        grid.pack(padx=14, pady=6)
        keys = [
            ["7", "8", "9", "/", "C"],
            ["4", "5", "6", "*", "("],
            ["1", "2", "3", "-", ")"],
            ["0", ".", "%", "+", "="],
            ["sin", "cos", "tan", "√", "^"],
        ]
        for r, row in enumerate(keys):
            for c, k in enumerate(row):
                tk.Button(grid, text=k, width=7, height=2,
                          font=("Segoe UI", 12, "bold"),
                          bg=ACCENT if k not in ("=", "C") else GOLD,
                          fg=WHITE if k not in ("=", "C") else BG_DARK,
                          command=lambda kk=k: self.calc_key(kk)
                          ).grid(row=r, column=c, padx=3, pady=3)

    def calc_key(self, k):
        if k == "C":
            self.calc_expr.set("")
        elif k == "=":
            self.calc_eq()
        elif k == "√":
            self.calc_expr.set(self.calc_expr.get() + "sqrt(")
        elif k == "^":
            self.calc_expr.set(self.calc_expr.get() + "**")
        else:
            self.calc_expr.set(self.calc_expr.get() + k)

    def calc_eq(self):
        try:
            safe = {"sqrt": math.sqrt, "sin": lambda x: math.sin(math.radians(x)),
                    "cos": lambda x: math.cos(math.radians(x)),
                    "tan": lambda x: math.tan(math.radians(x)),
                    "pi": math.pi, "__builtins__": {}}
            res = eval(self.calc_expr.get().replace("%", "/100"), safe)
            self.calc_expr.set(str(round(res, 8)))
        except Exception:
            messagebox.showerror("Error", "Invalid expression")


if __name__ == "__main__":
    app = TaleemHub()
    app.mainloop()
