# -*- coding: utf-8 -*-
# Auto-extracted from Taleem Hub v2.0 Android sources.
SUBJECTS = {
 "9th": [
  "Computer Science",
  "English",
  "Islamiat",
  "Pak Studies",
  "Tarjuma-tul-Quran",
  "Urdu",
  "Physics",
  "Chemistry",
  "Biology",
  "Math"
 ],
 "10th": [
  "English",
  "Chemistry",
  "Biology",
  "Physics",
  "Computer Science",
  "Islamiat",
  "Pak Studies",
  "Tarjuma-tul-Quran",
  "Urdu",
  "Math"
 ],
 "11th": [
  "English",
  "Biology",
  "Chemistry",
  "Computer Science",
  "Islamiat",
  "Pak Studies",
  "Physics",
  "Urdu",
  "Math"
 ],
 "12th": [
  "English",
  "Biology",
  "Chemistry",
  "Computer Science",
  "Islamiat",
  "Pak Studies",
  "Physics",
  "Urdu",
  "Math"
 ],
 "BA/BSc": [
  "English",
  "Urdu",
  "Islamiat",
  "Pak Studies",
  "Math",
  "Physics",
  "Chemistry",
  "Computer Science",
  "Economics",
  "Statistics",
  "Psychology"
 ]
}
CHAPTERS = {
 "9th|Physics": [
  "Physical Quantities and Measurement",
  "Kinematics",
  "Dynamics",
  "Turning Effect of Forces",
  "Gravitation",
  "Work and Energy",
  "Properties of Matter",
  "Thermal Properties of Matter",
  "Transfer of Heat",
  "Numericals: Kinematics and Dynamics",
  "Numericals: Gravitation, Work and Energy",
  "Physics Practicals: Vernier Callipers and Screw Gauge"
 ],
 "9th|Chemistry": [
  "Fundamentals of Chemistry",
  "Structure of Atoms",
  "Periodic Table and Periodicity of Properties",
  "Structure of Molecules",
  "Physical States of Matter",
  "Solutions",
  "Electrochemistry",
  "Chemical Reactivity",
  "Numericals: Mole Concept and Calculations",
  "Periodic Table: Trends and Uses",
  "Chemistry Practicals: 9th"
 ],
 "9th|Biology": [
  "Introduction to Biology",
  "Solving a Biological Problem",
  "Biodiversity",
  "Cells and Tissues",
  "Cell Cycle",
  "Enzymes",
  "Bioenergetics",
  "Nutrition",
  "Transport",
  "Cell Organelles and Their Functions",
  "Biological Diagrams Practice: 9th",
  "Human Body Systems: Overview"
 ],
 "9th|Math": [
  "Matrices and Determinants",
  "Real and Complex Numbers",
  "Logarithms",
  "Algebraic Expressions and Algebraic Formulas",
  "Factorization",
  "Algebraic Manipulation",
  "Linear Equations and Inequalities",
  "Linear Graphs and their Applications",
  "Introduction to Coordinate Geometry",
  "Congruent Triangles",
  "Parallelograms and Triangles",
  "Line Bisectors and Angle Bisectors",
  "Sides and Angles of a Triangle",
  "Ratio and Proportion",
  "Pythagoras Theorem",
  "Theorems Related with Area",
  "Practical Geometry-Triangles",
  "Algebra Formula Sheet",
  "Geometry: Important Theorems List",
  "Board Paper Practice: 9th Math"
 ],
 "9th|English": [
  "The Saviour of Mankind",
  "Patriotism",
  "Media and Its Impact",
  "Hazrat Asma (RA)",
  "Daffodils",
  "The Quaid's Vision and Pakistan",
  "Sultan Ahmad Mosque",
  "Stopping by Woods",
  "All is Not Lost",
  "Drug Addiction",
  "Noise in the Environment",
  "Three Days to See",
  "Grammar: Tenses and Sentence Structure",
  "Grammar: Articles and Prepositions",
  "Grammar: Narration (Direct and Indirect Speech)",
  "Grammar: Parts of Speech",
  "Grammar: Sentence Types",
  "Letter and Application Writing",
  "Story and Paragraph Writing",
  "Comprehension and Summary Writing",
  "Vocabulary: Synonyms, Antonyms and Pair of Words",
  "Grammar: Tenses Practice"
 ],
 "9th|Computer Science": [
  "Introduction to Computer",
  "Computer Memory",
  "Input and Output Devices",
  "System Software and Application Software",
  "Problem Solving",
  "Algorithms and Flowcharts",
  "Introduction to Programming",
  "Boolean Algebra",
  "Data Representation and Number Systems",
  "Computer Networks and Internet",
  "Word Processing: MS Word",
  "Spreadsheets: MS Excel",
  "Presentations: MS PowerPoint",
  "Introduction to Databases",
  "Internet, Email and Web Browsing"
 ],
 "9th|Islamiat": [
  "قرآن مجید کی اہمیت و فضیلت",
  "حدیث نبوی ﷺ کی اہمیت",
  "ایمانیات: توحید و رسالت",
  "عبادات: نماز و روزہ",
  "اخلاق و آداب",
  "سیرت نبوی ﷺ",
  "جہاد فی سبیل اللہ",
  "اسلامی معاشرت",
  "حقوق العباد",
  "امر بالمعروف و نہی عن المنکر",
  "سیرتِ صحابہ کرامؓ: نمایاں شخصیات",
  "روزے کے احکام و فضائل"
 ],
 "9th|Pak Studies": [
  "پاکستان کی نظریاتی بنیادیں",
  "دو قومی نظریہ",
  "تحریکِ پاکستان",
  "قیامِ پاکستان",
  "پاکستان کا محلِ وقوع اور جغرافیہ",
  "پاکستان کی معیشت کا تعارف",
  "آل انڈیا مسلم لیگ کا کردار",
  "پاکستان کی ثقافت اور ورثہ",
  "پاکستان کی زبانیں اور ادب",
  "قیامِ پاکستان کے بعد کے چیلنجز"
 ],
 "9th|Tarjuma-tul-Quran": [
  "تعارفِ قرآن مجید",
  "سورۃ البقرۃ: منتخب آیات",
  "سورۃ آلِ عمران: منتخب آیات",
  "سورۃ النساء: منتخب آیات",
  "سورۃ المائدہ: منتخب آیات",
  "احادیثِ نبوی ﷺ",
  "اخلاقی تعلیمات",
  "قرآنی دعائیں",
  "اسمائے حسنیٰ: تعارف",
  "توحید و آخرت کے قرآنی دلائل"
 ],
 "9th|Urdu": [
  "حمد",
  "نعتِ رسولِ مقبول ﷺ",
  "برسات کی بہاریں",
  "پہلی سیر",
  "ملتِ اسلامیہ کے نوجوان",
  "جنگِ آزادی 1857ء",
  "خطوطِ غالب",
  "ہجرتِ نبوی ﷺ",
  "صحت کے اصول",
  "اردو گرامر: الفاظ کی اقسام",
  "اردو گرامر: قواعد و انشا",
  "تحریر: درخواست اور مضمون",
  "اردو گرامر: محاورات اور ضرب الامثال",
  "اردو گرامر: واحد جمع اور مذکر مونث",
  "اردو گرامر: حروف اور الفاظِ مرکب",
  "تلخیص نویسی",
  "اردو ادب کے اہم ادیب",
  "نظم کا فن"
 ],
 "10th|Physics": [
  "Simple Harmonic Motion and Waves",
  "Sound",
  "Geometrical Optics",
  "Electrostatics",
  "Current Electricity",
  "Electromagnetism",
  "Basic Electronics",
  "Information and Communication Technology",
  "Atomic and Nuclear Physics",
  "Numericals: Electrostatics and Current Electricity",
  "ICT: Email, Internet and E-Commerce",
  "Nuclear Energy and Its Uses",
  "Physics Practicals: Mirrors and Lenses"
 ],
 "10th|Chemistry": [
  "Chemical Equilibrium",
  "Acids, Bases and Salts",
  "Organic Chemistry",
  "Hydrocarbons",
  "Biochemistry",
  "Chemical Industries",
  "Environmental Chemistry",
  "Water: Sources, Quality and Purification",
  "Numericals: Equilibrium, Acids and Salts",
  "Chemistry in Daily Life",
  "Chemistry Practicals: 10th"
 ],
 "10th|Biology": [
  "Gaseous Exchange",
  "Homeostasis",
  "Coordination and Control",
  "Support and Movement",
  "Reproduction",
  "Inheritance",
  "Man and His Environment",
  "Biotechnology",
  "Pharmacology",
  "Human Brain and Senses",
  "Biological Diagrams Practice: 10th",
  "Smoking and Health"
 ],
 "10th|Math": [
  "Quadratic Equations",
  "Theory of Quadratic Equations",
  "Variations",
  "Partial Fractions",
  "Sets and Functions",
  "Basic Statistics",
  "Introduction to Trigonometry",
  "Projection of a Side of a Triangle",
  "Chords of a Circle",
  "Tangent to a Circle",
  "Chords and Arcs",
  "Angle in a Segment of a Circle",
  "Practical Geometry-Circles",
  "Linear Programming",
  "Trigonometry Identities Practice",
  "Geometry Theorems List: Circles",
  "Board Paper Practice: 10th Math",
  "Statistics: Graphical Representation"
 ],
 "10th|English": [
  "Hazrat Muhammad (SAW) - An Embodiment of Justice",
  "Chinese New Year",
  "Try Again",
  "First Aid",
  "The Rain",
  "Peace",
  "Faithfulness",
  "The Great Masjid of Cordoba",
  "A World Without Books",
  "My Bank Account",
  "Grammar: Active/Passive and Reported Speech",
  "Grammar: Conditional Sentences",
  "Grammar: Active and Passive Voice (Advanced)",
  "Grammar: Tenses in Reported Speech",
  "Paragraph and Story Writing",
  "Vocabulary: Pair of Words",
  "Essay Writing Practice",
  "Dialogue Writing"
 ],
 "10th|Computer Science": [
  "Problem Solving Techniques",
  "Introduction to Programming in C",
  "Control Structures",
  "Arrays and Strings",
  "Functions",
  "File Handling",
  "Security, Privacy and Ethics",
  "Data Types, Operators and Expressions",
  "Pointers in C: Introduction",
  "Preprocessor Directives and Header Files",
  "Structures in C",
  "Introduction to C++"
 ],
 "10th|Islamiat": [
  "قرآن مجید: ہدایت کا سرچشمہ",
  "احادیثِ نبوی ﷺ",
  "توحید و رسالت",
  "نماز و روزہ",
  "اخلاقِ نبوی ﷺ",
  "سیرتِ صحابہ کرامؓ",
  "اسلامی نظامِ حکومت",
  "حج و زکوٰۃ",
  "اسلامی معیشت کا تعارف",
  "اسلام میں علم کی اہمیت"
 ],
 "10th|Pak Studies": [
  "قیامِ پاکستان کے بعد کے ابتدائی مسائل",
  "پاکستان کی آئینی تاریخ",
  "پاکستان کی خارجہ پالیسی",
  "پاکستان کی معیشت اور ترقی",
  "پاکستان کے اہم مسائل اور ان کا حل",
  "پاکستان کے قدرتی وسائل",
  "پاکستان میں جمہوریت کا سفر",
  "پاکستان میں تعلیم و صحت"
 ],
 "10th|Tarjuma-tul-Quran": [
  "سورۃ الاعراف: منتخب آیات",
  "سورۃ الانفال: منتخب آیات",
  "سورۃ التوبہ: منتخب آیات",
  "سورۃ یونس: منتخب آیات",
  "سورۃ یوسف: منتخب آیات",
  "احادیث و اخلاقیات",
  "سیرتِ نبوی ﷺ قرآنی آیات کی روشنی میں",
  "قرآنی اخلاقیات: منتخب موضوعات"
 ],
 "10th|Urdu": [
  "حمد",
  "نعت",
  "خطبہ حجۃ الوداع",
  "دلیر",
  "شاہراہِ ریشم",
  "پاکستان کی تعلیم",
  "غزل کا فن",
  "اردو کے اہم شعرا",
  "اردو گرامر",
  "مضمون نویسی",
  "اردو گرامر: تشبیہ، استعارہ اور کنایہ",
  "خط نویسی اور خلاصہ نویسی",
  "اردو افسانہ نگاری کا تعارف",
  "نعت کا فن",
  "اردو گرامر: جملوں کی اقسام"
 ],
 "11th|Physics": [
  "Measurements",
  "Vectors and Equilibrium",
  "Motion and Force",
  "Work and Energy",
  "Circular Motion",
  "Fluid Dynamics",
  "Oscillations",
  "Waves",
  "Physical Optics",
  "Optical Instruments",
  "Heat and Thermodynamics",
  "Numericals: Vectors, Motion and Force",
  "Waves: Doppler Effect and Applications",
  "Physics Practicals: 1st Year"
 ],
 "11th|Chemistry": [
  "Basic Concepts",
  "Experimental Techniques in Chemistry",
  "Gases",
  "Liquids and Solids",
  "Atomic Structure",
  "Chemical Bonding",
  "Thermochemistry",
  "Chemical Equilibrium",
  "Solutions",
  "Electrochemistry",
  "Chemical Kinetics",
  "Numericals: Gases, Liquids and Solutions",
  "Atomic Models: Comparison",
  "Chemistry Practicals: 1st Year"
 ],
 "11th|Biology": [
  "Introduction to Biology",
  "Biological Molecules",
  "Enzymes",
  "The Cell",
  "Variety of Life",
  "Kingdom Prokaryotae",
  "The Kingdom Protista",
  "Fungi",
  "Diversity Among Plants",
  "Nutrition",
  "Gaseous Exchange",
  "Transport",
  "Homeostasis",
  "Support and Movement",
  "Viruses and Bacteria"
 ],
 "11th|Math": [
  "Number System",
  "Sets, Functions and Groups",
  "Matrices and Determinants",
  "Quadratic Equations",
  "Partial Fractions",
  "Sequences and Series",
  "Permutations, Combinations and Probability",
  "Mathematical Induction and Binomial Theorem",
  "Fundamentals of Trigonometry",
  "Trigonometric Identities",
  "Trigonometric Functions and their Graphs",
  "Application of Trigonometry",
  "Inverse Trigonometric Functions",
  "Solutions of Trigonometric Equations",
  "Trigonometry Formula Sheet",
  "Binomial Theorem: Applications",
  "Complex Numbers Practice",
  "Logarithms and Exponents Review"
 ],
 "11th|English": [
  "The Dying Sun",
  "Using the Scientific Method",
  "Why Boys Fail in College",
  "End of Term",
  "On Destroying Books",
  "My Financial Career",
  "China's Way to Progress",
  "Hunger and Population Explosion",
  "The Jewel of the World",
  "First Year at Harrow",
  "Hitch-Hiking Across the Sahara",
  "Luis Pasteur",
  "Mustafa Kamal",
  "A Dialogue",
  "Grammar: Advanced Tenses and Voices",
  "Drug Addiction (Essay 15)",
  "Short Story: Thank You M'am",
  "Short Story: Button Button",
  "Short Story: Dark They Were and Golden Eyed",
  "Short Story: The Piece of String",
  "Short Story: Clearing in the Sky",
  "Poem: The Character of a Happy Life",
  "Poem: Ozymandias",
  "Poem: Departure and Arrival",
  "Poem: In the Street of Fruit Stalls",
  "Poem: Sindhi Woman",
  "Grammar: Punctuation and Capitalization",
  "Essay Writing: 1st Year",
  "Grammar: Articles and Determiners"
 ],
 "11th|Computer Science": [
  "Basics of Information Technology",
  "Information Networks",
  "Data Security, Privacy and Ethics",
  "The System Unit",
  "Programming Concepts",
  "Control Structures in C",
  "Arrays, Strings and Functions",
  "Pointers in C",
  "Structures and Unions in C",
  "File Handling Basics",
  "Introduction to Databases",
  "Number Systems in Computing"
 ],
 "11th|Urdu": [
  "حمد",
  "نعت",
  "ڈپٹی نذیر احمد",
  "غالب کی شخصیت",
  "پریم چند",
  "اردو افسانہ",
  "اردو گرامر: صرف و نحو",
  "انشا پردازی",
  "اردو نثر: سرسید احمد خان",
  "اردو شاعری: میر تقی میر",
  "اردو گرامر: علمِ بیان",
  "اردو ڈرامہ کا تعارف",
  "خطوط نویسی: نمونے",
  "نعت کا فن"
 ],
 "11th|Islamiat": [
  "تعارفِ قرآن و حدیث",
  "ایمان و عمل",
  "عبادات",
  "سیرتِ طیبہ ﷺ",
  "خلفائے راشدینؓ",
  "اسلامی نظامِ حیات",
  "اخلاق و معاشرت",
  "اسلامی قانون کے مصادر: قرآن، سنت، اجماع، قیاس",
  "اسلام اور جدید سائنس",
  "اسلامی تہذیب کا تعارف"
 ],
 "11th|Pak Studies": [
  "نظریۂ پاکستان",
  "تحریکِ پاکستان اور قیامِ پاکستان",
  "پاکستان کی تاریخ 1947 تا حال",
  "پاکستان کا آئین",
  "پاکستان کی معیشت",
  "پاکستان کی خارجہ پالیسی",
  "پاکستان کے مسائل اور ان کا حل",
  "18ویں ترمیم اور صوبائی خودمختاری",
  "پاکستان کی نوجوان نسل اور تعلیم",
  "پاکستان کی خارجہ پالیسی: نئے چیلنجز",
  "پاکستان کی عدلیہ"
 ],
 "12th|Physics": [
  "Electrostatics",
  "Current Electricity",
  "Electromagnetism and Electromagnetic Induction",
  "Alternating Current",
  "Physics of Solids",
  "Electronics",
  "Dawn of Modern Physics",
  "Atomic Spectra",
  "Nuclear Physics",
  "Numericals: Electrostatics and Magnetism",
  "X-Rays: Production and Uses",
  "Physics Practicals: 2nd Year"
 ],
 "12th|Chemistry": [
  "Periodic Classification and Periodicity",
  "s-Block Elements",
  "Group IIIA and IVA Elements",
  "Group VA and VIA Elements",
  "Halogens and Noble Gases",
  "Transition Elements",
  "Fundamental Principles of Organic Chemistry",
  "Aliphatic Hydrocarbons",
  "Aromatic Hydrocarbons",
  "Alkyl Halides",
  "Alcohols, Phenols and Ethers",
  "Aldehydes and Ketones",
  "Carboxylic Acids",
  "Amino Acids and Proteins",
  "Macromolecules",
  "Environmental Chemistry-II",
  "Soaps, Detergents and Cosmetics",
  "Numericals: Organic Reactions and Tests",
  "Chemistry Practicals: 2nd Year"
 ],
 "12th|Biology": [
  "Homeostasis",
  "Coordination and Control",
  "Reproduction",
  "Growth and Development",
  "Chromosomes and DNA",
  "Variations and Genetics",
  "DNA: Chemical Nature",
  "Biotechnology",
  "Evolution",
  "Ecosystem",
  "Man and His Environment",
  "Some Major Ecosystems",
  "Immunity and Vaccines",
  "Biological Diagrams Practice: 12th"
 ],
 "12th|Math": [
  "Functions and Limits",
  "Differentiation",
  "Integration",
  "Introduction to Analytic Geometry",
  "Linear Inequalities and Linear Programming",
  "Conic Section",
  "Vectors",
  "Differentiation Formula Sheet",
  "Integration Techniques Practice",
  "Conic Section: Formula Sheet",
  "Differential Equations: Introduction"
 ],
 "12th|English": [
  "Goodbye Mr Chips - Chapters 1-4",
  "Goodbye Mr Chips - Chapters 5-8",
  "Goodbye Mr Chips - Chapters 9-12",
  "Goodbye Mr Chips - Chapters 13-16",
  "Grammar: Sentence Correction and Synthesis",
  "Short Story: The Necklace",
  "Short Story: The Gulistan of Saadi",
  "Short Story: A Man Who Was a Hospital",
  "Short Story: The Foolish Quack",
  "Poem: The Rebel",
  "Poem: A Dream Within a Dream",
  "Goodbye Mr Chips: Character Sketches",
  "Grammar: Pair of Words (2nd Year)",
  "Summary Writing (2nd Year)"
 ],
 "12th|Computer Science": [
  "Basic Concepts of Programming",
  "Programming in C: Advanced",
  "Subprograms and Recursion",
  "File Handling in C",
  "Database Concepts",
  "Introduction to SQL",
  "E-Commerce and Emerging Technologies",
  "Data Structures: Stacks and Queues",
  "Operating System Concepts",
  "HTML and Web Page Basics",
  "Software Engineering Basics",
  "Cyber Security Basics"
 ],
 "12th|Urdu": [
  "حمد",
  "نعت",
  "اردو ادب کی تاریخ",
  "کلاسیکی شاعری",
  "غزل",
  "نظم",
  "افسانہ",
  "ڈراما",
  "مضمون",
  "اردو گرامر: صنائع بدائع",
  "اردو ادب: ترقی پسند تحریک",
  "اردو گرامر: علمِ عروض کا تعارف",
  "روداد نویسی اور مکتوب نگاری",
  "اردو تنقید کا تعارف",
  "مرثیہ کا فن"
 ],
 "12th|Islamiat": [
  "قرآن مجید کا مطالعہ",
  "حدیث کا مطالعہ",
  "فقہی مسائل",
  "اسلامی تہذیب و ثقافت",
  "سیرتِ نبوی ﷺ: مدنی دور",
  "اسلامی معاشیات",
  "اسلام اور حقوقِ نسواں",
  "اسلامی نظامِ عدل",
  "اسلامی بینکاری کا تعارف",
  "اسلامی معاشرت"
 ],
 "12th|Pak Studies": [
  "نظریۂ پاکستان کا تحفظ",
  "پاکستان کی سیاسی تاریخ",
  "آئینی ارتقا",
  "معاشی چیلنجز",
  "خارجہ پالیسی کے نئے رخ",
  "قومی سلامتی اور دفاع",
  "سی پیک اور معاشی راہداری",
  "پاکستان میں میڈیا کا کردار",
  "پاکستان کی توانائی کی پالیسی",
  "پاکستان کی زراعت"
 ],
 "BA/BSc|English": [
  "Short Stories",
  "One-Act Plays",
  "Poems",
  "Novels",
  "Essays",
  "Grammar: Tenses and Articles",
  "Grammar: Prepositions and Comprehension",
  "Grammar: Narration and Voice",
  "Literary Terms and Devices",
  "Essay Outlines Practice",
  "Translation: Urdu to English"
 ],
 "BA/BSc|Urdu": [
  "نثر: منتخب اسباق",
  "شاعری: غزل",
  "شاعری: نظم",
  "ڈراما",
  "افسانہ",
  "اردو ادب کی تاریخ",
  "گرامر و قواعد",
  "غالب کی شاعری",
  "اقبال کی شاعری",
  "نظم: منتخب اشعار"
 ],
 "BA/BSc|Islamiat": [
  "قرآن مجید کا مطالعہ",
  "حدیث کا مطالعہ",
  "فقہی مسائل",
  "اسلامی تہذیب",
  "سیرتِ نبوی ﷺ",
  "اسلامی معاشیات",
  "اسلامی فقہ کے مذاہب",
  "تصوف کا تعارف"
 ],
 "BA/BSc|Pak Studies": [
  "نظریۂ پاکستان",
  "تحریکِ پاکستان",
  "قیامِ پاکستان کے بعد کے ادوار",
  "آئینی تاریخ",
  "معاشی ترقی",
  "خارجہ پالیسی",
  "1973 کا آئین: نمایاں خصوصیات",
  "خارجہ پالیسی کے اصول"
 ],
 "BA/BSc|Math": [
  "Calculus: Limits and Continuity",
  "Differentiation",
  "Integration",
  "Matrices and Linear Algebra",
  "Differential Equations",
  "Statistics",
  "Probability",
  "Vector Calculus: Introduction",
  "Laplace Transforms",
  "Linear Algebra: Eigenvalues"
 ],
 "BA/BSc|Physics": [
  "Mechanics",
  "Waves and Oscillations",
  "Thermodynamics",
  "Electromagnetism",
  "Modern Physics",
  "Electronics",
  "Quantum Physics: Introduction",
  "Geometrical Optics",
  "Nuclear Physics: Introduction"
 ],
 "BA/BSc|Chemistry": [
  "Physical Chemistry",
  "Inorganic Chemistry",
  "Organic Chemistry",
  "Analytical Chemistry",
  "Biochemistry",
  "Chemical Thermodynamics",
  "Coordination Chemistry"
 ],
 "BA/BSc|Computer Science": [
  "Programming Fundamentals",
  "Database Management Systems",
  "Computer Networks: Basics"
 ],
 "BA/BSc|Economics": [
  "Introduction to Economics"
 ],
 "BA/BSc|Statistics": [
  "Descriptive Statistics"
 ],
 "BA/BSc|Psychology": [
  "Introduction to Psychology"
 ]
}
NOTES = {
 "9th|Physics|Physical Quantities and Measurement": [
  "Base quantities: length (m), mass (kg), time (s), current (A), temperature (K), amount of substance (mol), luminous intensity (cd).",
  "Derived quantities are combinations of base quantities, e.g. speed = distance/time with unit m/s.",
  "Prefixes: kilo (10^3), mega (10^6), milli (10^-3), micro (10^-6), nano (10^-9).",
  "Least count = smallest value an instrument can measure; e.g. vernier calipers have least count 0.01 cm.",
  "Scientific notation: M x 10^n where 1 <= M < 10; used for very large and very small numbers."
 ],
 "9th|Physics|Kinematics": [
  "Rest vs motion: a body is in motion if its position changes with time relative to a reference point.",
  "Distance is scalar (total path"
 ],
 "9th|Physics|Dynamics": [
  "Newton's 1st law (inertia): a body stays at rest or uniform motion unless a net external force acts on it.",
  "Newton's 2nd law: F = ma; unit of force is newton (N) = kg.m/s^2.",
  "Newton's 3rd law: every action has an equal and opposite reaction.",
  "Momentum p = mv; force equals the rate of change of momentum.",
  "Friction opposes relative motion; types are static and kinetic; reduced by lubrication and ball bearings."
 ],
 "9th|Physics|Turning Effect of Forces": [
  "Torque (moment of force) = force x perpendicular distance; unit is N.m.",
  "Couple: two equal, opposite, parallel forces; moment of couple = force x distance between them.",
  "Equilibrium: sum of forces = 0 (translational) and sum of torques = 0 (rotational).",
  "Centre of gravity: the point where the whole weight of a body appears to act.",
  "Stability depends on base width and height of centre of gravity; wider base and lower CG = more stable."
 ],
 "9th|Physics|Gravitation": [
  "Newton's law: F = G.m1.m2/r^2; universal constant G = 6.673 x 10^-11 N.m^2/kg^2.",
  "Mass is the amount of matter (constant everywhere"
 ],
 "9th|Physics|Work and Energy": [
  "Work W = F.d (force times displacement in the direction of force"
 ],
 "9th|Physics|Properties of Matter": [
  "Density = mass/volume; unit kg/m^3; relative density has no unit.",
  "Pressure P = F/A; unit is pascal (Pa"
 ],
 "9th|Physics|Thermal Properties of Matter": [
  "Temperature is the degree of hotness or coldness; scales: Celsius, Fahrenheit, Kelvin (K = C + 273).",
  "Heat is energy transferred due to temperature difference; its unit is the joule.",
  "Specific heat capacity c = Q/(m.DeltaT"
 ],
 "9th|Physics|Transfer of Heat": [
  "Conduction: heat transfer through solids by molecular vibration; metals are good conductors.",
  "Convection: heat transfer in fluids by actual movement of particles; causes land and sea breezes.",
  "Radiation: transfer by electromagnetic waves; needs no medium; black surfaces radiate best.",
  "Greenhouse effect: glass traps infrared radiation and warms the interior.",
  "Thermos flask uses a vacuum and silvered walls to minimize all three modes of transfer."
 ],
 "9th|Chemistry|Fundamentals of Chemistry": [
  "Atom: smallest particle of an element retaining its properties; molecule: two or more atoms chemically bonded.",
  "Atomic number (Z) = number of protons; mass number (A) = protons + neutrons.",
  "Empirical formula: simplest whole-number ratio of atoms; molecular formula: actual number of atoms.",
  "Mole = 6.022 x 10^23 particles (Avogadro's number"
 ],
 "9th|Chemistry|Structure of Atoms": [
  "Rutherford's model: atom has a dense positive nucleus with electrons revolving around it.",
  "Bohr's model: electrons revolve in fixed energy shells K, L, M, N.",
  "Electronic configuration follows the 2, 8, 8 rule, e.g. sodium is 2, 8, 1.",
  "Isotopes: same atomic number, different neutrons (e.g. C-12, C-14"
 ],
 "9th|Chemistry|Periodic Table and Periodicity of Properties": [
  "Mendeleev arranged elements by atomic mass; the modern table arranges them by atomic number.",
  "Groups are vertical columns (1-18"
 ],
 "9th|Chemistry|Structure of Molecules": [
  "Ionic bond: transfer of electrons (NaCl"
 ],
 "9th|Chemistry|Physical States of Matter": [
  "Kinetic molecular theory: particles are in constant random motion; gas particles have negligible attraction.",
  "Boyle's law: P1V1 = P2V2 at constant temperature; Charles's law: V1/T1 = V2/T2.",
  "Diffusion: intermixing of gases; rate depends on molecular mass (Graham's law).",
  "Plasma is the fourth state of matter at very high temperature, found in the sun and stars.",
  "Allotropy: same element in different forms, e.g. diamond and graphite for carbon."
 ],
 "9th|Chemistry|Solutions": [
  "Solution = solute + solvent; types by concentration: dilute, concentrated, saturated, unsaturated, supersaturated.",
  "Solubility: maximum solute dissolved at a given temperature; for most solids it increases with temperature.",
  "Molarity M = moles of solute / litres of solution.",
  "Colloids are heterogeneous mixtures with particles between true solutions and suspensions, e.g. milk.",
  "Percentage solutions are expressed as % w/w, % w/v or % v/v."
 ],
 "9th|Chemistry|Electrochemistry": [
  "Oxidation = loss of electrons (increase in oxidation number"
 ],
 "9th|Chemistry|Chemical Reactivity": [
  "Reactivity series: K > Na > Ca > Mg > Al > Zn > Fe > Pb > Cu > Hg > Ag > Au.",
  "Metals react with oxygen to form basic oxides; non-metals form acidic oxides.",
  "Noble metals (gold, platinum) are least reactive and resist corrosion.",
  "Displacement reaction: a more reactive metal displaces a less reactive metal from its salt.",
  "Corrosion: slow oxidation of metals; rusting of iron needs both air and moisture."
 ],
 "9th|Biology|Introduction to Biology": [
  "Biology is the study of living organisms; branches include zoology (animals), botany (plants), microbiology, genetics and ecology.",
  "Levels of organization: cell -> tissue -> organ -> organ system -> organism -> population -> community.",
  "Cellular organization: unicellular (Amoeba) vs multicellular (human).",
  "Modern fields: biotechnology, bioinformatics and genetic engineering.",
  "Careers in biology: medicine, agriculture, fisheries, horticulture and wildlife conservation."
 ],
 "9th|Biology|Solving a Biological Problem": [
  "Steps of the scientific method: observation -> hypothesis -> deduction -> experimentation -> theory.",
  "Biological method applied to malaria: Plasmodium is the cause, transmitted by the female Anopheles mosquito.",
  "Quantitative observations use numbers; qualitative observations use descriptions.",
  "Control group vs experimental group: only one variable differs between them.",
  "Theory: a hypothesis repeatedly tested and never disproved, e.g. the germ theory of disease."
 ],
 "9th|Biology|Biodiversity": [
  "Biodiversity: variety of life forms; species: a group of interbreeding organisms producing fertile offspring.",
  "Classification (taxonomy) was developed by Linnaeus; binomial nomenclature: Genus species, e.g. Homo sapiens.",
  "Taxonomic hierarchy: kingdom -> phylum -> class -> order -> family -> genus -> species.",
  "Five kingdoms: Monera, Protista, Fungi, Plantae, Animalia.",
  "Conservation: national parks and wildlife sanctuaries protect endangered species."
 ],
 "9th|Biology|Cells and Tissues": [
  "Cell theory (Schleiden, Schwann, Virchow): all organisms are made of cells; the cell is the basic unit of life.",
  "Plant cells have a cell wall, chloroplasts and a large vacuole; animal cells lack these.",
  "Organelles: mitochondria (energy/ATP), ribosomes (protein synthesis), nucleus (control centre).",
  "Tissue: similar cells performing a function; plant tissues: meristematic and permanent; animal tissues: epithelial, muscular, nervous, connective.",
  "Compound microscope uses two lenses; total magnification = objective x eyepiece."
 ],
 "9th|Biology|Cell Cycle": [
  "Interphase (G1, S, G2): the cell grows and replicates its DNA; it is the longest phase.",
  "Mitosis stages: prophase -> metaphase -> anaphase -> telophase (remember PMAT).",
  "Mitosis produces 2 identical diploid cells; it is used for growth and repair.",
  "Meiosis produces 4 haploid cells, occurs in gamete formation and introduces variation.",
  "Cytokinesis: division of the cytoplasm after nuclear division."
 ],
 "9th|Biology|Enzymes": [
  "Enzymes are biological catalysts made of protein; they speed up reactions without being consumed.",
  "Lock-and-key model: the substrate fits into the active site like a key.",
  "Factors: temperature (optimum about 37 C), pH (pepsin about 2, trypsin about 7.5), substrate concentration.",
  "Denaturation: high temperature or extreme pH destroys the enzyme's shape and function.",
  "Uses: biological washing powders, cheese making and the brewing industry."
 ],
 "9th|Biology|Bioenergetics": [
  "Photosynthesis: 6CO2 + 6H2O -> C6H12O6 + 6O2, carried out in chlorophyll using light energy.",
  "Limiting factors of photosynthesis: light intensity, CO2 concentration and temperature.",
  "Aerobic respiration: C6H12O6 + 6O2 -> 6CO2 + 6H2O + energy (ATP"
 ],
 "9th|Biology|Nutrition": [
  "Autotrophs make their own food (plants"
 ],
 "9th|Biology|Transport": [
  "In plants, xylem transports water and minerals upward; phloem transports food (translocation).",
  "Transpiration: loss of water vapour from leaves; it creates the transpiration pull.",
  "Human heart: double circulation; the right side pumps to the lungs, the left side to the body.",
  "Blood: RBC carry oxygen via haemoglobin, WBC defend the body, platelets help clotting, plasma transports materials.",
  "Blood pressure is recorded as systolic/diastolic; hypertension is a risk factor for heart disease."
 ],
 "9th|Math|Matrices and Determinants": [
  "Matrix: rectangular array of numbers in rows and columns; order is m x n.",
  "Types: row, column, square, diagonal, scalar, identity and zero matrices.",
  "Addition/subtraction only for same order; multiplication needs columns of first = rows of second.",
  "Determinant of 2x2 matrix [a b; c d] = ad - bc; a singular matrix has determinant zero.",
  "Inverse: A^-1 = adj(A)/|A|; it exists only when |A| is not zero."
 ],
 "9th|Math|Real and Complex Numbers": [
  "Real numbers = rational + irrational numbers; every real number has a place on the number line.",
  "Complex number: a + bi where i^2 = -1; a is the real part, b the imaginary part.",
  "Add/subtract: combine real parts together and imaginary parts together.",
  "Conjugate of a+bi is a-bi; (a+bi)(a-bi) = a^2 + b^2.",
  "Laws of exponents: a^m . a^n = a^(m+n"
 ],
 "9th|Math|Logarithms": [
  "If a^x = y then log_a y = x; common log uses base 10, natural log uses base e.",
  "Laws: log(mn) = log m + log n; log(m/n) = log m - log n; log m^n = n log m.",
  "log 1 = 0 and log 10 = 1 (base 10).",
  "A logarithm has two parts: characteristic and mantissa, read from log tables.",
  "Antilog reverses the logarithm to recover the original number."
 ],
 "9th|Math|Algebraic Expressions and Algebraic Formulas": [
  "(a+b)^2 = a^2 + 2ab + b^2; (a-b)^2 = a^2 - 2ab + b^2.",
  "a^2 - b^2 = (a+b)(a-b).",
  "(a+b)^3 = a^3 + 3a^2b + 3ab^2 + b^3; (a-b)^3 = a^3 - 3a^2b + 3ab^2 - b^3.",
  "a^3 + b^3 = (a+b)(a^2 - ab + b^2"
 ],
 "9th|Math|Factorization": [
  "Always take out the greatest common factor first.",
  "Difference of squares: a^2 - b^2 = (a-b)(a+b).",
  "Trinomial x^2 + bx + c: find two numbers with product c and sum b.",
  "Use sum/difference of cubes formulas where applicable.",
  "Grouping method: group terms that share common factors."
 ],
 "9th|Math|Algebraic Manipulation": [
  "LCM of expressions: product of the highest powers of all factors; HCF: product of the lowest powers of common factors.",
  "Simplify rational expressions by factoring first, then cancelling common factors.",
  "Square root of an algebraic expression can be found by factorization.",
  "Rationalize by multiplying numerator and denominator by the conjugate.",
  "Check answers by substituting a simple value for the variable."
 ],
 "9th|Math|Linear Equations and Inequalities": [
  "Linear equation in one variable: ax + b = 0 gives x = -b/a.",
  "Two variables: solve by elimination or substitution.",
  "Absolute value: |x| = a gives x = +a or x = -a.",
  "Inequalities: the sign reverses when multiplying or dividing by a negative number.",
  "Show the solution set of an inequality on the number line."
 ],
 "9th|Math|Linear Graphs and their Applications": [
  "y = mx + c: m is the slope, c is the y-intercept.",
  "Slope = (y2-y1)/(x2-x1"
 ],
 "9th|Math|Introduction to Coordinate Geometry": [
  "Cartesian plane: x-axis is horizontal, y-axis is vertical; origin is (0,0).",
  "Quadrants: signs of (x,y) are (+,+), (-,+), (-,-), (+,-).",
  "Use the distance and midpoint formulas to solve geometry problems.",
  "Collinear points: slopes between pairs of points are equal.",
  "A median of a triangle joins a vertex to the midpoint of the opposite side."
 ],
 "9th|Math|Congruent Triangles": [
  "Congruence conditions: SSS, SAS, ASA and RHS.",
  "Corresponding parts of congruent triangles are equal (CPCT).",
  "Isosceles triangle: angles opposite equal sides are equal.",
  "Equilateral triangle: all sides equal and every angle 60 degrees.",
  "In proofs, mark the given data on the diagram before starting."
 ],
 "9th|Math|Parallelograms and Triangles": [
  "Parallelogram: opposite sides parallel and equal; diagonals bisect each other.",
  "Rectangle, rhombus and square are special parallelograms.",
  "Area of parallelogram = base x height; area of triangle = 1/2 x base x height.",
  "Triangles on the same base and between the same parallels have equal area.",
  "A median divides a triangle into two triangles of equal area."
 ],
 "9th|Math|Line Bisectors and Angle Bisectors": [
  "Perpendicular bisector: any point on it is equidistant from the segment's endpoints.",
  "Angle bisector: any point on it is equidistant from the arms of the angle.",
  "The three angle bisectors of a triangle meet at the incenter.",
  "The three perpendicular bisectors meet at the circumcenter.",
  "Construct with a compass: draw intersecting arcs from the endpoints."
 ],
 "9th|Math|Sides and Angles of a Triangle": [
  "The longer side is opposite the greater angle.",
  "Triangle inequality: the sum of any two sides is greater than the third side.",
  "Exterior angle = sum of the two opposite interior angles.",
  "Angle sum of a triangle = 180 degrees.",
  "In a right triangle, the hypotenuse is the longest side."
 ],
 "9th|Math|Ratio and Proportion": [
  "Ratio a:b compares two quantities of the same kind; write it in simplest form by dividing by the HCF.",
  "Proportion a:b :: c:d means ad = bc (cross product).",
  "Continued proportion a:b :: b:c gives b^2 = ac.",
  "Rules: componendo, dividendo, and componendo-dividendo.",
  "Apply direct and inverse proportion carefully in word problems."
 ],
 "9th|Math|Pythagoras Theorem": [
  "In a right triangle: hypotenuse^2 = base^2 + perpendicular^2.",
  "Converse: if a^2 + b^2 = c^2, the triangle is right-angled.",
  "Pythagorean triplets: (3,4,5), (5,12,13), (8,15,17).",
  "Used to find the diagonal of a rectangle or the height of an isosceles triangle.",
  "The distance formula is Pythagoras applied to the coordinate plane."
 ],
 "9th|Math|Theorems Related with Area": [
  "Parallelograms on the same base and between the same parallels are equal in area.",
  "Triangles on the same base and between the same parallels are equal in area.",
  "Area of a triangle = 1/2 the area of a parallelogram on the same base and between the same parallels.",
  "Altitude: the perpendicular drawn from a vertex to the opposite side.",
  "Exam problems often combine area theorems with congruence results."
 ],
 "9th|Math|Practical Geometry-Triangles": [
  "Construct a triangle given: SSS, SAS, ASA or RHS.",
  "Constructions use only compass and straightedge; no protractor for making angles.",
  "60 degrees: equilateral-triangle arc method; 90 degrees: perpendicular bisector method.",
  "Circumscribed circle passes through all vertices; inscribed circle touches all sides.",
  "Write the construction steps in proper order in the exam."
 ],
 "9th|English|The Saviour of Mankind": [
  "Theme: the Holy Prophet (peace be upon him) as a mercy and guide for all mankind.",
  "Key vocabulary: saviour, mankind, compassion, justice, mercy.",
  "Grammar focus: present simple tense and basic sentence structure.",
  "Moral: character-building, honesty and kindness in daily life."
 ],
 "9th|English|Patriotism": [
  "Theme: love for one's country and the duties of a good citizen.",
  "Key vocabulary: patriotism, sacrifice, nation, loyalty, devotion.",
  "Learn to write a paragraph on 'My Country' using ideas from the lesson.",
  "Grammar focus: adjectives of nationality and possessive pronouns."
 ],
 "9th|English|Media and Its Impact": [
  "Theme: role of print and electronic media in modern society.",
  "Key vocabulary: media, impact, broadcast, awareness, influence.",
  "Discuss both positive effects (awareness) and negative effects (misinformation).",
  "Practice: write arguments for and against social media."
 ],
 "9th|English|Hazrat Asma (RA)": [
  "Theme: the bravery and sacrifice of Hazrat Asma (RA), daughter of Hazrat Abu Bakr (RA).",
  "Key vocabulary: courage, sacrifice, migration, trust, devotion.",
  "Historical background: the Hijrah of the Holy Prophet (peace be upon him) to Madinah.",
  "Learn short question answers about her services during the Hijrah."
 ],
 "9th|English|Daffodils": [
  "Poem by William Wordsworth about the beauty of nature.",
  "Key images: golden daffodils dancing beside the lake, like stars in the sky.",
  "Poetic devices: simile (like stars), personification (dancing flowers).",
  "Theme: nature gives lasting joy and comfort to the human heart."
 ],
 "9th|English|The Quaid's Vision and Pakistan": [
  "Theme: Quaid-e-Azam's vision of a democratic, just and tolerant Pakistan.",
  "Key vocabulary: vision, democracy, tolerance, unity, discipline.",
  "Famous quote: 'Unity, Faith and Discipline' - learn its meaning.",
  "Practice: write a speech on the Quaid's message to the youth."
 ],
 "9th|English|Sultan Ahmad Mosque": [
  "Theme: description of the famous Blue Mosque in Istanbul, Turkey.",
  "Key vocabulary: mosque, architecture, dome, minaret, heritage.",
  "Descriptive writing: learn how places are described with adjectives.",
  "Grammar focus: prepositions of place (in, on, at, near)."
 ],
 "9th|English|Stopping by Woods": [
  "Poem by Robert Frost about a traveller pausing to watch snowfall in woods.",
  "Famous lines: 'Miles to go before I sleep' - duties before rest.",
  "Poetic devices: imagery (snow, woods), repetition, rhyme scheme.",
  "Theme: attraction of nature vs responsibilities of life."
 ],
 "9th|English|All is Not Lost": [
  "Theme: hope and courage in difficult times; never give up.",
  "Key vocabulary: hope, despair, courage, struggle, success.",
  "Learn to write a story or paragraph on 'Never Give Up'.",
  "Grammar focus: modal verbs (can, should, must) for advice."
 ],
 "9th|English|Drug Addiction": [
  "Theme: dangers of drug addiction for health, family and society.",
  "Key vocabulary: addiction, harmful, rehabilitation, awareness, crime.",
  "Causes: bad company, stress, curiosity; solution: awareness and treatment.",
  "Practice: write a paragraph on 'Say No to Drugs'."
 ],
 "9th|English|Noise in the Environment": [
  "Theme: noise pollution, its causes and harmful effects on health.",
  "Key vocabulary: pollution, noise, harmful, peaceful, environment.",
  "Sources: traffic, factories, loudspeakers; effects: hearing loss, stress.",
  "Practice: write a letter suggesting steps to reduce noise pollution."
 ],
 "9th|English|Three Days to See": [
  "By Helen Keller: what she would do if she could see for three days.",
  "Theme: we should value the blessings we take for granted.",
  "Key vocabulary: sight, blessing, appreciate, senses, gratitude.",
  "Learn summary writing from this deeply moving essay."
 ],
 "9th|English|Grammar: Tenses and Sentence Structure": [
  "Present simple: habits and facts (He goes to school daily). Past simple: completed actions (She wrote a letter).",
  "Future simple: will/shall for promises and plans.",
  "Active vs passive voice: 'He wrote a letter' vs 'A letter was written by him'.",
  "Direct vs indirect speech: change of tense, pronouns and time words.",
  "Practice: translate Urdu sentences into correct English tenses daily."
 ],
 "9th|Computer Science|Introduction to Computer": [
  "Computer: an electronic device that processes data into information; works on the IPO cycle (Input-Process-Output).",
  "Generations: 1st (vacuum tubes) to 5th (AI"
 ],
 "9th|Computer Science|Computer Memory": [
  "Bit: smallest unit (0 or 1"
 ],
 "9th|Computer Science|Input and Output Devices": [
  "Input devices: keyboard, mouse, scanner, microphone, webcam, joystick.",
  "Output devices: monitor, printer, speaker, projector.",
  "Printers: impact (dot matrix) vs non-impact (inkjet, laser).",
  "Monitor types: LCD, LED; resolution measured in pixels.",
  "Some devices are both input and output, e.g. touchscreen and modem."
 ],
 "9th|Computer Science|System Software and Application Software": [
  "System software manages hardware: operating system, device drivers, utilities.",
  "Application software performs user tasks: MS Word, browsers, games.",
  "Operating system functions: memory, process, file and device management.",
  "Examples of OS: Windows, Linux, macOS, Android.",
  "Compiler translates the whole program at once; interpreter translates line by line."
 ],
 "9th|Computer Science|Problem Solving": [
  "Steps: understand the problem -> plan -> design algorithm -> code -> test -> document.",
  "Program: a set of instructions written in a programming language.",
  "Bugs: errors in a program; debugging is the process of removing them.",
  "Types of errors: syntax, logical and runtime errors.",
  "A good program is correct, efficient and easy to understand."
 ],
 "9th|Computer Science|Algorithms and Flowcharts": [
  "Algorithm: step-by-step procedure to solve a problem; must be finite and unambiguous.",
  "Flowchart symbols: oval (start/stop), parallelogram (input/output), rectangle (process), diamond (decision).",
  "Pseudocode: algorithm written in simple English-like statements.",
  "Draw a flowchart to find the largest of three numbers as practice.",
  "Test the algorithm with sample data (dry run) before coding."
 ],
 "9th|Computer Science|Introduction to Programming": [
  "Programming languages: machine, assembly, high-level (C, Python, Java).",
  "BASIC/C basics: variables store data; data types: integer, float, character.",
  "Input/output statements take data from the user and display results.",
  "Operators: arithmetic (+,-,*,/), relational (>,<,==), logical (AND, OR, NOT).",
  "Write simple programs: sum of two numbers, area of a circle."
 ],
 "9th|Computer Science|Boolean Algebra": [
  "Boolean values: true (1) and false (0"
 ],
 "9th|Islamiat|قرآن مجید کی اہمیت و فضیلت": [
  "قرآن مجید اللہ تعالیٰ کی آخری کتاب ہے جو حضرت محمد ﷺ پر نازل ہوئی۔",
  "یہ ہدایت، رحمت اور شفا ہے؛ اس کی تلاوت پر ہر حرف کے بدلے دس نیکیاں ملتی ہیں۔",
  "قرآن مجید 23 سال کے عرصے میں مکہ اور مدینہ میں نازل ہوا۔",
  "حفاظتِ قرآن کا وعدہ خود اللہ تعالیٰ نے کیا: 'بے شک ہم نے ہی ذکر نازل کیا اور ہم ہی اس کی حفاظت کرنے والے ہیں'۔"
 ],
 "9th|Islamiat|حدیث نبوی ﷺ کی اہمیت": [
  "حدیث: حضور ﷺ کے قول، فعل اور تقریر کو کہتے ہیں؛ یہ قرآن کی تشریح ہے۔",
  "سنت پر عمل کرنا ہر مسلمان پر لازم ہے؛ اطاعتِ رسول ﷺ دراصل اطاعتِ الٰہی ہے۔",
  "کتبِ حدیث میں صحیح بخاری اور صحیح مسلم کو سب سے زیادہ مستند مانا جاتا ہے۔",
  "حدیث سے نماز، روزہ، حج اور زکوٰۃ کے عملی طریقے معلوم ہوتے ہیں۔"
 ],
 "9th|Islamiat|ایمانیات: توحید و رسالت": [
  "توحید: اللہ تعالیٰ کو ذات، صفات اور عبادت میں یکتا ماننا اسلام کی بنیاد ہے۔",
  "شرک سب سے بڑا گناہ ہے جسے اللہ تعالیٰ معاف نہیں فرماتا۔",
  "رسالت: حضرت محمد ﷺ آخری نبی ہیں؛ آپ ﷺ کے بعد کوئی نبی نہیں آئے گا (ختمِ نبوت)۔",
  "ایمانِ مفصل: اللہ، فرشتوں، کتابوں، رسولوں، قیامت اور تقدیر پر ایمان۔"
 ],
 "9th|Islamiat|عبادات: نماز و روزہ": [
  "نماز دین کا ستون ہے؛ روزانہ پانچ وقت کی نماز فرض ہے۔",
  "نماز بے حیائی اور برے کاموں سے روکتی ہے۔",
  "روزہ رمضان المبارک میں فرض ہے؛ یہ تقویٰ پیدا کرتا ہے اور صبر سکھاتا ہے۔",
  "زکوٰۃ مال کو پاک کرتی ہے اور حج صاحبِ استطاعت پر زندگی میں ایک بار فرض ہے۔"
 ],
 "9th|Islamiat|اخلاق و آداب": [
  "حضور ﷺ نے فرمایا: 'تم میں سے بہتر وہ ہے جس کے اخلاق سب سے اچھے ہوں'۔",
  "سچ بولنا، وعدہ پورا کرنا اور امانت میں خیانت نہ کرنا مومن کی نشانیاں ہیں۔",
  "والدین کی خدمت، بڑوں کا ادب اور چھوٹوں پر شفقت اسلامی اخلاق ہیں۔",
  "غیبت، چغلی، حسد اور تکبر سے بچنا ہر مسلمان کا فرض ہے۔"
 ],
 "9th|Islamiat|سیرت نبوی ﷺ": [
  "حضور ﷺ 571ء میں مکہ مکرمہ میں پیدا ہوئے؛ والد کا نام عبداللہ اور والدہ کا نام آمنہ تھا۔",
  "40 سال کی عمر میں غارِ حرا میں پہلی وحی نازل ہوئی۔",
  "13 سال مکہ میں تبلیغ کے بعد 622ء میں مدینہ منورہ ہجرت فرمائی۔",
  "اخلاقِ نبوی ﷺ: صادق و امین کا لقب، عفو و درگزر، یتیموں اور مسکینوں سے محبت۔"
 ],
 "9th|Islamiat|جہاد فی سبیل اللہ": [
  "جہاد کے لغوی معنی کوشش کرنا ہیں؛ اصطلاحاً اللہ کی راہ میں ہر قسم کی کوشش جہاد ہے۔",
  "جہاد کی اقسام: جہاد بالنفس، جہاد بالمال، جہاد بالعلم اور جہاد بالسیف۔",
  "جہاد کا مقصد ظلم کا خاتمہ اور امن کا قیام ہے، نہ کہ زبردستی مذہب پھیلانا۔",
  "شہید کا مرتبہ بہت بلند ہے؛ شہداء زندہ ہیں اور ان کے رب کے پاس رزق پاتے ہیں۔"
 ],
 "9th|Islamiat|اسلامی معاشرت": [
  "اسلامی معاشرت عدل، اخوت اور مساوات پر قائم ہے۔",
  "پڑوسیوں کے حقوق: ان کی خبر گیری، تکلیف نہ پہنچانا اور مشکل میں مدد کرنا۔",
  "اسلام میں عورت کو ماں، بیوی، بیٹی اور بہن ہر حیثیت میں عزت و حقوق دیے گئے ہیں۔",
  "صفائی نصف ایمان ہے؛ پاکیزگی جسمانی اور روحانی دونوں طرح ضروری ہے۔"
 ],
 "9th|Pak Studies|پاکستان کی نظریاتی بنیادیں": [
  "نظریہ پاکستان کی بنیاد اسلام ہے؛ مسلمان ایک الگ قوم ہیں۔",
  "قرآن و سنت مسلمانوں کے لیے ضابطۂ حیات ہیں۔",
  "دو قومی نظریہ کے مطابق ہندو اور مسلمان دو الگ قومیں ہیں۔",
  "علامہ اقبال نے 1930ء میں الہ آباد کے خطبے میں الگ وطن کا تصور پیش کیا۔"
 ],
 "9th|Pak Studies|دو قومی نظریہ": [
  "دو قومی نظریہ: برصغیر کے مسلمان اور ہندو مذہب، تہذیب اور روایات میں الگ قومیں ہیں۔",
  "سر سید احمد خان نے اردو ہندی تنازعے کے بعد دو قومی نظریے کی بنیاد رکھی۔",
  "اس نظریے کے مطابق مسلمانوں کو اپنے مذہبی، سیاسی اور معاشی حقوق کے تحفظ کے لیے الگ وطن چاہیے تھا۔",
  "قراردادِ پاکستان 1940ء اسی نظریے کا عملی اظہار تھی۔"
 ],
 "9th|Pak Studies|تحریکِ پاکستان": [
  "آل انڈیا مسلم لیگ 1906ء میں ڈھاکہ میں قائم ہوئی۔",
  "قراردادِ پاکستان 23 مارچ 1940ء کو لاہور میں منظور ہوئی۔",
  "قائداعظم محمد علی جناح نے مسلمانوں کی قیادت کی اور بابائے قوم کہلائے۔",
  "1945-46 کے انتخابات میں مسلم لیگ کی کامیابی نے پاکستان کے قیام کی راہ ہموار کی۔"
 ],
 "9th|Pak Studies|قیامِ پاکستان": [
  "پاکستان 14 اگست 1947ء کو معرضِ وجود میں آیا۔",
  "ابتدائی مسائل: مہاجرین کی آبادکاری، اثاثوں کی تقسیم، نہری پانی کا تنازعہ۔",
  "قائداعظم پہلے گورنر جنرل اور لیاقت علی خان پہلے وزیراعظم بنے۔",
  "کراچی کو پہلا دارالحکومت بنایا گیا۔"
 ],
 "9th|Pak Studies|پاکستان کا محلِ وقوع اور جغرافیہ": [
  "پاکستان جنوبی ایشیا میں واقع ہے؛ رقبہ تقریباً 796,096 مربع کلومیٹر ہے۔",
  "چار صوبے: پنجاب، سندھ، خیبر پختونخوا، بلوچستان؛ علاوہ ازیں گلگت بلتستان اور آزاد کشمیر۔",
  "اہم دریا: سندھ، جہلم، چناب، راوی، بیاس، ستلج۔",
  "آب و ہوا: گرم مرطوب سے لے کر سرد خشک تک؛ مون سون کی بارشیں زراعت کے لیے اہم ہیں۔"
 ],
 "9th|Pak Studies|پاکستان کی معیشت کا تعارف": [
  "پاکستان کی معیشت زراعت پر مبنی ہے؛ گندم، چاول، کپاس اور گنا اہم فصلیں ہیں۔",
  "صنعتیں: ٹیکسٹائل سب سے بڑی صنعت ہے؛ علاوہ ازیں چینی، سیمنٹ اور کھاد کی صنعتیں۔",
  "اہم معدنیات: کوئلہ، قدرتی گیس، تیل، نمک اور جپسم۔",
  "بیرونِ ملک پاکستانیوں کی ترسیلاتِ زر معیشت میں اہم کردار ادا کرتی ہیں۔"
 ],
 "9th|Tarjuma-tul-Quran|تعارفِ قرآن مجید": [
  "قرآن مجید اللہ کی آخری الہامی کتاب ہے جو 23 سال میں نازل ہوئی۔",
  "مکی سورتیں عقائد اور آخرت پر زور دیتی ہیں؛ مدنی سورتیں احکام اور معاشرت پر۔",
  "قرآن مجید میں 114 سورتیں اور 6236 آیات ہیں۔",
  "تلاوت کے آداب: وضو، قبلہ رخ بیٹھنا، ترتیل سے پڑھنا اور غور و فکر کرنا۔"
 ],
 "9th|Tarjuma-tul-Quran|سورۃ البقرۃ: منتخب آیات": [
  "آیت الکرسی (آیت 255): اللہ کی وحدانیت اور قدرت کی عظیم ترین آیت۔",
  "ایمان والوں کی صفات: غیب پر ایمان، نماز قائم کرنا اور اللہ کی راہ میں خرچ کرنا۔",
  "روزے کا حکم اور اس کی حکمتیں بیان ہوئی ہیں۔",
  "سود کی حرمت اور تجارت کے احکام واضح کیے گئے ہیں۔"
 ],
 "9th|Tarjuma-tul-Quran|سورۃ آلِ عمران: منتخب آیات": [
  "اہلِ کتاب سے مناظرے اور دعوتِ توحید کا بیان۔",
  "غزوۂ احد کے واقعات سے صبر اور استقامت کا درس۔",
  "اتحاد و اتفاق کی تلقین: 'اللہ کی رسی کو مضبوطی سے تھام لو'۔",
  "شہداء کے بلند مرتبے کا ذکر۔"
 ],
 "9th|Tarjuma-tul-Quran|سورۃ النساء: منتخب آیات": [
  "عورتوں کے حقوق: مہر، وراثت اور حسنِ سلوک کے احکام۔",
  "یتیموں کے مال کی حفاظت کی تاکید۔",
  "عدل و انصاف قائم کرنے کا حکم، خواہ اپنے خلاف ہی کیوں نہ ہو۔",
  "نماز کی پابندی اور منافقت سے بچنے کی تلقین۔"
 ],
 "9th|Tarjuma-tul-Quran|سورۃ المائدہ: منتخب آیات": [
  "حلال و حرام کے احکام: مردار، خون اور خنزیر کا گوشت حرام۔",
  "وضو اور تیمم کے احکام بیان ہوئے۔",
  "عہد کی پابندی اور انصاف پر قائم رہنے کا حکم۔",
  "حضرت عیسیٰ علیہ السلام کے معجزات اور ان کی حقیقت کا بیان۔"
 ],
 "9th|Tarjuma-tul-Quran|احادیثِ نبوی ﷺ": [
  "'اعمال کا دارومدار نیتوں پر ہے' (صحیح بخاری)۔",
  "'مسلمان وہ ہے جس کی زبان اور ہاتھ سے دوسرے مسلمان محفوظ رہیں'۔",
  "'تم میں سے کوئی مومن نہیں ہو سکتا جب تک اپنے بھائی کے لیے وہی پسند نہ کرے جو اپنے لیے پسند کرتا ہے'۔",
  "'صفائی نصف ایمان ہے' (صحیح مسلم)۔"
 ],
 "9th|Tarjuma-tul-Quran|اخلاقی تعلیمات": [
  "والدین کے ساتھ حسنِ سلوک قرآن کا بنیادی حکم ہے۔",
  "جھوٹ، غیبت اور بہتان سے اجتناب کی تاکید۔",
  "امانت داری اور وعدے کی پابندی مومن کی صفات ہیں۔",
  "غریبوں، مسکینوں اور ہمسایوں کے حقوق ادا کرنا ضروری ہے۔"
 ],
 "9th|Urdu|حمد": [
  "حمد: اللہ تعالیٰ کی تعریف میں کہی گئی نظم کو حمد کہتے ہیں۔",
  "اس سبق میں اللہ کی قدرت، رحمت اور عظمت کا بیان ہے۔",
  "مشکل الفاظ کے معنی یاد کریں اور شاعر کا تعارف لکھنا سیکھیں۔",
  "اشعار کی تشریح اپنے الفاظ میں کرنا امتحان کا اہم حصہ ہے۔"
 ],
 "9th|Urdu|نعتِ رسولِ مقبول ﷺ": [
  "نعت: حضور ﷺ کی مدح میں کہی گئی شاعری کو نعت کہتے ہیں۔",
  "اس نظم میں عشقِ رسول ﷺ اور آپ ﷺ کے اخلاقِ حسنہ کا ذکر ہے۔",
  "نعت گو شعرا میں حسان بن ثابتؓ سب سے مشہور ہیں۔",
  "اشعار کی تشریح اور مرکزی خیال لکھنے کی مشق کریں۔"
 ],
 "9th|Urdu|برسات کی بہاریں": [
  "یہ ایک منظر نگار مضمون ہے جس میں برسات کے موسم کی خوبصورتی بیان کی گئی ہے۔",
  "مصنف نے فطرت کے مناظر کو نہایت دلکش انداز میں پیش کیا ہے۔",
  "تشبیہات اور استعارات کی نشاندہی کرنا سیکھیں۔",
  "خلاصہ اپنے الفاظ میں لکھنے کی مشق امتحان کے لیے ضروری ہے۔"
 ],
 "9th|Urdu|پہلی سیر": [
  "یہ سبق بچپن کی یادوں پر مبنی ایک دلچسپ نثری تحریر ہے۔",
  "مصنف نے پہلی سیر کے تجربات کو مزاحیہ انداز میں بیان کیا ہے۔",
  "کردار نگاری اور منظر کشی کے نمایاں پہلوؤں کو سمجھیں۔",
  "سبق کا مرکزی خیال ایک پیراگراف میں لکھنے کی مشق کریں۔"
 ],
 "9th|Urdu|ملتِ اسلامیہ کے نوجوان": [
  "یہ اقبال کی نظم ہے جس میں نوجوانوں کو خودی اور عمل کا پیغام دیا گیا ہے۔",
  "'خودی' کا تصور: اپنی ذات کو پہچاننا اور بلند مقصد کے لیے جدوجہد کرنا۔",
  "شاہین کی علامت: بلند پروازی، خودداری اور دور اندیشی۔",
  "اشعار کی تشریح میں اقبال کے فلسفۂ خودی کو واضح کریں۔"
 ],
 "9th|Urdu|جنگِ آزادی 1857ء": [
  "1857ء کی جنگ برصغیر کی پہلی منظم آزادی کی تحریک تھی۔",
  "بہادر شاہ ظفر کو علامتی سربراہ بنایا گیا۔",
  "ناکامی کی وجوہات: قیادت کا فقدان، جدید ہتھیاروں کی کمی اور آپس کی نااتفاقی۔",
  "اس جنگ کے بعد ایسٹ انڈیا کمپنی کا اقتدار ختم ہو کر براہِ راست برطانوی راج قائم ہوا۔"
 ],
 "9th|Urdu|خطوطِ غالب": [
  "مرزا غالب اردو کے عظیم شاعر اور نثر نگار تھے۔",
  "ان کے خطوط میں روزمرہ زندگی، مزاح اور گہرے مشاہدات ملتے ہیں۔",
  "غالب کی نثر سادہ، بے تکلف اور دلکش ہے۔",
  "خطوط سے غالب کی شخصیت کے مختلف پہلو سامنے آتے ہیں۔"
 ],
 "9th|Urdu|ہجرتِ نبوی ﷺ": [
  "ہجرت 622ء میں مکہ سے مدینہ کی طرف ہوئی؛ اسی سے ہجری تقویم کا آغاز ہوا۔",
  "حضرت ابوبکر صدیقؓ سفرِ ہجرت میں حضور ﷺ کے رفیق تھے۔",
  "غارِ ثور میں تین دن قیام کے بعد مدینہ روانگی ہوئی۔",
  "ہجرت سے اسلامی ریاست کی بنیاد پڑی اور مواخاتِ مدینہ قائم ہوئی۔"
 ],
 "9th|Urdu|صحت کے اصول": [
  "صحت مند زندگی کے لیے متوازن غذا، ورزش اور صفائی ضروری ہے۔",
  "'تندرستی ہزار نعمت ہے' — صحت کی قدر کا احساس۔",
  "روزانہ کی عادات: وقت پر سونا جاگنا، صاف پانی پینا اور کھیل کود۔",
  "اس مضمون سے صحت کے موضوع پر مضمون لکھنے کی مشق کریں۔"
 ],
 "9th|Urdu|اردو گرامر: الفاظ کی اقسام": [
  "کلمہ کی اقسام: اسم، فعل اور حرف۔",
  "اسم کی اقسام: اسمِ معرفہ، اسمِ نکرہ، اسمِ ضمیر وغیرہ۔",
  "فعل کی اقسام زمانے کے لحاظ سے: ماضی، حال، مستقبل۔",
  "مترادف، متضاد اور محاورے امتحان میں ضرور پوچھے جاتے ہیں۔"
 ],
 "9th|Urdu|اردو گرامر: قواعد و انشا": [
  "جملے کی اقسام: خبریہ، انشائیہ، استفہامیہ۔",
  "واحد جمع، مذکر مونث اور حروفِ جار کا صحیح استعمال سیکھیں۔",
  "رموزِ اوقاف (ختمہ، سوالیہ، واوین) کا درست استعمال نمبر دلاتا ہے۔",
  "غلط جملوں کی اصلاح کی مشق روزانہ کریں۔"
 ],
 "9th|Urdu|تحریر: درخواست اور مضمون": [
  "درخواست کا خاکہ: عنوان، مخاطب، موضوع، گزارش، نام و تاریخ۔",
  "مضمون کے تین حصے: تمہید، نفسِ مضمون، خاتمہ۔",
  "مضمون میں اقتباسات اور اشعار کا مناسب استعمال نمبر بڑھاتا ہے۔",
  "صاف ستھری تحریر اور مناسب حاشیہ امتحان میں اچھا تاثر ڈالتا ہے۔"
 ],
 "10th|Physics|Simple Harmonic Motion and Waves": [
  "Simple harmonic motion: to-and-fro motion about a mean position, e.g. mass on a spring, simple pendulum.",
  "Time period of simple pendulum T = 2.pi.sqrt(l/g"
 ],
 "10th|Physics|Sound": [
  "Sound is a longitudinal mechanical wave; it needs a material medium and cannot travel in vacuum.",
  "Speed of sound in air is about 343 m/s; it increases with temperature.",
  "Loudness depends on amplitude; pitch depends on frequency; quality depends on waveform.",
  "Audible range: 20 Hz to 20,000 Hz; below 20 Hz infrasonic, above 20,000 Hz ultrasonic.",
  "Echo: reflection of sound; used in SONAR to find depth of sea."
 ],
 "10th|Physics|Geometrical Optics": [
  "Reflection: angle of incidence = angle of reflection; laws hold for plane and spherical mirrors.",
  "Concave mirror converges light; convex mirror diverges; used in cars and street lights.",
  "Refraction: bending of light at a boundary; Snell's law: sin i / sin r = n.",
  "Total internal reflection: light travelling from denser to rarer medium beyond the critical angle; used in optical fibres.",
  "Lenses: convex (converging) and concave (diverging"
 ],
 "10th|Physics|Electrostatics": [
  "Electric charge: positive and negative; like charges repel, unlike attract.",
  "Coulomb's law: F = k.q1.q2/r^2; unit of charge is coulomb (C).",
  "Electric field: region around a charge where force is experienced; E = F/q.",
  "Capacitor stores charge; capacitance C = Q/V; unit is farad (F).",
  "Lightning is a giant electric discharge; lightning conductors protect buildings."
 ],
 "10th|Physics|Current Electricity": [
  "Current I = Q/t; unit is ampere (A"
 ],
 "10th|Physics|Electromagnetism": [
  "Magnetic field around a current-carrying wire: right-hand grip rule gives direction.",
  "Electromagnet: soft iron core in a solenoid; strength increased by more turns and current.",
  "Fleming's left-hand rule gives the direction of force on a current-carrying conductor in a magnetic field.",
  "Electromagnetic induction: changing magnetic flux induces emf; Faraday's law.",
  "Transformer: steps voltage up or down; works only on AC; Ns/Np = Vs/Vp."
 ],
 "10th|Physics|Basic Electronics": [
  "Semiconductors (silicon, germanium) have conductivity between conductors and insulators.",
  "n-type: doped with pentavalent impurity (extra electrons"
 ],
 "10th|Physics|Information and Communication Technology": [
  "ICT: technology used to handle information and aid communication.",
  "Components: computer hardware, software, networks, internet.",
  "Internet services: email, world wide web, video conferencing, e-commerce.",
  "Data vs information: raw facts vs processed meaningful facts.",
  "Computer security: passwords, antivirus, firewall protect data from threats."
 ],
 "10th|Physics|Atomic and Nuclear Physics": [
  "Atom: nucleus (protons + neutrons) with electrons in shells around it.",
  "Isotopes: same protons, different neutrons; e.g. carbon-12, carbon-14.",
  "Radioactivity: spontaneous decay of unstable nuclei; alpha, beta, gamma radiations.",
  "Half-life: time for half the radioactive nuclei to decay.",
  "Nuclear fission: heavy nucleus splits (atomic bomb, reactors"
 ],
 "10th|Chemistry|Chemical Equilibrium": [
  "Reversible reactions can go both ways; equilibrium is reached when forward and reverse rates are equal.",
  "At equilibrium, concentrations stay constant but the reaction does not stop (dynamic equilibrium).",
  "Law of mass action: Kc = [products]/[reactants] raised to their coefficients.",
  "Le Chatelier's principle: a system at equilibrium shifts to oppose any change (concentration, pressure, temperature).",
  "Increasing pressure favours the side with fewer gas moles; catalysts do not change equilibrium position."
 ],
 "10th|Chemistry|Acids, Bases and Salts": [
  "Acids: sour taste, turn blue litmus red, pH < 7; bases: bitter, turn red litmus blue, pH > 7.",
  "Strong acids (HCl, H2SO4) ionize completely; weak acids (CH3COOH) partially.",
  "Neutralization: acid + base -> salt + water.",
  "pH scale 0-14; pH 7 is neutral; each unit is a 10x change in H+ concentration.",
  "Salts: normal, acidic, basic; uses: NaCl (food), NaHCO3 (baking soda), CaCO3 (cement)."
 ],
 "10th|Chemistry|Organic Chemistry": [
  "Organic chemistry: study of carbon compounds (except oxides, carbonates).",
  "Catenation: carbon's ability to form long chains; tetravalency gives huge variety.",
  "Functional groups: -OH (alcohol), -COOH (carboxylic acid), -CHO (aldehyde).",
  "Homologous series: same functional group, differ by CH2, similar properties.",
  "Isomerism: same molecular formula, different structures (e.g. butane and isobutane)."
 ],
 "10th|Chemistry|Hydrocarbons": [
  "Alkanes: single bonds, general formula CnH2n+2; e.g. methane CH4, ethane C2H6.",
  "Alkenes: one double bond, CnH2n; e.g. ethene; undergo addition reactions.",
  "Alkynes: one triple bond, CnH2n-2; e.g. ethyne (acetylene).",
  "Test for unsaturation: decolourizes bromine water and Baeyer's reagent.",
  "Uses: natural gas (fuel), ethene (polythene), ethyne (welding)."
 ],
 "10th|Chemistry|Biochemistry": [
  "Carbohydrates: Cn(H2O)n; monosaccharides (glucose), disaccharides (sucrose), polysaccharides (starch).",
  "Proteins: made of amino acids linked by peptide bonds; build and repair body tissues.",
  "Lipids: fats and oils; concentrated energy source; made of fatty acids and glycerol.",
  "Vitamins: A (vision), C (scurvy prevention), D (bones), K (blood clotting).",
  "Nucleic acids: DNA (double helix, genetic code) and RNA (protein synthesis)."
 ],
 "10th|Chemistry|Chemical Industries": [
  "Solvay process: manufacture of sodium carbonate (washing soda) from brine, ammonia and CO2.",
  "Urea: important nitrogenous fertilizer; manufactured from ammonia and CO2.",
  "Petroleum refining: fractional distillation gives petrol, diesel, kerosene, lubricating oil.",
  "Metallurgy: extraction of metals from ores; e.g. iron in blast furnace.",
  "Pakistan's industries: fertilizer (Engro), cement, textile, sugar."
 ],
 "10th|Chemistry|Environmental Chemistry": [
  "Pollutants: substances that contaminate air, water or soil.",
  "Air pollution: CO, CO2, SO2, NOx from vehicles and factories; causes smog and acid rain.",
  "Acid rain: SO2 and NOx dissolve in rain; damages buildings, crops and aquatic life.",
  "Water pollution: industrial waste, sewage; treated by filtration, chlorination.",
  "Ozone depletion: CFCs destroy the ozone layer; greenhouse gases cause global warming."
 ],
 "10th|Biology|Gaseous Exchange": [
  "In humans, gaseous exchange occurs in the alveoli of the lungs; large surface area and thin walls help diffusion.",
  "Breathing mechanism: diaphragm contracts and ribs move up/out during inhalation.",
  "In plants, stomata allow exchange of CO2 and O2; lenticels in woody stems.",
  "Oxygen is transported by haemoglobin in RBC as oxyhaemoglobin.",
  "Smoking damages alveoli and causes bronchitis, emphysema and lung cancer."
 ],
 "10th|Biology|Homeostasis": [
  "Homeostasis: maintaining a constant internal environment despite external changes.",
  "Osmoregulation: kidneys filter blood and maintain water/salt balance; nephron is the functional unit.",
  "Thermoregulation: sweating cools the body; shivering and hair erection warm it.",
  "Diabetes: insulin deficiency raises blood glucose; controlled by insulin injections and diet.",
  "Kidney failure is treated by dialysis or kidney transplant."
 ],
 "10th|Biology|Coordination and Control": [
  "Two systems: nervous (fast, short-lived) and hormonal/endocrine (slow, long-lasting).",
  "Neuron: cell body, dendrites, axon; impulse travels as electrochemical signal.",
  "Brain parts: cerebrum (thinking), cerebellum (coordination), medulla (breathing, heartbeat).",
  "Reflex action: instant response via spinal cord without the brain, e.g. pulling hand from heat.",
  "Hormones: insulin (pancreas), thyroxine (thyroid), adrenaline (adrenal - fight or flight)."
 ],
 "10th|Biology|Support and Movement": [
  "Human skeleton: 206 bones; axial (skull, vertebral column) and appendicular (limbs).",
  "Joints: fixed (skull), slightly movable (vertebrae), freely movable - hinge (elbow), ball and socket (shoulder).",
  "Muscles: skeletal (voluntary), smooth (involuntary), cardiac (heart).",
  "Antagonistic pair: biceps contracts while triceps relaxes to bend the arm.",
  "Disorders: arthritis (joint inflammation), osteoporosis (weak bones)."
 ],
 "10th|Biology|Reproduction": [
  "Asexual: binary fission (Amoeba), budding (Hydra), vegetative propagation (plants"
 ],
 "10th|Biology|Inheritance": [
  "Mendel's laws: segregation and independent assortment, from pea plant experiments.",
  "Dominant allele expresses itself; recessive expresses only in homozygous condition.",
  "Genotype: genetic makeup (Tt"
 ],
 "10th|Biology|Man and His Environment": [
  "Ecology: study of organisms and their environment; ecosystem = biotic + abiotic components.",
  "Food chain: producer -> primary consumer -> secondary consumer; food web is interconnected chains.",
  "Pollution: air (smoke, smog), water (sewage), land (solid waste), noise.",
  "Deforestation causes floods, soil erosion and loss of biodiversity.",
  "Conservation: reduce, reuse, recycle; national parks protect wildlife."
 ],
 "10th|Biology|Biotechnology": [
  "Biotechnology: use of living organisms to make useful products.",
  "Fermentation: yeast produces alcohol; bacteria produce yogurt and cheese.",
  "Genetic engineering: inserting desired genes, e.g. insulin production by bacteria.",
  "Cloning: producing genetically identical copies, e.g. Dolly the sheep.",
  "Applications: disease-resistant crops (Bt cotton), vaccines, gene therapy."
 ],
 "10th|Math|Quadratic Equations": [
  "Standard form: ax^2 + bx + c = 0, where a is not zero.",
  "Solve by factorization, completing the square, or quadratic formula x = [-b +- sqrt(b^2-4ac)]/2a.",
  "Discriminant D = b^2 - 4ac decides the nature of roots.",
  "D > 0: two real distinct roots; D = 0: equal roots; D < 0: no real roots.",
  "Word problems: translate the statement into an equation first, then solve."
 ],
 "10th|Math|Theory of Quadratic Equations": [
  "Sum of roots = -b/a; product of roots = c/a.",
  "Form an equation from roots alpha, beta: x^2 - (sum)x + product = 0.",
  "Symmetric functions of roots can be found without solving the equation.",
  "If roots are reciprocal, product = 1; if equal in magnitude but opposite in sign, sum = 0.",
  "Check: substitute roots back into the original equation to verify."
 ],
 "10th|Math|Variations": [
  "Direct variation: y = kx; as x increases, y increases proportionally.",
  "Inverse variation: y = k/x; as x increases, y decreases.",
  "Joint variation: y = kxz; combined: y = kx/z.",
  "Find k using given values, then answer the required question.",
  "Real-life examples: speed-time-distance, workers and days."
 ],
 "10th|Math|Partial Fractions": [
  "Partial fractions split a complex fraction into simpler ones.",
  "Case 1: distinct linear factors; Case 2: repeated linear factors; Case 3: irreducible quadratic factor.",
  "Method: write identity, multiply out, compare coefficients or substitute values.",
  "Proper fraction: degree of numerator < degree of denominator; otherwise divide first.",
  "Useful in integration and inverse Laplace transforms later."
 ],
 "10th|Math|Sets and Functions": [
  "Set: well-defined collection of objects; denoted by capital letters.",
  "Operations: union, intersection, difference, complement; Venn diagrams show them visually.",
  "De Morgan's laws: (A union B)' = A' intersect B'.",
  "Function: each input has exactly one output; domain, codomain, range.",
  "Types: one-one, onto, bijective; inverse function reverses the mapping."
 ],
 "10th|Math|Basic Statistics": [
  "Mean = sum of values / number of values; median = middle value; mode = most frequent value.",
  "For grouped data use assumed mean method: mean = A + (sum fd / sum f).",
  "Median of grouped data: l + h[(n/2 - cf)/f]; mode = l + h[(f1-f0)/(2f1-f0-f2)].",
  "Bar charts, histograms and frequency polygons present data visually.",
  "Cumulative frequency curve (ogive) is used to find the median graphically."
 ],
 "10th|Math|Introduction to Trigonometry": [
  "Ratios: sin = p/h, cos = b/h, tan = p/b; remember with SOH-CAH-TOA.",
  "Reciprocals: cosec = 1/sin, sec = 1/cos, cot = 1/tan.",
  "Standard angles: 0, 30, 45, 60, 90 degrees - memorize their ratio table.",
  "Identities: sin^2 + cos^2 = 1; 1 + tan^2 = sec^2; 1 + cot^2 = cosec^2.",
  "Angle of elevation (looking up) and angle of depression (looking down) in height-distance problems."
 ],
 "10th|Math|Projection of a Side of a Triangle": [
  "Projection: the foot of the perpendicular from a vertex onto the opposite side.",
  "In an acute triangle, c^2 = a^2 + b^2 - 2a.(projection"
 ],
 "10th|Math|Chords of a Circle": [
  "Chord: line segment joining two points on a circle; diameter is the longest chord.",
  "Perpendicular from the centre to a chord bisects the chord.",
  "Equal chords are equidistant from the centre, and conversely.",
  "Learn the exact statements of theorems - examiners check wording.",
  "Corollaries follow directly from the main theorem."
 ],
 "10th|Math|Tangent to a Circle": [
  "Tangent: a line touching the circle at exactly one point.",
  "Radius to the point of contact is perpendicular to the tangent.",
  "Tangents drawn from an external point to a circle are equal in length.",
  "Common tangents: direct and transverse.",
  "Draw the figure accurately; it earns step marks."
 ],
 "10th|Math|Chords and Arcs": [
  "Equal chords cut off equal arcs, and conversely.",
  "Arc: part of the circumference; minor arc < semicircle < major arc.",
  "Central angle is twice any angle in the alternate segment subtended by the same arc.",
  "Concentric circles share the same centre.",
  "Relate arc length to the central angle: l = r.theta."
 ],
 "10th|Math|Angle in a Segment of a Circle": [
  "Angle in a semicircle is a right angle (Thales' theorem).",
  "Angles in the same segment of a circle are equal.",
  "Cyclic quadrilateral: opposite angles sum to 180 degrees.",
  "Exterior angle of a cyclic quadrilateral equals the interior opposite angle.",
  "These theorems are heavily used in board exam geometry questions."
 ],
 "10th|Math|Practical Geometry-Circles": [
  "Construct the circumcircle: draw perpendicular bisectors of two sides; their intersection is the centre.",
  "Construct the incircle: draw angle bisectors; their intersection is the incenter.",
  "Construct tangents to a circle from an external point using the midpoint method.",
  "Escribed circle touches one side externally and the extensions of the other two.",
  "Write construction steps neatly with justification."
 ],
 "10th|Math|Linear Programming": [
  "Objective function: the quantity to maximize or minimize, e.g. Z = ax + by.",
  "Constraints: inequalities from the given conditions; non-negativity x >= 0, y >= 0.",
  "Feasible region: graph all constraints and shade the common region.",
  "Corner point method: evaluate Z at each corner; optimum occurs at a corner.",
  "Formulate carefully: define variables, write objective and constraints from the word problem."
 ],
 "10th|English|Hazrat Muhammad (SAW) - An Embodiment of Justice": [
  "Theme: the Holy Prophet's (peace be upon him) perfect justice for all, friend and foe alike.",
  "Key vocabulary: embodiment, justice, impartial, mercy, equality.",
  "Learn short answers on incidents showing his justice.",
  "Practice: write a paragraph on 'Justice in Islam'."
 ],
 "10th|English|Chinese New Year": [
  "Theme: description of Chinese New Year celebrations and cultural traditions.",
  "Key vocabulary: celebration, tradition, lantern, festival, reunion.",
  "Compare with Eid celebrations in a paragraph.",
  "Grammar focus: present simple for describing customs."
 ],
 "10th|English|Try Again": [
  "Poem: motivational message - keep trying after failure.",
  "'If at first you don't succeed, try, try again.'",
  "Poetic devices: repetition, rhyme, refrain.",
  "Theme: perseverance leads to success; practice summary writing."
 ],
 "10th|English|First Aid": [
  "Theme: basic first aid for cuts, burns, fractures and snake bites.",
  "Key vocabulary: bandage, fracture, antiseptic, emergency, victim.",
  "Learn steps: keep calm, stop bleeding, call for help.",
  "Practice: write instructions for giving first aid."
 ],
 "10th|English|The Rain": [
  "Poem describing rain as a blessing that brings life to nature.",
  "Imagery: thirsty earth, dancing leaves, fresh fragrance.",
  "Poetic devices: personification, alliteration, simile.",
  "Theme: gratitude for nature's gifts."
 ],
 "10th|English|Peace": [
  "Theme: importance of peace for individuals, nations and the world.",
  "Key vocabulary: peace, harmony, conflict, tolerance, coexistence.",
  "Islam is a religion of peace: greetings of 'Assalam-o-Alaikum'.",
  "Practice: write a speech on 'Peace - Need of the Hour'."
 ],
 "10th|English|Faithfulness": [
  "Theme: loyalty and faithfulness in relationships and duties.",
  "Key vocabulary: faithful, loyalty, trust, devotion, sincerity.",
  "Examples: faithful friends, faithful citizens, faithful servants.",
  "Learn paragraph writing on moral values."
 ],
 "10th|English|The Great Masjid of Cordoba": [
  "Theme: the historic mosque of Cordoba, Spain - a jewel of Muslim architecture.",
  "Key vocabulary: architecture, pillar, arch, civilization, heritage.",
  "Historical background: Muslim rule in Spain (Andalusia).",
  "Practice: describe a historical place you have visited."
 ],
 "10th|English|A World Without Books": [
  "Theme: the value of books; a world without them would be dark and ignorant.",
  "Key vocabulary: knowledge, ignorance, wisdom, enlightenment.",
  "'Reading maketh a full man' - Bacon.",
  "Practice: write an essay on 'Books - Our Best Friends'."
 ],
 "10th|English|My Bank Account": [
  "Humorous story about the author's troubles with opening a bank account.",
  "Key vocabulary: account, clerk, nervous, signature, deposit.",
  "Learn the use of humour and irony in storytelling.",
  "Practice: write a funny incident from your own life."
 ],
 "10th|English|Grammar: Active/Passive and Reported Speech": [
  "Active to passive: object becomes subject; verb becomes be + past participle.",
  "Tense changes in passive: is/am/are, was/were, has been, will be.",
  "Reported speech: present -> past, will -> would, can -> could.",
  "Time words change: now -> then, today -> that day, tomorrow -> the next day.",
  "Practice 10 conversions daily from past papers."
 ],
 "10th|Computer Science|Problem Solving Techniques": [
  "Top-down design: break a big problem into smaller modules.",
  "Algorithm properties: finiteness, definiteness, input, output, effectiveness.",
  "Flowchart: visual representation using standard symbols.",
  "Pseudocode: write logic in simple English-like steps before coding.",
  "Dry run: trace the algorithm manually with test data."
 ],
 "10th|Computer Science|Introduction to Programming in C": [
  "C is a structured, middle-level language developed by Dennis Ritchie.",
  "Structure: #include <stdio.h>, main() function, statements ending with semicolon.",
  "Data types: int, float, double, char; format specifiers %d, %f, %c.",
  "printf() displays output; scanf() takes input from the user.",
  "Write your first program: display 'Hello World' and sum of two numbers."
 ],
 "10th|Computer Science|Control Structures": [
  "Sequence: statements execute one after another.",
  "Selection: if, if-else, nested if, switch statement.",
  "Repetition: for, while, do-while loops.",
  "for loop: initialization; condition; increment - best when count is known.",
  "Break exits the loop; continue skips to the next iteration."
 ],
 "10th|Computer Science|Arrays and Strings": [
  "Array: collection of same-type elements with one name; index starts at 0.",
  "Declaration: int marks[5]; initialization: int a[3] = {1, 2, 3}.",
  "2D array: rows and columns, e.g. int m[2][3];",
  "String: array of characters ending with null character '\\0'.",
  "String functions: strlen, strcpy, strcat, strcmp from <string.h>."
 ],
 "10th|Computer Science|Functions": [
  "Function: reusable block of code performing one task; reduces repetition.",
  "Declaration (prototype), definition, and function call.",
  "Library functions: printf, sqrt, pow; user-defined: written by the programmer.",
  "Arguments: actual vs formal parameters; return type and return statement.",
  "Call by value copies the value; the original variable is unchanged."
 ],
 "10th|Computer Science|File Handling": [
  "File: collection of data stored on disk; text vs binary files.",
  "Steps: open (fopen), read/write, close (fclose).",
  "Modes: r (read), w (write), a (append), r+ (read+write).",
  "fprintf/fscanf for formatted file I/O; fgetc/fputc for characters.",
  "Always check if the file pointer is NULL after opening."
 ],
 "10th|Computer Science|Security, Privacy and Ethics": [
  "Security threats: viruses, worms, trojans, hacking, phishing.",
  "Protection: antivirus software, firewall, strong passwords, backups.",
  "Privacy: personal data should not be shared without permission.",
  "Ethics: no piracy, no plagiarism, respect copyright and intellectual property.",
  "Cybercrime: illegal online activities; report to FIA Cybercrime in Pakistan."
 ],
 "10th|Islamiat|قرآن مجید: ہدایت کا سرچشمہ": [
  "قرآن مجید ہر شعبۂ زندگی کے لیے مکمل ہدایت ہے۔",
  "تدبرِ قرآن: صرف تلاوت نہیں بلکہ معنی پر غور بھی ضروری ہے۔",
  "قرآن مجید کے احکام پر عمل ہی کامیابی کی ضمانت ہے۔",
  "حفاظِ قرآن کی فضیلت اور ان کا احترام امت کی ذمہ داری ہے۔"
 ],
 "10th|Islamiat|احادیثِ نبوی ﷺ": [
  "حدیث قرآن کی عملی تفسیر ہے؛ بغیر حدیث کے قرآن کو سمجھنا ممکن نہیں۔",
  "'جو میری سنت سے منہ موڑے وہ مجھ سے نہیں' (صحیح بخاری)۔",
  "محبتِ رسول ﷺ ایمان کا حصہ ہے؛ درود شریف کی کثرت کریں۔",
  "اتباعِ سنت سے زندگی میں برکت اور آخرت میں نجات ملتی ہے۔"
 ],
 "10th|Islamiat|توحید و رسالت": [
  "توحید کے تقاضے: عبادت، دعا، نذر و نیاز صرف اللہ کے لیے۔",
  "توحید سے انسان میں خودداری، بے خوفی اور عزتِ نفس پیدا ہوتی ہے۔",
  "ختمِ نبوت: حضرت محمد ﷺ آخری نبی ہیں؛ اس پر ایمان ہر مسلمان کے لیے ضروری ہے۔",
  "رسول ﷺ کی اطاعت کے بغیر ایمان مکمل نہیں ہوتا۔"
 ],
 "10th|Islamiat|نماز و روزہ": [
  "نماز کے ارکان: قیام، قراءت، رکوع، سجود، قعدہ۔",
  "نمازِ جمعہ اور عیدین کی اہمیت و فضیلت۔",
  "روزے کے آداب: سحری، افطاری، تراویح اور شبِ قدر کی تلاش۔",
  "نماز و روزہ سے تقویٰ، صبر اور نظم و ضبط پیدا ہوتا ہے۔"
 ],
 "10th|Islamiat|اخلاقِ نبوی ﷺ": [
  "حضور ﷺ کے اخلاق قرآن کا عملی نمونہ تھے (حضرت عائشہؓ)۔",
  "عفو و درگزر: فتحِ مکہ کے موقع پر عام معافی کا اعلان۔",
  "امانت داری: نبوت سے پہلے ہی 'امین' کا لقب۔",
  "رحمت للعالمین: دشمنوں کے لیے بھی دعائے ہدایت۔"
 ],
 "10th|Islamiat|سیرتِ صحابہ کرامؓ": [
  "خلفائے راشدین: حضرت ابوبکرؓ، عمرؓ، عثمانؓ، علیؓ — ہدایت یافتہ خلفاء۔",
  "حضرت ابوبکر صدیقؓ: پہلے خلیفہ، جنگِ یمامہ اور جمعِ قرآن۔",
  "حضرت عمر فاروقؓ: عدل کی مثال، بیت المقدس کی فتح، دیوان کا قیام۔",
  "حضرت عثمانؓ: جمعِ قرآن ایک مصحف پر؛ حضرت علیؓ: علم و شجاعت کی مثال۔"
 ],
 "10th|Islamiat|اسلامی نظامِ حکومت": [
  "اسلامی حکومت کی بنیاد: حاکمیتِ الٰہی، عدل، شوریٰ اور مساوات۔",
  "خلیفہ/حکمران اللہ کے احکام کا پابند اور عوام کے سامنے جوابدہ ہوتا ہے۔",
  "بیت المال: اسلامی ریاست کا خزانہ؛ زکوٰۃ، خراج اور جزیہ اس کے ذرائع۔",
  "اقلیتوں کے حقوق کی حفاظت اسلامی ریاست کی ذمہ داری ہے۔"
 ],
 "10th|Islamiat|حج و زکوٰۃ": [
  "حج: صاحبِ استطاعت پر زندگی میں ایک بار فرض؛ ارکان: احرام، وقوفِ عرفہ، طواف، سعی۔",
  "حج سے اخوت، مساوات اور اتحادِ امت کا درس ملتا ہے۔",
  "زکوٰۃ: نصاب پر سال گزرنے پر اڑھائی فیصد؛ مصارف: فقراء، مساکین وغیرہ (آٹھ مصارف)۔",
  "زکوٰۃ سے دولت کی گردش اور غربت کا خاتمہ ہوتا ہے۔"
 ],
 "10th|Pak Studies|قیامِ پاکستان کے بعد کے ابتدائی مسائل": [
  "مہاجرین کی آبادکاری: لاکھوں مہاجرین کی رہائش اور روزگار کا مسئلہ۔",
  "اثاثوں کی تقسیم: بھارت نے پاکستان کا حصہ روکے رکھا۔",
  "نہری پانی کا تنازعہ: بھارت نے پنجاب کے نہروں کا پانی بند کیا۔",
  "انتظامی مسائل: دفاتر، عملہ اور ریکارڈ کی کمی؛ پھر بھی قوم نے ہمت نہ ہاری۔"
 ],
 "10th|Pak Studies|پاکستان کی آئینی تاریخ": [
  "1956ء کا آئین: پاکستان کا پہلا آئین؛ اسلامی جمہوریہ پاکستان کا نام۔",
  "1962ء کا آئین: صدارتی نظام؛ 1973ء کا آئین: موجودہ آئین، پارلیمانی نظام۔",
  "1973ء کے آئین کی خصوصیات: وفاقی پارلیمانی نظام، اسلامی دفعات، بنیادی حقوق۔",
  "آئین میں ترامیم وقت کی ضرورت کے مطابق کی جاتی رہی ہیں۔"
 ],
 "10th|Pak Studies|پاکستان کی خارجہ پالیسی": [
  "خارجہ پالیسی کے اصول: پرامن بقائے باہمی، عدم مداخلت، مسلم امہ سے یکجہتی۔",
  "اہم تعلقات: چین (آہنی بھائی)، سعودی عرب، ترکی، امریکہ۔",
  "مسئلہ کشمیر: پاکستان کی خارجہ پالیسی کا مرکزی نکتہ۔",
  "اقوامِ متحدہ اور او آئی سی میں پاکستان کا فعال کردار۔"
 ],
 "10th|Pak Studies|پاکستان کی معیشت اور ترقی": [
  "زراعت: معیشت کی ریڑھ کی ہڈی؛ اہم فصلیں: گندم، چاول، کپاس، گنا۔",
  "صنعت: ٹیکسٹائل، چینی، سیمنٹ، کھاد؛ ایس ایم ایز روزگار کا بڑا ذریعہ۔",
  "خدمات کا شعبہ: بینکنگ، ٹیلی کام، آئی ٹی تیزی سے ترقی کر رہے ہیں۔",
  "سی پیک: پاکستان اور چین کا مشترکہ اقتصادی منصوبہ؛ گوادر بندرگاہ اس کا مرکز۔"
 ],
 "10th|Pak Studies|پاکستان کے اہم مسائل اور ان کا حل": [
  "توانائی کا بحران: لوڈشیڈنگ؛ حل: ڈیم، سولر اور ہوا سے بجلی۔",
  "آبادی میں اضافہ: وسائل پر دباؤ؛ حل: تعلیم اور خاندانی منصوبہ بندی۔",
  "دہشت گردی: قومی سلامتی کا چیلنج؛ حل: قومی اتفاق اور مضبوط ادارے۔",
  "تعلیمی پسماندگی: شرحِ خواندگی بڑھانے کے لیے اسکولوں اور اساتذہ کی ضرورت۔"
 ],
 "10th|Tarjuma-tul-Quran|سورۃ الاعراف: منتخب آیات": [
  "حضرت آدم علیہ السلام کی تخلیق اور ابلیس کے انکار کا واقعہ۔",
  "لباسِ تقویٰ کی اہمیت اور بے حیائی سے اجتناب۔",
  "پچھلی قوموں (عاد، ثمود، قومِ لوط) کے انجام سے عبرت۔",
  "اللہ کے اسمائے حسنیٰ کے ساتھ دعا مانگنے کی ترغیب۔"
 ],
 "10th|Tarjuma-tul-Quran|سورۃ الانفال: منتخب آیات": [
  "غزوۂ بدر کے واقعات اور اللہ کی نصرت کا بیان۔",
  "مالِ غنیمت کی تقسیم کے احکام۔",
  "ثابت قدمی اور اللہ پر توکل کی تلقین۔",
  "مومنوں کی صفات: نماز، انفاق اور اللہ کے ذکر سے دلوں کا کانپنا۔"
 ],
 "10th|Tarjuma-tul-Quran|سورۃ التوبہ: منتخب آیات": [
  "توبہ کی قبولیت اور اس کی شرائط کا بیان۔",
  "غزوۂ تبوک میں پیچھے رہ جانے والوں کا واقعہ۔",
  "منافقین کی نشانیاں اور ان سے بچنے کی تاکید۔",
  "مسجدِ ضرار کا واقعہ اور اخلاصِ نیت کی اہمیت۔"
 ],
 "10th|Tarjuma-tul-Quran|سورۃ یونس: منتخب آیات": [
  "قرآن کے معجز ہونے اور اس پر ایمان لانے کی دعوت۔",
  "حضرت نوح، موسیٰ اور یونس علیہم السلام کے واقعات۔",
  "دنیا کی زندگی کی مثال: کھیت کی کھیتی جیسی عارضی۔",
  "اللہ کی رحمت سے مایوس نہ ہونے کی بشارت۔"
 ],
 "10th|Tarjuma-tul-Quran|سورۃ یوسف: منتخب آیات": [
  "احسن القصص: حضرت یوسف علیہ السلام کا خواب اور اس کی تعبیر۔",
  "بھائیوں کی سازش، کنویں میں ڈالا جانا اور مصر میں فروخت۔",
  "عزیزِ مصر کے گھر آزمائش اور قید خانے میں صبر۔",
  "خواب کی تعبیر سے عزت اور والدین سے ملاپ؛ معافی اور احسان کا درس۔"
 ],
 "10th|Tarjuma-tul-Quran|احادیث و اخلاقیات": [
  "'طہارت نصف ایمان ہے اور الحمد للہ ترازو کو بھر دیتی ہے'۔",
  "'جو شخص اللہ اور قیامت پر ایمان رکھتا ہے وہ اچھی بات کہے یا خاموش رہے'۔",
  "'رشتہ داروں سے تعلق جوڑو خواہ وہ تم سے توڑیں'۔",
  "'مومن کا معاملہ عجیب ہے؛ اس کے ہر کام میں خیر ہے'۔"
 ],
 "10th|Urdu|حمد": [
  "حمد میں اللہ تعالیٰ کی حمد و ثنا بیان کی گئی ہے۔",
  "شاعر نے کائنات کی نشانیوں سے اللہ کی قدرت کو واضح کیا ہے۔",
  "مشکل الفاظ کے معنی اور اشعار کی تشریح یاد کریں۔",
  "حمد اور نعت میں فرق واضح کر کے لکھیں۔"
 ],
 "10th|Urdu|نعت": [
  "نعت میں حضور ﷺ کی سیرت اور اخلاق کا بیان ہے۔",
  "عشقِ رسول ﷺ مومن کی زندگی کا سرمایہ ہے۔",
  "اشعار کی تشریح میں عقیدت اور ادب کا لحاظ رکھیں۔",
  "نعت گو شاعر کا تعارف مختصر لکھنا سیکھیں۔"
 ],
 "10th|Urdu|خطبہ حجۃ الوداع": [
  "حجۃ الوداع 10 ہجری میں ہوا؛ یہ حضور ﷺ کا آخری خطبہ تھا۔",
  "اہم نکات: جان و مال کی حرمت، سود کی حرمت، عورتوں کے حقوق، اخوت و مساوات۔",
  "'کسی عربی کو عجمی پر اور کسی عجمی کو عربی پر فوقیت نہیں'۔",
  "یہ خطبہ انسانی حقوق کا پہلا عالمی منشور کہلاتا ہے۔"
 ],
 "10th|Urdu|دلیر": [
  "یہ سبق شجاعت اور بہادری کے موضوع پر ہے۔",
  "دلیری کا مطلب اندھی جرات نہیں بلکہ حق کے لیے ڈٹ جانا ہے۔",
  "تاریخی مثالوں سے سبق کو سمجھیں۔",
  "کردار کی عظمت پر مضمون لکھنے کی مشق کریں۔"
 ],
 "10th|Urdu|شاہراہِ ریشم": [
  "شاہراہِ ریشم قدیم تجارتی راستہ تھا جو چین کو یورپ سے ملاتا تھا۔",
  "اس راستے سے ریشم، مصالحے اور تہذیبوں کا تبادلہ ہوا۔",
  "سفرنامے کی خصوصیات: منظر کشی، مشاہدات اور معلومات۔",
  "نقشے کی مدد سے راستے کو سمجھیں۔"
 ],
 "10th|Urdu|پاکستان کی تعلیم": [
  "تعلیم قوموں کی ترقی کی بنیاد ہے۔",
  "پاکستان میں شرحِ خواندگی بڑھانے کی ضرورت پر زور۔",
  "تعلیمی مسائل: اسکولوں کی کمی، اساتذہ کی تربیت، نصاب کی بہتری۔",
  "اس موضوع پر مضمون امتحان میں اکثر پوچھا جاتا ہے۔"
 ],
 "10th|Urdu|غزل کا فن": [
  "غزل: ہر شعر مکمل مضمون؛ مطلع، مقطع، قافیہ اور ردیف اس کے اجزا ہیں۔",
  "میر، غالب، مومن اور داغ اردو غزل کے بڑے نام ہیں۔",
  "غزل میں عشق، تصوف اور زندگی کے موضوعات ملتے ہیں۔",
  "اشعار کی تشریح میں قافیہ ردیف کی نشاندہی کریں۔"
 ],
 "10th|Urdu|اردو کے اہم شعرا": [
  "میر تقی میر: 'خدائے سخن'؛ درد و غم کے شاعر۔",
  "مرزا غالب: فکر و فلسفے کے شاعر؛ دیوانِ غالب۔",
  "علامہ اقبال: 'شاعرِ مشرق'؛ فلسفۂ خودی اور شاہین کا تصور۔",
  "فیض احمد فیض: ترقی پسند شاعری؛ مزاحمت اور امید کے شاعر۔"
 ],
 "10th|Urdu|اردو گرامر": [
  "صنائع بدائع: تشبیہ، استعارہ، کنایہ، مجاز مرسل۔",
  "تلمیح: کسی تاریخی یا مذہبی واقعے کی طرف اشارہ۔",
  "روزمرہ اور محاورے میں فرق؛ محاوروں کا جملوں میں استعمال۔",
  "سابقے لاحقے سے نئے الفاظ بنانا سیکھیں۔"
 ],
 "10th|Urdu|مضمون نویسی": [
  "اچھے مضمون کی خصوصیات: واضح خاکہ، مربوط پیراگراف، مناسب اختتام۔",
  "تعارفی پیراگراف میں موضوع کا تعارف اور اہمیت بیان کریں۔",
  "دلائل اور مثالوں سے اپنے موقف کو مضبوط بنائیں۔",
  "مشہور موضوعات: حبِ وطن، تعلیم، صحت، ماحولیات، سائنس۔"
 ],
 "11th|Physics|Measurements": [
  "Systematic errors (zero error) vs random errors; precision vs accuracy.",
  "Significant figures: all certain digits plus one doubtful digit; rules for counting them.",
  "Vernier calipers: LC = 1 MSD - 1 VSD; screw gauge: LC = pitch / circular divisions.",
  "Errors add in addition/subtraction (absolute) and in multiplication/division (percentage).",
  "Dimensional analysis: check correctness of equations and derive relations."
 ],
 "11th|Physics|Vectors and Equilibrium": [
  "Scalar: magnitude only; vector: magnitude + direction; vector addition by head-to-tail rule.",
  "Rectangular components: Ax = A cos(theta), Ay = A sin(theta"
 ],
 "11th|Physics|Motion and Force": [
  "Newton's laws; momentum p = mv; impulse = change in momentum = F.t.",
  "Law of conservation of momentum: total momentum before collision = after (isolated system).",
  "Elastic collision: both momentum and kinetic energy conserved; inelastic: only momentum.",
  "Projectile motion: horizontal (uniform) + vertical (accelerated) components; range R = vi^2 sin(2.theta)/g.",
  "Friction: static vs kinetic; coefficient mu = F/N; advantages and disadvantages."
 ],
 "11th|Physics|Work and Energy": [
  "Work = F.d.cos(theta"
 ],
 "11th|Physics|Circular Motion": [
  "Angular displacement theta, angular velocity omega = Delta.theta/Delta.t, angular acceleration.",
  "Relation v = r.omega; centripetal acceleration a = v^2/r = r.omega^2.",
  "Centripetal force F = mv^2/r, provided by tension, friction or gravity.",
  "Moment of inertia I = mr^2 (point mass"
 ],
 "11th|Physics|Fluid Dynamics": [
  "Viscosity: internal friction of fluids; Stokes' law F = 6.pi.eta.rv; terminal velocity.",
  "Equation of continuity: A1v1 = A2v2; speed increases where area decreases.",
  "Bernoulli's equation: P + 1/2.rho.v^2 + rho.gh = constant; explains lift on wings.",
  "Torricelli's theorem: speed of efflux v = sqrt(2gh).",
  "Applications: carburetor, spray gun, blood flow in arteries."
 ],
 "11th|Physics|Oscillations": [
  "SHM: acceleration proportional to displacement and opposite in direction (a = -omega^2.x).",
  "Mass-spring system: T = 2.pi.sqrt(m/k"
 ],
 "11th|Physics|Waves": [
  "Mechanical vs electromagnetic waves; transverse vs longitudinal.",
  "Speed of sound: v = sqrt(gamma.P/rho"
 ],
 "11th|Physics|Physical Optics": [
  "Wavefronts: spherical, plane; Huygens' principle explains reflection and refraction.",
  "Interference: constructive (bright) and destructive (dark) fringes; Young's double slit experiment.",
  "Diffraction: bending of waves around obstacles; grating equation d.sin(theta) = n.lambda.",
  "Polarization: transverse waves only; polaroids and applications (sunglasses, 3D movies).",
  "Path difference for bright fringe = n.lambda; for dark fringe = (n + 1/2).lambda."
 ],
 "11th|Physics|Optical Instruments": [
  "Least distance of distinct vision = 25 cm; near and far points of the eye.",
  "Magnifying glass: angular magnification M = 1 + D/f.",
  "Compound microscope: M = (L/f0)(1 + D/fe"
 ],
 "11th|Physics|Heat and Thermodynamics": [
  "Zeroth law defines temperature; first law: Delta.Q = Delta.U + Delta.W (energy conservation).",
  "Isothermal (constant T), adiabatic (no heat exchange), isobaric, isochoric processes.",
  "Second law: heat cannot flow from cold to hot without work; entropy of universe increases.",
  "Carnot engine: most efficient; efficiency = 1 - T2/T1.",
  "Reversible vs irreversible processes; petrol and diesel engine cycles."
 ],
 "11th|Chemistry|Basic Concepts": [
  "Stoichiometry: mole calculations; limiting reactant decides the amount of product.",
  "Percentage yield = (actual yield / theoretical yield) x 100.",
  "Empirical formula from percentage composition; molecular formula = n x empirical formula.",
  "Avogadro's law: equal volumes of gases have equal molecules at same T and P.",
  "Concentration units: molarity, molality, mole fraction, ppm."
 ],
 "11th|Chemistry|Experimental Techniques in Chemistry": [
  "Filtration separates insoluble solids; crystallization purifies soluble solids.",
  "Sublimation: solid to gas directly (camphor, naphthalene"
 ],
 "11th|Chemistry|Gases": [
  "Gas laws: Boyle (PV = k), Charles (V/T = k), Avogadro (V/n = k"
 ],
 "11th|Chemistry|Liquids and Solids": [
  "Intermolecular forces: London dispersion, dipole-dipole, hydrogen bonding (strongest).",
  "Vapour pressure: increases with temperature; boiling point when VP = external pressure.",
  "Viscosity and surface tension decrease with temperature.",
  "Crystalline solids (ordered, sharp MP) vs amorphous (disordered, e.g. glass).",
  "Crystal systems: cubic, tetragonal, orthorhombic, hexagonal, etc.; unit cell types."
 ],
 "11th|Chemistry|Atomic Structure": [
  "Quantum numbers: n (shell), l (subshell), m (orbital), s (spin).",
  "Aufbau principle, Pauli exclusion principle, Hund's rule for filling orbitals.",
  "Electronic configuration: e.g. Fe is [Ar] 4s2 3d6; write using noble gas core.",
  "Shapes of s (spherical), p (dumbbell), d orbitals.",
  "Spectrum: line spectrum of hydrogen explained by Bohr; Lyman (UV), Balmer (visible) series."
 ],
 "11th|Chemistry|Chemical Bonding": [
  "Ionic: complete transfer (NaCl"
 ],
 "11th|Chemistry|Thermochemistry": [
  "Enthalpy H; exothermic (Delta.H negative, heat released) vs endothermic (heat absorbed).",
  "Hess's law: total enthalpy change is independent of the path.",
  "Standard enthalpy of formation: forming 1 mole from elements in standard states.",
  "Bond energies: Delta.H = bonds broken - bonds formed.",
  "Calorimetry: q = m.c.Delta.T used to measure heat changes."
 ],
 "11th|Chemistry|Chemical Equilibrium": [
  "Kc and Kp expressions; relationship Kp = Kc(RT)^Delta.n.",
  "Reaction quotient Q predicts direction: Q < K shifts forward, Q > K shifts backward.",
  "Le Chatelier: effect of concentration, pressure, temperature changes.",
  "Common ion effect suppresses ionization of a weak electrolyte.",
  "Solubility product Ksp; precipitation occurs when ionic product > Ksp."
 ],
 "11th|Chemistry|Solutions": [
  "Raoult's law: vapour pressure of solution = mole fraction x pure vapour pressure.",
  "Ideal vs non-ideal solutions; azeotropes boil at constant composition.",
  "Colligative properties: vapour pressure lowering, boiling point elevation, freezing point depression, osmotic pressure.",
  "Osmosis: solvent moves through semipermeable membrane; reverse osmosis purifies water.",
  "Molality (mol/kg solvent) is temperature-independent, unlike molarity."
 ],
 "11th|Chemistry|Electrochemistry": [
  "Oxidation numbers: rules for assigning; redox balancing by ion-electron method.",
  "Galvanic cell: anode (oxidation, negative), cathode (reduction, positive"
 ],
 "11th|Chemistry|Chemical Kinetics": [
  "Rate of reaction = change in concentration / time; units mol/L.s.",
  "Factors: concentration, temperature, surface area, catalyst, nature of reactants.",
  "Rate law: rate = k[A]^m[B]^n; order = m + n; determined experimentally.",
  "Activation energy: minimum energy needed; catalysts lower it without being consumed.",
  "Arrhenius equation relates rate constant to temperature."
 ],
 "11th|Biology|Introduction to Biology": [
  "Branches: morphology, anatomy, histology, physiology, genetics, ecology, molecular biology.",
  "Levels: subatomic -> atom -> molecule -> organelle -> cell -> tissue -> organ -> system -> organism.",
  "Protection and conservation of environment; biodiversity under threat from humans.",
  "Quranic concept of balance in nature; man's role as steward.",
  "Careers: medicine, biotechnology, agriculture, environmental science."
 ],
 "11th|Biology|Biological Molecules": [
  "Carbohydrates: monosaccharides (glucose), oligosaccharides (sucrose), polysaccharides (starch, cellulose).",
  "Proteins: amino acids joined by peptide bonds; primary to quaternary structure.",
  "Lipids: triglycerides, phospholipids (membranes), steroids; hydrophobic.",
  "Nucleic acids: DNA double helix (A-T, G-C), RNA types (mRNA, tRNA, rRNA).",
  "Water: universal solvent; high specific heat stabilizes temperature; cohesion in xylem."
 ],
 "11th|Biology|Enzymes": [
  "Enzymes lower activation energy; specific due to active site shape (induced fit model).",
  "Factors: temperature (optimum), pH (optimum), substrate and enzyme concentration.",
  "Inhibitors: competitive (bind active site) vs non-competitive (bind elsewhere).",
  "Cofactors: inorganic ions; coenzymes: organic helpers (vitamins).",
  "Uses: detergents, food industry, DNA technology (restriction enzymes)."
 ],
 "11th|Biology|The Cell": [
  "Cell membrane: fluid mosaic model (phospholipid bilayer + proteins).",
  "Transport: diffusion, facilitated diffusion, osmosis, active transport, endo/exocytosis.",
  "Organelles: ER (rough/smooth), Golgi (packaging), lysosomes (digestion), mitochondria (ATP).",
  "Cytoskeleton: microtubules, microfilaments; centrioles in animal cells.",
  "Plant vs animal cells: wall, chloroplasts, large vacuole only in plants."
 ],
 "11th|Biology|Variety of Life": [
  "Five-kingdom system by Whittaker: Monera, Protista, Fungi, Plantae, Animalia.",
  "Classification basis: cell type, body organization, nutrition, reproduction.",
  "Binomial nomenclature rules: Latin, genus capitalized, italicized.",
  "Viruses: acellular, obligate parasites; between living and non-living.",
  "Bacteriophages infect bacteria; HIV, influenza are important viral diseases."
 ],
 "11th|Biology|Kingdom Prokaryotae": [
  "Bacteria: no membrane-bound nucleus; shapes: cocci, bacilli, spirilla.",
  "Gram staining: positive (thick peptidoglycan, purple) vs negative (pink).",
  "Nutrition: autotrophic (photosynthetic, chemosynthetic) and heterotrophic.",
  "Reproduction: binary fission; genetic variation by conjugation, transformation, transduction.",
  "Cyanobacteria: photosynthetic, fix nitrogen; cause algal blooms."
 ],
 "11th|Biology|The Kingdom Protista": [
  "Unicellular eukaryotes; animal-like (protozoa), plant-like (algae), fungus-like.",
  "Amoeba: pseudopodia for movement and feeding; Paramecium: cilia, contractile vacuoles.",
  "Euglena: mixotrophic - photosynthetic and heterotrophic.",
  "Plasmodium causes malaria; transmitted by female Anopheles mosquito.",
  "Algae: diatoms (silica walls), dinoflagellates (red tides), seaweeds."
 ],
 "11th|Biology|Fungi": [
  "Heterotrophic decomposers; cell walls of chitin; body is mycelium of hyphae.",
  "Nutrition: saprobic (dead matter), parasitic, mutualistic (lichens, mycorrhizae).",
  "Reproduction: asexual by spores; sexual by fusion of hyphae.",
  "Groups: zygomycetes (bread mold), ascomycetes (yeasts), basidiomycetes (mushrooms).",
  "Importance: antibiotics (penicillin), food (yeast, mushrooms"
 ],
 "11th|Biology|Diversity Among Plants": [
  "Bryophytes (mosses): no vascular tissue, need water for fertilization; alternation of generations.",
  "Pteridophytes (ferns): vascular, seedless; dominant sporophyte.",
  "Gymnosperms: naked seeds in cones (pine"
 ],
 "11th|Biology|Nutrition": [
  "Photosynthesis: light reactions (thylakoid) and Calvin cycle (stroma"
 ],
 "11th|Biology|Gaseous Exchange": [
  "In plants: stomata (leaves), lenticels (stems"
 ],
 "11th|Biology|Transport": [
  "Xylem: tracheids and vessels carry water up; cohesion-tension theory.",
  "Phloem: sieve tubes and companion cells; translocation by pressure-flow hypothesis.",
  "Human heart: four chambers; cardiac cycle: systole and diastole; SAN is the pacemaker.",
  "Blood vessels: arteries (thick walls), veins (valves), capillaries (exchange).",
  "Lymphatic system returns tissue fluid; immunity: B and T lymphocytes."
 ],
 "11th|Math|Number System": [
  "Real numbers: rational (p/q form) and irrational; properties: closure, commutative, associative, distributive.",
  "Complex numbers: a + bi; Argand diagram; modulus |z| = sqrt(a^2 + b^2).",
  "Operations on complex numbers; conjugate properties.",
  "De Moivre's theorem: (cos.theta + i sin.theta)^n = cos(n.theta) + i sin(n.theta).",
  "Cube roots of unity: 1, omega, omega^2; 1 + omega + omega^2 = 0."
 ],
 "11th|Math|Sets, Functions and Groups": [
  "Binary operations; properties: closure, associativity, identity, inverse.",
  "Group: set with operation satisfying four axioms; e.g. integers under addition.",
  "Relations: reflexive, symmetric, transitive; equivalence relations and partitions.",
  "Functions: injective, surjective, bijective; inverse exists only for bijective functions.",
  "Composition of functions: (fog)(x) = f(g(x)"
 ],
 "11th|Math|Matrices and Determinants": [
  "Matrix algebra: addition, scalar multiplication, matrix multiplication (not commutative).",
  "Transpose, symmetric and skew-symmetric matrices; (AB)^t = B^t.A^t.",
  "Determinants: properties used to evaluate without expansion; Cramer's rule for linear systems.",
  "Adjoint and inverse: A^-1 = adj(A)/|A|; solve AX = B as X = A^-1.B.",
  "Elementary row operations; rank of a matrix."
 ],
 "11th|Math|Quadratic Equations": [
  "Nature of roots from discriminant; roots are rational if D is a perfect square.",
  "Sum and product of roots; forming equations with transformed roots.",
  "Equations reducible to quadratics: e.g. x^4 - 5x^2 + 6 = 0 (substitute y = x^2).",
  "Simultaneous equations with one linear and one quadratic.",
  "Word problems: numbers, ages, areas leading to quadratic equations."
 ],
 "11th|Math|Partial Fractions": [
  "Distinct linear factors: A/(x-a) + B/(x-b) form.",
  "Repeated linear factors: include A/(x-a) + B/(x-a)^2.",
  "Irreducible quadratic factor: (Ax + B)/(x^2 + ...).",
  "Improper fractions: divide first to get polynomial + proper fraction.",
  "Heaviside cover-up method for quick coefficients."
 ],
 "11th|Math|Sequences and Series": [
  "Arithmetic progression: a, a+d, ...; nth term = a + (n-1)d; sum = n/2[2a + (n-1)d].",
  "Geometric progression: nth term = a.r^(n-1"
 ],
 "11th|Math|Permutations, Combinations and Probability": [
  "Fundamental counting principle; factorial notation.",
  "Permutations: nPr = n!/(n-r)!; arrangements with repetitions and identical objects.",
  "Combinations: nCr = n!/(r!(n-r)!"
 ],
 "11th|Math|Mathematical Induction and Binomial Theorem": [
  "Induction steps: prove for n=1, assume for n=k, prove for n=k+1.",
  "Useful for divisibility proofs and sum formulas.",
  "Binomial theorem: (a+b)^n = sum nCr.a^(n-r).b^r.",
  "General term: T(r+1) = nCr.a^(n-r).b^r; middle terms for even/odd n.",
  "Binomial expansion for rational index: (1+x)^n infinite series for |x|<1."
 ],
 "11th|Math|Fundamentals of Trigonometry": [
  "Radian measure: 180 degrees = pi radians; arc length l = r.theta; area = 1/2 r^2.theta.",
  "Trigonometric ratios in four quadrants: ASTC rule (All, Sin, Tan, Cos positive).",
  "Domain and range of the six trigonometric functions.",
  "Periodicity: sin and cos have period 2.pi; tan has period pi.",
  "Convert between degrees and radians fluently."
 ],
 "11th|Math|Trigonometric Identities": [
  "Fundamental: sin^2 + cos^2 = 1; 1 + tan^2 = sec^2; 1 + cot^2 = cosec^2.",
  "Sum/difference: sin(A+-B), cos(A+-B), tan(A+-B) formulas.",
  "Double angle: sin 2A = 2 sin A cos A; cos 2A = cos^2 A - sin^2 A = 1 - 2 sin^2 A.",
  "Half angle and triple angle formulas derived from double angle.",
  "Sum-to-product and product-to-sum formulas for simplification."
 ],
 "11th|Math|Trigonometric Functions and their Graphs": [
  "Sine and cosine: wave between -1 and 1; tangent: repeats every pi with asymptotes.",
  "Amplitude, period, phase shift from y = a sin(bx + c).",
  "Sketch graphs by marking key points (0, pi/2, pi, 3pi/2, 2pi).",
  "Inverse graphs: reflect in the line y = x.",
  "Use graphs to solve simple trigonometric equations visually."
 ],
 "11th|Math|Application of Trigonometry": [
  "Heights and distances: angle of elevation and depression.",
  "Sine rule: a/sin A = b/sin B = c/sin C = 2R.",
  "Cosine rule: a^2 = b^2 + c^2 - 2bc cos A.",
  "Area of triangle = 1/2 ab sin C; Hero's formula from sides.",
  "Ambiguous case of the sine rule: 0, 1 or 2 possible triangles."
 ],
 "11th|Math|Inverse Trigonometric Functions": [
  "Principal values: sin^-1 range [-pi/2, pi/2]; cos^-1 [0, pi]; tan^-1 (-pi/2, pi/2).",
  "sin(sin^-1 x) = x for x in [-1,1]; sin^-1(sin x) = x only in principal range.",
  "Relations: sin^-1 x + cos^-1 x = pi/2.",
  "Simplify expressions like tan^-1 x + tan^-1 y using formulas.",
  "Graphs of inverse functions are reflections of the originals."
 ],
 "11th|Math|Solutions of Trigonometric Equations": [
  "General solution: sin x = sin alpha gives x = n.pi + (-1)^n.alpha.",
  "cos x = cos alpha gives x = 2n.pi +- alpha; tan x = tan alpha gives x = n.pi + alpha.",
  "First reduce to a single trigonometric function, then apply the formula.",
  "Check solutions within a given interval [0, 2.pi].",
  "Quadratic-type equations: substitute and solve, rejecting invalid values."
 ],
 "11th|English|The Dying Sun": [
  "Theme: the sun as a dying star; scientific facts about stars in story form.",
  "Key vocabulary: star, nebula, galaxy, collapse, energy.",
  "Learn to explain scientific ideas in simple language.",
  "Practice: write a paragraph on 'The Sun - Our Star'."
 ],
 "11th|English|Using the Scientific Method": [
  "Theme: steps of the scientific method - observation, hypothesis, experiment, conclusion.",
  "Key vocabulary: hypothesis, experiment, observation, theory, data.",
  "Apply the method to a daily-life problem as practice.",
  "Grammar focus: passive voice in scientific writing."
 ],
 "11th|English|Why Boys Fail in College": [
  "Theme: reasons for student failure - lack of purpose, poor study habits, distractions.",
  "Key vocabulary: failure, purpose, discipline, distraction, effort.",
  "Advice: set goals, manage time, study regularly.",
  "Practice: write an essay on 'How to Succeed in Exams'."
 ],
 "11th|English|End of Term": [
  "Theme: humorous account of school examinations and teachers' comments.",
  "Key vocabulary: term, report, comment, progress, examination.",
  "Learn irony and humour in prose.",
  "Practice: write your own funny school memory."
 ],
 "11th|English|On Destroying Books": [
  "Theme: J.C. Squire's essay against destroying books; books preserve civilization.",
  "Key vocabulary: civilization, preserve, destroy, culture, heritage.",
  "'A room without books is like a body without a soul.'",
  "Practice: essay on 'Importance of Libraries'."
 ],
 "11th|English|My Financial Career": [
  "Humorous story by Stephen Leacock about nervousness in a bank.",
  "Key vocabulary: account, clerk, manager, nervous, deposit.",
  "Learn: humour comes from exaggeration of a common experience.",
  "Practice: write a humorous incident from your life."
 ],
 "11th|English|China's Way to Progress": [
  "Theme: China's development through hard work, discipline and planning.",
  "Key vocabulary: progress, discipline, industry, planning, development.",
  "Lessons for Pakistan: self-reliance and hard work.",
  "Practice: essay on 'Progress of Nations'."
 ],
 "11th|English|Hunger and Population Explosion": [
  "Theme: overpopulation causes hunger; need for family planning and food production.",
  "Key vocabulary: population, hunger, resources, explosion, famine.",
  "Pakistan's population problem: causes and solutions.",
  "Practice: write a paragraph with facts and figures."
 ],
 "11th|English|The Jewel of the World": [
  "Theme: Cordoba under Muslim rule - centre of learning and culture.",
  "Key vocabulary: jewel, civilization, learning, library, culture.",
  "Historical pride: Muslims' contributions to science and art.",
  "Practice: describe the golden age of Muslim Spain."
 ],
 "11th|English|First Year at Harrow": [
  "Winston Churchill's humorous account of his school days and examinations.",
  "Key vocabulary: examination, Latin, failure, determination.",
  "Message: early failure does not decide your future.",
  "Practice: write about overcoming a failure."
 ],
 "11th|English|Hitch-Hiking Across the Sahara": [
  "Travel account: adventure, dangers and hospitality in the desert.",
  "Key vocabulary: desert, hitch-hike, adventure, oasis, caravan.",
  "Learn travel writing: vivid description of places and people.",
  "Practice: write about a journey you remember."
 ],
 "11th|English|Luis Pasteur": [
  "Biography: founder of microbiology; germ theory, pasteurization, rabies vaccine.",
  "Key vocabulary: germ, vaccine, experiment, discovery, disease.",
  "Message: persistence in research saves millions of lives.",
  "Practice: write a short biography of a scientist."
 ],
 "11th|English|Mustafa Kamal": [
  "Biography of Mustafa Kamal Ataturk, founder of modern Turkey.",
  "Key vocabulary: reform, nation, independence, modern, leader.",
  "Leadership qualities: vision, courage, determination.",
  "Practice: compare great leaders of the Muslim world."
 ],
 "11th|English|A Dialogue": [
  "Learn dialogue writing: names, colons, natural speech, stage directions in plays.",
  "One-act plays: single setting, few characters, one main incident.",
  "Practice: write a dialogue between two friends about exams.",
  "Punctuation in dialogue: quotation marks, commas, new paragraph per speaker."
 ],
 "11th|English|Grammar: Advanced Tenses and Voices": [
  "Perfect tenses: present perfect (have done), past perfect (had done).",
  "Conditionals: type 1 (will), type 2 (would), type 3 (would have).",
  "Passive of all tenses; causative use of get/have.",
  "Reported speech with questions, commands and requests.",
  "Practice: 10 mixed grammar MCQs daily from past papers."
 ],
 "11th|Computer Science|Basics of Information Technology": [
  "IT: use of computers and telecom to store, retrieve and send information.",
  "Data vs information vs knowledge hierarchy.",
  "IT applications: education (e-learning), health (telemedicine), business (e-commerce).",
  "Emerging technologies: AI, IoT, cloud computing, blockchain.",
  "Digital divide: gap between those with and without technology access."
 ],
 "11th|Computer Science|Information Networks": [
  "Network: computers connected to share resources; PAN, LAN, MAN, WAN.",
  "Topologies: star, bus, ring, mesh - advantages of each.",
  "Devices: hub, switch, router, modem, access point.",
  "Internet vs intranet vs extranet; IP addresses and DNS.",
  "Network models: OSI 7 layers and TCP/IP in brief."
 ],
 "11th|Computer Science|Data Security, Privacy and Ethics": [
  "Threats: malware (virus, worm, trojan, ransomware), phishing, hacking.",
  "Defenses: antivirus, firewall, encryption, strong passwords, 2FA.",
  "Privacy: data minimization, consent, GDPR-style principles.",
  "Ethics: software piracy, plagiarism, cyberbullying are wrong and punishable.",
  "Backups: full, incremental; 3-2-1 rule for important data."
 ],
 "11th|Computer Science|The System Unit": [
  "CPU: control unit + ALU; fetch-decode-execute cycle.",
  "Machine cycle speed measured in GHz; multi-core processors.",
  "Memory hierarchy: registers, cache, RAM, SSD/HDD.",
  "Motherboard, buses (data, address, control), ports.",
  "Binary, octal, hexadecimal conversions; 1's and 2's complement."
 ],
 "11th|Computer Science|Programming Concepts": [
  "Low-level (machine, assembly) vs high-level (C, Python, Java) languages.",
  "Translators: compiler, interpreter, assembler.",
  "Programming paradigms: procedural, object-oriented, functional.",
  "Algorithm design: stepwise refinement; flowcharts and pseudocode.",
  "Program development life cycle: analyze, design, code, test, maintain."
 ],
 "11th|Computer Science|Control Structures in C": [
  "Decision: if, if-else, else-if ladder, nested if, switch-case.",
  "Loops: for (counter-controlled), while (condition), do-while (runs at least once).",
  "Nested loops for patterns and tables; dry run to verify.",
  "break and continue; goto is discouraged.",
  "Practice: prime check, factorial, Fibonacci, number patterns."
 ],
 "11th|Computer Science|Arrays, Strings and Functions": [
  "1D and 2D arrays; passing arrays to functions.",
  "Strings: null-terminated char arrays; gets/puts, string.h functions.",
  "Functions: prototype, definition, call; return values.",
  "Storage classes: auto, static, extern, register.",
  "Recursion: function calling itself; base case is essential (factorial example)."
 ],
 "11th|Urdu|حمد": [
  "انٹر کی حمد میں اللہ کی صفات کا فلسفیانہ بیان ملتا ہے۔",
  "شاعر کے اسلوب اور تشبیہات کا تجزیہ کریں۔",
  "اشعار کی تشریح میں مرکزی خیال کو نمایاں کریں۔",
  "حمد کے روایتی موضوعات: توحید، قدرت، رحمت۔"
 ],
 "11th|Urdu|نعت": [
  "نعت میں عشقِ رسول ﷺ کا اظہار اعلیٰ ادبی اسلوب میں۔",
  "نعت گوئی کی روایت: حسانؓ سے لے کر موجودہ دور تک۔",
  "اشعار میں جذبات اور عقیدت کا امتزاج۔",
  "تشریح میں شاعر کے جذبات کو اپنے الفاظ میں بیان کریں۔"
 ],
 "11th|Urdu|ڈپٹی نذیر احمد": [
  "ڈپٹی نذیر احمد اردو کے پہلے ناول نگار کہلاتے ہیں (مراۃ العروس)۔",
  "ان کی تحریروں کا مقصد اصلاحِ معاشرہ تھا۔",
  "ناول میں کردار نگاری اور مقصدیت نمایاں ہے۔",
  "سبق کا خلاصہ اور مصنف کا تعارف یاد کریں۔"
 ],
 "11th|Urdu|غالب کی شخصیت": [
  "غالب کی شخصیت: ظرافت، خودداری اور گہری فکر کا امتزاج۔",
  "ان کے خطوط سے ان کی روزمرہ زندگی کے حالات معلوم ہوتے ہیں۔",
  "غالب کی شاعری میں تصوف، فلسفہ اور انسانی نفسیات۔",
  "امتحان میں شخصیت نگاری کے سوال کی تیاری کریں۔"
 ],
 "11th|Urdu|پریم چند": [
  "پریم چند ہندوستان کے عظیم افسانہ نگار اور ناول نگار تھے۔",
  "ان کے افسانوں میں دیہی زندگی اور کسانوں کے مسائل۔",
  "حقیقت نگاری ان کے فن کی نمایاں خصوصیت ہے۔",
  "افسانے کا خلاصہ اور مرکزی خیال لکھنے کی مشق کریں۔"
 ],
 "11th|Urdu|اردو افسانہ": [
  "افسانہ: مختصر نثری کہانی؛ اجزا: پلاٹ، کردار، مکالمہ، ماحول۔",
  "اردو افسانے کے بڑے نام: پریم چند، کرشن چندر، منٹو، عصمت چغتائی۔",
  "افسانے اور ناول میں فرق: طوالت، کرداروں کی تعداد، موضوع کی وسعت۔",
  "تنقیدی جائزے میں فن اور فکر دونوں پہلوؤں کو دیکھیں۔"
 ],
 "11th|Urdu|اردو گرامر: صرف و نحو": [
  "صرف: الفاظ کی ساخت (سابقے، لاحقے، مصدر)؛ نحو: جملوں کی ساخت۔",
  "تشبیہ کے ارکان: مشبہ، مشبہ بہ، وجہِ شبہ، حرفِ تشبیہ۔",
  "استعارہ، کنایہ اور مجاز مرسل کی تعریف اور مثالیں۔",
  "تلمیح اور مبالغے کی پہچان اشعار میں کریں۔"
 ],
 "11th|Urdu|انشا پردازی": [
  "مضمون، انشائیہ اور خاکے میں فرق سمجھیں۔",
  "انشائیے کی خصوصیات: بے تکلفی، ذاتی تجربات، مزاح۔",
  "خاکہ نگاری: شخصیت کا ادبی پورٹریٹ۔",
  "امتحان میں مضمون کے لیے خاکہ پہلے بنائیں پھر لکھیں۔"
 ],
 "11th|Islamiat|تعارفِ قرآن و حدیث": [
  "قرآن مجید کی تدوین: عہدِ نبوی ﷺ، صدیقی اور عثمانی ادوار۔",
  "حدیث کی اقسام: قول، فعل، تقریر؛ صحیح، حسن، ضعیف۔",
  "صحاحِ ستہ: بخاری، مسلم، ابوداؤد، ترمذی، نسائی، ابنِ ماجہ۔",
  "قرآن و حدیث آپس میں لازم و ملزوم ہیں۔"
 ],
 "11th|Islamiat|ایمان و عمل": [
  "ایمان اور عملِ صالح کا چولی دامن کا ساتھ ہے۔",
  "ایمان کے ثمرات: سکونِ قلب، اخروی نجات، معاشرتی اصلاح۔",
  "منافقت کی علامات: جھوٹ، وعدہ خلافی، امانت میں خیانت۔",
  "تقویٰ: اللہ کے خوف سے گناہوں سے بچنا؛ متقی کی صفات۔"
 ],
 "11th|Islamiat|عبادات": [
  "عبادت کا مفہوم: اللہ کی رضا کے لیے اس کے احکام کی تعمیل۔",
  "نماز: شرائط، ارکان، واجبات اور سنن۔",
  "روزہ، زکوٰۃ اور حج کے احکام کا خلاصہ۔",
  "عبادات کا مقصد: تقویٰ، نظم، اخوت اور روحانی ترقی۔"
 ],
 "11th|Islamiat|سیرتِ طیبہ ﷺ": [
  "مکی زندگی: تبلیغ، مشکلات، شعبِ ابی طالب کا محاصرہ۔",
  "مدنی زندگی: مسجدِ نبوی، مواخات، میثاقِ مدینہ۔",
  "غزوات: بدر، احد، خندق، فتحِ مکہ کے اسباق۔",
  "آخری خطبہ: انسانی حقوق کا منشور۔"
 ],
 "11th|Islamiat|خلفائے راشدینؓ": [
  "خلافتِ راشدہ تیس سالہ سنہری دور تھا۔",
  "حضرت ابوبکرؓ: ارتداد کی جنگیں، جمعِ قرآن۔",
  "حضرت عمرؓ: فتوحات، انتظامی اصلاحات، عدل۔",
  "حضرت عثمانؓ: توحیدِ مصاحف؛ حضرت علیؓ: علم و قضا۔"
 ],
 "11th|Islamiat|اسلامی نظامِ حیات": [
  "اسلام مکمل ضابطۂ حیات ہے: عقائد، عبادات، معاملات، اخلاق۔",
  "معاشی نظام: حلال روزی، سود کی حرمت، زکوٰۃ۔",
  "عدالتی نظام: عدل، مساوات، گواہی کے احکام۔",
  "خاندانی نظام: نکاح، حقوقِ زوجین، تربیتِ اولاد۔"
 ],
 "11th|Islamiat|اخلاق و معاشرت": [
  "اسلامی اخلاق کی بنیاد: تقویٰ، صدق، امانت، عدل۔",
  "حقوق العباد: والدین، رشتہ دار، پڑوسی، مہمان۔",
  "معاشرتی برائیاں: غیبت، بہتان، حسد، تکبر کا علاج۔",
  "اخوتِ اسلامی: 'مسلمان مسلمان کا بھائی ہے'۔"
 ],
 "11th|Pak Studies|نظریۂ پاکستان": [
  "نظریۂ پاکستان کی اسلامی بنیادیں: قرآن و سنت۔",
  "دو قومی نظریہ: سر سید سے اقبال اور قائداعظم تک کا سفر۔",
  "نظریے کی اہمیت: قومی وحدت اور شناخت کی بنیاد۔",
  "نظریۂ پاکستان کے خلاف پروپیگنڈے کا جواب۔"
 ],
 "11th|Pak Studies|تحریکِ پاکستان اور قیامِ پاکستان": [
  "1857ء سے 1947ء تک تحریک کا خلاصہ: اہم واقعات کی ترتیب۔",
  "قائداعظم کی قیادت: آئینی جدوجہد اور سیاسی بصیرت۔",
  "1940ء کی قرارداد سے 1947ء کے قیام تک۔",
  "تحریک میں طلبہ، علماء اور خواتین کا کردار۔"
 ],
 "11th|Pak Studies|پاکستان کی تاریخ 1947 تا حال": [
  "ابتدائی دور: قائداعظم اور لیاقت علی خان۔",
  "1958-1971: ایوب خان، یحییٰ خان؛ سقوطِ ڈھاکہ کے اسباب۔",
  "1971-1977: بھٹو دور؛ 1977-1988: ضیاء دور۔",
  "1988 تا حال: جمہوری ادوار کا خلاصہ۔"
 ],
 "11th|Pak Studies|پاکستان کا آئین": [
  "آئین کی ضرورت اور اہمیت۔",
  "1973ء کے آئین کی نمایاں خصوصیات: وفاق، پارلیمانی نظام، اسلامی دفعات۔",
  "بنیادی حقوق اور ان کا تحفظ۔",
  "آئین کی بالادستی اور قانون کی حکمرانی۔"
 ],
 "11th|Pak Studies|پاکستان کی معیشت": [
  "معیشت کے شعبے: زراعت، صنعت، خدمات۔",
  "پانچ سالہ منصوبے اور ان کے نتائج۔",
  "مہنگائی، بے روزگاری اور غربت: اسباب و حل۔",
  "سی پیک اور معاشی ترقی کے امکانات۔"
 ],
 "11th|Pak Studies|پاکستان کی خارجہ پالیسی": [
  "خارجہ پالیسی کے رہنما اصول۔",
  "پاک چین دوستی: 'ہمالیہ سے بلند، سمندر سے گہری'۔",
  "مسئلہ کشمیر پر پاکستان کا اصولی موقف۔",
  "افغانستان، ایران اور وسطی ایشیا سے تعلقات۔"
 ],
 "11th|Pak Studies|پاکستان کے مسائل اور ان کا حل": [
  "تعلیمی پسماندگی اور اس کا حل۔",
  "توانائی کا بحران: وجوہات اور تجاویز۔",
  "دہشت گردی اور انتہا پسندی کا مقابلہ۔",
  "قومی یکجہتی کے لیے اقدامات۔"
 ],
 "12th|Physics|Electrostatics": [
  "Electric field intensity E = F/q; field lines start at positive and end at negative charges.",
  "Electric flux = E.A.cos(theta"
 ],
 "12th|Physics|Current Electricity": [
  "Drift velocity: slow electron drift causes current; I = nAev.",
  "Resistivity depends on material and temperature; semiconductors decrease resistance with temperature.",
  "Kirchhoff's rules: junction rule (current) and loop rule (voltage).",
  "Wheatstone bridge: balanced when P/Q = R/S; used to find unknown resistance.",
  "Potentiometer: measures emf accurately without drawing current; principle of potential drop along uniform wire."
 ],
 "12th|Physics|Electromagnetism and Electromagnetic Induction": [
  "Biot-Savart law and Ampere's law give magnetic fields of currents.",
  "Force on moving charge: F = qvB sin(theta"
 ],
 "12th|Physics|Alternating Current": [
  "AC: I = I0 sin(omega.t"
 ],
 "12th|Physics|Physics of Solids": [
  "Crystalline vs amorphous solids; unit cell and crystal lattices.",
  "Elastic moduli: Young's, bulk, shear; stress-strain curve and elastic limit.",
  "Electrical properties: conductors, insulators, semiconductors by band theory.",
  "Magnetic properties: dia, para, ferromagnetic materials; hysteresis loop.",
  "Superconductivity: zero resistance below critical temperature; Meissner effect."
 ],
 "12th|Physics|Electronics": [
  "p-n junction: depletion region; forward bias conducts, reverse bias blocks.",
  "Rectifiers: half-wave and full-wave (bridge"
 ],
 "12th|Physics|Dawn of Modern Physics": [
  "Blackbody radiation: Planck's quantum theory E = hf resolved the ultraviolet catastrophe.",
  "Photoelectric effect: electrons emitted when light hits metal; Einstein's equation hf = phi + KEmax.",
  "Compton effect: X-rays scatter with increased wavelength, proving photon momentum.",
  "De Broglie wavelength: lambda = h/mv; matter has wave nature (Davisson-Germer experiment).",
  "Uncertainty principle: cannot know position and momentum exactly together."
 ],
 "12th|Physics|Atomic Spectra": [
  "Bohr's model: quantized orbits; energy En = -13.6/n^2 eV for hydrogen.",
  "Spectral series: Lyman (UV), Balmer (visible), Paschen/Brackett/Pfund (IR).",
  "Excitation vs ionization; Franck-Hertz experiment confirms quantized energy levels.",
  "X-rays: produced when fast electrons hit a metal target; Moseley's law.",
  "Laser: stimulated emission; properties: monochromatic, coherent, intense; uses in medicine and industry."
 ],
 "12th|Physics|Nuclear Physics": [
  "Nucleus: protons + neutrons; mass defect and binding energy E = Delta.m.c^2.",
  "Binding energy per nucleon peaks at iron; explains fusion and fission energy release.",
  "Radioactive decay law: N = N0.e^(-lambda.t"
 ],
 "12th|Chemistry|Periodic Classification and Periodicity": [
  "Modern periodic law: properties are periodic functions of atomic number.",
  "Trends: atomic/ionic radius, ionization energy, electron affinity, electronegativity across periods and down groups.",
  "Shielding effect increases down a group, reducing effective nuclear charge felt by valence electrons.",
  "Diagonal relationship: Li-Mg, Be-Al show similar properties.",
  "Predict properties of unknown elements from their position (Mendeleev's success with germanium)."
 ],
 "12th|Chemistry|s-Block Elements": [
  "Group IA (alkali metals): soft, low MP, highly reactive; reactivity increases down the group.",
  "Group IIA (alkaline earth metals): harder than alkali metals; Be shows diagonal relation with Al.",
  "Flame colours: Li (crimson), Na (golden yellow), K (violet), Ca (brick red).",
  "Oxides: basic, increasing basicity down the group; carbonates decompose on heating (except Na, K).",
  "Uses: Na in street lights, Mg in flash bulbs, Ca in cement."
 ],
 "12th|Chemistry|Group IIIA and IVA Elements": [
  "Boron: metalloid, used in borosilicate glass; aluminium: amphoteric oxide, extraction by electrolysis.",
  "Carbon: catenation, allotropes (diamond, graphite, fullerene"
 ],
 "12th|Chemistry|Group VA and VIA Elements": [
  "Nitrogen: inert due to triple bond; ammonia by Haber process (N2 + 3H2, Fe catalyst).",
  "Phosphorus: white (poisonous, glows) vs red (stable"
 ],
 "12th|Chemistry|Halogens and Noble Gases": [
  "Halogens: F2 > Cl2 > Br2 > I2 in reactivity and electronegativity; colours darken down the group.",
  "Chlorine: bleaching agent, water purification; bleaching powder Ca(OCl)2.",
  "Hydrogen halides: acidity increases HF < HCl < HBr < HI.",
  "Noble gases: inert due to complete octet; Xe forms compounds (XeF2, XeF4).",
  "Uses: He in balloons/MRI, Ne in signs, Ar in bulbs/welding."
 ],
 "12th|Chemistry|Transition Elements": [
  "d-block elements with partially filled d-orbitals; show variable oxidation states.",
  "Coloured ions due to d-d transitions; paramagnetic due to unpaired electrons.",
  "Good catalysts: Fe (Haber), V2O5 (contact), Ni (hydrogenation).",
  "Form complex ions: ligands donate electron pairs to central metal (e.g. [Cu(NH3)4]2+).",
  "Alloys: brass (Cu+Zn), bronze (Cu+Sn), steel (Fe+C)."
 ],
 "12th|Chemistry|Fundamental Principles of Organic Chemistry": [
  "IUPAC naming: longest chain, numbering for lowest locants, prefixes/suffixes.",
  "Isomerism: structural (chain, position, functional) and stereo (geometrical, optical).",
  "Inductive effect: electron shift along sigma bonds; +I (alkyl) and -I (halogen, NO2).",
  "Electrophiles (electron lovers) vs nucleophiles (nucleus lovers).",
  "Reaction types: substitution, addition, elimination, rearrangement."
 ],
 "12th|Chemistry|Aliphatic Hydrocarbons": [
  "Alkanes: free radical substitution (chlorination in UV light"
 ],
 "12th|Chemistry|Aromatic Hydrocarbons": [
  "Benzene: resonance structures; aromaticity by Huckel's rule (4n+2 pi electrons).",
  "Electrophilic substitution: nitration (conc. HNO3/H2SO4), sulphonation, Friedel-Crafts.",
  "Directing effects: ortho/para directors (activating, e.g. -OH) vs meta directors (deactivating, e.g. -NO2).",
  "Toluene oxidized to benzoic acid; side-chain chlorination in sunlight.",
  "Uses: TNT explosive, phenol, aniline, DDT (banned pesticide)."
 ],
 "12th|Chemistry|Alkyl Halides": [
  "Reactivity: RI > RBr > RCl > RF; 3-degree > 2-degree > 1-degree.",
  "SN1: two steps via carbocation, favoured by 3-degree; SN2: one step, favoured by 1-degree.",
  "Grignard reagent (RMgX): forms alcohols with carbonyls, alkanes with water.",
  "Wurtz reaction: 2RX + 2Na -> R-R (longer alkane).",
  "Uses: chloroform (anaesthetic, careful - phosgene), CCl4 (fire extinguisher)."
 ],
 "12th|Chemistry|Alcohols, Phenols and Ethers": [
  "Alcohols: 1, 2, 3-degree; Lucas test distinguishes them (3-degree gives immediate turbidity).",
  "Oxidation: 1-degree -> aldehyde -> acid; 2-degree -> ketone; 3-degree resists.",
  "Phenol: acidic (carbolic acid"
 ],
 "12th|Chemistry|Aldehydes and Ketones": [
  "Carbonyl group C=O; aldehydes have at least one H on carbonyl carbon.",
  "Nucleophilic addition: HCN, NaHSO3, 2,4-DNP (orange ppt identifies carbonyl).",
  "Tests: Tollens' (silver mirror, aldehydes only), Fehling's (red ppt, aldehydes only).",
  "Aldol condensation: aldehydes with alpha-H form beta-hydroxy aldehydes in dilute NaOH.",
  "Cannizzaro: aldehydes without alpha-H disproportionate in conc. NaOH."
 ],
 "12th|Chemistry|Carboxylic Acids": [
  "Acidity: RCOOH > phenol > alcohol; electron-withdrawing groups increase acidity.",
  "Derivatives: acid chlorides, anhydrides, esters, amides - reactivity order.",
  "Esterification: acid + alcohol with conc. H2SO4; fruity smell identifies esters.",
  "HVZ reaction: alpha-halogenation with Br2/red P.",
  "Uses: vinegar (acetic acid), formic acid in ant stings, citric acid in citrus."
 ],
 "12th|Chemistry|Amino Acids and Proteins": [
  "Amino acids: -NH2 and -COOH on same carbon; zwitterion structure.",
  "Essential amino acids cannot be made by the body (10 for humans).",
  "Peptide bond: -CO-NH- between amino acids; proteins are polypeptides.",
  "Protein structure: primary to quaternary; denaturation by heat/pH.",
  "Tests: biuret (violet), ninhydrin (purple) for proteins."
 ],
 "12th|Chemistry|Macromolecules": [
  "Polymers: monomers joined; addition (polythene) vs condensation (nylon, terylene).",
  "Natural polymers: starch, cellulose, proteins, natural rubber.",
  "Synthetic: PVC, Teflon (non-stick), Bakelite, polystyrene.",
  "Vulcanization: sulphur cross-links make rubber harder (tyres).",
  "Biodegradable vs non-biodegradable plastics; environmental concerns."
 ],
 "12th|Biology|Homeostasis": [
  "Kidney structure: cortex, medulla, pelvis; nephron: glomerulus, Bowman's capsule, tubules.",
  "Urine formation: filtration, selective reabsorption, secretion; ADH controls water reabsorption.",
  "Thermoregulation in detail: vasodilation/vasoconstriction, sweating, shivering.",
  "Diabetes mellitus vs insipidus; kidney stones and dialysis.",
  "Plant homeostasis: stomatal regulation, guttation, salt glands in halophytes."
 ],
 "12th|Biology|Coordination and Control": [
  "Human brain: forebrain (cerebrum, thalamus, hypothalamus), midbrain, hindbrain.",
  "Spinal cord: reflex arc - receptor, sensory neuron, interneuron, motor neuron, effector.",
  "Autonomic nervous system: sympathetic (fight/flight) vs parasympathetic (rest).",
  "Endocrine glands: pituitary (master), thyroid, parathyroid, adrenal, pancreas, gonads.",
  "Plant hormones: auxins (growth), gibberellins (stem elongation), cytokinins, abscisic acid, ethene."
 ],
 "12th|Biology|Reproduction": [
  "Male reproductive system: testes, seminiferous tubules, spermatogenesis.",
  "Female: ovaries, oogenesis, menstrual cycle (28 days, hormonal control).",
  "Fertilization, implantation, placenta, embryonic development stages.",
  "Sexually transmitted diseases: AIDS, gonorrhea, syphilis - prevention.",
  "Plant reproduction: alternation of generations; seed dormancy and germination."
 ],
 "12th|Biology|Growth and Development": [
  "Growth: irreversible increase in size; development: changes toward maturity.",
  "Primary vs secondary growth in plants; apical and lateral meristems.",
  "Growth curve: lag, log, stationary phases; measurement by auxanometer.",
  "Conditions for growth: nutrients, water, oxygen, temperature, light.",
  "Aging and death: programmed cell death (apoptosis) in animals."
 ],
 "12th|Biology|Chromosomes and DNA": [
  "Chromosome structure: chromatids, centromere, telomeres; karyotype of humans (46).",
  "DNA: double helix by Watson and Crick; base pairing A-T, G-C.",
  "DNA replication: semi-conservative; enzymes: helicase, DNA polymerase, ligase.",
  "Cell cycle control: checkpoints; cancer from uncontrolled division.",
  "Mutations: point (substitution) vs chromosomal; causes: radiation, chemicals."
 ],
 "12th|Biology|Variations and Genetics": [
  "Sources of variation: mutation, crossing over, independent assortment, random fertilization.",
  "Mendel's dihybrid cross: 9:3:3:1 ratio; test cross determines genotype.",
  "Linkage and crossing over; sex-linked inheritance (haemophilia, colour blindness).",
  "Multiple alleles: ABO blood groups; codominance and incomplete dominance.",
  "Pedigree analysis traces traits through families."
 ],
 "12th|Biology|DNA: Chemical Nature": [
  "Central dogma: DNA -> RNA -> protein.",
  "Transcription: mRNA made from DNA template in the nucleus.",
  "Translation: ribosomes read codons; tRNA brings amino acids; start codon AUG.",
  "Genetic code: triplet, universal, degenerate, non-overlapping.",
  "Gene regulation: lac operon in bacteria; mutations and their effects."
 ],
 "12th|Biology|Biotechnology": [
  "Recombinant DNA: cut with restriction enzymes, join with ligase, insert into vector.",
  "PCR amplifies DNA; gel electrophoresis separates fragments by size.",
  "Applications: insulin, growth hormone, Bt crops, gene therapy.",
  "Cloning: reproductive vs therapeutic; Dolly the sheep (1996).",
  "Ethical concerns: designer babies, privacy of genetic data."
 ],
 "12th|Biology|Evolution": [
  "Lamarck: inheritance of acquired characters; Darwin: natural selection.",
  "Evidences: fossils, homologous/analogous organs, embryology, biogeography, biochemistry.",
  "Hardy-Weinberg equilibrium: p^2 + 2pq + q^2 = 1; factors disturbing it.",
  "Speciation: allopatric (geographic) vs sympatric; adaptive radiation.",
  "Human evolution: from Australopithecus to Homo sapiens."
 ],
 "12th|Biology|Ecosystem": [
  "Components: biotic (producers, consumers, decomposers) and abiotic (light, water, soil).",
  "Energy flow: 10% law; ecological pyramids (number, biomass, energy).",
  "Biogeochemical cycles: water, carbon, nitrogen (fixation, nitrification, denitrification).",
  "Succession: primary (bare rock) to climax community; hydrosere and xerosere.",
  "Major ecosystems: desert, grassland, forest, aquatic; adaptations of organisms."
 ],
 "12th|Biology|Man and His Environment": [
  "Population growth: exponential vs logistic; carrying capacity.",
  "Environmental issues: global warming, ozone depletion, deforestation, desertification.",
  "Renewable vs non-renewable resources; sustainable development.",
  "Conservation strategies in Pakistan: national parks (Hingol, Deosai), wildlife sanctuaries.",
  "Environmental laws and the role of EPA Pakistan."
 ],
 "12th|Math|Functions and Limits": [
  "Limit: value a function approaches; left-hand and right-hand limits must agree.",
  "Standard limits: lim (sin x)/x = 1 as x->0; lim (1 + 1/n)^n = e.",
  "Continuity: limit equals function value; types of discontinuity.",
  "L'Hopital's rule for 0/0 and infinity/infinity forms.",
  "Evaluate limits by factorization, rationalization or standard results."
 ],
 "12th|Math|Differentiation": [
  "Derivative as rate of change and slope of tangent; first principles: lim [f(x+h)-f(x)]/h.",
  "Rules: power, product, quotient, chain rule.",
  "Derivatives of trigonometric, exponential, logarithmic functions.",
  "Second derivative and concavity; maxima/minima by first/second derivative test.",
  "Applications: velocity/acceleration, increasing/decreasing functions, approximations."
 ],
 "12th|Math|Integration": [
  "Integration as anti-derivative; standard integrals table must be memorized.",
  "Methods: substitution, integration by parts (ILATE rule), partial fractions.",
  "Definite integral: area under curve; properties of definite integrals.",
  "Area between curves; volume of revolution (disk method).",
  "Differential equations: order, degree; variable separable and linear forms."
 ],
 "12th|Math|Introduction to Analytic Geometry": [
  "Distance between points; section formula (internal/external division).",
  "Slope of line; equations: point-slope, two-point, slope-intercept, intercept form.",
  "Parallel (equal slopes) and perpendicular (m1.m2 = -1) lines.",
  "Distance of a point from a line; angle between two lines.",
  "Pair of straight lines: homogeneous second-degree equation."
 ],
 "12th|Math|Linear Inequalities and Linear Programming": [
  "Graph linear inequalities; feasible region is the intersection of half-planes.",
  "Formulate: decision variables, objective function, constraints.",
  "Corner point theorem: optimum at a vertex of the feasible region.",
  "Unbounded and infeasible problems; real-life examples (diet, production).",
  "Solve at least two variables graphically; check all corner points."
 ],
 "12th|Math|Conic Section": [
  "Circle: (x-h)^2 + (y-k)^2 = r^2; general form and finding centre/radius.",
  "Parabola: y^2 = 4ax; focus, directrix, latus rectum.",
  "Ellipse: x^2/a^2 + y^2/b^2 = 1; eccentricity e < 1.",
  "Hyperbola: x^2/a^2 - y^2/b^2 = 1; eccentricity e > 1; asymptotes.",
  "Identify the conic from the general second-degree equation."
 ],
 "12th|Math|Vectors": [
  "Vector in plane and space; unit vectors i, j, k.",
  "Dot product: a.b = |a||b|cos(theta"
 ],
 "12th|English|Goodbye Mr Chips - Chapters 1-4": [
  "Introduction: Mr Chipping, an old Latin teacher at Brookfield school, remembers his past.",
  "His early days: shy, strict, unpopular with boys; nicknamed 'Chips'.",
  "Key vocabulary: Brookfield, Latin, discipline, nostalgia.",
  "Learn character sketch: describe Mr Chips' personality in your own words."
 ],
 "12th|English|Goodbye Mr Chips - Chapters 5-8": [
  "Marriage: meets Katherine Bridges; she transforms him into a beloved teacher.",
  "Katherine's influence: humour, warmth, popularity among boys.",
  "Key events: their happy life; her tragic death in childbirth.",
  "Theme: love changes personality; practice writing a character sketch of Katherine."
 ],
 "12th|English|Goodbye Mr Chips - Chapters 9-12": [
  "The Great War: Brookfield boys go to war; Chips reads their names with pride and grief.",
  "Chips becomes acting headmaster; his famous farewell speech.",
  "Key vocabulary: sacrifice, patriotism, duty, remembrance.",
  "Practice: summarize the war years chapter in 150 words."
 ],
 "12th|English|Goodbye Mr Chips - Chapters 13-16": [
  "Post-war years: Chips retires but stays near Brookfield; boys still visit him.",
  "His death: peaceful end; 'I have thousands of children - the boys.'",
  "Theme: a teacher's true legacy lives in his students.",
  "Practice: write the moral/theme of the novel; prepare short questions from all chapters."
 ],
 "12th|English|Grammar: Sentence Correction and Synthesis": [
  "Common errors: subject-verb agreement, article usage, prepositions.",
  "Synthesis: combine two sentences using participles, infinitives, conjunctions.",
  "Transformation: assertive to interrogative, exclamatory, degrees of comparison.",
  "Punctuation: commas, semicolons, apostrophes in sentences.",
  "Practice: solve 5 years of board grammar sections."
 ],
 "12th|Computer Science|Basic Concepts of Programming": [
  "Program planning tools: algorithms, flowcharts, pseudocode, decision tables.",
  "Structured programming: sequence, selection, repetition; avoid goto.",
  "Object-oriented concepts: class, object, inheritance, polymorphism, encapsulation.",
  "Testing: unit, integration, system testing; debugging techniques.",
  "Documentation: internal (comments) and external (manuals)."
 ],
 "12th|Computer Science|Programming in C: Advanced": [
  "Pointers: variables holding addresses; * dereferences, & gives address.",
  "Pointer arithmetic and arrays; pointers with strings.",
  "Structures: struct keyword; array of structures; nested structures.",
  "Dynamic memory: malloc, calloc, realloc, free from <stdlib.h>.",
  "Command-line arguments: argc, argv."
 ],
 "12th|Computer Science|Subprograms and Recursion": [
  "Functions: call by value vs call by reference (pointers).",
  "Recursion: base case + recursive case; factorial and Fibonacci examples.",
  "Scope: local vs global variables; storage classes.",
  "Header files and modular programming.",
  "Trace recursive calls with a stack diagram."
 ],
 "12th|Computer Science|File Handling in C": [
  "Text vs binary files; fopen modes: r, w, a, r+, w+, b for binary.",
  "fprintf/fscanf, fgets/fputs, fread/fwrite, fseek/ftell/rewind.",
  "EOF handling; always fclose files.",
  "Practice: student record system - add, display, search records.",
  "Error handling: check NULL file pointer."
 ],
 "12th|Computer Science|Database Concepts": [
  "Database vs file system: less redundancy, better security, data integrity.",
  "DBMS examples: MySQL, Oracle, MS Access; DBA role.",
  "Data models: hierarchical, network, relational (tables).",
  "Keys: primary (unique), foreign (link), candidate, composite.",
  "Normalization: 1NF, 2NF, 3NF remove redundancy."
 ],
 "12th|Computer Science|Introduction to SQL": [
  "DDL: CREATE, ALTER, DROP; DML: SELECT, INSERT, UPDATE, DELETE.",
  "SELECT with WHERE, ORDER BY, DISTINCT; aggregate functions (COUNT, SUM, AVG).",
  "Clauses: GROUP BY, HAVING; joins: INNER, LEFT, RIGHT.",
  "Constraints: PRIMARY KEY, FOREIGN KEY, NOT NULL, UNIQUE.",
  "Practice: write queries for a student database."
 ],
 "12th|Computer Science|E-Commerce and Emerging Technologies": [
  "E-commerce types: B2B, B2C, C2C, C2B; payment methods in Pakistan (COD, cards, mobile wallets).",
  "AI: machine learning basics; applications: chatbots, recommendations.",
  "Cloud computing: IaaS, PaaS, SaaS; examples: Google Drive, AWS.",
  "IoT: connected devices; blockchain: distributed ledger, cryptocurrency basics.",
  "Cyber ethics and digital citizenship."
 ],
 "12th|Urdu|حمد": [
  "انٹرمیڈیٹ کی حمد میں عرفانی اور فلسفیانہ رنگ نمایاں ہے۔",
  "شاعر کے فکر اور اسلوب کا تنقیدی جائزہ لیں۔",
  "مشکل الفاظ اور تراکیب کے معنی یاد کریں۔",
  "تشریح میں حوالۂ متن ضرور شامل کریں۔"
 ],
 "12th|Urdu|نعت": [
  "نعت میں حضور ﷺ کی ذاتِ اقدس سے والہانہ عقیدت کا اظہار۔",
  "کلاسیکی اور جدید نعت گوئی کا موازنہ۔",
  "اشعار کی تشریح ادبی اسلوب میں کریں۔",
  "نعت کے تاریخی پس منظر پر مختصر نوٹ تیار کریں۔"
 ],
 "12th|Urdu|اردو ادب کی تاریخ": [
  "اردو کی ابتدا: دکن، گجرات اور دہلی کے ادوار۔",
  "دبستانِ دہلی اور دبستانِ لکھنو کی خصوصیات۔",
  "ترقی پسند تحریک: سجاد ظہیر، فیض، کرشن چندر۔",
  "جدید دور: نئی شاعری اور نثری تجربات۔"
 ],
 "12th|Urdu|کلاسیکی شاعری": [
  "میر: درد و سوز کے شاعر؛ 'پتہ پتہ بوٹا بوٹا حال ہمارا جانے ہے'۔",
  "غالب: فکر انگیز شاعری؛ دیوانِ غالب کی خصوصیات۔",
  "مومن: محبت کے نازک جذبات؛ 'تم میرے پاس ہوتے ہو گویا'۔",
  "ذوق اور ابراہیم ذوق: قصیدہ گوئی۔"
 ],
 "12th|Urdu|غزل": [
  "غزل کی ہیئت: مطلع، حسنِ مطلع، مقطع، قافیہ، ردیف۔",
  "غزل کے موضوعات: عشقِ مجازی، عشقِ حقیقی، تصوف۔",
  "جدید غزل: ناصر کاظمی، احمد فراز، پروین شاکر۔",
  "اشعار کی تشریح میں صنعتوں کی نشاندہی کریں۔"
 ],
 "12th|Urdu|نظم": [
  "نظم کی اقسام: پابند، آزاد، معرا، سانیٹ۔",
  "اقبال کی نظمیں: شکوہ، جوابِ شکوہ، خضرِ راہ۔",
  "نظم اور غزل میں فرق: موضوع کی وحدت بمقابلہ ہر شعر کی آزادی۔",
  "نظم کی تشریح میں تسلسلِ خیال کو واضح کریں۔"
 ],
 "12th|Urdu|افسانہ": [
  "افسانے کے عناصر: وحدتِ تاثر، پلاٹ، کردار، نقطۂ عروج۔",
  "منٹو: حقیقت نگاری اور جراتِ اظہار۔",
  "کرشن چندر: رومانویت اور ترقی پسندی۔",
  "افسانے کا تنقیدی جائزہ لکھنے کا طریقہ۔"
 ],
 "12th|Urdu|ڈراما": [
  "ڈرامے کی اقسام: المیہ، طربیہ، ایکانکی۔",
  "اردو ڈرامے کی تاریخ: آغا حشر سے ریڈیو اور ٹی وی ڈرامے تک۔",
  "مکالمہ نگاری ڈرامے کی جان ہے۔",
  "کرداروں کے نفسیاتی تجزیے کی مشق کریں۔"
 ],
 "12th|Urdu|مضمون": [
  "اعلیٰ مضمون کی خصوصیات: گہرائی، ترتیب، زبان کی شستگی۔",
  "تحقیقی مضمون: حوالہ جات اور ثبوت۔",
  "ادبی مضمون: تخیل اور اسلوب کی اہمیت۔",
  "امتحان میں وقت کی تقسیم: خاکہ 5 منٹ، تحریر 25 منٹ۔"
 ],
 "12th|Urdu|اردو گرامر: صنائع بدائع": [
  "صنائعِ لفظی: تجنیس، ایہام، مراعات النظیر۔",
  "صنائعِ معنوی: تشبیہ، استعارہ، کنایہ، حسنِ تعلیل۔",
  "صنعتِ تلمیح اور صنعتِ تضاد کی مثالیں۔",
  "اشعار میں صنعتوں کی نشاندہی کی مشق روزانہ کریں۔"
 ],
 "12th|Islamiat|قرآن مجید کا مطالعہ": [
  "منتخب سورتوں کا ترجمہ اور تفسیر: یٰسین، الرحمٰن، الملک۔",
  "قرآن مجید کے بنیادی موضوعات: توحید، رسالت، آخرت۔",
  "تدبرِ قرآن کے اصول: سیاق و سباق، شانِ نزول۔",
  "قرآن مجید اور جدید سائنس: غور و فکر کی دعوت۔"
 ],
 "12th|Islamiat|حدیث کا مطالعہ": [
  "منتخب احادیث کا ترجمہ اور تشریح۔",
  "حدیث کی حفاظت: کتابتِ حدیث اور اسمائے رجال۔",
  "صحیح اور ضعیف حدیث میں فرق۔",
  "حدیث سے مستنبط احکام کی مثالیں۔"
 ],
 "12th|Islamiat|فقہی مسائل": [
  "فقہ کا مفہوم اور اس کی ضرورت۔",
  "اجتہاد: شرائط اور اہمیت۔",
  "طہارت، نماز اور روزے کے اہم فقہی مسائل۔",
  "عصری مسائل میں فقہی رہنمائی کی ضرورت۔"
 ],
 "12th|Islamiat|اسلامی تہذیب و ثقافت": [
  "تہذیب کا مفہوم اور اسلامی تہذیب کی خصوصیات۔",
  "مسلمانوں کی علمی خدمات: طب، فلکیات، ریاضی۔",
  "اسلامی فنِ تعمیر: مساجد، مدارس۔",
  "مغربی تہذیب کے چیلنجز اور اسلامی جواب۔"
 ],
 "12th|Islamiat|سیرتِ نبوی ﷺ: مدنی دور": [
  "میثاقِ مدینہ: پہلا تحریری دستور۔",
  "مواخات: مہاجرین و انصار میں بھائی چارہ۔",
  "غزوات و سرایا کے اسباق۔",
  "فتحِ مکہ: عفوِ عام کی مثال۔"
 ],
 "12th|Islamiat|اسلامی معاشیات": [
  "اسلامی معیشت کے اصول: حلال و حرام، عدل۔",
  "سود کی حرمت اور اس کے نقصانات۔",
  "زکوٰۃ، عشر اور صدقات کا نظام۔",
  "اسلامی بینکاری کا تعارف۔"
 ],
 "12th|Pak Studies|نظریۂ پاکستان کا تحفظ": [
  "نظریۂ پاکستان کو درپیش چیلنجز: لسانیت، فرقہ واریت۔",
  "نوجوان نسل میں نظریاتی شعور کی بیداری۔",
  "تعلیمی نصاب میں نظریۂ پاکستان کی اہمیت۔",
  "قومی وحدت کے لیے نظریے کا کردار۔"
 ],
 "12th|Pak Studies|پاکستان کی سیاسی تاریخ": [
  "قیامِ پاکستان سے اب تک سیاسی ادوار کا جائزہ۔",
  "مارشل لاز کے اسباب اور اثرات۔",
  "جمہوری ادوار کی کامیابیاں اور ناکامیاں۔",
  "سیاسی استحکام کی ضرورت۔"
 ],
 "12th|Pak Studies|آئینی ارتقا": [
  "1956، 1962 اور 1973 کے آئین کا تقابلی جائزہ۔",
  "1973 کے آئین کی اسلامی دفعات۔",
  "اٹھارویں ترمیم اور صوبائی خودمختاری۔",
  "عدلیہ کی آزادی کی اہمیت۔"
 ],
 "12th|Pak Studies|معاشی چیلنجز": [
  "گردشی قرضے اور توانائی کا بحران۔",
  "برآمدات بڑھانے کی حکمتِ عملی۔",
  "آئی ٹی اور ڈیجیٹل معیشت کے امکانات۔",
  "مہنگائی پر قابو پانے کے اقدامات۔"
 ],
 "12th|Pak Studies|خارجہ پالیسی کے نئے رخ": [
  "علاقائی تعاون: سارک، ای سی او، ایس سی او۔",
  "پاکستان کا کردار: افغان امن عمل۔",
  "معاشی سفارت کاری کی اہمیت۔",
  "ڈائسپورا کا کردار۔"
 ],
 "12th|Pak Studies|قومی سلامتی اور دفاع": [
  "پاکستان کی مسلح افواج کی قربانیاں۔",
  "ایٹمی پروگرام: دفاعی ضرورت۔",
  "دہشت گردی کے خلاف جنگ: آپریشن ضربِ عضب، رد الفساد۔",
  "قومی سلامتی میں عوام کا کردار۔"
 ],
 "BA/BSc|English|Short Stories": [
  "Elements: plot, character, setting, theme, point of view.",
  "Famous stories: 'The Necklace' (Maupassant), 'The Last Leaf' (O. Henry).",
  "Irony and surprise endings are common techniques.",
  "Practice: write a critical appreciation of one story."
 ],
 "BA/BSc|English|One-Act Plays": [
  "Single act, few characters, one setting, unity of action.",
  "Learn dialogue writing and stage directions.",
  "Famous: 'The Boy Comes Home' (A.A. Milne).",
  "Practice: summarize the plot and analyze one character."
 ],
 "BA/BSc|English|Poems": [
  "Poetic forms: sonnet (14 lines), ode, elegy, ballad.",
  "Devices: metaphor, alliteration, imagery, symbolism, enjambment.",
  "Romantic poets: Wordsworth, Coleridge, Keats, Shelley.",
  "Practice: paraphrase and critically appreciate selected poems."
 ],
 "BA/BSc|English|Novels": [
  "Elements: plot, characterization, setting, theme, narrative technique.",
  "Types: picaresque, epistolary, stream of consciousness.",
  "Study one novel in detail: plot summary + character analysis.",
  "Practice: write a 300-word critical note on the novel's theme."
 ],
 "BA/BSc|English|Essays": [
  "Types: narrative, descriptive, argumentative, reflective.",
  "Structure: introduction, body paragraphs, conclusion.",
  "Famous essayists: Bacon ('Of Studies'), Lamb, Russell.",
  "Practice: write one essay weekly on current topics."
 ],
 "BA/BSc|English|Grammar: Tenses and Articles": [
  "All 12 tenses with timelines; perfect vs perfect continuous.",
  "Articles: a/an (first mention), the (specific), zero article rules.",
  "Common errors: 'the' with proper nouns, uncountable nouns.",
  "Practice: error correction exercises from past papers."
 ],
 "BA/BSc|English|Grammar: Prepositions and Comprehension": [
  "Prepositions of time (at, on, in), place, movement; fixed phrases.",
  "Phrasal verbs: look after, put off, bring up - learn with meanings.",
  "Comprehension: read twice, underline key points, answer in own words.",
  "Precis writing: one-third length, own words, single paragraph.",
  "Practice: one unseen passage weekly with timed answers."
 ],
 "BA/BSc|Urdu|نثر: منتخب اسباق": [
  "منتخب مضامین کا بغور مطالعہ؛ مصنف کا اسلوب سمجھیں۔",
  "خلاصہ نگاری: اصل کا ایک تہائی، اپنے الفاظ میں۔",
  "مشکل الفاظ اور محاورات کے معنی یاد کریں۔",
  "تنقیدی سوالات کے جوابات حوالوں کے ساتھ لکھیں۔"
 ],
 "BA/BSc|Urdu|شاعری: غزل": [
  "منتخب غزلوں کی تشریح؛ شاعر کا تعارف۔",
  "غالب، میر، مومن کی منتخب غزلیں۔",
  "صنائع بدائع کی نشاندہی۔",
  "غزل کے موضوعات: عشق، تصوف، حیات۔"
 ],
 "BA/BSc|Urdu|شاعری: نظم": [
  "اقبال، فیض، ناصر کاظمی کی منتخب نظمیں۔",
  "نظم کا مرکزی خیال اور فکری جائزہ۔",
  "آزاد نظم اور پابند نظم کی خصوصیات۔",
  "تشریح میں تسلسلِ خیال برقرار رکھیں۔"
 ],
 "BA/BSc|Urdu|ڈراما": [
  "منتخب ڈرامے کا مطالعہ: پلاٹ، کردار، مکالمے۔",
  "اردو ڈرامے کی تاریخ کا خلاصہ۔",
  "کردار نگاری پر تنقیدی نوٹ۔",
  "مکالموں سے مصنف کے فن کا اندازہ۔"
 ],
 "BA/BSc|Urdu|افسانہ": [
  "منتخب افسانوں کا تنقیدی مطالعہ۔",
  "منٹو، کرشن چندر، پریم چند کے افسانے۔",
  "افسانے کے عناصر کی روشنی میں تجزیہ۔",
  "موضوع اور پیغام پر نوٹ۔"
 ],
 "BA/BSc|Urdu|اردو ادب کی تاریخ": [
  "ادوارِ ادب: دکنی، شمالی ہند، جدید۔",
  "تحریکیں: علی گڑھ، ترقی پسند، جدیدیت۔",
  "اہم اصناف کا ارتقا: غزل، نظم، ناول، افسانہ۔",
  "امتحان میں مختصر نوٹ کی تیاری۔"
 ],
 "BA/BSc|Urdu|گرامر و قواعد": [
  "صرف و نحو کے اعلیٰ مباحث۔",
  "صنائع بدائع کی مکمل فہرست اور مثالیں۔",
  "روزمرہ، محاورے اور ضرب الامثال۔",
  "غلط فقرات کی اصلاح کی مشق۔"
 ],
 "BA/BSc|Islamiat|قرآن مجید کا مطالعہ": [
  "منتخب آیات کا ترجمہ، تفسیر اور احکام۔",
  "علومِ قرآن: نزول، جمع و تدوین، قراءات۔",
  "قرآن مجید کے معاشی و معاشرتی احکام۔",
  "عصری مسائل میں قرآنی رہنمائی۔"
 ],
 "BA/BSc|Islamiat|حدیث کا مطالعہ": [
  "منتخب احادیث کی تشریح۔",
  "اصولِ حدیث: سند و متن کی تحقیق۔",
  "کتبِ حدیث کا تعارف۔",
  "حدیث سے فقہی استنباط کی مثالیں۔"
 ],
 "BA/BSc|Islamiat|فقہی مسائل": [
  "فقہ کی تعریف، ضرورت اور ارتقا۔",
  "ائمۂ اربعہ کا تعارف۔",
  "اجتہاد و تقلید کا مسئلہ۔",
  "عصری فقہی مسائل: بینکاری، میڈیکل۔"
 ],
 "BA/BSc|Islamiat|اسلامی تہذیب": [
  "تہذیب و ثقافت کا اسلامی تصور۔",
  "مسلمانوں کی علمی و فنی خدمات۔",
  "اسلامی تہذیب کے زوال کے اسباب۔",
  "احیائے تہذیب کی صورتیں۔"
 ],
 "BA/BSc|Islamiat|سیرتِ نبوی ﷺ": [
  "سیرت کے ماخذ: قرآن، حدیث، تاریخی کتب۔",
  "مکی و مدنی ادوار کا تقابلی مطالعہ۔",
  "سیرت سے رہنمائی: قیادت، معیشت، سیاست۔",
  "مستشرقین کے اعتراضات کا جواب۔"
 ],
 "BA/BSc|Islamiat|اسلامی معاشیات": [
  "اسلامی معیشت کے بنیادی اصول۔",
  "سود، سٹہ اور جوئے کی حرمت۔",
  "زکوٰۃ و عشر کا نظام۔",
  "اسلامی بینکاری اور تکافل۔"
 ],
 "BA/BSc|Pak Studies|نظریۂ پاکستان": [
  "نظریے کے ماخذ: قرآن و سنت، دو قومی نظریہ۔",
  "اقبال اور قائداعظم کے افکار۔",
  "نظریۂ پاکستان کی عصری اہمیت۔",
  "نظریے کے تحفظ کی ذمہ داری۔"
 ],
 "BA/BSc|Pak Studies|تحریکِ پاکستان": [
  "1857 سے 1947 تک: اہم مراحل۔",
  "مسلم لیگ کی جدوجہد۔",
  "قائداعظم کی قیادت کا تجزیہ۔",
  "تحریک میں مختلف طبقات کا کردار۔"
 ],
 "BA/BSc|Pak Studies|قیامِ پاکستان کے بعد کے ادوار": [
  "1947-1958: ابتدائی مسائل اور جمہوری تجربات۔",
  "1958-1971: ایوب و یحییٰ ادوار؛ سقوطِ ڈھاکہ۔",
  "1971-1977: بھٹو دور؛ 1977-1988: ضیاء دور۔",
  "1988 تا حال: جمہوریت کا سفر۔"
 ],
 "BA/BSc|Pak Studies|آئینی تاریخ": [
  "آئین سازی کی کوششیں: 1949 کی قراردادِ مقاصد۔",
  "1956، 1962، 1973 کے آئین کا موازنہ۔",
  "آئین کی اسلامی دفعات۔",
  "آئینی بحران اور ان کا حل۔"
 ],
 "BA/BSc|Pak Studies|معاشی ترقی": [
  "معاشی پالیسیوں کا جائزہ: دہائی بہ دہائی۔",
  "زرعی اصلاحات اور صنعتی ترقی۔",
  "غربت اور بے روزگاری کے مسائل۔",
  "مستقبل کے امکانات: سی پیک، آئی ٹی۔"
 ],
 "BA/BSc|Pak Studies|خارجہ پالیسی": [
  "خارجہ پالیسی کے اصول و مقاصد۔",
  "بڑی طاقتوں سے تعلقات۔",
  "مسلم دنیا سے تعلقات۔",
  "کشمیر اور علاقائی امن۔"
 ],
 "BA/BSc|Math|Calculus: Limits and Continuity": [
  "Epsilon-delta definition of limit; one-sided limits.",
  "Continuity on intervals; intermediate value theorem.",
  "Indeterminate forms and L'Hopital's rule.",
  "Limits of sequences; squeeze theorem.",
  "Practice: standard limits must be memorized."
 ],
 "BA/BSc|Math|Differentiation": [
  "Chain rule, implicit differentiation, parametric forms.",
  "Logarithmic differentiation for complex products/powers.",
  "Higher-order derivatives; Leibnitz theorem.",
  "Mean value theorems: Rolle's, Lagrange's, Cauchy's.",
  "Applications: maxima/minima, curve sketching, related rates."
 ],
 "BA/BSc|Math|Integration": [
  "Integration by parts, partial fractions, trigonometric substitutions.",
  "Definite integrals: properties, improper integrals.",
  "Reduction formulas for powers of sin, cos.",
  "Applications: areas, volumes, arc length, surface area.",
  "Beta and gamma functions (BSc level)."
 ],
 "BA/BSc|Math|Matrices and Linear Algebra": [
  "Rank, nullity; systems of linear equations (consistent/inconsistent).",
  "Eigenvalues and eigenvectors; characteristic equation.",
  "Cayley-Hamilton theorem; diagonalization.",
  "Vector spaces: basis, dimension, linear independence.",
  "Linear transformations and their matrices."
 ],
 "BA/BSc|Math|Differential Equations": [
  "Order, degree, formation of differential equations.",
  "First order: variable separable, homogeneous, linear (integrating factor).",
  "Second order linear with constant coefficients; auxiliary equation.",
  "Particular integrals for standard RHS forms.",
  "Applications: growth/decay, Newton's law of cooling."
 ],
 "BA/BSc|Math|Statistics": [
  "Measures of central tendency and dispersion (variance, SD, CV).",
  "Moments, skewness, kurtosis.",
  "Correlation: Karl Pearson's coefficient; regression lines.",
  "Probability distributions: binomial, Poisson, normal.",
  "Sampling, hypothesis testing basics (z-test, t-test)."
 ],
 "BA/BSc|Math|Probability": [
  "Axioms of probability; conditional probability; Bayes' theorem.",
  "Random variables: discrete and continuous; expectation, variance.",
  "Binomial, Poisson, normal distributions with applications.",
  "Chebyshev's inequality; law of large numbers.",
  "Practice: numerical problems from past papers."
 ],
 "BA/BSc|Physics|Mechanics": [
  "Newtonian mechanics: frames of reference, inertial vs non-inertial.",
  "Conservation laws: momentum, angular momentum, energy.",
  "Rotational dynamics: torque, moment of inertia of standard bodies.",
  "Gravitation: Kepler's laws, satellite motion, escape velocity.",
  "Special relativity: time dilation, length contraction, E = mc^2."
 ],
 "BA/BSc|Physics|Waves and Oscillations": [
  "Damped, forced oscillations; resonance and Q-factor.",
  "Wave equation; superposition; standing waves in strings and pipes.",
  "Sound: intensity, Doppler effect, beats, ultrasonics.",
  "Electromagnetic waves: spectrum, Poynting vector.",
  "Interference, diffraction, polarization in detail."
 ],
 "BA/BSc|Physics|Thermodynamics": [
  "Laws of thermodynamics; entropy and its statistical meaning.",
  "Kinetic theory: Maxwell-Boltzmann distribution.",
  "Heat engines: Carnot, Otto, Diesel cycles and efficiencies.",
  "Low-temperature physics: liquefaction of gases.",
  "Thermodynamic potentials: internal energy, enthalpy, free energy."
 ],
 "BA/BSc|Physics|Electromagnetism": [
  "Maxwell's equations in integral and differential form.",
  "Electrostatics: multipole expansion; dielectrics.",
  "Magnetostatics: Biot-Savart, Ampere's law; magnetic materials.",
  "Electromagnetic induction; AC circuits with phasors.",
  "Electromagnetic waves: production, properties, applications."
 ],
 "BA/BSc|Physics|Modern Physics": [
  "Photoelectric effect, Compton effect, pair production.",
  "Bohr model and its limitations; Sommerfeld extension.",
  "X-rays: production, spectra, applications.",
  "Nuclear physics: radioactivity, fission, fusion, reactors.",
  "Particle physics: standard model basics; accelerators."
 ],
 "BA/BSc|Physics|Electronics": [
  "Semiconductor physics: bands, doping, p-n junction in detail.",
  "Diodes: rectifier, Zener, LED, photodiode.",
  "Transistors: BJT and FET; amplifiers, oscillators.",
  "Digital electronics: gates, flip-flops, counters, ADC/DAC.",
  "Operational amplifiers and applications."
 ],
 "BA/BSc|Physics|Quantum Physics: Introduction": [
  "Wave-particle duality; de Broglie hypothesis.",
  "Schrodinger equation: time-dependent and time-independent.",
  "Particle in a box; quantum tunneling.",
  "Heisenberg uncertainty principle and its consequences.",
  "Hydrogen atom: quantum numbers and orbitals."
 ],
 "BA/BSc|Chemistry|Physical Chemistry": [
  "Chemical thermodynamics: laws, entropy, free energy, equilibrium constant.",
  "Chemical kinetics: rate laws, order, molecularity, catalysis.",
  "Electrochemistry: cells, Nernst equation, conductance.",
  "Quantum chemistry basics: particle in a box, H-atom.",
  "Spectroscopy: UV, IR, NMR principles and applications."
 ],
 "BA/BSc|Chemistry|Inorganic Chemistry": [
  "Periodic trends in detail; diagonal relationships.",
  "Coordination chemistry: Werner's theory, IUPAC naming, isomerism.",
  "Crystal field theory: splitting, high/low spin complexes.",
  "Organometallic compounds; bioinorganic chemistry (haemoglobin).",
  "Acids and bases: Arrhenius, Bronsted-Lowry, Lewis concepts."
 ],
 "BA/BSc|Chemistry|Organic Chemistry": [
  "Reaction mechanisms: SN1, SN2, E1, E2, electrophilic substitution.",
  "Stereochemistry: R/S, E/Z, optical activity, racemic mixtures.",
  "Carbonyl chemistry in depth; named reactions (Cannizzaro, Aldol, Perkin).",
  "Aromatic chemistry: directing effects, polycyclic aromatics.",
  "Heterocyclic compounds: pyrrole, furan, pyridine, purines."
 ],
 "BA/BSc|Chemistry|Analytical Chemistry": [
  "Quantitative analysis: titrations (acid-base, redox, complexometric).",
  "Gravimetric analysis: precipitation, weighing forms.",
  "Instrumental: chromatography (GC, HPLC), spectroscopy, electroanalysis.",
  "Errors: systematic vs random; significant figures; statistics.",
  "Quality control in pharmaceutical and food industries."
 ],
 "BA/BSc|Chemistry|Biochemistry": [
  "Carbohydrates, lipids, proteins, nucleic acids in depth.",
  "Enzyme kinetics: Michaelis-Menten equation.",
  "Metabolism: glycolysis, Krebs cycle, oxidative phosphorylation.",
  "Photosynthesis: light and dark reactions in detail.",
  "Vitamins, hormones and their biochemical roles."
 ],
 "9th|Computer Science|Data Representation and Number Systems": [
  "Data is represented inside a computer in binary form using only two digits: 0 and 1 (bits).",
  "Number systems: binary (base 2), octal (base 8), decimal (base 10) and hexadecimal (base 16).",
  "Decimal to binary conversion: divide the decimal number by 2 repeatedly and write remainders in reverse order; e.g. 13 = 1101.",
  "Binary to decimal conversion: multiply each bit by 2 raised to its position power and add; e.g. 1101 = 8+4+0+1 = 13.",
  "1 byte = 8 bits; 1 KB = 1024 bytes; 1 MB = 1024 KB; 1 GB = 1024 MB.",
  "ASCII code uses 7 or 8 bits to represent English characters; Unicode (UTF-8/UTF-16) represents characters of all world languages including Urdu.",
  "Exam tip: practice converting at least 5 decimal-to-binary and 5 binary-to-decimal numbers before the board exam."
 ],
 "9th|Computer Science|Computer Networks and Internet": [
  "A computer network is a group of computers connected together to share data, software and hardware resources.",
  "LAN (Local Area Network) covers a small area like a school or office; WAN (Wide Area Network) covers cities or countries — the Internet is the largest WAN.",
  "Common network devices: hub, switch, router, modem and network interface card (NIC).",
  "The Internet is a global network of networks; an ISP (Internet Service Provider) connects users to the Internet, e.g. PTCL and Nayatel in Pakistan.",
  "A web browser (Chrome, Edge, Firefox) is used to open websites; a URL is the address of a web page, e.g. www.google.com.",
  "An IP address is a unique numerical address of each device on a network; DNS converts domain names into IP addresses.",
  "Wi-Fi uses radio waves for wireless connection; a hotspot shares mobile internet with nearby devices.",
  "Exam tip: draw and label a simple diagram of LAN vs WAN for a 4-mark question."
 ],
 "9th|Computer Science|Word Processing: MS Word": [
  "A word processor is application software used to create, edit, format and print documents; MS Word is the most popular example.",
  "Common file extensions: .docx for Word documents, .pdf for portable documents, .txt for plain text files.",
  "Formatting tools: bold (Ctrl+B), italic (Ctrl+I), underline (Ctrl+U), font size, font colour and text alignment (left, center, right, justify).",
  "Cut (Ctrl+X) removes and copies text, Copy (Ctrl+C) duplicates text, Paste (Ctrl+V) inserts it at the cursor position.",
  "Save (Ctrl+S) stores the document; Save As creates a copy with a new name or location; Print preview is checked with Ctrl+P.",
  "Tables are inserted from the Insert menu to arrange data in rows and columns; rows and columns can be added or deleted later.",
  "Header appears at the top and footer at the bottom of every page; page numbers are usually added in the footer.",
  "Spell check (F7) underlines wrong spellings in red and grammar mistakes in blue in MS Word."
 ],
 "9th|Computer Science|Spreadsheets: MS Excel": [
  "A spreadsheet is application software used to organise data in rows and columns and perform calculations; MS Excel is the most popular example.",
  "The intersection of a row and a column is called a cell; each cell has an address like A1, B5 (column letter + row number).",
  "A formula always starts with the = sign, e.g. =A1+A2 adds the values of cells A1 and A2.",
  "Common functions: SUM(range) adds values, AVERAGE(range) finds the mean, MAX/MIN find the largest/smallest value, COUNT counts numbers.",
  "A chart (bar, pie, line) presents data graphically; it is created from selected data using the Insert > Chart option.",
  "Sorting arranges data in ascending or descending order; filtering shows only the rows that meet a condition.",
  "A workbook contains one or more worksheets; a new worksheet is added with the + button at the bottom.",
  "Cell formatting includes number formats (currency, percentage, date), borders, background colour and merging cells."
 ],
 "9th|Computer Science|Presentations: MS PowerPoint": [
  "MS PowerPoint is presentation software used to create slideshows for class presentations, lectures and business meetings.",
  "A presentation is made of slides; each slide can contain text, pictures, charts, audio and video.",
  "Slide layouts include Title Slide, Title and Content, Two Content, and Blank; a new slide is added with Ctrl+M.",
  "Transitions are effects between slides (fade, push, wipe); animations are effects on objects within a slide.",
  "Slide Show is started with F5 (from the beginning) or Shift+F5 (from the current slide).",
  "Themes give a consistent design (colours, fonts, backgrounds) to all slides in one click.",
  "The file extension of a PowerPoint presentation is .pptx; speaker notes are written below each slide for the presenter only.",
  "Exam tip: prepare one 5-slide presentation on any topic as practical practice — it covers layouts, transitions and animations."
 ],
 "9th|Computer Science|Introduction to Databases": [
  "A database is an organised collection of related data stored electronically so it can be searched, updated and managed easily.",
  "A table stores data in rows (records) and columns (fields); e.g. a Students table has fields Name, RollNo, Class, Marks.",
  "A primary key is a field that uniquely identifies each record, e.g. Roll Number — no two records can have the same primary key.",
  "MS Access is a popular desktop database software; MySQL and Oracle are used for large online databases.",
  "A query is a question asked to the database, e.g. 'show names of students with marks above 80'.",
  "A form is a user-friendly screen for entering data into a table; a report prints data in a formatted layout.",
  "DBMS (Database Management System) is the software that manages databases, e.g. MS Access, MySQL, SQL Server.",
  "Advantages of databases over files: less duplication, data security, fast searching and easy sharing among users."
 ],
 "9th|Computer Science|Internet, Email and Web Browsing": [
  "The World Wide Web (WWW) is a service on the Internet used to access web pages through browsers.",
  "An email address has two parts: username@domain, e.g. student@gmail.com — the @ symbol separates them.",
  "Inbox receives incoming emails; Sent stores sent emails; Drafts stores unfinished emails; Spam/Junk stores unwanted emails.",
  "CC sends a copy to another person visibly; BCC sends a hidden copy; attachments (files, photos) are added with the paperclip icon.",
  "A search engine (Google, Bing) finds information on the web; use specific keywords in quotes for exact phrases.",
  "Downloading means copying files from the Internet to your device; uploading means sending files from your device to the Internet.",
  "Strong passwords use a mix of capital and small letters, digits and symbols; never share your password with anyone.",
  "Cyber safety: do not click unknown links, do not share personal photos with strangers, and log out on shared computers."
 ],
 "9th|English|Grammar: Articles and Prepositions": [
  "Articles: 'a' and 'an' are indefinite articles used before singular countable nouns mentioned for the first time.",
  "Use 'an' before vowel sounds (an apple, an hour) and 'a' before consonant sounds (a book, a university).",
  "'The' is the definite article used for specific things already mentioned or unique things (the sun, the Holy Quran).",
  "No article is used before plural/general nouns (Books are useful), proper names, meals and languages in general.",
  "Prepositions of time: at (exact time — at 5 o'clock), on (days/dates — on Monday), in (months/years — in 2026).",
  "Prepositions of place: at (point — at the door), on (surface — on the table), in (inside — in the room).",
  "Common fixed prepositions: afraid of, good at, interested in, depend on/upon, fond of, proud of.",
  "Exam tip: 9th board paper has 5 marks for prepositions and 5 for articles — learn the fixed-preposition list by heart."
 ],
 "9th|English|Grammar: Narration (Direct and Indirect Speech)": [
  "Direct speech repeats the exact words of the speaker inside quotation marks: He said, 'I am ill.'",
  "Indirect (reported) speech reports the meaning without quotation marks: He said that he was ill.",
  "In narration, the reporting verb 'said' changes to 'told' when an object follows: He told me that he was ill.",
  "Tense change rule: present simple becomes past simple (is -> was), present continuous -> past continuous, past simple -> past perfect.",
  "Pronouns change according to speaker and listener: I -> he/she, you -> I/me, we -> they.",
  "Time words change: now -> then, today -> that day, yesterday -> the previous day, tomorrow -> the next day.",
  "Questions: 'said' becomes 'asked'; yes/no questions use 'if/whether': He asked me if I was ill. Wh-questions keep the wh-word.",
  "Imperatives: 'said' becomes 'ordered/requested/advised'; use to + verb: He ordered him to go out."
 ],
 "9th|English|Grammar: Parts of Speech": [
  "The 8 parts of speech are: noun, pronoun, verb, adjective, adverb, preposition, conjunction, interjection.",
  "Noun names a person, place or thing; types: proper (Lahore), common (city), collective (team), abstract (honesty), countable/uncountable.",
  "Pronoun replaces a noun: personal (I, you, he), possessive (mine, yours), reflexive (myself), relative (who, which, that), demonstrative (this, that).",
  "Verb shows action or state: main verbs (run, eat) and helping verbs (is, have, will, can, must).",
  "Adjective describes a noun (beautiful flower, tall boy); degrees: positive, comparative (taller), superlative (tallest).",
  "Adverb describes a verb, adjective or another adverb (runs quickly, very tall); many end in -ly.",
  "Conjunction joins words or sentences: coordinating (and, but, or, so), subordinating (because, if, although, when).",
  "Interjection expresses sudden feeling: Hurrah! Alas! Oh! Bravo! — followed by an exclamation mark."
 ],
 "9th|English|Grammar: Sentence Types": [
  "Four sentence types by purpose: declarative (statement), interrogative (question), imperative (order/request), exclamatory (strong feeling).",
  "Declarative ends with a full stop: Pakistan is my country. Interrogative ends with a question mark: Where do you live?",
  "Imperative starts with a verb: Open the door. / Please help me. Exclamatory ends with ! : What a beautiful scene!",
  "By structure: simple (one clause), compound (two independent clauses joined by and/but/or), complex (independent + dependent clause).",
  "A phrase is a group of words without a complete verb (in the morning); a clause has a subject and verb.",
  "Subject-verb agreement: singular subject takes singular verb (He goes), plural subject takes plural verb (They go).",
  "'Each, every, either, neither' take singular verbs; 'many, few, several' take plural verbs.",
  "Exam tip: identify sentence type questions carry 5 marks — practice converting statements into questions and exclamations."
 ],
 "9th|English|Letter and Application Writing": [
  "Formal letters/applications follow the format: sender's address, date, receiver's address, subject, salutation, body, closing, signature.",
  "Applications to the principal: start 'Respected Sir/Madam', state class and section, give a clear reason, end with 'Yours obediently'.",
  "Common applications: sick leave, fee concession, urgent piece of work, character certificate, remission of fine.",
  "Letters to friends/family are informal: begin 'My dear ...', share news, ask about health, end 'Yours sincerely/affectionately'.",
  "Keep the body in 3 paragraphs: introduction (purpose), detail (facts/dates), request or closing line.",
  "Use polite language: 'I shall be grateful', 'Kindly grant me leave', 'I hope you will consider my request'.",
  "Dates are written as: Examination Hall, City — 9th October, 2026 (never write only the date without place in exams).",
  "Word limit: about 120-150 words; neat handwriting and correct format carry separate marks."
 ],
 "9th|English|Story and Paragraph Writing": [
  "A story needs: title, introduction (characters/setting), rising action (events), climax (turning point), moral at the end.",
  "Common board stories: A Greedy Dog, Thirsty Crow, Honesty is the Best Policy, A Foolish Stag, Union is Strength.",
  "Write the moral in a separate line, e.g. MORAL: Greed is a curse. / Slow and steady wins the race.",
  "Use past tense for stories and sequence words: once, then, suddenly, finally, at last.",
  "A paragraph is one topic in 100-120 words: topic sentence, 4-6 supporting sentences, concluding sentence.",
  "Common paragraph topics: My Best Friend, My Hobby, A Visit to a Hill Station, Load Shedding, My Aim in Life.",
  "Dialogue: write each speaker's words in a new line inside quotation marks with correct punctuation.",
  "Exam tip: learn 6 story outlines by heart — the board repeats them; write at least 150 words for full marks."
 ],
 "9th|English|Comprehension and Summary Writing": [
  "Comprehension: read the passage twice — first for general idea, second to underline answers to the given questions.",
  "Answer in your own words; copy only short phrases where exact wording is needed (names, dates).",
  "For 'what/why/how' questions give complete sentences, not single words.",
  "Summary: read the passage, pick the main points, and rewrite them in about one-third of the original length.",
  "A good summary has no examples, no repetitions, no quotations and no personal opinions — only the central ideas.",
  "Use linking words in summary: firstly, moreover, however, therefore, finally.",
  "Give the summary a suitable title if asked (2 marks are often fixed for the title).",
  "Time management: spend 15 minutes on comprehension + summary in the paper; do not copy whole sentences."
 ],
 "9th|English|Vocabulary: Synonyms, Antonyms and Pair of Words": [
  "Synonym = same meaning (happy - joyful); Antonym = opposite meaning (happy - sad).",
  "Common board synonyms: brave - courageous, honest - truthful, kind - gentle, begin - start, wealthy - rich.",
  "Common board antonyms: victory x defeat, ancient x modern, cruel x kind, success x failure, include x exclude.",
  "Pair of words are similar-sounding words with different meanings, e.g. accept (receive) / except (excluding).",
  "Important pairs: affect/effect, advice/advise, principal/principle, stationary/stationery, fair/fare, weak/week.",
  "Learn each pair with one sentence: 'The principal (head) explained the principle (rule).'",
  "Prefixes change meaning: un- (unhappy), dis- (dislike), im- (impossible); suffixes change word class: -ness, -tion, -ly.",
  "Exam tip: make a personal diary of 100 pair-of-words with sentences — 5 marks are fixed in the 9th paper."
 ],
 "9th|Islamiat|حقوق العباد": [
  "حقوق العباد سے مراد بندوں کے حقوق ہیں؛ ان کی ادائیگی میں کوتاہی معاف نہیں ہوتی جب تک حق دار معاف نہ کرے۔",
  "والدین کے حقوق: ان کی خدمت، اطاعت اور احترام فرض ہے؛ قرآن میں انہیں اُف تک کہنے سے منع کیا گیا ہے۔",
  "پڑوسیوں کے حقوق: ان کی خیرخواہی، مدد اور تکلیف نہ دینا حدیث میں ایمان کا حصہ قرار دیا گیا ہے۔",
  "رشتہ داروں اور یتیموں کے حقوق کی حفاظت اسلام نے لازم قرار دی ہے؛ یتیم کا مال کھانا حرام ہے۔",
  "مزدوروں کو ان کی محنت کا پورا اجر اور وقت پر ادا کرنا واجب ہے — حدیث: پسینہ خشک ہونے سے پہلے مزدور کو اجرت دے دو۔",
  "مہمان نوازی اسلامی اخلاق کا اہم حصہ ہے؛ نبی کریم ۺ نے مہمان کی خاطر اپنا کمبل بھی رہن رکھا۔",
  "غیبت، چغلی اور بہتان حقوق العباد کی خلاف ورزیاں ہیں اور ان سے بچنا لازم ہے۔",
  "امتحانی نکتہ: حقوق اللہ اور حقوق العباد میں فرق واضح کر کے لکھیں — یہ اکثر پوچھا جانے والا سوال ہے۔"
 ],
 "9th|Islamiat|امر بالمعروف و نہی عن المنکر": [
  "امر بالمعروف کا مطلب نیکی کا حکم دینا اور نہی عن المنکر کا مطلب برائی سے روکنا ہے۔",
  "یہ امت مسلمہ کی اجتماعی ذمہ داری ہے — قرآن: تم بہترین امت ہو جو نیکی کا حکم دیتی ہو (3:110)۔",
  "حدیث: جو برائی دیکھے وہ اسے ہاتھ سے روکے؛ اگر طاقت نہ ہو تو زبان سے؛ پھر دل سے برا سمجھے۔",
  "برائی سے روکنے کے تین درجے: ہاتھ سے (طاقت ہو تو)، زبان سے، دل سے نفرت — آخری ایمان کا کمزور درجہ ہے۔",
  "حکمت وقت کا فریضہ ہے کہ وہ عدل قائم کرے اور ظلم روکے؛ علماء کا کام علم و نصیحت ہے۔",
  "افراد کی سطح پر: گھر والوں، دوستوں اور پڑوسیوں کو نیکی کی تلقین اور برائی سے منع کرنا چاہیے۔",
  "امتحانی نکتہ: تینوں درجوں کی ترتیب اور آیت 3:110 کا حوالہ لازمی لکھیں۔"
 ],
 "9th|Islamiat|سیرتِ صحابہ کرامؓ: نمایاں شخصیات": [
  "حضرت ابوبکر صدیق رضی اللہ عنہ: پہلے خلیفہ، صدیق کا لقب؛ غارِ ثور میں نبی کریم ۺ کے ساتھی۔",
  "حضرت عمر فاروق رضی اللہ عنہ: دوسرے خلیفہ؛ عدل و انصاف کی مثال؛ ان کے دور میں اسلامی ریاست فتح ہوئیں۔",
  "حضرت عثمان غنی رضی اللہ عنہ: تیسرے خلیفہ؛ قرآن مجید کو ایک مصحف میں جمع کیا؛ ذوالنورین کا لقب۔",
  "حضرت علی المرتضٰ رضی اللہ عنہ: چوتھے خلیفہ؛ علم و شجاعت کے پیکر؛ بابِ علم کا لقب۔",
  "حضرت حمزہ رضی اللہ عنہ: سید الشہداء؛ جنگِ احد میں شہید ہوئے۔",
  "حضرت بلال حبشی رضی اللہ عنہ: پہلے موذن؛ صبر و استقامت کی علامت۔",
  "امتحانی نکتہ: چاروں خلفاء کے القاب اور نمایاں کارنامے یاد کریں — مختصر سوالات میں آتے ہیں۔"
 ],
 "9th|Pak Studies|آل انڈیا مسلم لیگ کا کردار": [
  "آل انڈیا مسلم لیگ 30 دسمبر 1906ء کو ڈھاکہ میں قائم ہوئی؛ بانی نواب سلیم اللہ خاں تھے۔",
  "قیام کا مقصد: مسلمانوں کے سیاسی حقوق کا تحفظ اور ان کی آواز حکومت تک پہنچانا۔",
  "1916ء کا میثاقِ لکھنؤ: مسلم لیگ اور کانگریس کے درمیان معاہدہ؛ مسلمانوں کے جداگانہ انتخابات تسلیم کیے گئے۔",
  "1940ء کی قراردادِ لاہور مسلم لیگ کے پلیٹ فارم سے منظور ہوئی — پاکستان کے قیام کی بنیاد رکھی۔",
  "1945-46 کے انتخابات میں مسلم لیگ نے مسلم نشستوں پر بھاری اکثریت حاصل کی۔",
  "قائداعظم نے 1913ء میں مسلم لیگ میں شمولیت اختیار کی اور اسے مسلمانوں کی واحد جماعت بنایا۔",
  "امتحانی نکتہ: تاریخیں (1906، 1916، 1940، 1946) ترتیب سے یاد کریں۔"
 ],
 "9th|Pak Studies|پاکستان کی ثقافت اور ورثہ": [
  "پاکستان کی ثقافت اسلامی اقدار، مقامی روایات اور جدید رجحانات کا امتزاج ہے۔",
  "مشہور تہوار: عیدالفطر، عیدالاضحیٰ، عید میلاد النبی ۺ، یومِ آزادی (14 اگست)، یومِ پاکستان (23 مارچ)۔",
  "قدیم آثار: موئنجودڑو، ہڑپہ، ٹیکسلا اور بادشاہی مسجد پاکستان کے تاریخی ورثے کی علامتیں۔",
  "لباس: شلوار قمیض قومی لباس؛ صوبوں میں دھوتی کرتا، سندھی ٹوپی اور پگڑی بھی رائج ہے۔",
  "کھانے: بریانی، نہاری، حلیم، سجی اور چپلی کباب مشہور پاکستانی کھانے ہیں۔",
  "کھیل: ہاکی قومی کھیل؛ کرکٹ سب سے مقبول کھیل ہے؛ کبڃی اور کشتی بھی روایتی کھیل ہیں۔",
  "لوک فن: ٹرک آرٹ، اجرک، پھلکاری اور نیلے گنبد والی مساجد پاکستانی ثقافت کی پہچان ہیں۔",
  "امتحانی نکتہ: قومی نشانیاں یاد کریں — قومی کھیل ہاکی، قومی جانور مارخور، قومی پھول چمبیلی۔"
 ],
 "9th|Pak Studies|پاکستان کی زبانیں اور ادب": [
  "اردو پاکستان کی قومی زبان ہے اور انگریزی دفتری زبان ہے۔",
  "صوبائی زبانیں: پنجابی (پنجاب)، سندھی (سندھ)، پشتو (خیبر پختونخوا)، بلوچی (بلوچستان)۔",
  "پنجابی کے مشہور شاعر: بلے شاہ، وارث شاہ (ہیر)، سلطان باہو۔",
  "سندھی کے مشہور شاعر: شاہ عبداللطیف بھٹائی (شاہ جو رسالو)۔",
  "پشتو کے مشہور شاعر: خوشحال خان خٹک، رحمان بابا۔",
  "اردو ادب کے ستون: علامہ اقبال (ﺷﺎﻋﺮِ ﻣﺸﺮﻕ)، مرزا غالب، فیض احمد فیض۔",
  "امتحانی نکتہ: ہر صوبے کی زبان اور ایک مشہور شاعر کا نام یاد کریں۔"
 ],
 "9th|Tarjuma-tul-Quran|قرآنی دعائیں": [
  "قرآن مجید میں انبیاء کرام کی دعائیں بندوں کے لیے بہترین نمونہ ہیں۔",
  "رَبَّنَا آتِنَا فِی الدُّنْیَا حَسَنَۃً — اے ہمارے رب! ہمیں دنیا میں بھلائی عطا فرما (البقرۃ: 201)۔",
  "رَبِّ اشْرَحْ لِیْ صَدْرِیْ — اے میرے رب! میرا سینہ کھول دے (طٰہٰ: 25) — حضرت موسیٰ کی دعا۔",
  "رَبَّنَا اغْفِرْ لَنَا — اے ہمارے رب! ہمیں بخش دے — مغفرت کی دعا۔",
  "دعا عبادت کا مغز ہے — حدیث کے مطابق دعا مانگنا اللہ کو بہت پسند ہے۔",
  "دعا کے آداب: وضو، قبلہ رخ، ہاتھ اٹھانا، اللہ کی حمد و ثنا سے آغاز اور درود شریف پر اختتام۔",
  "قبولیت کے اوقات: تہجد، اذان و اقامت کے درمیان، جمعہ کا دن، بارش کے وقت اور روزے دار کی دعا۔",
  "امتحانی نکتہ: دو قرآنی دعائیں ترجمے سمیت یاد کریں — اکثر پوچھی جاتی ہیں۔"
 ],
 "9th|Tarjuma-tul-Quran|اسمائے حسنیٰ: تعارف": [
  "اسمائے حسنیٰ سے مراد اللہ تعالیٰ کے خوبصورت نام ہیں — حدیث میں 99 ناموں کا ذکر ہے۔",
  "حدیث: جس نے ان 99 ناموں کو یاد کیا وہ جنت میں داخل ہوگا (بخاری و مسلم)۔",
  "الرحمٰن (بہت رحم کرنے والا)، الرحیم (نہایت مہربان) — رحمت کے نام۔",
  "الملک (بادشاہ)، القدوس (پاک)، السلام (سلامتی دینے والا) — عظمت کے نام۔",
  "الخالق (پیدا کرنے والا)، الرزاق (روزی دینے والا)، الفتاح (کھولنے والا) — قدرت کے نام۔",
  "الغفور (بخشنے والا)، التواب (توبہ قبول کرنے والا)، العدل (انصاف کرنے والا)۔",
  "اسماء کے ذریعے دعا مانگنا مسنون ہے: اے غفور! مجھے بخش دے۔",
  "امتحانی نکتہ: کم از کم 10 اسمائے حسنیٰ معانی سمیت یاد کریں۔"
 ],
 "9th|Tarjuma-tul-Quran|توحید و آخرت کے قرآنی دلائل": [
  "توحید: اللہ ایک ہے، اس کا کوئی شریک نہیں — سورۃ الاخلاص اس کی مکمل دلیل ہے۔",
  "سورۃ الاخلاص: قُلْ ہُوَ اللّٰہُ اَحَدٌ — کہہ دیجیے وہ اللہ ایک ہے۔",
  "شرک کی مذمت: اللہ شرک کو نہیں بخشتا (النساء: 48) — یہ سب سے بڑا گناہ ہے۔",
  "آخرت: ہر نفس کو موت کا مزہ چکھنا ہے، پھر حساب و کتاب ہوگا (آل عمران: 185)۔",
  "قیامت کے دلائل: پہلی تخلیق پر قدرت رکھنے والا دوبارہ پیدا کرنے پر بھی قادر ہے (یٰس: 79)۔",
  "جنت نیک اعمال والوں کا ٹھکانا اور دوزخ کافروں اور گناہگاروں کا ٹھکانا ہے۔",
  "یومِ حساب میں نامۂ اعمال دائیں ہاتھ میں ملنا کامیابی کی علامت ہے (الحاقۃ)۔",
  "امتحانی نکتہ: سورۃ الاخلاص کا ترجمہ اور توحید کے دو قرآنی دلائل ضرور یاد کریں۔"
 ],
 "9th|Urdu|اردو گرامر: محاورات اور ضرب الامثال": [
  "محاورہ ایسا مرکب ہے جس کے معنی اس کے الفاظ کے ظاہری معنوں سے مختلف ہوتے ہیں۔",
  "مشہور محاورات: آنکھوں کا تارا (بہت پیارا)، دل باغ باغ ہونا (بہت خوش ہونا)، ناک میں دم کرنا (تنگ کرنا)۔",
  "مزید محاورات: ایڑی چوٹی کا زور لگانا (پوری کوشش)، دانتوں تلے انگلی دبانا (حیران ہونا)۔",
  "ضرب الامثل ایک مکمل جملہ ہوتا ہے جو تجربے یا حکمت پر مبنی ہو۔",
  "مشہور امثال: جیسی کرنی ویسی بھرنی، دیر آید درست آید، ناچ نہ جانے آنگن ٹیڑھا۔",
  "محاورے میں فعل کی تبدیلی جملے کے مطابق ہوتی ہے، ضرب الامثل میں نہیں ہوتی۔",
  "امتحان میں 5 محاورات جملوں میں استعمال کرنے کو کہا جاتا ہے — ہر محاورہ ایک مکمل جملے میں لکھیں۔",
  "امتحانی نکتہ: 20 محاورات اور 10 ضرب الامثال معانی سمیت یاد کریں۔"
 ],
 "9th|Urdu|اردو گرامر: واحد جمع اور مذکر مونث": [
  "واحد ایک چیز کو اور جمع ایک سے زیادہ چیزوں کو ظاہر کرتا ہے۔",
  "جمع بنانے کے طریقے: کتاب-کتابیں، لڑکا-لڑکے، درخت-درختوں، استاد-اساتذہ۔",
  "عربی الفاظ کی جمع: مسجد-مساجد، علم-علوم، خبر-اخبار، قوم-اقوام۔",
  "فارسی الفاظ کی جمع: باغ-باغات، دیوار-دیواریں، نامہ-نامے۔",
  "مذکر نر اور مونث مادہ کو ظاہر کرتا ہے — اردو میں بے جان چیزوں کی بھی تذکیر و تانیث ہوتی ہے۔",
  "مونث بنانے کے طریقے: لڑکا-لڑکی، استاد-استانی، شیر-شیرنی، بکرا-بکری۔",
  "بے جان: کتاب (مونث)، قلم (مذکر)، کرسی (مونث)، دروازہ (مذکر) — استعمال سے پہچانیں۔",
  "امتحانی نکتہ: فعل کا صیغہ فاعل کی تذکیر و تانیث کے مطابق بدلتا ہے — لڑکا گیا، لڑکی گئی۔"
 ],
 "9th|Urdu|اردو گرامر: حروف اور الفاظِ مرکب": [
  "حرف وہ کلمہ ہے جو تنہا پورا معنی نہ دے بلکہ دوسرے الفاظ سے مل کر معنی دے، جیسے کا، کی، سے، میں۔",
  "حروفِ جار: سے، میں، پر، تک، کو، کے لیے — اسم کے ساتھ مل کر معنی پورا کرتے ہیں۔",
  "حروفِ عطف: اور، و — دو الفاظ یا جملوں کو جوڑتے ہیں۔",
  "لفظِ مرکب دو یا زیادہ الفاظ کے ملنے سے بنتا ہے۔",
  "مرکبِ توصیفی: صفت + موصوف، جیسے خوبصورت باغ، نیک لڑکا۔",
  "مرکبِ اضافی: مضاف + مضاف الیہ، جیسے کتابِ غالب، نورِ خدا۔",
  "مرکبِ عطفی: دو اسموں کا اور/و سے ملنا، جیسے دین و دنیا، رات دن۔",
  "امتحانی نکتہ: مرکب کی تینوں اقسام کی ایک ایک مثال ضرور یاد رکھیں۔"
 ],
 "9th|Urdu|تلخیص نویسی": [
  "تلخیص کسی عبارت کا خلاصہ ہے — اصل عبارت کا تیسرا حصہ ہونا چاہیے۔",
  "پہلے عبارت دو بار پڑھیں اور اہم نکات کو خط کشیدہ کریں۔",
  "تلخیص میں مثالیں، تفصیلات، اشعار اور اقتباسات شامل نہیں کیے جاتے۔",
  "اپنے الفاظ میں لکھیں — اصل عبارت کے جملے ہو بہو نقل نہ کریں۔",
  "تلخیص ایک ہی پیراگراف میں ہو اور اس کا مناسب عنوان بھی دیں۔",
  "غیر ضروری الفاظ، تکرار اور ذاتی رائے سے پرہیز کریں۔",
  "ربط کے لیے الفاظ استعمال کریں: علاوہ ازیں، تاہم، لہٰذا، آخر میں۔",
  "امتحانی نکتہ: عنوان کے 2 نمبر الگ ہوتے ہیں — عنوان ضرور لکھیں۔"
 ],
 "9th|Urdu|اردو ادب کے اہم ادیب": [
  "مرزا غالب (1797-1869): اردو کے عظیم شاعر؛ دیوانِ غالب اور خطوطِ غالب مشہور۔",
  "علامہ اقبال (1877-1938): شاعرِ مشرق؛ بانگِ درا، بالِ جبریل؛ پاکستان کا تصور پیش کیا۔",
  "سرسید احمد خان (1817-1898): علی گڑھ تحریک کے بانی؛ رسالہ تہذیب الاخلاق جاری کیا۔",
  "ڈپٹی نذیر احمد (1831-1912): اردو کے پہلے ناول نگار؛ مراۃ العروس اور توبۃ النصوح۔",
  "پریم چند (1880-1936): اردو ہندی کے عظیم افسانہ نگار؛ گودان مشہور ناول۔",
  "مولانا الطاف حسین حالی: مسدسِ حالی اور مقدمہ شعر و شاعری کے مصنف۔",
  "اشفاق احمد: اردو کے مشہور افسانہ نگار اور ڈراما نویس؛ زاویہ مشہور۔",
  "امتحانی نکتہ: ہر ادیب کی ایک مشہور تصنیف کا نام ضرور یاد رکھیں۔"
 ],
 "9th|Physics|Numericals: Kinematics and Dynamics": [
  "Speed = distance/time; velocity = displacement/time; SI unit of both is m/s.",
  "Acceleration a = (v - u)/t; its SI unit is m/s². Retardation is negative acceleration.",
  "First equation of motion: v = u + at (use when time is given, distance not needed).",
  "Second equation: S = ut + ½at² (use when distance is asked and final velocity unknown).",
  "Third equation: 2aS = v² - u² (use when time is not given).",
  "Newton's second law: F = ma; SI unit of force is newton (N) = kg·m/s².",
  "Weight W = mg where g = 10 m/s²; mass is constant but weight changes with gravity.",
  "Exam tip: always write given data, formula, substitution and final unit — stepwise marks are given."
 ],
 "9th|Physics|Numericals: Gravitation, Work and Energy": [
  "Newton's law of gravitation: F = G(m1m2)/r²; G = 6.673 × 10^-11 N·m²/kg².",
  "Value of g decreases with altitude and depth; g is maximum at sea level (poles) and zero at Earth's centre.",
  "Mass of Earth can be found by M = gR²/G where R is Earth's radius.",
  "Work W = Fd; 1 joule = 1 N × 1 m. Work is zero when force is perpendicular to displacement.",
  "Kinetic energy K.E. = ½mv²; potential energy P.E. = mgh.",
  "Power P = W/t; SI unit is watt (W); 1 horsepower = 746 W.",
  "Efficiency = (output energy/input energy) × 100%; always less than 100% in real machines.",
  "Law of conservation of energy: energy can neither be created nor destroyed, only converted from one form to another."
 ],
 "9th|Physics|Physics Practicals: Vernier Callipers and Screw Gauge": [
  "Vernier callipers measure small lengths, internal/external diameters; least count = 0.01 cm (0.1 mm).",
  "Least count of vernier callipers = (value of 1 main scale division) / (total vernier divisions) = 1mm/10 = 0.1 mm.",
  "Reading = main scale reading + (vernier coincidence × least count).",
  "Zero error: if vernier zero is right of main zero, error is positive and subtracted; if left, negative and added.",
  "Screw gauge measures very small thickness/diameter of wires; least count = 0.01 mm.",
  "Least count of screw gauge = pitch / number of circular divisions = 1mm/100 = 0.01 mm.",
  "Reading = linear scale reading + (circular coincidence × least count).",
  "Exam tip: practice 5 readings of each instrument; zero error correction is asked in viva."
 ],
 "9th|Chemistry|Numericals: Mole Concept and Calculations": [
  "1 mole = 6.02 × 10^23 particles (Avogadro's number); molar mass of water = 18 g/mol.",
  "Number of moles = given mass / molar mass; number of particles = moles × 6.02 × 10^23.",
  "Empirical formula shows the simplest whole-number ratio of atoms; molecular formula shows actual numbers.",
  "Steps for empirical formula: % to mass, mass to moles, divide by smallest, get whole-number ratio.",
  "Molecular formula = n × empirical formula, where n = molecular mass / empirical formula mass.",
  "Percentage composition = (mass of element / molar mass of compound) × 100.",
  "1 mole of any gas at STP occupies 22.4 dm³ (litres).",
  "Exam tip: learn atomic masses of H=1, C=12, N=14, O=16, Na=23, Mg=24, S=32, Cl=35.5, Ca=40 by heart."
 ],
 "9th|Chemistry|Periodic Table: Trends and Uses": [
  "Modern periodic table is arranged by increasing atomic number; it has 7 periods (rows) and 18 groups (columns).",
  "Period number = number of electron shells; group number = number of valence electrons (for main groups).",
  "Atomic size increases down a group (new shell added) and decreases across a period (greater nuclear pull).",
  "Ionization energy decreases down a group and increases across a period.",
  "Electronegativity increases across a period and decreases down a group; fluorine is the most electronegative element.",
  "Metals are on the left/centre (good conductors), non-metals on the right, metalloids (Si, B, As) on the border.",
  "Noble gases (Group 18) are inert because their valence shell is complete.",
  "Exam tip: draw period 3 (Na to Ar) and explain any one trend — a favourite 4-mark question."
 ],
 "9th|Chemistry|Chemistry Practicals: 9th": [
  "Common apparatus: test tube, beaker, flask, burner, litmus paper, pH paper, evaporating dish.",
  "Litmus test: blue litmus turns red in acid; red litmus turns blue in base; no change in neutral solution.",
  "pH scale 0-14: below 7 acidic, 7 neutral, above 7 basic; pH paper gives approximate pH by colour matching.",
  "To test hydrogen gas: it burns with a pop sound when a burning splinter is brought near.",
  "To test oxygen gas: it rekindles a glowing splinter.",
  "To test carbon dioxide: it turns lime water milky.",
  "Filtration separates insoluble solids from liquids; evaporation separates dissolved solids from solutions.",
  "Safety: never taste chemicals, wear safety goggles, add acid to water (never water to acid)."
 ],
 "9th|Biology|Cell Organelles and Their Functions": [
  "Cell wall (plants only): made of cellulose; gives shape and protection to plant cells.",
  "Cell membrane: selectively permeable; controls entry and exit of materials in all cells.",
  "Nucleus: the control centre; contains chromosomes (DNA) that carry hereditary information.",
  "Mitochondria: powerhouse of the cell; release energy from food by respiration.",
  "Chloroplasts (plants): contain chlorophyll; site of photosynthesis.",
  "Ribosomes: tiny bodies that make proteins; found free in cytoplasm or on endoplasmic reticulum.",
  "Vacuole: stores water and wastes; large and central in plant cells, small in animal cells.",
  "Exam tip: draw and label a labelled diagram of animal cell vs plant cell — 5 marks fixed almost every year."
 ],
 "9th|Biology|Biological Diagrams Practice: 9th": [
  "Always draw diagrams with a sharp pencil, label with straight horizontal lines, and give a title.",
  "Animal cell: label nucleus, cell membrane, cytoplasm, mitochondria, vacuole, ribosomes.",
  "Plant cell: label cell wall, chloroplast, large central vacuole, nucleus, cell membrane.",
  "Stages of mitosis: prophase, metaphase, anaphase, telophase — draw each with chromosomes behaviour.",
  "Human heart: label atria, ventricles, aorta, pulmonary artery/vein, valves.",
  "Leaf structure (for photosynthesis): label upper epidermis, palisade cells, xylem, phloem, stomata.",
  "Nephron (kidney): label glomerulus, Bowman's capsule, tubule — asked in 10th but revise early.",
  "Exam tip: a neat labelled diagram can earn full 5 marks even with short theory."
 ],
 "9th|Biology|Human Body Systems: Overview": [
  "Digestive system: mouth, oesophagus, stomach, small/large intestine; digests food and absorbs nutrients.",
  "Respiratory system: nose, trachea, bronchi, lungs (alveoli); exchange of oxygen and carbon dioxide.",
  "Circulatory system: heart, arteries, veins, capillaries; transports blood, oxygen and nutrients.",
  "Nervous system: brain, spinal cord, nerves; coordinates body by electrical messages.",
  "Excretory system: kidneys, ureters, bladder; removes urea and extra water as urine.",
  "Skeletal system: 206 bones in adults; gives support, shape and protection to soft organs.",
  "Muscular system: muscles attached to bones produce movement; three types: skeletal, smooth, cardiac.",
  "Reproductive system: produces gametes; ensures continuation of the species."
 ],
 "9th|Math|Algebra Formula Sheet": [
  "(a + b)² = a² + 2ab + b²; (a - b)² = a² - 2ab + b².",
  "a² - b² = (a + b)(a - b) — the most used factorization formula.",
  "(a + b)³ = a³ + 3a²b + 3ab² + b³; (a - b)³ = a³ - 3a²b + 3ab² - b³.",
  "a³ + b³ = (a + b)(a² - ab + b²); a³ - b³ = (a - b)(a² + ab + b²).",
  "Log laws: log(mn) = log m + log n; log(m/n) = log m - log n; log(m^n) = n log m.",
  "Change of base: log_a(x) = log(x)/log(a); log_a(a) = 1; log(1) = 0.",
  "Surd rules: √a × √b = √(ab); (√a)² = a; rationalize by multiplying with conjugate.",
  "Exam tip: write all formulas on one page and revise daily for 10 minutes — algebra is 40% of the paper."
 ],
 "9th|Math|Geometry: Important Theorems List": [
  "Theorem: angles opposite to equal sides of a triangle are equal (and converse).",
  "Theorem: in any correspondence of two triangles, if three sides of one are equal to three sides of the other, the triangles are congruent (SSS).",
  "Theorem: the line segment joining the midpoints of two sides of a triangle is parallel to the third side and half of it.",
  "Theorem: parallelograms on the same base and between the same parallels are equal in area.",
  "Theorem: triangles on the same base and between the same parallels are equal in area.",
  "Pythagoras theorem: in a right triangle, hypotenuse² = base² + perpendicular².",
  "Theorem: the internal bisector of an angle of a triangle divides the opposite side in the ratio of the sides containing the angle.",
  "Exam tip: each theorem carries a figure + given + to prove + construction + proof — practice the figure first."
 ],
 "9th|Math|Board Paper Practice: 9th Math": [
  "Paper pattern: Section A (15 MCQs), Section B (short questions), Section C (long questions — attempt with choice).",
  "Time management: 15 min for MCQs, 60 min for short questions, 60 min for long questions, 15 min revision.",
  "Most repeated long questions: factorization by grouping, logarithm applications, matrices (multiplication/inverse), linear equations.",
  "Geometry long questions always come from: congruent triangles, parallelograms area, Pythagoras — prepare all proofs.",
  "Do not skip the figure in geometry: a correct labelled figure carries 1-2 marks even if proof is incomplete.",
  "In algebra, verify factorization by expanding back — it catches sign mistakes.",
  "Write statements of theorems word-to-word from the book in proofs.",
  "Attempt the full paper at home in 3 hours with a timer at least 3 times before the board exam."
 ],
 "10th|English|Grammar: Conditional Sentences": [
  "Zero conditional (universal truth): If + present, present — If you heat ice, it melts.",
  "First conditional (possible future): If + present, will + verb — If it rains, we will stay home.",
  "Second conditional (imaginary present): If + past, would + verb — If I were rich, I would help the poor.",
  "Third conditional (imaginary past): If + past perfect, would have + past participle — If he had worked hard, he would have passed.",
  "Note: in second conditional, 'were' is used with all subjects: If I were you, I would apologize.",
  "'Unless' means 'if not': Unless you hurry, you will miss the bus = If you do not hurry, you will miss the bus.",
  "Common error: do not use 'will' in the if-clause — If he will come... is wrong; say If he comes...",
  "Exam tip: board asks to complete conditional sentences — first identify the tense of the given clause, then match the type."
 ],
 "10th|English|Grammar: Active and Passive Voice (Advanced)": [
  "Active: subject does the action (Ali wrote a letter). Passive: subject receives the action (A letter was written by Ali).",
  "Passive formula: object becomes subject + be-verb (matching tense) + past participle (+ by + agent).",
  "Present simple: is/am/are + V3 — They make cars here -> Cars are made here.",
  "Past simple: was/were + V3 — She sang a song -> A song was sung by her.",
  "Future simple: will be + V3 — He will finish the work -> The work will be finished by him.",
  "Present perfect: has/have been + V3 — I have eaten lunch -> Lunch has been eaten by me.",
  "Modals: can/must/should + be + V3 — You must obey the rules -> The rules must be obeyed.",
  "Intransitive verbs (sleep, go, laugh) have no passive; the agent 'by...' is dropped when unknown or obvious."
 ],
 "10th|English|Grammar: Tenses in Reported Speech": [
  "Present simple -> past simple: 'I work hard' -> He said that he worked hard.",
  "Present continuous -> past continuous: 'I am working' -> He said that he was working.",
  "Present perfect -> past perfect: 'I have worked' -> He said that he had worked.",
  "Past simple -> past perfect: 'I worked' -> He said that he had worked.",
  "will -> would: 'I will work' -> He said that he would work; can -> could; may -> might.",
  "No tense change when the reporting verb is in present: He says, 'I am ill' -> He says that he is ill.",
  "No change for universal truths: The teacher said, 'The earth moves round the sun' -> ...that the earth moves round the sun.",
  "Exam tip: underline the reporting verb first — if it is 'said' (past), shift every tense one step back."
 ],
 "10th|English|Paragraph and Story Writing": [
  "Paragraph structure: topic sentence (main idea), supporting sentences (details/examples), concluding sentence.",
  "Length: 100-150 words in one paragraph (no line breaks inside).",
  "Common 10th topics: My Aim in Life, A Cricket Match, Morning Walk, My Favourite Personality, Environmental Pollution.",
  "Story elements: title, characters, setting, problem, events in order, climax, moral.",
  "Repeated board stories: A Thirsty Crow, The Greedy Dog, Honesty is the Best Policy, Tit for Tat, A Foolish Stag.",
  "Use past tense and connectors: once upon a time, one day, suddenly, after that, finally, at last.",
  "Write the MORAL in capital letters on a separate line at the end.",
  "Exam tip: a story with a clear title and moral gets full 8 marks even with simple language."
 ],
 "10th|English|Vocabulary: Pair of Words": [
  "Accept (to receive) / Except (excluding): All students except Ali accepted the gift.",
  "Affect (to influence, verb) / Effect (result, noun): Smoking affects health; it has bad effects.",
  "Advice (noun, suggestion) / Advise (verb): He gave me good advice; please advise me.",
  "Principal (head of school) / Principle (rule): The principal explained the principle of honesty.",
  "Stationary (not moving) / Stationery (writing material): The bus was stationary; buy stationery from the shop.",
  "Fair (just/beautiful) / Fare (ticket price): Life is not fair; pay the bus fare.",
  "Weak (not strong) / Week (7 days): He is weak; I will come next week.",
  "Exam tip: 10 pair-of-words carry 5 marks — learn each pair inside one sentence, not alone."
 ],
 "10th|English|Essay Writing Practice": [
  "Essay structure: introduction, 3-4 body paragraphs (one idea each), conclusion.",
  "Introduction: start with a quotation, definition or general statement; end with your thesis (main point).",
  "Body paragraphs: each begins with a topic sentence, then explanation, example or fact from Pakistan.",
  "Conclusion: restate the main idea in new words; end with a hope, suggestion or quotation.",
  "Common 10th essays: My Best Friend, A Visit to a Historical Place, My Hobby, Science in Daily Life, A Road Accident.",
  "Use varied vocabulary and 4-5 linking words per essay: moreover, however, therefore, for example, in conclusion.",
  "Length: 200-250 words; write in paragraphs with a one-line gap between them.",
  "Exam tip: learn 2 quotations for each favourite essay — quotations add 1-2 extra marks."
 ],
 "10th|Chemistry|Water: Sources, Quality and Purification": [
  "Water is a universal solvent; its formula is H2O; pure water is neutral with pH 7.",
  "Sources: rain, rivers, lakes, wells, tube wells, glaciers and sea water.",
  "Hard water contains dissolved calcium and magnesium salts; it wastes soap and forms boiler scale.",
  "Temporary hardness (bicarbonates) is removed by boiling; permanent hardness (sulphates/chlorides) needs washing soda or ion exchange.",
  "Water pollution causes waterborne diseases: cholera, typhoid, dysentery, hepatitis.",
  "Purification steps at waterworks: sedimentation, filtration, chlorination (kills germs).",
  "Boiling for 15-20 minutes kills germs at home; chlorination tablets are used in emergencies.",
  "Exam tip: difference between temporary and permanent hardness with removal methods is a fixed 4-mark question."
 ],
 "10th|Chemistry|Numericals: Equilibrium, Acids and Salts": [
  "Law of mass action: Kc = [products]^coefficients / [reactants]^coefficients at equilibrium.",
  "For N2 + 3H2 ⇌ 2NH3: Kc = [NH3]² / ([N2][H2]³).",
  "Large Kc (>1) means products dominate; small Kc (<1) means reactants dominate.",
  "pH = -log[H+]; [H+] = 10^-pH; for pH 3, [H+] = 10^-3 mol/dm³.",
  "pH + pOH = 14; neutral pH = 7; acidic < 7; basic > 7.",
  "Mole calculations in titrations: M1V1 = M2V2 for acid-base neutralization (1:1 ratio).",
  "Percentage of an element in a salt: (atomic mass × atoms / molar mass of salt) × 100.",
  "Exam tip: in Kc questions, first write the balanced equation, then the expression, then substitute values with units."
 ],
 "10th|Chemistry|Chemistry in Daily Life": [
  "Soaps are sodium/potassium salts of fatty acids; detergents are synthetic and work even in hard water.",
  "Cleansing action: soap molecules have a water-loving head and oil-loving tail that trap grease in micelles.",
  "Fertilizers supply NPK (nitrogen, phosphorus, potassium); urea is 46% nitrogen.",
  "Pesticides kill pests but their overuse pollutes soil and water and harms useful insects.",
  "Plastics are polymers: thermoplastics (melt on heating, e.g. polythene) vs thermosetting (e.g. bakelite).",
  "Cement, glass and steel are chemical industries' products; Pakistan Steel Mills is at Karachi.",
  "Medicines: analgesics relieve pain (aspirin), antibiotics kill bacteria (penicillin), antiseptics prevent germ growth.",
  "Preservatives (sodium benzoate) and food colours are food additives — excess use is harmful to health."
 ],
 "10th|Biology|Pharmacology": [
  "Pharmacology is the study of drugs — their sources, uses, effects and side effects on the body.",
  "Drug sources: plants (morphine from poppy, quinine from cinchona bark), animals (insulin), minerals and synthetic labs.",
  "Analgesics relieve pain (aspirin, paracetamol); antibiotics kill or stop bacteria (penicillin, amoxicillin).",
  "Vaccines give immunity: BCG (tuberculosis), polio drops, measles, hepatitis-B vaccines are given to children in Pakistan.",
  "Antiseptics (Dettol, spirit) are applied on skin; disinfectants (phenyl) clean floors and toilets.",
  "Drug addiction: repeated use of narcotics (heroin, charas) damages brain, liver and social life — say no to drugs.",
  "Self-medication is dangerous: always use medicines on a doctor's prescription and complete the full course of antibiotics.",
  "Exam tip: classify 6 drugs with one example each — a favourite short-question set."
 ],
 "10th|Biology|Human Brain and Senses": [
  "The brain has three parts: cerebrum (thinking, memory), cerebellum (balance, coordination), medulla (heartbeat, breathing).",
  "Neurons are nerve cells; a nerve impulse travels as an electrical signal along the axon.",
  "Reflex action is a quick automatic response (pulling hand from hot object) controlled by the spinal cord.",
  "Eye: retina contains rods (dim light) and cones (colour vision); the optic nerve carries images to the brain.",
  "Ear: eardrum vibrates, ear ossicles amplify, cochlea converts sound to nerve signals.",
  "Skin is the largest sense organ — touch, pressure, pain and temperature receptors lie in the dermis.",
  "Tongue tastes sweet, salty, sour, bitter; nose smells through olfactory receptors.",
  "Disorders: myopia (short sight, concave lens), hyperopia (long sight, convex lens)."
 ],
 "10th|Biology|Biological Diagrams Practice: 10th": [
  "Human heart: draw two atria, two ventricles, aorta, pulmonary trunk, vena cava; show arrows of blood flow.",
  "Nephron: label glomerulus, Bowman's capsule, proximal tubule, loop of Henle, distal tubule, collecting duct.",
  "Human brain: label cerebrum, cerebellum, medulla oblongata, spinal cord.",
  "Eye structure: label cornea, lens, iris, retina, optic nerve, vitreous humour.",
  "Flower (for reproduction): label sepals, petals, stamen (anther + filament), carpel (stigma, style, ovary).",
  "Bacterial cell: label cell wall, cell membrane, cytoplasm, ribosomes, flagellum, circular DNA.",
  "Use a sharp pencil, single straight label lines, and write labels on one side only.",
  "Exam tip: practice each diagram 3 times with a timer — neatness carries marks in board checking."
 ],
 "10th|Physics|Numericals: Electrostatics and Current Electricity": [
  "Coulomb's law: F = k(q1q2)/r²; k = 9 × 10^9 N·m²/C².",
  "Electric field E = F/q; unit N/C or V/m; field lines go from positive to negative charge.",
  "Potential V = W/q; 1 volt = 1 joule/coulomb.",
  "Ohm's law: V = IR; resistance R = V/I; SI unit ohm (Ω).",
  "Resistors in series: R = R1 + R2; in parallel: 1/R = 1/R1 + 1/R2.",
  "Electric power P = VI = I²R = V²/R; commercial unit is kilowatt-hour (kWh) = 3.6 × 10^6 J.",
  "Energy E = Pt; cost = units consumed (kWh) × rate per unit.",
  "Exam tip: in circuit numericals, first decide series or parallel, then apply the right formula."
 ],
 "10th|Physics|ICT: Email, Internet and E-Commerce": [
  "ICT = Information and Communication Technology: use of computers and telecom for storing and sharing information.",
  "Components: hardware, software, data, people, communication networks.",
  "Email parts: username@domain; inbox, sent, drafts, spam folders; CC/BCC for copies.",
  "E-commerce: buying and selling online; examples in Pakistan: Daraz, Foodpanda, OLX.",
  "Online banking and mobile banking (JazzCash, Easypaisa) transfer money without visiting a bank.",
  "Video conferencing (Zoom, Meet) allows face-to-face meetings over the Internet.",
  "Social media uses: education, business marketing, news — and risks: fake news, privacy loss, addiction.",
  "Cyber safety: strong passwords, no unknown links, verify news before sharing, report cybercrime to FIA."
 ],
 "10th|Physics|Nuclear Energy and Its Uses": [
  "Nuclear fission: a heavy nucleus (U-235) splits into lighter nuclei releasing huge energy; used in power plants.",
  "Nuclear fusion: light nuclei (hydrogen) join to form helium releasing energy; powers the sun and stars.",
  "E = mc² (Einstein): a small mass converts into enormous energy in nuclear reactions.",
  "Pakistan's nuclear power plants: KANUPP (Karachi), CHASNUPP (Mianwali) generate electricity.",
  "Medical uses: radiotherapy treats cancer; radioactive tracers diagnose diseases.",
  "Pakistan became a nuclear power on 28 May 1998 (Youm-e-Takbeer) after tests at Chaghi.",
  "Radiation hazards: can cause cancer and genetic damage; controlled with lead shielding and safety rules.",
  "Background radiations come from cosmic rays, rocks and soil — small doses are harmless."
 ],
 "10th|Physics|Physics Practicals: Mirrors and Lenses": [
  "Concave mirror: converges light; used in headlights, shaving mirrors, solar furnaces.",
  "Convex mirror: diverges light, gives wide view; used as rear-view and shop security mirrors.",
  "Mirror formula: 1/f = 1/v + 1/u; f = R/2; sign convention: distances measured against incident light are negative.",
  "Convex lens converges light (used in cameras, magnifiers); concave lens diverges (used in myopia glasses).",
  "Lens formula: 1/f = 1/v - 1/u; power of lens P = 1/f (dioptre) where f is in metres.",
  "To find focal length practically: focus a distant object on a screen; distance from lens to screen = f.",
  "Prism splits white light into 7 colours (dispersion); total internal reflection is used in optical fibres.",
  "Viva tip: state the laws of reflection (angle i = angle r) and refraction (Snell's law) without hesitation."
 ],
 "10th|Computer Science|Data Types, Operators and Expressions": [
  "C data types: int (whole numbers), float (decimals), double (large decimals), char (single character).",
  "Size: int 2 or 4 bytes, float 4 bytes, double 8 bytes, char 1 byte (depends on compiler).",
  "Variable: a named memory location that stores a value; rules: start with letter/underscore, no spaces, case-sensitive.",
  "Arithmetic operators: + - * / % (modulus gives remainder); relational: < > <= >= == !=; logical: && || !.",
  "Assignment: = stores a value; == compares two values — confusing them is the most common beginner error.",
  "Increment/decrement: ++ adds 1, -- subtracts 1; a++ is post, ++a is pre-increment.",
  "Type conversion: implicit (int to float automatically) and explicit casting: (float)a/b.",
  "printf() prints output, scanf() takes input; format specifiers: %d int, %f float, %c char, %s string."
 ],
 "10th|Computer Science|Pointers in C: Introduction": [
  "A pointer is a variable that stores the memory address of another variable.",
  "Declaration: int *p; — the * shows p is a pointer to an integer.",
  "& (address-of) gives the address: p = &x; stores address of x in p.",
  "* (dereference) gives the value at the address: *p means the value stored in x.",
  "Example: int x = 5; int *p = &x; printf('%d', *p); prints 5.",
  "Pointers allow functions to change original variables (call by reference) using addresses as arguments.",
  "NULL pointer points to nothing: int *p = NULL; — always initialize pointers before use.",
  "Common error: using an uninitialized pointer crashes the program; using *p without & assignment gives garbage."
 ],
 "10th|Computer Science|Preprocessor Directives and Header Files": [
  "Preprocessor directives start with # and run before compilation; #include adds header files.",
  "#include <stdio.h> brings printf() and scanf(); #include <conio.h> brings clrscr() and getch().",
  "#include <math.h> brings sqrt(), pow(), sin(), cos(); link with -lm on some compilers.",
  "#include <string.h> brings strlen(), strcpy(), strcmp() for string handling.",
  "#define PI 3.14159 creates a constant macro — every PI is replaced before compiling; no semicolon at end.",
  "Difference: #include <file> searches system folders; #include 'file' searches the current folder first.",
  "Conditional compilation (#ifdef) includes code only when a macro is defined — used in large projects.",
  "Exam tip: write which header file each library function needs — 1 mark per function is common."
 ],
 "10th|Computer Science|Structures in C": [
  "A structure groups different data types under one name, e.g. a student with name, roll number and marks.",
  "Declaration: struct Student { char name[20]; int roll; float marks; }; — note the semicolon after }.",
  "Variable: struct Student s1; members accessed with dot: s1.roll = 5; strcpy(s1.name, 'Ali').",
  "Structures remove the need for many parallel arrays — one array of structures holds whole records.",
  "Array of structures: struct Student class[30]; access: class[i].marks = 90.5;",
  "Nested structure: a structure inside another, e.g. struct Date inside struct Student.",
  "Difference from array: array holds same-type items; structure holds different-type items.",
  "typedef gives a short name: typedef struct Student STU; then STU s1; works directly."
 ],
 "10th|Islamiat|اسلامی معیشت کا تعارف": [
  "اسلامی معیشت اللہ کی ملکیت کے تصور پر مبنی ہے — انسان امانت دار ہے، مالک نہیں۔",
  "سود (ربا) حرام ہے: قرآن میں سود خور کے خلاف اللہ اور رسول سے جنگ کا اعلان ہے (البقرۃ: 279)۔",
  "زکوٰۃ مال کو پاک کرتی ہے اور غربت ختم کرتی ہے — نصاب پر ڈھائی فیصد سالانہ۔",
  "ناجائز ذرائع آمدنی: سود، جوا، رشوت، ذخیرہ اندوزی اور دھوکہ — سب حرام ہیں۔",
  "جائز تجارت کی شرائط: باہمی رضامندی، واضح معاہدہ، ناپ تول میں انصاف۔",
  "اسلامی بینکاری: مضاربہ، مشارکہ اور مرابحہ کی بنیاد پر سود سے پاک نظام۔",
  "محنت کی عظمت: ہاتھ کی کمائی بہترین روزی ہے — حدیث کے مطابق کوئی کھانا ہاتھ کی کمائی سے بہتر نہیں۔",
  "امتحانی نکتہ: سود کی حرمت کی قرآنی دلیل اور زکوٰۃ کے معاشی فوائد ضرور لکھیں۔"
 ],
 "10th|Islamiat|اسلام میں علم کی اہمیت": [
  "پہلی وحی کا پہلا لفظ 'اقرأ' (پڑھیے) تھا — علم اسلام کی بنیاد ہے۔",
  "قرآن: 'کیا جاننے والے اور نہ جاننے والے برابر ہو سکتے ہیں؟' (الزمر: 9)۔",
  "حدیث: علم حاصل کرنا ہر مسلمان مرد و عورت پر فرض ہے (ابن ماجہ)۔",
  "علماء انبیاء کے وارث ہیں — حدیث کے مطابق عالم کی فضیلت عابد پر ایسی ہے جیسے چاند کی ستاروں پر۔",
  "مسلمان سائنسدان: ابن سینا (طب)، الخوارزمی (الجبرا)، ابن الہیثم (بصریات)، جابر بن حیان (کیمیا)۔",
  "علم نافع وہ ہے جو عمل میں آئے — بے عمل علم پر وعید آئی ہے۔",
  "دینی و دنیوی دونوں علوم اہم ہیں — طب، انجینئرنگ اور ٹیکنالوجی بھی خدمتِ خلق کا ذریعہ ہیں۔",
  "امتحانی نکتہ: 'اقرأ' والی آیت اور علم کی فرضیت والی حدیث حوالے سمیت یاد کریں۔"
 ],
 "10th|Pak Studies|پاکستان کے قدرتی وسائل": [
  "قدرتی وسائل: زمین، پانی، معدنیات، جنگلات اور توانائی کے ذرائع۔",
  "زرعی وسائل: پنجاب اور سندھ کی زرخیز زمین؛ گندم، چاول، کپاس اور گنا اہم فصلیں۔",
  "آبی وسائل: دریائے سندھ کا نظام؛ تربیلا اور منگلا بڑے ڈیم؛ کالا باغ متنازع منصوبہ۔",
  "معدنی وسائل: کوئلہ (تھر)، قدرتی گیس (سوئی)، تیل، نمک (کھیوڑہ)، سنگِ مرمر۔",
  "ریکوڈک (بلوچستان) میں سونے اور تانبے کے بڑے ذخائر ہیں۔",
  "توانائی: پن بجلی، تھرمل، جوہری اور شمسی/ہوائی توانائی کے امکانات۔",
  "مسائل: وسائل کا غیر منصفانہ استعمال، آبادی کا دباؤ اور ماحولیاتی آلودگی۔",
  "امتحانی نکتہ: ہر صوبے کا ایک معدنی وسیلہ یاد کریں — مختصر سوالات میں آتا ہے۔"
 ],
 "10th|Pak Studies|پاکستان میں جمہوریت کا سفر": [
  "جمہوریت عوام کی حکمرانی ہے — ووٹ کے ذریعے نمائندوں کا انتخاب۔",
  "پہلا عام انتخاب 1970ء میں ہوا جس میں عوامی لیگ نے مشرقی پاکستان میں کامیابی حاصل کی۔",
  "1973ء کا آئین پارلیمانی جمہوریت کی بنیاد ہے — وزیراعظم سربراہِ حکومت ہوتا ہے۔",
  "فوجی ادوار: ایوب خان (1958)، یحییٰ خان (1969)، ضیاء الحق (1977)، پرویز مشرف (1999)۔",
  "2008ء کے بعد جمہوری تسلسل: ایک منتخب حکومت سے دوسری کو اقتدار کی پرامن منتقلی۔",
  "18ویں ترمیم (2010ء) نے صوبوں کو خودمختاری دی اور جمہوریت مضبوط کی۔",
  "جمہوریت کی مضبوطی کے لیے آزاد عدلیہ، آزاد میڈیا اور شفاف انتخابات ضروری ہیں۔",
  "امتحانی نکتہ: 1970ء کے انتخابات کے نتائج اور اس کے اثرات تفصیل سے یاد کریں۔"
 ],
 "10th|Pak Studies|پاکستان میں تعلیم و صحت": [
  "تعلیم قومی ترقی کی بنیاد ہے — خواندگی کی شرح بڑھانا حکومت کی ذمہ داری ہے۔",
  "آئین کی دفعہ 25-A: 5 سے 16 سال کے بچوں کو مفت اور لازمی تعلیم ریاست فراہم کرے گی۔",
  "تعلیمی ادارے: پرائمری، مڈل، ہائی، کالج اور یونیورسٹیاں؛ ایچ ای سی اعلیٰ تعلیم کی نگران ہے۔",
  "مسائل: اسکولوں کی کمی، اساتذہ کی تربیت، نصاب کی یکسانیت اور ڈراپ آؤٹ۔",
  "صحت کی سہولتیں: بنیادی مراکزِ صحت (BHU)، دیہی مراکز (RHC)، تحصیل اور ضلعی اسپتال۔",
  "قومی پروگرام: پولیو کے قطرے، حفاظتی ٹیکے (EPI)، زچہ و بچہ کی صحت۔",
  "صحت کے مسائل: صاف پانی کی کمی، غذائی قلت اور آبادی کا دباؤ۔",
  "امتحانی نکتہ: دفعہ 25-A کا حوالہ تعلیم والے ہر جواب میں نمبر بڑھاتا ہے۔"
 ],
 "10th|Tarjuma-tul-Quran|سیرتِ نبوی ﷺ قرآنی آیات کی روشنی میں": [
  "قرآن نے نبی کریم ﷺ کو 'رحمۃ للعالمین' قرار دیا (الانبیاء: 107) — تمام جہانوں کے لیے رحمت۔",
  "آپ ﷺ کے اخلاقِ عظیمہ کی گواہی: 'بے شک آپ عظیم اخلاق پر ہیں' (القلم: 4)۔",
  "اطاعتِ رسول اطاعتِ الٰہی ہے: 'جس نے رسول کی اطاعت کی اس نے اللہ کی اطاعت کی' (النساء: 80)۔",
  "آپ ﷺ کی زندگی بہترین نمونہ ہے: 'تمہارے لیے رسول اللہ میں عمدہ نمونہ ہے' (الاحزاب: 21)۔",
  "درود شریف کا حکم: 'بے شک اللہ اور اس کے فرشتے نبی پر درود بھیجتے ہیں' (الاحزاب: 56)۔",
  "مکی دور کی آیات میں توحید و آخرت، مدنی دور میں احکام و معاشرت کا بیان ہے۔",
  "ہجرتِ مدینہ اسلامی تقویم (ہجری) کی بنیاد ہے — 622ء میں ہوئی۔",
  "امتحانی نکتہ: 'رحمۃ للعالمین' اور 'اسوہ حسنہ' والی آیات ترجمے سمیت یاد کریں۔"
 ],
 "10th|Tarjuma-tul-Quran|قرآنی اخلاقیات: منتخب موضوعات": [
  "سچائی: سچ بولو — جھوٹ منافقت کی علامت ہے؛ قرآن سچوں کے ساتھ رہنے کا حکم دیتا ہے (التوبہ: 119)۔",
  "امانت: امانتیں ان کے حقداروں کو پہنچاؤ (النساء: 58) — وعدہ خلافی منافق کی نشانی ہے۔",
  "صبر: مصیبت پر صبر کرو — 'بے شک اللہ صبر کرنے والوں کے ساتھ ہے' (البقرۃ: 153)۔",
  "شکر: نعمت پر شکر کرو — 'اگر تم شکر کرو گے تو میں تمہیں اور دوں گا' (ابراہیم: 7)۔",
  "عفو و درگزر: معاف کرنا اللہ کو پسند ہے — 'اور معاف کر دو، بے شک اللہ معاف کرنے والوں سے محبت کرتا ہے'۔",
  "غیبت کی ممانعت: غیبت مردہ بھائی کا گوشت کھانے کے برابر ہے (الحجرات: 12)۔",
  "اسراف سے بچو: 'بے شک اسراف کرنے والے شیطانوں کے بھائی ہیں' (بنی اسرائیل: 27)۔",
  "امتحانی نکتہ: ہر اخلاقی موضوع کی ایک آیت بمع ترجمہ لکھنے کی مشق کریں۔"
 ],
 "10th|Urdu|اردو گرامر: تشبیہ، استعارہ اور کنایہ": [
  "تشبیہ: ایک چیز کو دوسری سے مشابہت کی بنا پر ملانا — ارکان: مشبہ، مشبہ بہ، وجہ شبہ، حرفِ تشبیہ۔",
  "مثال: 'وہ چاند جیسا حسین ہے' — وہ (مشبہ)، چاند (مشبہ بہ)، جیسا (حرفِ تشبیہ)، حسین (وجہ شبہ)۔",
  "استعارہ: مشبہ کو حذف کر کے صرف مشبہ بہ کا ذکر — 'چاند نکل آیا' (محبوب کے لیے)۔",
  "تشبیہ اور استعارے میں فرق: تشبیہ میں حرفِ تشبیہ (جیسا، مانند) ہوتا ہے، استعارے میں نہیں۔",
  "کنایہ: ایسا کلام جس سے مراد لفظی معنی نہ ہو بلکہ اشارۃً دوسرا معنی ہو — 'اس کے ہاتھ کھلے ہیں' (سخی)۔",
  "مجاز مرسل: ایک لفظ کو اس کے حقیقی معنی کے بجائے قریبی معنی میں استعمال کرنا۔",
  "صنعتِ تضاد: متضاد الفاظ کا ایک ساتھ استعمال — 'دن رات محنت کرتا ہے'۔",
  "امتحانی نکتہ: ہر صنعت کی تعریف کے ساتھ ایک مثال لکھیں — نمبر یقینی ہوتے ہیں۔"
 ],
 "10th|Urdu|خط نویسی اور خلاصہ نویسی": [
  "خط ذاتی یا کاروباری پیغام رسانی کا تحریری ذریعہ ہے۔",
  "خط کے حصے: پتہ، تاریخ، القاب، متن (آغاز، اصل بات، اختتام)، دستخط۔",
  "دوست کو خط: غیر رسمی انداز — 'عزیزم' سے آغاز، احوال پوچھنا، 'تمہارا دوست' پر اختتام۔",
  "والد کو خط: ادب کے ساتھ — تعلیمی رپورٹ، ضروریات اور دعاؤں کی درخواست۔",
  "مدیر کو خط: رسمی انداز — اخبار میں شکایت یا تجویز کے لیے۔",
  "خلاصہ: کسی عبارت یا سبق کا مختصر اور جامع بیان — اصل کا ایک تہائی۔",
  "خلاصے میں صرف مرکزی خیال ہو — تفصیل، مثالیں اور اقتباسات نہ ہوں۔",
  "امتحانی نکتہ: خط میں پتہ اور تاریخ لکھنا نہ بھولیں — فارمیٹ کے الگ نمبر ہیں۔"
 ],
 "10th|Urdu|اردو افسانہ نگاری کا تعارف": [
  "افسانہ مختصر نثری کہانی ہے — ایک ہی واقعہ، محدود کردار اور ایک مرکزی خیال۔",
  "افسانے کے عناصر: پلاٹ، کردار نگاری، مکالمہ، ماحول اور نقطۂ نظر۔",
  "پریم چند اردو کے عظیم افسانہ نگار — 'کفن' اور 'پوس کی رات' مشہور افسانے۔",
  "سعادت حسن منٹو: حقیقت نگاری کے امام — 'ٹوبہ ٹیک سنگھ' اور 'کھول دو'۔",
  "کرشن چندر: رومانی اور ترقی پسند افسانے — 'ان داتا'۔",
  "اشفاق احمد اور بانو قدسیہ نے جدید اردو افسانے کو نئی جہت دی۔",
  "افسانہ اور ناول میں فرق: افسانہ مختصر اور ایک واقعے پر، ناول طویل اور کئی واقعات پر مبنی۔",
  "امتحانی نکتہ: دو افسانہ نگاروں کے نام اور ان کے ایک ایک افسانے کا نام یاد رکھیں۔"
 ],
 "10th|Urdu|نعت کا فن": [
  "نعت رسول اکرم ﷺ کی مدح میں کہی گئی شاعری ہے۔",
  "نعت میں حضور ﷺ کے فضائل، معجزات اور سیرت کا بیان ہوتا ہے۔",
  "مشہور نعت گو شعرا: حسان بن ثابت (پہلے نعت گو)، امام احمد رضا (حدائقِ بخشش)، مظفر وارثی۔",
  "نعت اور حمد میں فرق: حمد اللہ کی تعریف میں، نعت رسول ﷺ کی مدح میں۔",
  "نعت خوانی پاکستان کی مذہبی ثقافت کا اہم حصہ ہے — محافلِ نعت عام ہیں۔",
  "نعت میں ادب و احترام کا خاص خیال رکھا جاتا ہے — الفاظ کا انتخاب محتاط ہو۔",
  "مشہور نعتیہ اشعار: 'فاصلوں کو تکلف ہے ہم سے اگر' (مظفر وارثی)۔",
  "امتحانی نکتہ: نصابی نعت کے شاعر کا نام اور مرکزی خیال ضرور لکھیں۔"
 ],
 "10th|Math|Trigonometry Identities Practice": [
  "sin²θ + cos²θ = 1; 1 + tan²θ = sec²θ; 1 + cot²θ = csc²θ.",
  "Standard angles: sin 30° = 1/2, cos 30° = √3/2, tan 45° = 1, sin 60° = √3/2.",
  "sin(90° - θ) = cos θ; cos(90° - θ) = sin θ; tan(90° - θ) = cot θ.",
  "To prove identities: start from the harder side and convert everything into sin and cos.",
  "Common pattern: (1 - sinθ)(1 + sinθ) = 1 - sin²θ = cos²θ.",
  "Heights and distances: angle of elevation (looking up), angle of depression (looking down).",
  "tan θ = perpendicular/base; in height problems draw the right triangle first.",
  "Exam tip: memorize the 0°, 30°, 45°, 60°, 90° table — it is asked directly for 3 marks."
 ],
 "10th|Math|Geometry Theorems List: Circles": [
  "Theorem: one and only one circle passes through three non-collinear points.",
  "Theorem: the perpendicular from the centre to a chord bisects the chord (and converse).",
  "Theorem: equal chords of a circle are equidistant from the centre (and converse).",
  "Theorem: the angle in a semicircle is a right angle.",
  "Theorem: angles in the same segment of a circle are equal.",
  "Theorem: the tangent at any point of a circle is perpendicular to the radius through the point of contact.",
  "Theorem: tangents drawn from an external point to a circle are equal in length.",
  "Exam tip: circle theorems need exact figures — practice drawing tangent, chord and segment diagrams neatly."
 ],
 "10th|Math|Board Paper Practice: 10th Math": [
  "Paper pattern: MCQs (15), short questions (attempt with choice), long questions (4-5 with internal choice).",
  "High-weightage chapters: quadratic equations, trigonometry, circles (theorems), statistics.",
  "Statistics long question: always find mean, median or mode from grouped data — practice the formula table.",
  "Trigonometry: identities proof + heights/distances numerical — both are fixed long questions.",
  "Circle theorems: learn statements word-to-word; figure + proof stepwise.",
  "Linear programming: feasible region shading and corner-point method for maximum/minimum.",
  "Do not leave any MCQ blank — there is no negative marking.",
  "Solve the last 5 years' board papers with a 3-hour timer before the exam."
 ],
 "11th|English|Drug Addiction (Essay 15)": [
  "Drug addiction is the 15th essay of Intermediate Part-I English; it warns against narcotics.",
  "The essay explains how drugs destroy the addict's health, family and future.",
  "Causes: bad company, curiosity, unemployment, frustration and easy availability of drugs.",
  "Effects: damage to brain and liver, loss of appetite, criminal behaviour and social isolation.",
  "The essay stresses that prevention is better than cure — youth must be educated about dangers.",
  "Treatment: rehabilitation centres help addicts return to normal life with medical and moral support.",
  "Message: parents and teachers should watch children's company and activities closely.",
  "Exam tip: prepare one quotation on drug abuse, e.g. 'Say no to drugs' theme lines from the essay."
 ],
 "11th|English|Short Story: Thank You M'am": [
  "Author: Langston Hughes; a story of kindness transforming a young thief.",
  "Mrs. Luella Bates Washington Jones catches Roger trying to snatch her purse.",
  "Instead of punishing him, she takes him home, feeds him and gives him money for shoes.",
  "Roger's motive: he wanted money to buy blue suede shoes.",
  "Theme: compassion and trust can reform a person better than punishment.",
  "Character sketch: Mrs. Jones is kind, strong, generous and understanding.",
  "Ending: Roger cannot even say 'thank you' properly — he is overwhelmed by her kindness.",
  "Exam tip: the question 'What did Mrs. Jones do with Roger?' is frequently asked — answer in 5-6 lines."
 ],
 "11th|English|Short Story: Button Button": [
  "Author: Richard Matheson; a science-fiction story about greed and choice.",
  "Mr. Steward offers Norma and Arthur Lewis a button: pressing it gives $50,000 but kills an unknown person.",
  "Norma presses the button out of greed; Arthur throws the button away in anger.",
  "Twist: Mr. Steward returns — Norma's husband Arthur dies in an accident; the $50,000 is his life insurance.",
  "Theme: greed and moral compromise bring tragic consequences.",
  "Irony: Norma thought a stranger would die, but the victim was her own husband.",
  "Message: every choice has a price; easy money always costs something precious.",
  "Exam tip: explain the irony of the ending — it carries the most marks."
 ],
 "11th|English|Short Story: Dark They Were and Golden Eyed": [
  "Author: Ray Bradbury; a science-fiction story set on Mars.",
  "The Bittering family migrates to Mars; gradually their bodies change — golden eyes, dark skin.",
  "They start liking Martian food and climate; their Earth identity fades.",
  "Theme: environment shapes human beings physically and culturally.",
  "When a rescue rocket arrives from Earth, the family no longer wants to return.",
  "Symbolism: the Martian villa and the changing garden show nature reclaiming human effort.",
  "Message: humans adapt to new environments, but adaptation can erase original identity.",
  "Exam tip: describe any two physical changes in the family for short questions."
 ],
 "11th|English|Short Story: The Piece of String": [
  "Author: Guy de Maupassant; a story of false accusation and pride.",
  "Maitre Hauchecorne picks up a piece of string; a rival claims he picked up a lost wallet.",
  "Though innocent, nobody believes him; he repeats his defence obsessively until his death.",
  "Theme: pride, misjudgment and the cruelty of public opinion.",
  "Irony: the wallet is found, yet people think Hauchecorne returned it out of fear — his name is never cleared.",
  "His dying words 'a little piece of string' show how the accusation destroyed his mind.",
  "Message: society should verify facts before judging a person.",
  "Exam tip: the question on Hauchecorne's death and its cause is a favourite."
 ],
 "11th|English|Short Story: Clearing in the Sky": [
  "Author: Jesse Stuart; a touching story of a father's love and sacrifice.",
  "An old father works hard clearing a rocky field so his son can have farmland.",
  "He hides his age and weakness, working beyond his strength out of love.",
  "The son discovers the truth and is moved by his father's silent sacrifice.",
  "Theme: parental love, hard work and selfless sacrifice.",
  "The 'clearing' symbolizes the father's effort to clear difficulties from his son's future.",
  "Message: respect and value parents' sacrifices before it is too late.",
  "Exam tip: write the character sketch of the old father in 8-10 lines for long questions."
 ],
 "11th|English|Poem: The Character of a Happy Life": [
  "Poet: Sir Henry Wotton; a poem describing the qualities of a truly happy man.",
  "The happy man is honest, free from greed, envy and the slavery of passions.",
  "He does not depend on others' praise or fear others' blame.",
  "His desires are limited to what he has; his conscience is clear.",
  "The poem praises simplicity, contentment and moral uprightness.",
  "Central idea: real happiness lies in virtue and a clear conscience, not in wealth or power.",
  "The tone is calm, moral and philosophical.",
  "Exam tip: quote the first two lines and explain 'happy life' in your own words."
 ],
 "11th|English|Poem: Ozymandias": [
  "Poet: P. B. Shelley; a sonnet on the ruins of a proud king's statue.",
  "A traveller describes a broken statue in the desert: 'two vast and trunkless legs of stone'.",
  "The inscription reads: 'My name is Ozymandias, king of kings: Look on my works, ye Mighty, and despair!'",
  "Irony: nothing remains except ruins — time destroyed all his 'works'.",
  "Theme: pride and power are temporary; time defeats even the greatest kings.",
  "The sculptor's art survived the king — art outlives power.",
  "The lone and level sands stretching far away symbolize eternity swallowing human glory.",
  "Exam tip: explain the irony of the inscription — the most repeated question on this poem."
 ],
 "11th|English|Poem: Departure and Arrival": [
  "Poet: Taufiq Rafat; a Pakistani poem about the partition and migration.",
  "The poem describes the painful journey of migrants leaving their homes during 1947.",
  "Images of crowded trains, weary travellers and uncertain destinations create a sorrowful mood.",
  "Theme: the human cost of partition — loss of home, identity and peace.",
  "The poet contrasts the hope of arrival with the grief of departure.",
  "It reflects the shared suffering of millions on both sides of the border.",
  "The poem is a reminder that freedom came with great sacrifice.",
  "Exam tip: as a Pakistani poem, relate it to the Pakistan Movement in your answer."
 ],
 "11th|English|Poem: In the Street of Fruit Stalls": [
  "Poet: Jan Stallworthy; a vivid picture of a colourful bazaar.",
  "The poem describes fruit stalls piled with colours: melons, pomegranates, apples.",
  "Rich imagery appeals to sight, smell and taste — 'a mosaic of colour'.",
  "The street is full of life: vendors calling, customers bargaining, children staring.",
  "Theme: beauty in everyday life; joy found in simple, ordinary scenes.",
  "The poet finds poetry in a common marketplace, not in grand palaces.",
  "Contrast: the freshness of fruit against the dust and noise of the street.",
  "Exam tip: pick two images from the poem and explain their effect — a standard 5-mark question."
 ],
 "11th|English|Poem: Sindhi Woman": [
  "Poet: Jan Stallworthy; a portrait of a hardworking rural woman.",
  "The Sindhi woman carries heavy loads with grace and dignity.",
  "She walks barefoot, balancing pitchers or bundles on her head.",
  "The poet admires her strength, endurance and quiet pride.",
  "Theme: dignity of labour; beauty in hard work and simplicity.",
  "She represents the unsung women of rural Pakistan who sustain families.",
  "The poem contrasts her natural grace with artificial city life.",
  "Exam tip: describe the Sindhi woman's appearance and character in 6-8 lines."
 ],
 "11th|English|Grammar: Punctuation and Capitalization": [
  "Full stop (.) ends a statement; question mark (?) ends a direct question; exclamation (!) shows strong feeling.",
  "Comma (,) separates items in a list, clauses, and the reporting clause: He said, 'I am ill.'",
  "Apostrophe (') shows possession (Ali's book) and contraction (don't = do not).",
  "Quotation marks ('...') enclose direct speech; colon (:) introduces a list or explanation.",
  "Capitalize: first word of a sentence, proper nouns (Lahore, Quran), days, months, languages, the pronoun I.",
  "Capitalize titles: Mr., Dr., Quaid-e-Azam; and the first word inside quotation marks in direct speech.",
  "Semicolon (;) joins two related independent clauses: He worked hard; he passed.",
  "Exam tip: punctuation carries 5 marks in 11th paper — read your answer aloud to catch missing stops."
 ],
 "11th|English|Essay Writing: 1st Year": [
  "1st year essays: 300-350 words with introduction, body paragraphs and conclusion.",
  "Popular topics: My Aim in Life, Importance of Education, Inflation/Price Hike, My Best Friend, A Visit to a Museum.",
  "Introduction techniques: quotation, question, definition, or a striking fact.",
  "Each body paragraph = one argument + explanation + example from Pakistan.",
  "Use formal vocabulary; avoid slang and contractions (don't -> do not).",
  "Linking words: firstly, moreover, furthermore, however, on the other hand, in conclusion.",
  "Conclusion: restate thesis, give a suggestion or hopeful ending — never introduce new points here.",
  "Exam tip: prepare 8 essays fully; learn 2 quotations for each — quotations impress the checker."
 ],
 "11th|Biology|Homeostasis": [
  "Homeostasis is the maintenance of a constant internal environment despite external changes.",
  "In plants, stomata regulate water loss (transpiration); guard cells open/close the stomatal pore.",
  "Xerophytes (cacti) reduce water loss with thick cuticle, reduced leaves and deep roots.",
  "In humans, the skin, kidneys, lungs and liver are the main homeostatic organs.",
  "Thermoregulation: sweating cools the body; shivering and vasoconstriction warm it; normal temp 37°C.",
  "Osmoregulation: kidneys balance water and salts; ADH hormone controls water reabsorption.",
  "Blood glucose is controlled by insulin (lowers) and glucagon (raises) from the pancreas.",
  "Feedback mechanism: negative feedback reverses the change (e.g. sweating stops when cool)."
 ],
 "11th|Biology|Support and Movement": [
  "Support in plants: turgor pressure, cell wall (cellulose), and woody xylem tissue.",
  "Types of plant movements: tropic (growth towards stimulus, e.g. phototropism) and nastic (non-directional, e.g. Mimosa leaves).",
  "Human skeleton: 206 bones; axial (skull, vertebral column, ribs) and appendicular (limbs) skeleton.",
  "Joints: immovable (skull), slightly movable (vertebrae), freely movable — ball-and-socket (shoulder), hinge (knee).",
  "Muscles: skeletal (voluntary, striped), smooth (involuntary, gut), cardiac (heart, never tires).",
  "Muscle contraction: sliding filament theory — actin slides over myosin using ATP energy.",
  "Antagonistic pairs: biceps contracts while triceps relaxes to bend the arm.",
  "Disorders: arthritis (joint inflammation), osteoporosis (weak bones), muscle cramps."
 ],
 "11th|Biology|Viruses and Bacteria": [
  "Viruses are acellular — not true cells; they reproduce only inside living host cells.",
  "Virus structure: protein coat (capsid) + nucleic acid (DNA or RNA); some have an envelope.",
  "Bacteriophage infects bacteria; HIV causes AIDS; TMV causes tobacco mosaic disease in plants.",
  "Bacteria are prokaryotes: no true nucleus, circular DNA, reproduce by binary fission every ~20 minutes.",
  "Useful bacteria: decompose waste, fix nitrogen (Rhizobium), make curd/yoghurt (Lactobacillus), produce antibiotics.",
  "Harmful bacteria cause tuberculosis, cholera, typhoid, tetanus — controlled by antibiotics and vaccines.",
  "Gram staining: Gram-positive (purple, thick wall) vs Gram-negative (pink, thin wall).",
  "Difference: viruses need a host to multiply; bacteria can live and multiply independently."
 ],
 "11th|Chemistry|Numericals: Gases, Liquids and Solutions": [
  "Boyle's law: P1V1 = P2V2 (at constant T); Charles's law: V1/T1 = V2/T2 (at constant P); T in kelvin.",
  "General gas equation: P1V1/T1 = P2V2/T2; ideal gas: PV = nRT, R = 0.0821 dm³·atm/mol·K.",
  "Dalton's law: total pressure = sum of partial pressures; Graham's law: rate ∝ 1/√(density).",
  "Molarity M = moles of solute / dm³ of solution; molality m = moles / kg of solvent.",
  "Mole fraction = moles of component / total moles; ppm = mg of solute per kg of solution.",
  "Raoult's law: vapour pressure of solution = mole fraction of solvent × vapour pressure of pure solvent.",
  "Elevation of boiling point and depression of freezing point depend on molality: ΔTb = Kb·m.",
  "Exam tip: convert °C to K (+273) first in every gas numerical — the commonest lost mark."
 ],
 "11th|Chemistry|Atomic Models: Comparison": [
  "Dalton (1803): atom is an indivisible solid sphere — like a billiard ball.",
  "Thomson (1897): plum pudding model — electrons embedded in positive charge; discovered the electron.",
  "Rutherford (1911): nuclear model — tiny dense positive nucleus with electrons around; from gold-foil experiment.",
  "Bohr (1913): electrons revolve in fixed orbits (shells K, L, M, N) with fixed energy; explained hydrogen spectrum.",
  "Quantum mechanical model: electrons exist in orbitals (probability clouds) — s, p, d, f subshells.",
  "Shell capacities: K=2, L=8, M=18, N=32 by the 2n² rule.",
  "Subshell order (Aufbau): 1s 2s 2p 3s 3p 4s 3d 4p... — write electronic configurations with it.",
  "Exam tip: draw all four models with labels — a favourite 5-mark comparison question."
 ],
 "11th|Chemistry|Chemistry Practicals: 1st Year": [
  "Salt analysis: identify one cation (NH4+, Pb2+, Cu2+, Fe2+/3+, Zn2+, Ca2+) and one anion (CO3 2-, Cl-, SO4 2-).",
  "Flame test: calcium gives brick-red, copper gives blue-green flame.",
  "Confirm carbonate: add dilute acid — CO2 turns lime water milky.",
  "Confirm chloride: add AgNO3 — white precipitate of AgCl soluble in NH4OH.",
  "Confirm sulphate: add BaCl2 — white precipitate of BaSO4 insoluble in acids.",
  "Titration: acid-base titration using phenolphthalein (pink in base, colourless in acid).",
  "Standard solution: prepare 0.1 M NaOH or oxalic acid; weigh accurately with a chemical balance.",
  "Viva tip: know the confirmatory test and observation for every ion in the syllabus."
 ],
 "11th|Computer Science|Pointers in C": [
  "Pointer = variable holding a memory address; declared as int *p; float *q;",
  "& gives address: p = &x; * gives value at address: y = *p;",
  "Pointer arithmetic: p++ moves to the next element of its type (by sizeof type bytes).",
  "Pointers and arrays: array name is the address of its first element; *(arr+i) = arr[i].",
  "Call by reference: void swap(int *a, int *b) changes the original variables.",
  "Dynamic memory: malloc() allocates bytes at runtime; free() releases them — check stdlib.h.",
  "Dangling pointer points to freed memory; wild pointer is uninitialized — both cause crashes.",
  "Exam tip: trace *p and &x values on paper for 3-4 examples — pointer tracing is always asked."
 ],
 "11th|Computer Science|Structures and Unions in C": [
  "struct groups different-type members: struct Book { char title[50]; int pages; float price; };",
  "Access with dot: b1.pages = 200; array of structs: struct Book lib[100];",
  "Nested struct: struct Date { int d, m, y; }; inside struct Student for date of birth.",
  "Union: like struct but all members share the same memory — only one member valid at a time.",
  "union Data { int i; float f; char c; }; size of union = size of its largest member.",
  "Difference: struct gives each member separate memory; union overlays all members on one memory block.",
  "typedef creates aliases: typedef struct { int x, y; } Point; then Point p1; works.",
  "Use: structs for records (student, employee); unions to save memory in embedded systems."
 ],
 "11th|Computer Science|File Handling Basics": [
  "File = permanent storage on disk; text files store readable characters, binary files store raw bytes.",
  "FILE *fp; declares a file pointer; fopen('data.txt', 'w') opens for writing, 'r' for reading, 'a' for appending.",
  "Always check: if (fp == NULL) — file may not exist or disk may be full.",
  "fputc/fputs write, fgetc/fgets read; fprintf/fscanf do formatted file I/O like printf/scanf.",
  "fclose(fp); must close every opened file — it saves data and frees resources.",
  "feof(fp) detects end-of-file; fseek() moves the file position pointer randomly.",
  "Example: copy a file by reading with fgetc in a loop until EOF and writing with fputc.",
  "Exam tip: write the program to count characters/words in a file — the most repeated file-handling question."
 ],
 "11th|Computer Science|Introduction to Databases": [
  "Database: organized collection of related data; DBMS software manages it (MySQL, MS Access, Oracle).",
  "Table = relation: rows are records/tuples, columns are fields/attributes.",
  "Primary key: unique identifier per row (e.g. RollNo); foreign key links two tables.",
  "Normalization removes duplication: 1NF (atomic values), 2NF, 3NF (no transitive dependency).",
  "SQL: DDL (CREATE, ALTER, DROP), DML (INSERT, UPDATE, DELETE), DQL (SELECT).",
  "SELECT name, marks FROM Students WHERE marks > 80 ORDER BY marks DESC;",
  "INSERT INTO Students VALUES (1, 'Ali', 85); UPDATE ... SET ... WHERE ...; DELETE FROM ... WHERE ...;",
  "DBMS advantages: data integrity, security, concurrent access, backup and recovery."
 ],
 "11th|Islamiat|اسلامی قانون کے مصادر: قرآن، سنت، اجماع، قیاس": [
  "قرآن مجید اسلامی قانون کا پہلا اور بنیادی مصدر ہے — اس کے احکام قطعی ہیں۔",
  "سنت: نبی کریم ﷺ کے اقوال، افعال اور تقریرات — قرآن کی تشریح و توضیح کرتی ہے۔",
  "اجماع: امت کے مجتہدین کا کسی شرعی مسئلے پر اتفاق — حدیث: میری امت گمراہی پر جمع نہ ہوگی۔",
  "قیاس: نئے مسئلے کو علت کی بنا پر پرانے حکم سے ملانا — جیسے شراب پر نشہ آور چیزوں کا قیاس۔",
  "ترتیب: پہلے قرآن، پھر سنت، پھر اجماع، پھر قیاس — اسی ترتیب سے فتویٰ دیا جاتا ہے۔",
  "اجتہاد: اہل علم کا نصوص سے نئے مسائل کا حل نکالنا — ہر دور کی ضرورت ہے۔",
  "فقہی مذاہب (حنفی، مالکی، شافعی، حنبلی) انہی مصادر سے استنباط کے مختلف طریقے ہیں۔",
  "امتحانی نکتہ: چاروں مصادر کی تعریف اور ایک ایک مثال یاد کریں۔"
 ],
 "11th|Islamiat|اسلام اور جدید سائنس": [
  "قرآن نے 1400 سال پہلے سائنسی حقائق بیان کیے جو آج ثابت ہوئے — یہ اس کا معجزہ ہے۔",
  "تخلیقِ کائنات: 'آسمان اور زمین ملے ہوئے تھے، ہم نے انہیں جدا کیا' (الانبیاء: 30) — بگ بینگ کی طرف اشارہ۔",
  "جنینیات: نطفے سے علقہ، پھر مضغہ کے مراحل (المؤمنون: 12-14) جدید ایمبریالوجی سے مطابقت رکھتے ہیں۔",
  "پہاڑوں کو میخوں سے تشبیہ (النبأ: 7) — جدید جیولوجی میں پہاڑوں کی جڑوں کا ثبوت۔",
  "لوہے کا نزول: 'ہم نے لوہا اتارا' (الحدید: 25) — سائنس کے مطابق لوہا خلا سے آیا۔",
  "مسلمان سائنسدانوں (ابن الہیثم، الخوارزمی، ابن سینا) نے جدید سائنس کی بنیاد رکھی۔",
  "اسلام علم کی حوصلہ افزائی کرتا ہے — 'اقرأ' پہلی وحی کا پہلا لفظ ہے۔",
  "امتحانی نکتہ: دو قرآنی آیات اور ان کی سائنسی توضیح لکھیں۔"
 ],
 "11th|Pak Studies|18ویں ترمیم اور صوبائی خودمختاری": [
  "18ویں ترمیم اپریل 2010ء میں منظور ہوئی — صدر آصف زرداری کے دور میں۔",
  "اس ترمیم نے صدر کے 17ویں ترمیم والے اختیارات ختم کر کے پارلیمانی نظام بحال کیا۔",
  "تعلیم اور صحت سمیت کئی وزارتیں صوبوں کو منتقل ہوئیں — صوبائی خودمختاری بڑھی۔",
  "صوبوں کو اپنے وسائل پر زیادہ اختیار ملا؛ این ایف سی ایوارڈ میں صوبوں کا حصہ بڑھا۔",
  "وزیراعظم کی مدت کی حد ختم — کوئی شخص تیسری بار بھی وزیراعظم بن سکتا ہے۔",
  "عدلیہ کی آزادی کے لیے ججوں کی تقرری کا نیا طریقہ (جوڈیشل کمیشن) متعارف ہوا۔",
  "یہ ترمیم 1973ء کے آئین کی اصل روح کی بحالی سمجھی جاتی ہے۔",
  "امتحانی نکتہ: 18ویں ترمیم کی 4 نمایاں تبدیلیاں پوائنٹس میں لکھیں۔"
 ],
 "11th|Pak Studies|پاکستان کی نوجوان نسل اور تعلیم": [
  "پاکستان کی 64 فیصد آبادی 30 سال سے کم عمر ہے — یہ ایک بڑا انسانی وسیلہ ہے۔",
  "تعلیم یافتہ نوجوان ہی ملک کی ترقی کی ضمانت ہیں — ہنر مند افرادی قوت کی ضرورت ہے۔",
  "ٹیکنیکل و ووکیشنل تعلیم (ٹیوٹا، نیوٹیک) نوجوانوں کو روزگار کے قابل بناتی ہے۔",
  "آئی ٹی اور فری لانسنگ نے پاکستانی نوجوانوں کے لیے عالمی مواقع کھولے ہیں۔",
  "مسائل: بے روزگاری، منشیات، انتہا پسندی اور تعلیم کی کمی۔",
  "حکومتی اقدامات: لیپ ٹاپ اسکیم، اسکل ڈیولپمنٹ پروگرام، نوجوانوں کے قرضے۔",
  "نوجوانوں کو مثبت سرگرمیوں (کھیل، مطالعہ، ہنر) کی طرف راغب کرنا ضروری ہے۔",
  "قائداعظم کا فرمان: نوجوان قوم کے معمار ہیں — نظم و ضبط اور ایمانداری اپنائیں۔"
 ],
 "11th|Pak Studies|پاکستان کی خارجہ پالیسی: نئے چیلنجز": [
  "خارجہ پالیسی کے اصول: عدم مداخلت، پرامن بقائے باہمی، مسلم امہ سے یکجہتی۔",
  "بھارت سے تعلقات: کشمیر بنیادی تنازع؛ 1948، 1965، 1971 اور کارگل کی جنگیں۔",
  "چین سے دوستی: 'ہمالیہ سے اونچی، سمندر سے گہری' — سی پیک اس کی عملی شکل ہے۔",
  "افغانستان: امن پاکستان کے مفاد میں ہے؛ مہاجرین کا مسئلہ دیرینہ ہے۔",
  "امریکہ سے تعلقات میں اتار چڑھاؤ — دہشت گردی کے خلاف جنگ میں کردار۔",
  "مسلم دنیا: سعودی عرب، ترکی اور ایران سے برادرانہ تعلقات۔",
  "نئے چیلنجز: اسلاموفوبیا، کشمیر پر عالمی توجہ، معاشی سفارت کاری۔",
  "امتحانی نکتہ: خارجہ پالیسی کے 3 اصول اور 2 اہم تعلقات تفصیل سے لکھیں۔"
 ],
 "11th|Physics|Numericals: Vectors, Motion and Force": [
  "Vector addition: head-to-tail rule; resultant R = √(A² + B² + 2AB cosθ).",
  "Rectangular components: Ax = A cosθ, Ay = A sinθ; A = √(Ax² + Ay²).",
  "Dot product: A·B = AB cosθ (scalar); cross product: A×B = AB sinθ (vector).",
  "Projectile motion: horizontal velocity constant; vertical motion under gravity; range R = vi² sin2θ/g.",
  "Maximum range at 45°; maximum height H = vi² sin²θ/2g.",
  "Newton's laws: F = ma; action-reaction pairs act on different bodies.",
  "Friction: f = μN; static friction adjusts up to a maximum, kinetic friction is constant.",
  "Momentum p = mv; impulse J = F·t = Δp; collisions conserve total momentum."
 ],
 "11th|Physics|Waves: Doppler Effect and Applications": [
  "Doppler effect: apparent change in frequency when source and observer move relative to each other.",
  "Approaching source: higher pitch (ambulance coming); receding: lower pitch (ambulance going).",
  "Formula: f' = f(v ± vo)/(v ∓ vs) — use +vo for approaching observer, -vs for approaching source.",
  "Stationary waves form by superposition of two identical waves travelling in opposite directions.",
  "Nodes = points of zero displacement; antinodes = points of maximum displacement.",
  "In a stretched string: f = (n/2L)√(T/m) — frequency rises with tension, falls with length.",
  "Applications: radar speed guns, medical ultrasound, sonar, red shift of galaxies (expanding universe).",
  "Shock waves form when source speed exceeds wave speed (supersonic jets, sonic boom)."
 ],
 "11th|Physics|Physics Practicals: 1st Year": [
  "Vernier callipers: least count 0.01 cm; measure diameter of a cylinder or sphere.",
  "Screw gauge: least count 0.01 mm; measure wire diameter, then find cross-sectional area πr².",
  "Find g by simple pendulum: T = 2π√(l/g); plot T² vs l graph; slope = 4π²/g.",
  "Verify Boyle's law with a Boyle's law apparatus: plot P vs 1/V — a straight line verifies it.",
  "Find focal length of convex lens by displacement method or distant-object method.",
  "Study the laws of reflection with a plane mirror and pins; angle i = angle r.",
  "Graph work: label axes with units, choose suitable scales, draw the best-fit straight line.",
  "Viva tip: define least count, zero error and parallax error clearly — asked in every viva."
 ],
 "11th|Urdu|اردو نثر: سرسید احمد خان": [
  "سرسید احمد خان (1817-1898) علی گڑھ تحریک کے بانی اور جدید اردو نثر کے امام ہیں۔",
  "انہوں نے مسلمانوں میں جدید تعلیم کی تحریک چلائی — ایم اے او کالج علی گڑھ قائم کیا۔",
  "رسالہ 'تہذیب الاخلاق' جاری کیا جس میں اصلاحی مضامین شائع ہوتے تھے۔",
  "ان کی نثر سادہ، واضح اور دلیل پر مبنی ہے — تصنع سے پاک۔",
  "مشہور مضامین: 'امید کی خوشی' — امید کی اہمیت پر فلسفیانہ مضمون۔",
  "انہوں نے اردو کو سائنسی اور جدید علوم کی زبان بنانے کی کوشش کی۔",
  "سائنٹفک سوسائٹی کے ذریعے انگریزی کتابوں کے اردو تراجم کرائے۔",
  "امتحانی نکتہ: سرسید کی نثر کی 3 خصوصیات اور 2 خدمات لکھیں۔"
 ],
 "11th|Urdu|اردو شاعری: میر تقی میر": [
  "میر تقی میر (1723-1810) 'خدائے سخن' کہلاتے ہیں — اردو غزل کے امام۔",
  "ان کی شاعری میں درد، غم اور انسانی جذبات کی سچی عکاسی ہے۔",
  "مشہور شعر: 'پتّا پتّا بوٹا بوٹا حال ہمارا جانے ہے / جانے نہ جانے گل ہی نہ جانے باغ تو سارا جانے ہے'۔",
  "میر کی غزل میں سادگی، روانی اور فطری جذبات نمایاں ہیں۔",
  "انہوں نے دہلی کی تباہی اور ذاتی دکھوں کو شاعری میں ڈھالا۔",
  "دیوانِ میر ان کا شعری مجموعہ ہے؛ فارسی میں بھی شاعری کی۔",
  "غالب نے میر کی عظمت تسلیم کی: 'ریختے کے تمہیں استاد نہیں ہو غالب / کہتے ہیں اگلے زمانے میں کوئی میر بھی تھا'۔",
  "امتحانی نکتہ: میر کو 'خدائے سخن' کیوں کہا جاتا ہے — 3 وجوہات لکھیں۔"
 ],
 "11th|Urdu|اردو گرامر: علمِ بیان": [
  "علمِ بیان میں الفاظ کے مجازی معنوں اور خوبصورتی کے طریقے بیان کیے جاتے ہیں۔",
  "تشبیہ: مشبہ، مشبہ بہ، وجہِ شبہ اور حرفِ تشبیہ — چار ارکان۔",
  "استعارہ: حرفِ تشبیہ کے بغیر مشبہ بہ کا ذکر — 'شیر آیا' (بہادر کے لیے)۔",
  "کنایہ: اشارے میں بات کہنا — 'سفید پوش' (عزت دار غریب)۔",
  "مجازِ مرسل: سبب سے مسبب مراد لینا — 'بارش ہوئی' (بادل برسا)۔",
  "صنعتِ مبالغہ: حد سے بڑھا کر بیان — 'دریا بہہ نکلا آنکھوں سے'۔",
  "صنعتِ تضاد: متضاد الفاظ کا اجتماع — 'زندگی موت سے مل گئی'۔",
  "امتحانی نکتہ: ہر صنعت کی تعریف + مثال — 10 نمبر کا سوال بن سکتا ہے۔"
 ],
 "11th|Urdu|اردو ڈرامہ کا تعارف": [
  "ڈرامہ اسٹیج پر پیش کی جانے والی کہانی ہے — مکالمے اس کی جان ہیں۔",
  "ڈرامے کے عناصر: کہانی، کردار، مکالمہ، منظر کشی اور اختتام۔",
  "اردو ڈرامے کی ابتدا: امانت لکھنوی کا 'اندر سبھا' (1853ء) پہلا اردو ڈرامہ۔",
  "آغا حشر کاشمیری 'ہندوستان کے شیکسپیئر' کہلاتے ہیں — 'یہودی کی لڑکی' مشہور۔",
  "جدید دور: اشفاق احمد، بانو قدسیہ اور امجد اسلام امجد کے ٹی وی ڈرامے۔",
  "ریڈیو ڈرامہ: آواز اور مکالمے پر مبنی — ساؤنڈ ایفیکٹس سے منظر کشی۔",
  "ٹی وی ڈرامہ پاکستان کی ثقافت کا اہم حصہ — 'وارث'، 'دھوپ کنارے' کلاسک۔",
  "امتحانی نکتہ: اردو کے پہلے ڈرامے اور ڈراما نویس کا نام یاد رکھیں۔"
 ],
 "11th|Urdu|خطوط نویسی: نمونے": [
  "دوست کو خط: غیر رسمی — 'پیارے دوست' سے آغاز، خیریت، اصل بات، 'تمہارا دوست' پر ختم۔",
  "والدین کو خط: 'محترم والد صاحب' — ادب، تعلیمی کارکردگی، ضروریات کا ذکر۔",
  "پرنسپل کو درخواست: 'جناب عالی' — مختصر، شائستہ، مقصد واضح۔",
  "مدیرِ اخبار کو خط: عوامی مسئلے (صفائی، لوڈشیڈنگ) کی نشاندہی۔",
  "خط میں تاریخ اور پتہ اوپر دائیں جانب لکھیں۔",
  "زبان شائستہ اور جملے مختصر ہوں — ایک خط ایک ہی موضوع پر ہو۔",
  "امتحانی نکتہ: بورڈ میں اکثر والد کو یا دوست کو خط آتا ہے — دونوں کے فارمیٹ تیار رکھیں۔"
 ],
 "11th|Math|Trigonometry Formula Sheet": [
  "sin(A+B) = sinA cosB + cosA sinB; sin(A-B) = sinA cosB - cosA sinB.",
  "cos(A+B) = cosA cosB - sinA sinB; cos(A-B) = cosA cosB + sinA sinB.",
  "tan(A+B) = (tanA + tanB)/(1 - tanA tanB); tan(A-B) = (tanA - tanB)/(1 + tanA tanB).",
  "Double angle: sin2A = 2sinA cosA; cos2A = cos²A - sin²A = 1 - 2sin²A = 2cos²A - 1.",
  "tan2A = 2tanA/(1 - tan²A); sin3A = 3sinA - 4sin³A.",
  "Sum to product: sinC + sinD = 2sin((C+D)/2)cos((C-D)/2).",
  "Product to sum: 2sinA cosB = sin(A+B) + sin(A-B).",
  "Sine rule: a/sinA = b/sinB = c/sinC; Cosine rule: a² = b² + c² - 2bc cosA."
 ],
 "11th|Math|Binomial Theorem: Applications": [
  "Binomial theorem: (a+b)^n = Σ C(n,r) a^(n-r) b^r, r = 0 to n.",
  "General term: T(r+1) = C(n,r) a^(n-r) b^r — the (r+1)th term formula.",
  "Number of terms in (a+b)^n is n+1; middle term(s): if n even, one middle term T(n/2 + 1).",
  "C(n,r) = n!/(r!(n-r)!); C(n,0) = C(n,n) = 1; C(n,r) = C(n,n-r).",
  "To find the term independent of x: set the power of x to zero and solve for r.",
  "Approximations: (1+x)^n ≈ 1 + nx for small x — used in error estimation.",
  "Binomial coefficients sum: C(n,0)+C(n,1)+...+C(n,n) = 2^n.",
  "Exam tip: 'find the 5th term' and 'term independent of x' are fixed long questions."
 ],
 "11th|Math|Complex Numbers Practice": [
  "Complex number: z = a + bi where i = √(-1), i² = -1, i³ = -i, i^4 = 1.",
  "Real part Re(z) = a, imaginary part Im(z) = b; conjugate z̄ = a - bi.",
  "Modulus |z| = √(a² + b²); |z|² = z × z̄.",
  "Addition: (a+bi)+(c+di) = (a+c)+(b+d)i; multiplication uses i² = -1.",
  "Division: multiply numerator and denominator by the conjugate of the denominator.",
  "Argand diagram: x-axis = real, y-axis = imaginary; z = a+bi is the point (a,b).",
  "De Moivre's theorem: (cosθ + i sinθ)^n = cos nθ + i sin nθ.",
  "Exam tip: rationalizing 1/(a+bi) with the conjugate is asked in almost every paper."
 ],
 "12th|English|Short Story: The Necklace": [
  "Author: Guy de Maupassant; a story of pride, loss and harsh reality.",
  "Matilda Loisel borrows a diamond necklace from her friend to look rich at a party.",
  "She loses it and replaces it with a real one bought for 36,000 francs, paying through 10 years of poverty.",
  "Twist: the original necklace was fake — worth only 500 francs.",
  "Theme: pride and vanity destroy happiness; honesty about one's position is wiser.",
  "Irony: ten years of suffering were caused by a worthless imitation.",
  "Character: Matilda is beautiful but discontented; her husband is loving and sacrificing.",
  "Exam tip: the ending's irony and Matilda's character sketch are the two most asked questions."
 ],
 "12th|English|Short Story: The Gulistan of Saadi": [
  "Author: Sheikh Saadi; a moral tale from the Persian classic Gulistan.",
  "A king asks a dervish for advice; the dervish teaches him justice and humility.",
  "The story shows that a ruler's power is temporary but good deeds are eternal.",
  "Saadi's wisdom: treat subjects with kindness, for cruelty turns people against the king.",
  "Theme: justice, humility and the moral duty of rulers.",
  "The Gulistan (Rose Garden) is a collection of moral stories and maxims in prose and verse.",
  "Sheikh Saadi (1210-1291) is one of Persia's greatest poets; his other work is Bustan.",
  "Exam tip: write the moral lesson of the story in 5-6 lines for short questions."
 ],
 "12th|English|Short Story: A Man Who Was a Hospital": [
  "Author: Jerome K. Jerome (from 'Three Men in a Boat'); a humorous story of hypochondria.",
  "The narrator reads a medical book and imagines he has every disease except housemaid's knee.",
  "He visits a doctor, who prescribes simple food, exercise and no worry — instead of medicines.",
  "Humour: exaggeration of symptoms and the narrator's serious self-diagnosis.",
  "Theme: overthinking about health creates imaginary illness; a simple life is the best cure.",
  "The doctor's advice — beefsteak, beer, long walks, early bed — mocks the narrator's fears.",
  "Style: first-person comic narration with witty asides.",
  "Exam tip: describe the doctor's prescription — it is the funniest and most asked part."
 ],
 "12th|English|Short Story: The Foolish Quack": [
  "A quack is a fake doctor who treats patients without real medical knowledge.",
  "The story shows a quack whose wrong treatment harms the patient instead of curing him.",
  "Theme: deception and greed; unqualified people cause great damage in society.",
  "Message: always consult qualified doctors; do not trust street healers for serious illness.",
  "The quack's confidence contrasts with his ignorance — a satire on false expertise.",
  "Real-life lesson: check a doctor's degree and registration (PMDC) before treatment.",
  "The story warns against superstition in matters of health.",
  "Exam tip: write the moral and relate it to quackery in rural Pakistan."
 ],
 "12th|English|Poem: The Rebel": [
  "Poet: D. J. Enright; a humorous poem about a non-conformist.",
  "The rebel does the opposite of what society expects: when all grow long hair, he cuts his short.",
  "When others praise the sun, he praises the rain; when all talk, he stays silent.",
  "The poem lists funny contradictions showing the rebel's love of opposition.",
  "Theme: individuality vs conformity; society dislikes those who differ.",
  "Tone: light, witty and playful — not a serious revolutionary poem.",
  "The rebel is not a criminal; he simply refuses to follow the crowd blindly.",
  "Exam tip: give four examples of the rebel's contrary behaviour from the poem."
 ],
 "12th|English|Poem: A Dream Within a Dream": [
  "Poet: Edgar Allan Poe; a poem on the fleeting nature of life.",
  "The poet holds grains of sand slipping through his fingers — time and life slipping away.",
  "Question: 'Is all that we see or seem / But a dream within a dream?'",
  "Theme: life is unreal and temporary; nothing can be held permanently.",
  "The sand symbolizes moments of life; the pitiless wave is cruel time.",
  "Mood: sad, helpless and philosophical.",
  "The poem asks whether we can save even one precious moment from being lost.",
  "Exam tip: explain the sand imagery — the central symbol of the poem."
 ],
 "12th|English|Goodbye Mr Chips: Character Sketches": [
  "Mr. Chipping (Mr. Chips): kind, shy, old-fashioned teacher at Brookfield; loves Latin and his students.",
  "Katherine Bridges: Chips' young wife; lively and modern; softens his strictness; dies in childbirth.",
  "Brookfield School: the public school where Chips teaches for 58 years (1870-1928).",
  "Dr. Merivale: the school doctor and Chips' friend in old age.",
  "Mrs. Wickett: Chips' landlady after retirement; cares for him like family.",
  "Theme of the novel: dedication of a teacher; a teacher lives on in his students' hearts.",
  "Famous line: Chips feels he has no children, but realizes he has thousands — his students.",
  "Exam tip: Chips' character sketch (10-12 lines) is a guaranteed long question."
 ],
 "12th|English|Grammar: Pair of Words (2nd Year)": [
  "2nd year pair-of-words carry 10 marks — double the weight of 1st year.",
  "Bale (bundle) / Bail (security money): a bale of cotton; he was released on bail.",
  "Caste (social class) / Cast (to throw/actors): the cast of the drama; caste system.",
  "Dairy (milk shop) / Diary (daily record): buy milk from the dairy; write in your diary.",
  "Eligible (fit) / Illegible (unreadable): eligible candidate; illegible handwriting.",
  "Later (afterwards) / Latter (second of two): come later; the latter option.",
  "Marry (wed) / Merry (happy): they will marry; a merry festival.",
  "Learn 60 pairs with sentences; 2nd year paper repeats 1st year pairs too."
 ],
 "12th|Biology|Some Major Ecosystems": [
  "Ecosystem = living community + non-living environment interacting as one system.",
  "Aquatic ecosystems: freshwater (rivers, lakes) and marine (oceans cover 71% of Earth).",
  "Terrestrial ecosystems: desert, grassland, temperate forest, tropical rainforest, tundra.",
  "Desert: low rainfall, xerophytes (cacti), nocturnal animals; e.g. Thar desert in Pakistan.",
  "Grassland: grazing animals (deer, buffalo); few trees; fertile soil.",
  "Tropical rainforest: highest biodiversity; heavy rainfall; tall evergreen trees.",
  "Tundra: permanently frozen subsoil (permafrost); mosses, lichens; polar bears.",
  "Pakistan's ecosystems: mangroves (Indus delta), alpine (northern areas), wetlands (Haleji lake)."
 ],
 "12th|Biology|Immunity and Vaccines": [
  "Immunity = the body's ability to resist disease; two types: innate (by birth) and acquired.",
  "Active immunity: body makes its own antibodies after infection or vaccination (long-lasting).",
  "Passive immunity: ready-made antibodies received, e.g. mother's milk to baby (short-term).",
  "Vaccine = weakened/killed germs that train the immune system without causing disease.",
  "EPI vaccines in Pakistan: BCG, polio (OPV), pentavalent (diphtheria, tetanus, hepatitis-B), measles.",
  "Antibodies are Y-shaped proteins made by white blood cells (lymphocytes).",
  "Allergy is an overreaction of immunity (dust, pollen); AIDS destroys immunity via HIV.",
  "Herd immunity: when most people are vaccinated, the disease cannot spread to the few unvaccinated."
 ],
 "12th|Biology|Biological Diagrams Practice: 12th": [
  "L.S. of human kidney: label cortex, medulla, pelvis, ureter, renal artery/vein.",
  "Neuron: label dendrites, cell body, axon, myelin sheath, synapse.",
  "Flower L.S.: label anther, filament, stigma, style, ovary, ovule, sepals, petals.",
  "DNA double helix: label sugar-phosphate backbone, base pairs (A-T, G-C), hydrogen bonds.",
  "Human embryo development stages: zygote, morula, blastula — draw in order.",
  "Ecosystem: draw a food chain and food web with arrows showing energy flow.",
  "Bacterial growth curve: label lag, log, stationary and death phases.",
  "Exam tip: in 12th, diagrams of kidney, neuron and flower are repeated every year."
 ],
 "12th|Chemistry|Environmental Chemistry-II": [
  "Greenhouse gases: CO2, CH4, N2O trap heat — causing global warming.",
  "Ozone layer (stratosphere) blocks UV rays; CFCs from old refrigerators deplete it — Montreal Protocol (1987) bans CFCs.",
  "Acid rain: SO2 and NOx from factories dissolve in rain (pH < 5.6), damaging buildings, crops and lakes.",
  "Smog = smoke + fog; photochemical smog forms from car exhaust in sunlight — Lahore faces severe smog in winter.",
  "Water pollutants: industrial waste, sewage, fertilizers; BOD measures water pollution level.",
  "Solid waste management: reduce, reuse, recycle; landfills vs incineration.",
  "Pakistan's issues: deforestation, water scarcity, air pollution in cities, plastic waste.",
  "Exam tip: causes + effects + control of any one pollution type makes a complete 7-mark answer."
 ],
 "12th|Chemistry|Soaps, Detergents and Cosmetics": [
  "Soap: sodium salt of long-chain fatty acids; made by saponification (oil + NaOH).",
  "Detergent: synthetic surfactant; works in hard water because its calcium salts are soluble.",
  "Micelle: soap molecules arrange with tails in grease and heads in water, lifting dirt away.",
  "Shampoo = detergent + conditioner; toothpaste = mild abrasive + fluoride (prevents cavities).",
  "Cosmetics chemistry: creams are emulsions (oil in water); lipstick uses waxes and pigments.",
  "Antiperspirants contain aluminium compounds that block sweat pores temporarily.",
  "Harmful effects: some fairness creams contain mercury/steroids — damage skin permanently.",
  "Exam tip: saponification reaction with equation is a fixed short question."
 ],
 "12th|Chemistry|Numericals: Organic Reactions and Tests": [
  "Degree of unsaturation: DU = C - H/2 + N/2 + 1; ethane DU=0, ethene DU=1, benzene DU=4.",
  "Markovnikov's rule: in HX addition to alkenes, H adds to the carbon with more hydrogens.",
  "Test for unsaturation: bromine water decolourised (red-brown to colourless) by alkenes/alkynes.",
  "Baeyer's test: pink KMnO4 decolourised by alkenes.",
  "Tollens' test: aldehydes give silver mirror; ketones do not — distinguishes aldehyde from ketone.",
  "Fehling's test: aldehydes give red precipitate of Cu2O; ketones do not.",
  "Iodoform test: yellow precipitate with compounds having CH3CO- group.",
  "2,4-DNP test: orange precipitate with all carbonyl compounds (aldehydes + ketones)."
 ],
 "12th|Computer Science|Data Structures: Stacks and Queues": [
  "Data structure = organized way of storing data for efficient use; e.g. arrays, stacks, queues, trees.",
  "Stack: LIFO (Last In First Out) — like a pile of plates; operations: push (add), pop (remove), peek (see top).",
  "Stack uses: undo feature, function calls, expression evaluation, browser back button.",
  "Queue: FIFO (First In First Out) — like a ticket line; operations: enqueue (add at rear), dequeue (remove from front).",
  "Queue uses: printer jobs, CPU scheduling, call centres, keyboard buffer.",
  "Stack overflow: pushing to a full stack; underflow: popping from an empty stack.",
  "Circular queue reuses empty front spaces — efficient for fixed-size buffers.",
  "Exam tip: trace push/pop sequences on paper — 'show the stack after these operations' is always asked."
 ],
 "12th|Computer Science|Operating System Concepts": [
  "OS = system software managing hardware and programs; e.g. Windows, Linux, Android, macOS.",
  "Functions: process management, memory management, file management, device management, security.",
  "Process: a running program; the OS schedules processes on the CPU (multitasking).",
  "Memory management: allocates RAM to programs; virtual memory uses disk as extra RAM.",
  "File system: organizes data in files/folders; FAT32, NTFS (Windows), ext4 (Linux).",
  "Booting: starting the computer; BIOS/UEFI loads the OS from disk into RAM.",
  "Types: single-user (Windows), multi-user (Linux server), real-time (embedded systems), mobile (Android).",
  "Deadlock: two processes waiting for each other's resources forever — OS must detect and resolve it."
 ],
 "12th|Computer Science|HTML and Web Page Basics": [
  "HTML = HyperText Markup Language; builds the structure of web pages using tags.",
  "Basic skeleton: <html><head><title>Page</title></head><body>content</body></html>.",
  "Tags: <h1> to <h6> headings, <p> paragraph, <a href='url'> link, <img src='pic.jpg'> image.",
  "Lists: <ul> unordered (bullets), <ol> ordered (numbers), <li> list item.",
  "Tables: <table>, <tr> row, <td> data cell, <th> header cell.",
  "Forms: <form>, <input type='text'>, <input type='submit'> — collect user data.",
  "CSS styles pages (colours, layout); JavaScript adds interactivity — HTML alone is static.",
  "Exam tip: write the HTML for a 3-row table or a login form — the standard practical question."
 ],
 "12th|Computer Science|Software Engineering Basics": [
  "Software engineering = systematic development of reliable software using engineering principles.",
  "SDLC phases: requirement analysis, design, coding, testing, deployment, maintenance.",
  "Waterfall model: phases in strict sequence — simple but inflexible to changes.",
  "Agile model: work in short sprints with customer feedback — flexible, used by most companies today.",
  "Testing types: unit (single module), integration (modules together), system (whole software), acceptance (client).",
  "Bugs: errors in code; debugging = finding and fixing them; beta testing uses real users.",
  "Documentation: user manuals and code comments help future maintenance.",
  "Project roles: analyst, designer, programmer, tester, project manager."
 ],
 "12th|Islamiat|اسلام اور حقوقِ نسواں": [
  "اسلام نے عورت کو وراثت، تعلیم، رائے اور مالکیت کے حقوق دیے — 1400 سال پہلے۔",
  "قرآن: 'مردوں کے لیے ان کی کمائی کا حصہ اور عورتوں کے لیے ان کی کمائی کا حصہ ہے' (النساء: 32)۔",
  "وراثت میں عورت کا حصہ مقرر ہے — بیٹی، بیوی اور ماں سب وارث ہیں (النساء: 11-12)۔",
  "تعلیم کا حق: 'علم حاصل کرنا ہر مسلمان مرد و عورت پر فرض ہے'۔",
  "شادی میں عورت کی رضامندی ضروری ہے — زبردستی کا نکاح جائز نہیں۔",
  "حق مہر عورت کا شرعی حق ہے — شوہر پر لازم ہے۔",
  "ماں کا درجہ: 'جنت ماؤں کے قدموں تلے ہے' — والدین میں ماں کا حق تین گنا۔",
  "امتحانی نکتہ: وراثت اور تعلیم کے حقوق قرآنی حوالوں سمیت لکھیں۔"
 ],
 "12th|Islamiat|اسلامی نظامِ عدل": [
  "عدل اسلام کی بنیاد ہے — 'بے شک اللہ عدل اور احسان کا حکم دیتا ہے' (النحل: 90)۔",
  "قاضی کے لیے شرائط: مسلمان، عاقل، بالغ، عادل اور علمِ شرع کا حامل۔",
  "عدالت میں امیر و غریب، حاکم و محکوم سب برابر ہیں — نبی ﷺ نے فرمایا: اگر فاطمہ بھی چوری کرتی تو حد جاری کرتا۔",
  "گواہی: دو مرد یا ایک مرد و دو عورتیں — سچ کی گواہی فرض ہے۔",
  "حدود: چوری، زنا، قذف اور شراب نوشی پر مقرر سزائیں — شرائط سخت ہیں۔",
  "قصاص: جان کے بدلے جان — مگر معافی اور دیت کی گنجائش ہے (البقرۃ: 178)۔",
  "مظلوم کی مدد فرض ہے — 'ظالم کا ہاتھ پکڑو' (حدیث)۔",
  "امتحانی نکتہ: عدل کی اہمیت پر آیت النحل: 90 کا حوالہ ضرور دیں۔"
 ],
 "12th|Islamiat|اسلامی بینکاری کا تعارف": [
  "اسلامی بینکاری سود سے پاک نظام ہے — قرآن میں سود حرام قرار دیا گیا (البقرۃ: 275-279)۔",
  "مضاربہ: ایک فریق سرمایہ دے، دوسرا محنت کرے — نفع معاہدے کے مطابق تقسیم۔",
  "مشارکہ: دونوں فریق سرمایہ لگائیں — نفع و نقصان حصے کے مطابق۔",
  "مرابحہ: بینک چیز خرید کر نفع کے ساتھ قسطوں پر فروخت کرے — قیمت پہلے طے ہو۔",
  "اجارہ: کرایے پر دینا — اسلامی لیزنگ کا طریقہ۔",
  "سلم اور استصناع: زرعی اور صنعتی مالیاتی طریقے۔",
  "پاکستان میں میزان بینک سب سے بڑا اسلامی بینک ہے — اسٹیٹ بینک کی نگرانی میں۔",
  "امتحانی نکتہ: مضاربہ اور مشارکہ میں فرق واضح کر کے لکھیں۔"
 ],
 "12th|Pak Studies|سی پیک اور معاشی راہداری": [
  "سی پیک (CPEC) چین پاکستان اقتصادی راہداری ہے — 2015ء میں معاہدہ ہوا۔",
  "یہ چین کے شہر کاشغر کو گوادر بندرگاہ سے ملاتی ہے — تقریباً 3000 کلومیٹر۔",
  "منصوبے: توانائی (بجلی گھر)، سڑکیں، ریلوے، گوادر پورٹ اور صنعتی زون۔",
  "فوائد: بجلی کا بحران کم ہوا، روزگار کے مواقع، تجارت میں اضافہ۔",
  "گوادر: بلوچستان کی گہرے پانی کی بندرگاہ — علاقائی تجارت کا مرکز بنے گی۔",
  "چیلنجز: سیکیورٹی، قرضوں کا بوجھ اور صوبوں میں فوائد کی تقسیم۔",
  "یہ منصوبہ چین کے 'بیلٹ اینڈ روڈ' کا اہم حصہ ہے۔",
  "امتحانی نکتہ: سی پیک کے 3 معاشی فوائد اور 2 چیلنجز پوائنٹس میں لکھیں۔"
 ],
 "12th|Pak Studies|پاکستان میں میڈیا کا کردار": [
  "میڈیا: پرنٹ (اخبارات)، الیکٹرانک (ٹی وی) اور سوشل میڈیا۔",
  "آزاد میڈیا جمہوریت کا چوتھا ستون ہے — حکومت پر نظر رکھتا ہے۔",
  "مثبت کردار: عوامی آگاہی، تعلیم، احتساب اور قومی یکجہتی۔",
  "منفی پہلو: سنسنی خیزی، جھوٹی خبریں (فیک نیوز) اور اخلاقی بے راہ روی۔",
  "پیمرا الیکٹرانک میڈیا کی نگران ادارہ ہے — ضابطۂ اخلاق نافذ کرتی ہے۔",
  "سوشل میڈیا نے ہر شہری کو صحافی بنا دیا — تصدیق کے بغیر خبر پھیلانا خطرناک ہے۔",
  "مشہور اخبارات: جنگ، ڈان، ایکسپریس، نوائے وقت۔",
  "امتحانی نکتہ: میڈیا کے مثبت و منفی کردار کا موازنہ کریں۔"
 ],
 "12th|Pak Studies|پاکستان کی توانائی کی پالیسی": [
  "توانائی کی اقسام: پن بجلی، تھرمل (تیل/گیس)، جوہری، شمسی اور ہوائی۔",
  "بڑے ڈیم: تربیلا (دریائے سندھ)، منگلا (دریائے جہلم) — پن بجلی کے مراکز۔",
  "تھر کا کوئلہ: پاکستان کے توانائی بحران کا دیرپا حل ہو سکتا ہے۔",
  "جوہری توانائی: چشمہ اور کراچی کے پلانٹ قومی گرڈ کو بجلی دیتے ہیں۔",
  "قابلِ تجدید توانائی: شمسی (بہاولپور کا قائداعظم سولر پارک)، ہوائی (جھمپیر، سندھ)۔",
  "مسائل: لوڈشیڈنگ، گردشی قرضہ، مہنگی بجلی اور ترسیل کے نقصانات۔",
  "بجلی بچانے کے طریقے: ایل ای ڈی بلب، غیر ضروری بتیاں بند، سولر کا استعمال۔",
  "امتحانی نکتہ: قابلِ تجدید ذرائع کے 3 فوائد لکھیں۔"
 ],
 "12th|Physics|Numericals: Electrostatics and Magnetism": [
  "Coulomb's law: F = kq1q2/r², k = 9×10^9 N·m²/C².",
  "Electric field of a point charge: E = kq/r²; direction away from positive charge.",
  "Capacitance C = Q/V; parallel plate: C = ε₀A/d; energy stored U = ½QV = ½CV².",
  "Capacitors in parallel: C = C1 + C2; in series: 1/C = 1/C1 + 1/C2.",
  "Magnetic force on a moving charge: F = qvB sinθ; maximum when v perpendicular to B.",
  "Force on current wire: F = ILB sinθ; unit of B is tesla (T).",
  "Faraday's law: induced emf ε = -N(ΔΦ/Δt); Lenz's law gives the negative sign (opposition).",
  "Transformer: Vs/Vp = Ns/Np; step-up raises voltage, step-down lowers it; power in ≈ power out."
 ],
 "12th|Physics|X-Rays: Production and Uses": [
  "X-rays are electromagnetic waves of very short wavelength (0.01-10 nm), discovered by Roentgen (1895).",
  "Production: fast electrons strike a tungsten target in a Coolidge tube; sudden deceleration emits X-rays.",
  "Two types: continuous spectrum (braking radiation) and characteristic X-rays (inner-shell transitions).",
  "Properties: penetrate soft tissue, ionize gases, affect photographic film, travel at speed of light.",
  "Medical: X-ray imaging of bones, CT scans, radiotherapy for cancer.",
  "Industrial: check cracks in metal parts, scan luggage at airports, study crystal structure (X-ray diffraction).",
  "Safety: lead aprons and shielding — excessive exposure causes burns and cancer.",
  "Bragg's law: nλ = 2d sinθ — used to find spacing between crystal planes."
 ],
 "12th|Physics|Physics Practicals: 2nd Year": [
  "Find resistance by ammeter-voltmeter method: R = V/I; plot V vs I — slope = R.",
  "Verify Ohm's law: V-I graph must be a straight line through the origin.",
  "Find emf and internal resistance of a cell using a potentiometer.",
  "Study the I-V characteristics of a diode: forward bias conducts, reverse bias blocks.",
  "Find the refractive index of glass slab: n = sin i / sin r using pins and a glass block.",
  "Determine the focal length of a concave mirror by u-v method: 1/f = 1/v + 1/u.",
  "Find the frequency of AC mains using a sonometer/meldes apparatus.",
  "Viva tip: state Ohm's law, laws of refraction and the diode's working in one line each."
 ],
 "12th|Urdu|اردو ادب: ترقی پسند تحریک": [
  "ترقی پسند تحریک 1936ء میں لکھنؤ کے اجلاس سے شروع ہوئی — سجاد ظہیر بانیوں میں تھے۔",
  "مقصد: ادب کو عوامی مسائل (غربت، ظلم، استحصال) کی ترجمانی بنانا۔",
  "اہم ادیب: پریم چند، کرشن چندر، سعادت حسن منٹو، فیض احمد فیض، علی سردار جعفری۔",
  "فیض کی شاعری میں انقلاب اور انسانی ہمدردی نمایاں ہے — 'مجھ سے پہلی سی محبت'۔",
  "منٹو نے سماج کی تلخ حقیقتوں کو بے باکی سے لکھا۔",
  "اس تحریک نے اردو افسانے اور نظم کو نئی زندگی دی۔",
  "تنقید: بعض نقادوں نے اسے ادب پر سیاست حاوی کرنے کا الزام دیا۔",
  "امتحانی نکتہ: تحریک کا سال (1936) اور 3 ادیبوں کے نام یاد رکھیں۔"
 ],
 "12th|Urdu|اردو گرامر: علمِ عروض کا تعارف": [
  "علمِ عروض شعر کے وزن اور بحر کا علم ہے — خلیل بن احمد اس کے بانی ہیں۔",
  "رکن: وزن کی اکائی، جیسے فاعلن، مفاعیلن، مستفعلن۔",
  "بحر: ارکان کی مخصوص ترتیب — ہر بحر کا اپنا نام اور آہنگ ہے۔",
  "مشہور بحریں: بحرِ ہزج (مفاعیلن مفاعیلن)، بحرِ رجز (مستفعلن مستفعلن)۔",
  "قافیہ: شعر کے آخر میں ہم آواز الفاظ — 'دل، مشکل، قاتل'۔",
  "ردیف: قافیے کے بعد دہرایا جانے والا لفظ — 'ہے'، 'گیا'۔",
  "مطلع: غزل کا پہلا شعر جس کے دونوں مصرعے ہم قافیہ ہوں۔",
  "امتحانی نکتہ: قافیہ اور ردیف میں فرق ایک مثال سے واضح کریں۔"
 ],
 "12th|Urdu|روداد نویسی اور مکتوب نگاری": [
  "روداد کسی واقعے یا سفر کی تفصیلی تحریری رپورٹ ہے۔",
  "روداد کے حصے: عنوان، تعارف، واقعات کی ترتیب، نتائج اور تاثرات۔",
  "سفر کی روداد: روانگی، راستے کے مناظر، قیام اور واپسی — دلچسپ انداز میں۔",
  "تقریب کی روداد: مہمانان، پروگرام کی ترتیب اور اختتامی تاثر۔",
  "مکتوب نگاری: خطوط لکھنے کا فن — ذاتی، کاروباری اور سرکاری خطوط۔",
  "سرکاری خط: حوالہ نمبر، موضوع، مختصر اور واضح زبان۔",
  "روداد میں مبالغے سے بچیں — سچائی اور ترتیب اس کی جان ہے۔",
  "امتحانی نکتہ: 'تعلیمی دورے کی روداد' ہر سال آتی ہے — خاکہ تیار رکھیں۔"
 ],
 "12th|Urdu|اردو تنقید کا تعارف": [
  "تنقید ادب کے حسن و قبح کا جائزہ لینے کا علم ہے — اصلاح کا ذریعہ۔",
  "مولانا الطاف حسین حالی: 'مقدمہ شعر و شاعری' اردو تنقید کی بنیاد۔",
  "حالی نے شاعری میں سچائی، اخلاق اور فطرت کی عکاسی پر زور دیا۔",
  "شمس الرحمن فاروقی جدید اردو تنقید کے امام — 'شعرِ شور انگیز' مشہور۔",
  "تنقید کی اقسام: فنی تنقید (اسلوب)، تاریخی تنقید اور نفسیاتی تنقید۔",
  "اچھی تنقید تعمیری ہوتی ہے — صرف خامیاں نکالنا تنقید نہیں۔",
  "تنقید ادیب کی رہنمائی کرتی ہے اور قاری کا ذوق سنوارتی ہے۔",
  "امتحانی نکتہ: حالی کی تنقیدی خدمات کے 3 نکات لکھیں۔"
 ],
 "12th|Math|Differentiation Formula Sheet": [
  "d/dx(x^n) = nx^(n-1); d/dx(constant) = 0; d/dx(e^x) = e^x.",
  "d/dx(ln x) = 1/x; d/dx(a^x) = a^x ln a; d/dx(sin x) = cos x.",
  "d/dx(cos x) = -sin x; d/dx(tan x) = sec²x; d/dx(cot x) = -csc²x.",
  "d/dx(sec x) = sec x tan x; d/dx(csc x) = -csc x cot x.",
  "Product rule: (uv)' = u'v + uv'; quotient rule: (u/v)' = (u'v - uv')/v².",
  "Chain rule: dy/dx = dy/du × du/dx — for composite functions like sin(x²).",
  "d/dx(sin^-1 x) = 1/√(1-x²); d/dx(tan^-1 x) = 1/(1+x²).",
  "Maxima/minima: set dy/dx = 0; d²y/dx² < 0 means maximum, > 0 means minimum."
 ],
 "12th|Math|Integration Techniques Practice": [
  "∫x^n dx = x^(n+1)/(n+1) + C (n ≠ -1); ∫(1/x)dx = ln|x| + C.",
  "∫e^x dx = e^x + C; ∫sin x dx = -cos x + C; ∫cos x dx = sin x + C.",
  "Substitution: for ∫2x·e^(x²)dx put u = x², du = 2x dx.",
  "By parts: ∫u dv = uv - ∫v du; choose u by ILATE (Inverse, Log, Algebraic, Trig, Exponential).",
  "Definite integral: ∫a^b f(x)dx = F(b) - F(a); area under curve = ∫y dx.",
  "Properties: ∫a^b = -∫b^a; ∫a^b = ∫a^c + ∫c^b.",
  "Partial fractions: split 1/((x+1)(x+2)) into A/(x+1) + B/(x+2) before integrating.",
  "Exam tip: in by-parts questions, wrong choice of u wastes time — apply ILATE strictly."
 ],
 "12th|Math|Conic Section: Formula Sheet": [
  "Circle: x² + y² + 2gx + 2fy + c = 0; centre (-g,-f); radius √(g²+f²-c).",
  "Parabola y² = 4ax: focus (a,0); directrix x = -a; vertex (0,0); axis x-axis.",
  "Ellipse x²/a² + y²/b² = 1: foci (±ae, 0); eccentricity e < 1.",
  "Hyperbola x²/a² - y²/b² = 1: foci (±ae, 0); eccentricity e > 1; asymptotes y = ±(b/a)x.",
  "Eccentricity: e = 0 circle, 0<e<1 ellipse, e = 1 parabola, e > 1 hyperbola.",
  "Tangent to circle x²+y²=a² at (x1,y1): xx1 + yy1 = a² (T = 0 rule).",
  "Parametric: circle (a cosθ, a sinθ); parabola (at², 2at).",
  "Exam tip: identify the conic from e first, then apply its standard formulas."
 ],
 "BA/BSc|English|Grammar: Narration and Voice": [
  "Narration revision: direct 'He said, \"I am busy\"' -> indirect 'He said that he was busy.'",
  "Universal truths do not change tense: 'The sun rises in the east' stays the same in indirect speech.",
  "Imperatives in narration: 'said' -> ordered/advised/requested + to-infinitive.",
  "Voice revision: active 'She writes letters' -> passive 'Letters are written by her.'",
  "Passive of modals: 'We must respect elders' -> 'Elders must be respected.'",
  "Passive of interrogatives: 'Who wrote this?' -> 'By whom was this written?'",
  "Double object verbs: 'He gave me a pen' -> 'I was given a pen' or 'A pen was given to me.'",
  "BA exam tip: narration and voice together carry 15+ marks — practice 20 sentences of each type."
 ],
 "BA/BSc|English|Literary Terms and Devices": [
  "Simile: comparison with like/as — 'brave as a lion'; metaphor: direct comparison — 'he is a lion.'",
  "Personification: giving human qualities to things — 'the wind whispered.'",
  "Alliteration: repetition of initial sounds — 'sweet silent song.'",
  "Hyperbole: exaggeration — 'I have told you a million times.'",
  "Irony: saying the opposite of what is meant; satire: mocking folly to reform it.",
  "Symbol: an object standing for an idea — dove for peace, white for purity.",
  "Protagonist = main character; antagonist = opposing force; climax = turning point.",
  "BA exam tip: define 10 terms with one example each — a fixed 10-mark question."
 ],
 "BA/BSc|English|Essay Outlines Practice": [
  "BA essay: 400-500 words; outline first (10 min), then write (40 min).",
  "Outline format: introduction, 4-5 headings with sub-points, conclusion.",
  "Popular BA topics: Inflation in Pakistan, Importance of Education, Women Empowerment, Climate Change, Social Media.",
  "Introduction: quotation or current fact; thesis statement at the end of intro.",
  "Body: one heading per paragraph; support with statistics, examples, quotations.",
  "Use formal academic tone; avoid 'I think' — use 'It is evident that...'.",
  "Conclusion: summarize arguments, give suggestions, end on a hopeful note.",
  "Learn 3 versatile quotations usable in many essays, e.g. on education, hard work, honesty."
 ],
 "BA/BSc|Urdu|غالب کی شاعری": [
  "مرزا اسد اللہ خاں غالب (1797-1869) اردو کے سب سے عظیم شاعر مانے جاتے ہیں۔",
  "ان کی شاعری میں فکر کی گہرائی، تصوف اور انسانی نفسیات کا بیان ہے۔",
  "مشہور اشعار: 'دلِ ناداں تجھے ہوا کیا ہے / آخر اس درد کی دوا کیا ہے'۔",
  "'ہزاروں خواہشیں ایسی کہ ہر خواہش پہ دم نکلے / بہت نکلے مرے ارماں لیکن پھر بھی کم نکلے'۔",
  "غالب کی فارسی شاعری بھی اعلیٰ درجے کی ہے — وہ خود فارسی کو فوقیت دیتے تھے۔",
  "خطوطِ غالب اردو نثر کا شاہکار ہیں — ان میں ان کی شخصیت جھلکتی ہے۔",
  "دیوانِ غالب ان کا اردو شعری مجموعہ ہے۔",
  "امتحانی نکتہ: غالب کے 4 اشعار مع تشریح تیار رکھیں — بی اے میں لازمی سوال۔"
 ],
 "BA/BSc|Urdu|اقبال کی شاعری": [
  "علامہ محمد اقبال (1877-1938) شاعرِ مشرق اور مفکرِ پاکستان ہیں۔",
  "انہوں نے مسلمانوں میں خودی، عمل اور امید کا پیغام دیا۔",
  "مشہور مجموعے: بانگِ درا، بالِ جبریل، ضربِ کلیم (اردو)؛ پیامِ مشرق، زبورِ عجم (فارسی)۔",
  "خودی کا تصور: انسان اپنی صلاحیتوں کو پہچانے — 'خودی کو کر بلند اتنا کہ ہر تقدیر سے پہلے'۔",
  "شاہین ان کا علامتی پرندہ ہے — بلند پروازی اور خودداری کی علامت۔",
  "'ستاروں سے آگے جہاں اور بھی ہیں / ابھی عشق کے امتحاں اور بھی ہیں'۔",
  "اقبال نے 1930ء کے خطبۂ الہ آباد میں مسلمانوں کے لیے الگ وطن کا تصور پیش کیا۔",
  "امتحانی نکتہ: خودی اور شاہین کی علامت کی وضاحت ضرور تیار کریں۔"
 ],
 "BA/BSc|Islamiat|اسلامی فقہ کے مذاہب": [
  "فقہ شریعت کے عملی احکام کا علم ہے — قرآن و سنت سے استنباط کیا جاتا ہے۔",
  "حنفی: امام ابو حنیفہ (80-150ھ) — برصغیر، ترکی اور وسطی ایشیا میں رائج۔",
  "مالکی: امام مالک (93-179ھ) — مدینہ کی روایت پر مبنی؛ شمالی افریقہ میں رائج۔",
  "شافعی: امام شافعی (150-204ھ) — مصر، شام اور جنوب مشرقی ایشیا میں۔",
  "حنبلی: امام احمد بن حنبل (164-241ھ) — سعودی عرب میں رائج۔",
  "چاروں مذاہب اہلِ سنت کے ہیں — بنیادی عقائد میں اتفاق، فروعی مسائل میں اختلاف۔",
  "اختلافِ فقہاء رحمت ہے — کسی ایک کی تقلید میں شدت پسندی درست نہیں۔",
  "امتحانی نکتہ: چاروں ائمہ کے نام اور علاقے یاد رکھیں۔"
 ],
 "BA/BSc|Islamiat|تصوف کا تعارف": [
  "تصوف اسلام کی روحانی جہت ہے — دل کی صفائی اور اللہ سے قرب کا راستہ۔",
  "صوفیاء نے محبتِ الٰہی، زہد اور اخلاص کی تعلیم دی۔",
  "مشہور صوفیاء: حضرت داتا گنج بخش (لاہور)، خواجہ معین الدین چشتی (اجمیر)، بابا فرید (پاکپتن)۔",
  "سلاسل: چشتیہ، قادریہ، سہروردیہ، نقشبندیہ — روحانی تربیت کے طریقے۔",
  "صوفیاء نے برصغیر میں اسلام کی تبلیغ میں نمایاں کردار ادا کیا۔",
  "صحیح تصوف شریعت کے تابع ہے — شریعت سے ہٹا ہوا دعویٰ تصوف نہیں۔",
  "ذکر، فکر اور صحبتِ صالحین تصوف کی بنیادی مشقیں ہیں۔",
  "امتحانی نکتہ: دو صوفیاء اور ان کے مزارات کے شہر لکھیں۔"
 ],
 "BA/BSc|Pak Studies|1973 کا آئین: نمایاں خصوصیات": [
  "1973ء کا آئین 14 اگست 1973ء کو نافذ ہوا — ذوالفقار علی بھٹو کے دور میں۔",
  "پارلیمانی نظام: وزیراعظم سربراہِ حکومت، صدر سربراہِ مملکت۔",
  "وفاقی نظام: مرکز اور چار صوبے — اختیارات کی تقسیم۔",
  "اسلامی دفعات: قرآن و سنت کے منافی کوئی قانون نہیں بن سکتا؛ اسلامی نظریاتی کونسل کا قیام۔",
  "بنیادی حقوق: ہر شہری کو جان، مال، عزت اور اظہارِ رائے کا تحفظ۔",
  "اردو قومی زبان قرار پائی — 15 سال میں انگریزی کی جگہ لینے کا ہدف تھا۔",
  "آئین میں اب تک 26 ترامیم ہو چکی ہیں (18ویں سب سے اہم)۔",
  "امتحانی نکتہ: اسلامی دفعات اور بنیادی حقوق ہر جواب کی جان ہیں۔"
 ],
 "BA/BSc|Pak Studies|خارجہ پالیسی کے اصول": [
  "بنیادی اصول: قومی مفاد، عدم مداخلت، پرامن بقائے باہمی۔",
  "مسلم امہ سے یکجہتی — فلسطین اور کشمیر کی حمایت۔",
  "چین سے اسٹریٹجک شراکت داری — سی پیک اس کی عملی مثال۔",
  "بھارت سے کشمیر تنازع مرکزی مسئلہ — مذاکرات سے حل کی کوشش۔",
  "امریکہ اور مغرب سے متوازن تعلقات — معیشت اور دفاع میں تعاون۔",
  "افغانستان میں امن پاکستان کے لیے ضروری — مہاجرین کی واپسی کا مسئلہ۔",
  "اقوامِ متحدہ اور او آئی سی میں فعال کردار۔",
  "امتحانی نکتہ: 4 اصول اور 3 اہم دوطرفہ تعلقات لکھیں۔"
 ],
 "BA/BSc|Math|Vector Calculus: Introduction": [
  "Scalar field: e.g. temperature T(x,y,z); vector field: e.g. velocity v(x,y,z).",
  "Gradient of scalar f: ∇f = (∂f/∂x, ∂f/∂y, ∂f/∂z) — points in the direction of fastest increase.",
  "Divergence of vector F: ∇·F = ∂Fx/∂x + ∂Fy/∂y + ∂Fz/∂z (scalar).",
  "Curl of vector F: ∇×F — measures rotation of the field (vector).",
  "Identities: div(curl F) = 0; curl(grad f) = 0 — always true.",
  "Line integral ∫F·dr = work done by force F along a path.",
  "Green's theorem connects a line integral around a closed curve to a double integral over the region.",
  "Physical meaning: divergence = source/sink strength; curl = rotation — remember this for viva."
 ],
 "BA/BSc|Math|Laplace Transforms": [
  "Laplace transform converts a time function f(t) into a frequency function F(s): L{f(t)} = ∫₀^∞ e^(-st) f(t) dt.",
  "L{1} = 1/s; L{t^n} = n!/s^(n+1); L{e^(at)} = 1/(s-a).",
  "L{sin at} = a/(s²+a²); L{cos at} = s/(s²+a²).",
  "First shifting: L{e^(at)f(t)} = F(s-a); second shifting handles delayed functions u(t-a).",
  "L{f'(t)} = sF(s) - f(0); L{f''(t)} = s²F(s) - sf(0) - f'(0) — converts ODEs to algebra.",
  "Steps to solve ODE: transform both sides, solve for F(s), take inverse transform.",
  "Inverse: L^-1{1/(s-a)} = e^(at); use partial fractions for rational F(s).",
  "Applications: electrical circuits, control systems, solving initial-value problems."
 ],
 "BA/BSc|Physics|Geometrical Optics": [
  "Fermat's principle: light travels the path of least time between two points.",
  "Laws of reflection: angle of incidence = angle of reflection; both in the same plane as the normal.",
  "Snell's law: n1 sinθ1 = n2 sinθ2; refractive index n = c/v.",
  "Total internal reflection: when light goes from denser to rarer medium beyond the critical angle θc = sin^-1(1/n).",
  "Applications of TIR: optical fibres (endoscopy, internet), sparkling diamond, mirages.",
  "Lens maker's formula: 1/f = (n-1)(1/R1 - 1/R2).",
  "Thin lens formula: 1/f = 1/v - 1/u; magnification m = v/u = image height/object height.",
  "Dispersion: prism splits white light; Cauchy's formula n = A + B/λ² shows blue bends most."
 ],
 "BA/BSc|Physics|Nuclear Physics: Introduction": [
  "Nucleus: protons + neutrons (nucleons); atomic number Z = protons; mass number A = Z + N.",
  "Isotopes: same Z, different N (e.g. C-12, C-14); isobars: same A, different Z.",
  "Nuclear radius R = R₀A^(1/3), R₀ ≈ 1.2 fm; density of nuclear matter is enormous (~10^17 kg/m³).",
  "Mass defect Δm = (mass of nucleons) - (nuclear mass); binding energy = Δm c².",
  "Binding energy per nucleon peaks at iron (A≈56) — the most stable nucleus.",
  "Fission splits heavy nuclei (energy); fusion joins light nuclei (sun's energy).",
  "Radioactivity: α (He nucleus), β (electron), γ (EM wave); half-life T½ = 0.693/λ.",
  "Uses: power plants, medical tracers, carbon dating (C-14, T½ = 5730 years)."
 ],
 "BA/BSc|Chemistry|Chemical Thermodynamics": [
  "First law: energy is conserved; ΔU = q + w (heat added + work done on system).",
  "Enthalpy H = U + PV; at constant pressure, ΔH = qp (heat of reaction).",
  "Hess's law: ΔH of a reaction is the same regardless of the path — add stepwise ΔH values.",
  "Standard enthalpy of formation ΔHf°: forming 1 mole from elements; ΔH°rxn = ΣΔHf°(products) - ΣΔHf°(reactants).",
  "Entropy S = measure of disorder; second law: entropy of the universe always increases.",
  "Gibbs free energy G = H - TS; ΔG = ΔH - TΔS; reaction spontaneous if ΔG < 0.",
  "ΔG° = -RT ln K — links thermodynamics to equilibrium constant.",
  "Third law: entropy of a perfect crystal at 0 K is zero."
 ],
 "BA/BSc|Chemistry|Coordination Chemistry": [
  "Coordination compound: central metal ion + ligands (electron-pair donors), e.g. [Cu(NH3)4]SO4.",
  "Ligands: monodentate (NH3, H2O, Cl-), bidentate (ethylenediamine 'en'), polydentate (EDTA).",
  "Coordination number: number of donor atoms bonded to metal (commonly 4 or 6).",
  "IUPAC naming: name ligands alphabetically, then metal with oxidation state — [Co(NH3)6]Cl3 = hexaamminecobalt(III) chloride.",
  "Isomerism: ionization, linkage (NO2- vs ONO-), geometrical (cis/trans), optical.",
  "Crystal field theory: d-orbitals split into t2g and eg sets in octahedral field; splitting = Δo.",
  "Colour of complexes comes from d-d electron transitions absorbing visible light.",
  "Applications: EDTA in water treatment, cisplatin as anti-cancer drug, chlorophyll (Mg complex)."
 ],
 "BA/BSc|Computer Science|Programming Fundamentals": [
  "Program = sequence of instructions; programming languages: machine, assembly, high-level (C, Python, Java).",
  "Compiler translates the whole program at once (C, Java); interpreter translates line by line (Python).",
  "Algorithm qualities: finite steps, definite, effective, general — write pseudocode before coding.",
  "Variables and data types: int, float, char, bool; constants cannot change during execution.",
  "Control structures: sequence, selection (if/switch), iteration (for/while) — the three building blocks.",
  "Functions: divide programs into reusable blocks; parameters pass data in, return sends result back.",
  "Arrays store many values of one type; strings are char arrays ending with '\\0'.",
  "Debugging: use print statements and a debugger; common errors — syntax, runtime, logic."
 ],
 "BA/BSc|Computer Science|Database Management Systems": [
  "DBMS: software to create, manage and query databases — MySQL, PostgreSQL, Oracle, MS Access.",
  "Data models: hierarchical, network, relational (tables), object-oriented, NoSQL (document/key-value).",
  "Relational model: tables with rows (tuples) and columns (attributes); keys link tables.",
  "Primary key: unique per row; foreign key: references another table's primary key; composite key: combination.",
  "Normalization: 1NF (atomic), 2NF (no partial dependency), 3NF (no transitive dependency), BCNF.",
  "SQL commands: DDL (CREATE/ALTER/DROP), DML (INSERT/UPDATE/DELETE), DCL (GRANT/REVOKE), TCL (COMMIT/ROLLBACK).",
  "Joins: INNER (matching rows), LEFT/RIGHT (all from one side), FULL OUTER (all rows).",
  "ACID properties: Atomicity, Consistency, Isolation, Durability — guarantee reliable transactions."
 ],
 "BA/BSc|Computer Science|Computer Networks: Basics": [
  "Network = connected devices sharing resources; topologies: bus, star, ring, mesh.",
  "OSI model (7 layers): Physical, Data Link, Network, Transport, Session, Presentation, Application.",
  "TCP/IP model (4 layers): Network Access, Internet, Transport, Application — the practical Internet model.",
  "IP addressing: IPv4 (32-bit, e.g. 192.168.1.1), IPv6 (128-bit); subnetting divides networks.",
  "TCP: reliable, ordered delivery (web, email); UDP: fast, no guarantee (video streaming, games).",
  "Protocols: HTTP/HTTPS (web), FTP (files), SMTP (send mail), POP3/IMAP (receive mail), DNS (names to IPs).",
  "Devices: hub (broadcasts), switch (directs by MAC), router (connects networks), firewall (security).",
  "Network security: encryption, VPNs, firewalls, strong authentication against eavesdropping and attacks."
 ],
 "BA/BSc|Economics|Introduction to Economics": [
  "Economics studies how societies allocate scarce resources among unlimited wants.",
  "Microeconomics: individual units (consumer, firm); macroeconomics: whole economy (inflation, GDP).",
  "Law of demand: price rises -> quantity demanded falls (inverse relation), ceteris paribus.",
  "Law of supply: price rises -> quantity supplied rises (direct relation).",
  "Equilibrium: where demand = supply; shortage when price is below, surplus when above equilibrium.",
  "GDP = total value of goods/services produced in a country in a year; GDP per capita = GDP/population.",
  "Inflation: general rise in prices; measured by CPI (Consumer Price Index) in Pakistan.",
  "Types of unemployment: frictional, structural, cyclical; Pakistan's youth unemployment is a key issue."
 ],
 "BA/BSc|Statistics|Descriptive Statistics": [
  "Statistics: collecting, organizing, analyzing and interpreting numerical data.",
  "Data types: qualitative (categories) vs quantitative — discrete (counts) vs continuous (measurements).",
  "Mean = Σx/n; median = middle value of ordered data; mode = most frequent value.",
  "For grouped data: mean = Σfm/Σf using class marks; median via cumulative frequency formula.",
  "Range = max - min; variance = Σ(x-mean)²/n; standard deviation = √variance.",
  "Standard deviation measures spread — small SD means data clustered near the mean.",
  "Graphical: histogram, frequency polygon, ogive (cumulative), pie chart, bar chart.",
  "Skewness: symmetric (mean=median=mode), positively skewed (mean > median), negatively skewed."
 ],
 "BA/BSc|Psychology|Introduction to Psychology": [
  "Psychology = scientific study of behaviour and mental processes.",
  "Schools: structuralism (Wundt), functionalism (James), behaviourism (Watson/Skinner), psychoanalysis (Freud), humanistic (Maslow/Rogers).",
  "Neuron: nerve cell — dendrites receive, axon transmits; synapse is the gap between neurons.",
  "Brain parts: cerebrum (thinking), cerebellum (coordination), brainstem (vital functions: breathing, heartbeat).",
  "Learning: classical conditioning (Pavlov's dogs), operant conditioning (Skinner's rewards/punishment), observational learning.",
  "Memory stages: sensory -> short-term (7±2 items) -> long-term; forgetting curve (Ebbinghaus).",
  "Maslow's hierarchy: physiological, safety, love/belonging, esteem, self-actualization.",
  "Personality theories: Freud's id/ego/superego; Big Five traits: openness, conscientiousness, extraversion, agreeableness, neuroticism."
 ],
 "9th|English|Grammar: Tenses Practice": [
  "Present simple: habits and facts — She goes to school daily; water boils at 100°C.",
  "Present continuous: happening now — They are playing cricket at the moment.",
  "Present perfect: completed action with present result — I have finished my homework.",
  "Past simple: finished past time — He visited Lahore last year.",
  "Past continuous: interrupted action — I was sleeping when he came.",
  "Future simple: will + verb — We will win the match; Future plan: going to — I am going to study.",
  "Signal words: always/usually (present simple), now (continuous), yesterday (past), tomorrow (future).",
  "Exam tip: underline the time word first — it tells you the tense in 90% of questions."
 ],
 "9th|Urdu|نظم کا فن": [
  "نظم ایسا شعری مجموعہ ہے جس میں ایک ہی موضوع پر مسلسل اشعار ہوں۔",
  "نظم اور غزل میں فرق: غزل کے اشعار الگ الگ مضمون کے، نظم کے سب اشعار ایک موضوع پر۔",
  "نظم کی اقسام: پابند نظم (بحر و قافیے کی پابندی)، آزاد نظم، معرا نظم۔",
  "نصابی نظمیں: 'برسات کی بہاریں' — برسات کے مناظر کی عکاسی۔",
  "نظم میں تشبیہات اور استعارے موضوع کو واضح کرتے ہیں۔",
  "نظم کا خلاصہ لکھتے وقت مرکزی خیال اور شاعر کا پیغام ضرور بیان کریں۔",
  "مشہور نظم گو: نظیر اکبر آبادی، علامہ اقبال، فیض احمد فیض۔",
  "امتحانی نکتہ: نظم کی تشریح میں مشکل الفاظ کے معنی پہلے لکھیں۔"
 ],
 "9th|Islamiat|روزے کے احکام و فضائل": [
  "روزہ اسلام کا چوتھا رکن ہے — رمضان کے روزے ہر بالغ مسلمان پر فرض ہیں۔",
  "روزے کی فرضیت: 'اے ایمان والو! تم پر روزے فرض کیے گئے' (البقرۃ: 183)۔",
  "سحری کھانا سنت ہے — سحری میں برکت ہے (حدیث)۔",
  "افطار جلدی کرنا سنت ہے — کھجور یا پانی سے افطار مسنون ہے۔",
  "روزے کے فضائل: جنت کا باب الریان روزے داروں کے لیے ہے؛ روزہ ڈھال ہے۔",
  "لیلۃ القدر ہزار مہینوں سے بہتر ہے — رمضان کے آخری عشرے کی طاق راتوں میں تلاش کریں۔",
  "روزہ توڑنے والی چیزیں: جان بوجھ کر کھانا پینا — قضا یا کفارہ لازم۔",
  "امتحانی نکتہ: روزے کی فرضیت کی آیت اور دو فضائل حدیث سمیت یاد کریں۔"
 ],
 "9th|Pak Studies|قیامِ پاکستان کے بعد کے چیلنجز": [
  "1947ء میں پاکستان کو انتظامی، معاشی اور دفاعی مسائل کا سامنا تھا۔",
  "مہاجرین کی آبادکاری: لاکھوں مہاجرین کی رہائش اور روزگار بڑا چیلنج تھا۔",
  "انتظامی ڈھانچہ: دفاتر، ریکارڈ اور عملہ کی کمی — کراچی دارالحکومت بنا۔",
  "مالی مسائل: خزانہ خالی، بینک اور صنعتوں کی کمی۔",
  "نہری پانی کا تنازع: بھارت نے 1948ء میں پانی بند کیا — سندھ طاس معاہدہ 1960ء میں ہوا۔",
  "دفاع: فوج کی تنظیمِ نو اور کشمیر میں قبائلی مدد۔",
  "قائداعظم کی قیادت میں ان مسائل کا حوصلے سے مقابلہ کیا گیا۔",
  "امتحانی نکتہ: ابتدائی مسائل کے 5 نکات مع حل لکھنے کی مشق کریں۔"
 ],
 "10th|English|Dialogue Writing": [
  "A dialogue is a conversation between two speakers on a given situation.",
  "Format: write names in capitals (ALI: / FATHER:), each speech on a new line.",
  "Common topics: between friends about exams, father and son about career, teacher and student about homework.",
  "Keep it natural: use short sentences, questions and answers, polite expressions.",
  "Include 8-10 exchanges (each speaker 4-5 times) for full marks.",
  "Use present tense mostly; add one or two idioms for extra marks.",
  "End the dialogue with a conclusion or agreement, not abruptly.",
  "Exam tip: read the situation twice and note 4 key points to cover before writing."
 ],
 "10th|Urdu|اردو گرامر: جملوں کی اقسام": [
  "جملہ اسمیہ: مسند الیہ اسم ہو — 'علی ذہین ہے'۔",
  "جملہ فعلیہ: فعل پر مبنی ہو — 'علی نے کتاب پڑھی'۔",
  "خبریہ جملہ: خبر دے — 'بارش ہو رہی ہے'؛ انشائیہ: حکم، سوال یا خواہش — 'بیٹھو!'۔",
  "مثبت جملہ: 'وہ آیا'؛ منفی جملہ: 'وہ نہیں آیا'۔",
  "سادہ جملہ: ایک ہی خیال — 'لڑکا کھیلتا ہے'؛ مرکب: دو جملوں کا ملاپ۔",
  "سوالیہ جملے میں کیا، کب، کہاں، کیوں جیسے الفاظ آتے ہیں۔",
  "فجائیہ جملہ: حیرت یا خوشی — 'کیا خوب منظر ہے!'۔",
  "امتحانی نکتہ: ہر قسم کی ایک مثال یاد رکھیں — مختصر سوال میں آتا ہے۔"
 ],
 "10th|Math|Statistics: Graphical Representation": [
  "Histogram: bars joined together for continuous grouped data; area shows frequency.",
  "Frequency polygon: join midpoints of histogram tops; useful for comparing two data sets.",
  "Ogive (cumulative frequency curve): plot cumulative frequencies; used to find median graphically.",
  "Pie chart: circle divided into sectors; angle = (value/total) × 360°.",
  "Bar chart: separate bars for discrete data (e.g. students per class).",
  "Median from ogive: draw horizontal line at n/2 cumulative frequency, drop to x-axis.",
  "Mode from histogram: tallest bar; draw diagonal lines to neighbours, drop to x-axis.",
  "Exam tip: label axes and give a title — presentation carries 2 marks."
 ],
 "10th|Chemistry|Chemistry Practicals: 10th": [
  "Identify gases: H2 (pop sound), O2 (rekindles splinter), CO2 (milky lime water).",
  "Test for water: anhydrous copper sulphate turns blue with water.",
  "Acid-base titration: standardize NaOH against oxalic acid using phenolphthalein.",
  "Prepare standard solution: weigh accurately, dissolve, make up to the mark in a volumetric flask.",
  "Purify a salt by crystallization: dissolve, filter hot, cool, filter crystals, dry.",
  "Test for chloride, sulphate and carbonate anions with silver nitrate, barium chloride and acid.",
  "pH measurement: use pH paper or universal indicator; compare colour with chart.",
  "Safety: add acid to water slowly; never pipette by mouth — use a filler."
 ],
 "10th|Biology|Smoking and Health": [
  "Tobacco smoke contains nicotine (addictive), tar (carcinogenic) and carbon monoxide (poisonous).",
  "Smoking damages lungs: causes bronchitis, emphysema and lung cancer.",
  "Carbon monoxide binds haemoglobin, reducing oxygen supply to the body.",
  "Nicotine raises blood pressure and heartbeat — risk of heart attack and stroke.",
  "Passive smoking harms non-smokers, especially children and pregnant women.",
  "Sheesha/vape also damage lungs — 'safer' claims are misleading.",
  "Quitting benefits: within weeks breathing improves; within years cancer risk drops sharply.",
  "Exam tip: name the three harmful chemicals and one disease caused by each."
 ],
 "10th|Computer Science|Introduction to C++": [
  "C++ extends C with object-oriented features; created by Bjarne Stroustrup.",
  "Basic program: #include <iostream> using namespace std; int main() { cout << 'Hello'; }",
  "cout << prints output; cin >> takes input — they replace printf/scanf.",
  "// is single-line comment; /* */ is multi-line comment.",
  "Data types: int, float, double, char, bool, string (needs #include <string>).",
  "Classes bundle data and functions; objects are instances of classes.",
  "C++ is used in game engines, operating systems and competitive programming.",
  "Difference from C: C++ supports classes/objects; C is purely procedural."
 ],
 "11th|English|Grammar: Articles and Determiners": [
  "Determiners come before nouns: articles, demonstratives (this/that), possessives (my/his), quantifiers.",
  "Use 'the' for: unique things (the sun), superlatives (the best), previously mentioned nouns.",
  "Use 'a/an' for: first mention of countable singular nouns, professions (a teacher).",
  "Zero article: plural/general nouns (Honesty is good), meals (dinner), languages, most proper names.",
  "'Some/any': some in positives (some books), any in negatives/questions (any books?).",
  "'Much' with uncountable (much water), 'many' with countable (many books).",
  "'Few/a few': few = almost none (negative), a few = some (positive).",
  "Exam tip: 'the' vs zero article confuses most — learn the fixed list of no-article cases."
 ],
 "11th|Urdu|نعت کا فن": [
  "نعت رسول اکرم ﷺ کی مدح میں کہی گئی شاعری ہے — حمد سے اس کا فرق واضح ہے۔",
  "نعت میں سیرتِ طیبہ، معجزات اور فضائل کا بیان ہوتا ہے۔",
  "پہلے نعت گو: حسان بن ثابت رضی اللہ عنہ — عہدِ نبوی کے شاعر۔",
  "اردو کے مشہور نعت گو: امام احمد رضا (حدائقِ بخشش)، مظفر وارثی، حفیظ تائب۔",
  "نعت میں ادب و احترام کا خاص خیال — الفاظ کا انتخاب محتاط ہو۔",
  "نعت خوانی پاکستان کی مذہبی محافل کا حصہ ہے۔",
  "نعت اور قصیدے میں فرق: قصیدہ کسی بھی شخصیت کی مدح میں، نعت صرف حضور ﷺ کی مدح میں۔",
  "امتحانی نکتہ: نصابی نعت کے شاعر اور مرکزی خیال لکھیں۔"
 ],
 "11th|Math|Logarithms and Exponents Review": [
  "If a^x = y then x = log_a(y); log_a(a) = 1; log_a(1) = 0.",
  "Laws: log(mn) = log m + log n; log(m/n) = log m - log n; log(m^n) = n log m.",
  "Change of base: log_a b = (log b)/(log a) = 1/(log_b a).",
  "Common log: base 10 (log); natural log: base e (ln); ln e = 1.",
  "Exponential equations: 2^x = 8 -> x = 3; take log both sides for harder ones: 3^x = 10 -> x = log10/log3.",
  "a^0 = 1; a^-n = 1/a^n; (a^m)^n = a^(mn); a^m × a^n = a^(m+n).",
  "Solve log equations: combine logs first, then convert to exponential form.",
  "Exam tip: check answers — log of zero or negative numbers is undefined."
 ],
 "11th|Islamiat|اسلامی تہذیب کا تعارف": [
  "تہذیب کسی قوم کے رہن سہن، اقدار اور طرزِ زندگی کا نام ہے۔",
  "اسلامی تہذیب کی بنیاد توحید، رسالت اور آخرت کے عقائد پر ہے۔",
  "اسلامی تہذیب میں علم، عدل، اخوت اور احسان بنیادی اقدار ہیں۔",
  "مسلمانوں نے علم و فن میں شاندار تہذیب قائم کی — بغداد، قرطبہ اور دہلی مراکز تھے۔",
  "اسلامی فنِ تعمیر: مساجد کے مینار، گنبد اور خطاطی اس کی پہچان ہیں۔",
  "مغربی تہذیب سے فرق: اسلامی تہذیب مادیت کے ساتھ روحانیت بھی رکھتی ہے۔",
  "تہذیبی یلغار سے بچنے کے لیے اپنی اقدار سے وابستگی ضروری ہے۔",
  "امتحانی نکتہ: اسلامی تہذیب کی 4 خصوصیات پوائنٹس میں لکھیں۔"
 ],
 "11th|Pak Studies|پاکستان کی عدلیہ": [
  "عدلیہ انصاف فراہم کرنے والا ریاستی ستون ہے — مقننہ اور انتظامیہ سے الگ۔",
  "ساخت: سپریم کورٹ، ہائی کورٹس (ہر صوبے میں)، ضلعی عدالتیں۔",
  "سپریم کورٹ کے ججوں کی تقرری جوڈیشل کمیشن کے ذریعے ہوتی ہے (18ویں ترمیم)۔",
  "عدلیہ آئین کی محافظ ہے — غیر آئینی اقدامات کو کالعدم قرار دے سکتی ہے۔",
  "آزاد عدلیہ جمہوریت اور بنیادی حقوق کے تحفظ کے لیے ضروری ہے۔",
  "موبائل کورٹس اور تنازعات کے متبادل حل (ADR) انصاف کو عوام تک پہنچاتے ہیں۔",
  "انصاف میں تاخیر انصاف سے انکار کے مترادف ہے — زیر التواء مقدمات بڑا مسئلہ ہیں۔",
  "امتحانی نکتہ: عدالتوں کی درجہ بندی چارٹ بنا کر یاد کریں۔"
 ],
 "11th|Computer Science|Number Systems in Computing": [
  "Computers use binary (0,1); programmers also use octal, decimal and hexadecimal.",
  "Binary to octal: group bits in 3s; binary to hex: group bits in 4s.",
  "Hex digits: 0-9 then A=10, B=11, C=12, D=13, E=14, F=15.",
  "Example: binary 11010111 = D7 in hex (1101=13=D, 0111=7).",
  "1's complement: flip all bits; 2's complement: flip and add 1 — used for negative numbers.",
  "Subtraction in computers is done by adding the 2's complement.",
  "ASCII: 7-bit code for characters (A=65, a=97, 0=48); Unicode covers all languages.",
  "Exam tip: practice 2's complement subtraction of 4-bit numbers — a fixed numerical."
 ],
 "12th|English|Summary Writing (2nd Year)": [
  "2nd year summary: compress a passage to one-third length in your own words.",
  "Steps: read twice, underline key sentences, note main points, draft, then write fair.",
  "Do not copy original sentences; change vocabulary and sentence structure.",
  "Omit examples, repetitions, quotations and minor details.",
  "Write in paragraph form (not points) unless asked otherwise.",
  "Give a suitable title — 2 marks are fixed for it.",
  "Keep the same tense and person as the original passage.",
  "Exam tip: count words roughly — too long or too short both lose marks."
 ],
 "12th|Urdu|مرثیہ کا فن": [
  "مرثیہ کسی کی وفات پر غم کا اظہار کرنے والی نظم ہے۔",
  "اردو میں مرثیہ زیادہ تر واقعۂ کربلا اور شہدائے کربلا پر کہے جاتے ہیں۔",
  "میر انیس اور مرزا دبیر اردو مرثیے کے امام ہیں — لکھنؤ کی روایت۔",
  "مرثیے کے اجزا: چہرہ (آغاز)، سراپا، رخصت، آمد، جنگ اور شہادت کا بیان۔",
  "میر انیس کے مرثیوں میں جنگی مناظر کی تصویر کشی بے مثال ہے۔",
  "مرثیہ خوانی محرم میں مجالس کا حصہ ہے۔",
  "مرثیہ اور نوحہ میں فرق: نوحہ مختصر اور بین پر مبنی، مرثیہ طویل نظم۔",
  "امتحانی نکتہ: میر انیس کی دو خصوصیات لکھیں۔"
 ],
 "12th|Math|Differential Equations: Introduction": [
  "Differential equation: an equation involving derivatives, e.g. dy/dx = 2x.",
  "Order = highest derivative; degree = power of the highest derivative.",
  "Example: d²y/dx² + dy/dx = 0 is order 2, degree 1.",
  "General solution contains arbitrary constants (= order of the equation).",
  "Particular solution: constants found using given conditions.",
  "Variable separable: dy/dx = f(x)g(y) -> ∫dy/g(y) = ∫f(x)dx.",
  "Example: dy/dx = 2x -> y = x² + C; with y(0)=1 -> y = x² + 1.",
  "Applications: population growth, radioactive decay, cooling of objects."
 ],
 "12th|Chemistry|Chemistry Practicals: 2nd Year": [
  "Salt analysis: detect one basic radical (Pb2+, Cu2+, Fe3+, Zn2+, Ca2+, NH4+) and one acid radical.",
  "Confirmatory tests: Pb2+ gives yellow PbI2; Cu2+ gives deep blue with NH4OH; Fe3+ gives blood-red with KCNS.",
  "Anions: CO3 2- (CO2 with acid), Cl- (white AgCl ppt), SO4 2- (white BaSO4 ppt).",
  "Titration: determine molarity of NaOH using standard oxalic acid; indicator phenolphthalein.",
  "Organic tests: aldehyde (Tollens' silver mirror), unsaturation (bromine water decolourised).",
  "Prepare a standard solution of Mohr's salt for redox titration with KMnO4.",
  "Record observations in a table: experiment, observation, inference.",
  "Viva tip: revise all confirmatory tests with balanced ionic equations."
 ],
 "12th|Islamiat|اسلامی معاشرت": [
  "اسلامی معاشرت اخوت، مساوات اور عدل پر مبنی ہے۔",
  "اخوت: تمام مسلمان بھائی بھائی ہیں — رنگ و نسل کی برتری نہیں (خطبۂ حجۃ الوداع)۔",
  "مساوات: حاکم و محکوم، امیر و غریب سب قانون کے سامنے برابر۔",
  "پڑوسیوں کے حقوق: خیال رکھنا، تکلیف نہ دینا — ایمان کا حصہ۔",
  "رشتہ داروں سے صلہ رحمی فرض ہے — قطع رحمی گناہ۔",
  "کمزوروں (یتیم، بیوہ، مسکین) کی کفالت معاشرے کی ذمہ داری ہے۔",
  "اجتماعی عبادات (نمازِ جمعہ، عیدین، حج) معاشرتی یکجہتی پیدا کرتی ہیں۔",
  "امتحانی نکتہ: خطبۂ حجۃ الوداع کا مساوات والا حصہ ضرور لکھیں۔"
 ],
 "12th|Pak Studies|پاکستان کی زراعت": [
  "زراعت پاکستان کی معیشت کی ریڑھ کی ہڈی ہے — آبادی کا بڑا حصہ اس سے وابستہ۔",
  "اہم فصلیں: گندم (خوراک)، چاول، کپاس (نقد آور)، گنا، مکئی۔",
  "نہری نظام: دنیا کا بڑا آبپاشی نظام — تربیلا اور منگلا ڈیم۔",
  "مسائل: پانی کی کمی، چھوٹے کھیت، جدید ٹیکنالوجی کی کمی، موسمیاتی تبدیلی۔",
  "اصلاحات: زرعی قرضے، بہتر بیج، کھاد کی فراہمی اور زرعی تحقیق۔",
  "لائیو اسٹاک: دودھ، گوشت اور چمڑے کی صنعت میں اہم کردار۔",
  "زرعی برآمدات: چاول اور کپاس سے قیمتی زرمبادلہ حاصل ہوتا ہے۔",
  "امتحانی نکتہ: نقد آور اور غذائی فصلوں میں فرق واضح کریں۔"
 ],
 "12th|Computer Science|Cyber Security Basics": [
  "Cyber security protects systems and data from digital attacks and theft.",
  "Common threats: viruses, worms, trojans, ransomware, phishing, hacking.",
  "Phishing: fake emails/websites stealing passwords — check the sender's address carefully.",
  "Strong password: 12+ characters, mix of cases, digits, symbols; use a password manager.",
  "Two-factor authentication (2FA) adds a second check — enable it on email and banking.",
  "Firewall blocks unauthorized access; antivirus scans for malware — keep both updated.",
  "Backup important data regularly (cloud + external drive) against ransomware.",
  "In Pakistan, report cybercrime to FIA's Cybercrime Wing with evidence screenshots."
 ],
 "BA/BSc|English|Translation: Urdu to English": [
  "BA translation: 5-10 Urdu sentences into correct English (10-15 marks).",
  "Keep the same tense: identify the Urdu tense first, then choose the English equivalent.",
  "'نے' usually signals past indefinite: 'اس نے خط لکھا' = He wrote a letter.",
  "'رہا ہے/رہی ہے' = continuous: 'وہ کھیل رہا ہے' = He is playing.",
  "'گا/گی/گے' = future: 'وہ آئے گا' = He will come.",
  "Idioms: translate meaning, not words — 'ناک میں دم کرنا' = to make life miserable.",
  "Proverbs need English equivalents: 'جیسی کرنی ویسی بھرنی' = As you sow, so shall you reap.",
  "Avoid word-for-word translation; keep natural English word order (SVO).",
  "Exam tip: practice 50 sentences covering all tenses before the paper."
 ],
 "BA/BSc|Urdu|نظم: منتخب اشعار": [
  "بی اے میں نظم کی تشریح کے لیے منتخب اشعار کی تیاری ضروری ہے۔",
  "اقبال کی نظم 'شکوہ' — امت کی حالت پر اللہ سے شکوہ، پھر 'جوابِ شکوہ' میں جواب۔",
  "'طلوعِ اسلام' میں اقبال نے مسلمانوں کے عروج کی تاریخ بیان کی۔",
  "فیض کی نظم 'مجھ سے پہلی سی محبت' — محبت اور سماجی شعور کا امتزاج۔",
  "تشریح کا طریقہ: مشکل الفاظ کے معنی، پھر مفہوم، پھر شاعر کا پیغام۔",
  "نظم کے مرکزی خیال کو ایک جملے میں بیان کرنے کی مشق کریں۔",
  "تشبیہات اور استعاروں کی وضاحت تشریح کو مکمل بناتی ہے۔",
  "امتحانی نکتہ: 6 نظموں کے 4-4 اشعار مع تشریح تیار رکھیں۔"
 ],
 "BA/BSc|Math|Linear Algebra: Eigenvalues": [
  "Eigenvalue λ and eigenvector v satisfy Av = λv (v ≠ 0).",
  "Find λ: solve the characteristic equation det(A - λI) = 0.",
  "Example: A = [[2,0],[0,3]] -> (2-λ)(3-λ) = 0 -> λ = 2, 3.",
  "For each λ, solve (A - λI)v = 0 to get the eigenvector.",
  "Trace = sum of eigenvalues; determinant = product of eigenvalues.",
  "Diagonalizable if n independent eigenvectors exist: A = PDP^-1.",
  "Applications: stability analysis, principal component analysis, quantum mechanics.",
  "Cayley-Hamilton: every matrix satisfies its own characteristic equation."
 ]
}
FORMULAS = [
 [
  "Physics",
  "Newton's First Law",
  "Body stays at rest or uniform motion unless net external force acts"
 ],
 [
  "Physics",
  "Newton's Second Law",
  "F = m × a"
 ],
 [
  "Physics",
  "Newton's Third Law",
  "F12 = -F21 (action = -reaction)"
 ],
 [
  "Physics",
  "Law of Gravitation",
  "F = G × m1 × m2 / r²"
 ],
 [
  "Physics",
  "Weight",
  "W = m × g"
 ],
 [
  "Physics",
  "Speed",
  "v = d / t"
 ],
 [
  "Physics",
  "Velocity",
  "v = Δx / Δt"
 ],
 [
  "Physics",
  "Acceleration",
  "a = Δv / Δt"
 ],
 [
  "Physics",
  "1st Equation of Motion",
  "vf = vi + a × t"
 ],
 [
  "Physics",
  "2nd Equation of Motion",
  "s = vi × t + ½ × a × t²"
 ],
 [
  "Physics",
  "3rd Equation of Motion",
  "2 × a × s = vf² - vi²"
 ],
 [
  "Physics",
  "Momentum",
  "p = m × v"
 ],
 [
  "Physics",
  "Impulse",
  "J = F × Δt = Δp"
 ],
 [
  "Physics",
  "Conservation of Momentum",
  "m1v1 + m2v2 = m1v1' + m2v2'"
 ],
 [
  "Physics",
  "Work Done",
  "W = F × d × cos θ"
 ],
 [
  "Physics",
  "Kinetic Energy",
  "KE = ½ × m × v²"
 ],
 [
  "Physics",
  "Potential Energy",
  "PE = m × g × h"
 ],
 [
  "Physics",
  "Elastic Potential Energy",
  "PE = ½ × k × x²"
 ],
 [
  "Physics",
  "Work-Energy Theorem",
  "W(net) = ΔKE"
 ],
 [
  "Physics",
  "Power",
  "P = W / t = F × v"
 ],
 [
  "Physics",
  "Efficiency",
  "η = (output / input) × 100%"
 ],
 [
  "Physics",
  "Torque",
  "τ = r × F × sin θ"
 ],
 [
  "Physics",
  "Angular Velocity",
  "ω = Δθ / Δt"
 ],
 [
  "Physics",
  "Angular Acceleration",
  "α = Δω / Δt"
 ],
 [
  "Physics",
  "Centripetal Acceleration",
  "ac = v² / r = ω² × r"
 ],
 [
  "Physics",
  "Centripetal Force",
  "Fc = m × v² / r"
 ],
 [
  "Physics",
  "Moment of Inertia (ring)",
  "I = m × r²"
 ],
 [
  "Physics",
  "Moment of Inertia (disc)",
  "I = ½ × m × r²"
 ],
 [
  "Physics",
  "Moment of Inertia (rod)",
  "I = (1/12) × m × L²"
 ],
 [
  "Physics",
  "Rotational Kinetic Energy",
  "KE = ½ × I × ω²"
 ],
 [
  "Physics",
  "Angular Momentum",
  "L = I × ω"
 ],
 [
  "Physics",
  "Projectile Range",
  "R = v0² × sin 2θ / g"
 ],
 [
  "Physics",
  "Projectile Max Height",
  "H = v0² × sin²θ / (2 × g)"
 ],
 [
  "Physics",
  "Projectile Time of Flight",
  "T = 2 × v0 × sin θ / g"
 ],
 [
  "Physics",
  "Orbital Velocity",
  "v = √(G × M / r)"
 ],
 [
  "Physics",
  "Escape Velocity",
  "ve = √(2 × G × M / r)"
 ],
 [
  "Physics",
  "Kepler's Third Law",
  "T² ∝ r³"
 ],
 [
  "Physics",
  "Gravitational Potential Energy",
  "U = -G × m1 × m2 / r"
 ],
 [
  "Physics",
  "Gravitational Field Strength",
  "g = G × M / r²"
 ],
 [
  "Physics",
  "Kinetic Friction",
  "fk = μk × N"
 ],
 [
  "Physics",
  "Static Friction (max)",
  "fs ≤ μs × N"
 ],
 [
  "Physics",
  "Hooke's Law",
  "F = k × x"
 ],
 [
  "Physics",
  "Young's Modulus",
  "Y = (F/A) / (ΔL/L)"
 ],
 [
  "Physics",
  "Bulk Modulus",
  "B = -ΔP / (ΔV/V)"
 ],
 [
  "Physics",
  "Density",
  "ρ = m / V"
 ],
 [
  "Physics",
  "Pressure",
  "P = F / A"
 ],
 [
  "Physics",
  "Liquid Pressure",
  "P = ρ × g × h"
 ],
 [
  "Physics",
  "Archimedes' Principle",
  "Fb = ρ(fluid) × V × g"
 ],
 [
  "Physics",
  "Bernoulli's Equation",
  "P + ½ρv² + ρgh = constant"
 ],
 [
  "Physics",
  "Torricelli's Law",
  "v = √(2 × g × h)"
 ],
 [
  "Physics",
  "Stokes' Law",
  "F = 6 × π × η × r × v"
 ],
 [
  "Physics",
  "Surface Tension",
  "T = F / L"
 ],
 [
  "Physics",
  "Wave Speed",
  "v = f × λ"
 ],
 [
  "Physics",
  "Frequency and Period",
  "T = 1 / f"
 ],
 [
  "Physics",
  "Simple Pendulum Period",
  "T = 2π × √(L/g)"
 ],
 [
  "Physics",
  "Mass-Spring Period",
  "T = 2π × √(m/k)"
 ],
 [
  "Physics",
  "SHM Displacement",
  "x = A × sin(ω × t + φ)"
 ],
 [
  "Physics",
  "SHM Acceleration",
  "a = -ω² × x"
 ],
 [
  "Physics",
  "Angular Frequency",
  "ω = 2 × π × f"
 ],
 [
  "Physics",
  "Speed of Sound (0°C)",
  "v = 331 m/s"
 ],
 [
  "Physics",
  "Doppler Effect",
  "f' = f × (v ± vo) / (v ∓ vs)"
 ],
 [
  "Physics",
  "Beat Frequency",
  "f(beat) = |f1 - f2|"
 ],
 [
  "Physics",
  "Wave Intensity",
  "I = P / A"
 ],
 [
  "Physics",
  "Sound Level",
  "β = 10 × log(I / I0)"
 ],
 [
  "Physics",
  "Specific Heat",
  "Q = m × c × ΔT"
 ],
 [
  "Physics",
  "Latent Heat",
  "Q = m × L"
 ],
 [
  "Physics",
  "Linear Expansion",
  "ΔL = α × L0 × ΔT"
 ],
 [
  "Physics",
  "Boyle's Law",
  "P1 × V1 = P2 × V2"
 ],
 [
  "Physics",
  "Charles's Law",
  "V1 / T1 = V2 / T2"
 ],
 [
  "Physics",
  "Pressure Law",
  "P1 / T1 = P2 / T2"
 ],
 [
  "Physics",
  "Ideal Gas Law",
  "P × V = n × R × T"
 ],
 [
  "Physics",
  "First Law of Thermodynamics",
  "ΔU = Q - W"
 ],
 [
  "Physics",
  "Carnot Efficiency",
  "η = 1 - Tc / Th"
 ],
 [
  "Physics",
  "Thermal Conduction",
  "Q/t = k × A × ΔT / L"
 ],
 [
  "Physics",
  "Entropy Change",
  "ΔS = Q(rev) / T"
 ],
 [
  "Physics",
  "RMS Speed of Gas",
  "vrms = √(3 × R × T / M)"
 ],
 [
  "Physics",
  "Coulomb's Law",
  "F = k × q1 × q2 / r²"
 ],
 [
  "Physics",
  "Electric Field",
  "E = F / q"
 ],
 [
  "Physics",
  "Field of Point Charge",
  "E = k × q / r²"
 ],
 [
  "Physics",
  "Electric Potential",
  "V = k × q / r"
 ],
 [
  "Physics",
  "Capacitance",
  "C = Q / V"
 ],
 [
  "Physics",
  "Parallel-Plate Capacitor",
  "C = ε0 × A / d"
 ],
 [
  "Physics",
  "Capacitors in Series",
  "1/C = 1/C1 + 1/C2"
 ],
 [
  "Physics",
  "Capacitors in Parallel",
  "C = C1 + C2"
 ],
 [
  "Physics",
  "Energy in Capacitor",
  "U = ½ × C × V²"
 ],
 [
  "Physics",
  "Electric Current",
  "I = Q / t"
 ],
 [
  "Physics",
  "Ohm's Law",
  "V = I × R"
 ],
 [
  "Physics",
  "Resistance",
  "R = ρ × L / A"
 ],
 [
  "Physics",
  "Resistors in Series",
  "R = R1 + R2"
 ],
 [
  "Physics",
  "Resistors in Parallel",
  "1/R = 1/R1 + 1/R2"
 ],
 [
  "Physics",
  "Electric Power",
  "P = V × I = I² × R"
 ],
 [
  "Physics",
  "Joule Heating",
  "H = I² × R × t"
 ],
 [
  "Physics",
  "Kirchhoff's Current Law",
  "ΣI(in) = ΣI(out)"
 ],
 [
  "Physics",
  "Kirchhoff's Voltage Law",
  "ΣV = 0 around a loop"
 ],
 [
  "Physics",
  "EMF and Internal Resistance",
  "ε = V + I × r"
 ],
 [
  "Physics",
  "Drift Velocity",
  "I = n × A × vd × e"
 ],
 [
  "Physics",
  "Magnetic Force on Charge",
  "F = q × v × B × sin θ"
 ],
 [
  "Physics",
  "Magnetic Force on Wire",
  "F = I × L × B × sin θ"
 ],
 [
  "Physics",
  "Faraday's Law",
  "ε = -N × ΔΦ / Δt"
 ],
 [
  "Physics",
  "Magnetic Flux",
  "Φ = B × A × cos θ"
 ],
 [
  "Physics",
  "Transformer Equation",
  "Vs / Vp = Ns / Np"
 ],
 [
  "Physics",
  "Cyclotron Frequency",
  "f = q × B / (2 × π × m)"
 ],
 [
  "Physics",
  "Snell's Law",
  "n1 × sin θ1 = n2 × sin θ2"
 ],
 [
  "Physics",
  "Refractive Index",
  "n = c / v"
 ],
 [
  "Physics",
  "Mirror and Lens Formula",
  "1/f = 1/v + 1/u"
 ],
 [
  "Physics",
  "Magnification",
  "m = hi / ho = -v / u"
 ],
 [
  "Physics",
  "Lens Maker's Formula",
  "1/f = (n-1) × (1/R1 - 1/R2)"
 ],
 [
  "Physics",
  "Power of Lens",
  "P = 100 / f(cm)"
 ],
 [
  "Physics",
  "Critical Angle",
  "sin θc = 1 / n"
 ],
 [
  "Physics",
  "Photon Energy",
  "E = h × f = h × c / λ"
 ],
 [
  "Physics",
  "Photoelectric Equation",
  "h × f = φ + KE(max)"
 ],
 [
  "Physics",
  "de Broglie Wavelength",
  "λ = h / p"
 ],
 [
  "Physics",
  "Mass-Energy Equivalence",
  "E = m × c²"
 ],
 [
  "Physics",
  "Radioactive Decay",
  "N = N0 × e^(-λt)"
 ],
 [
  "Physics",
  "Half-Life",
  "T(½) = 0.693 / λ"
 ],
 [
  "Physics",
  "Binding Energy",
  "BE = Δm × c²"
 ],
 [
  "Physics",
  "Speed of Light",
  "c = 3 × 10⁸ m/s"
 ],
 [
  "Physics",
  "Gravitational Constant",
  "G = 6.67 × 10⁻¹¹ N·m²/kg²"
 ],
 [
  "Physics",
  "Planck's Constant",
  "h = 6.63 × 10⁻³⁴ J·s"
 ],
 [
  "Physics",
  "Elementary Charge",
  "e = 1.6 × 10⁻¹⁹ C"
 ],
 [
  "Physics",
  "Coulomb's Constant",
  "k = 9 × 10⁹ N·m²/C²"
 ],
 [
  "Physics",
  "Permittivity of Free Space",
  "ε0 = 8.85 × 10⁻¹² C²/(N·m²)"
 ],
 [
  "Physics",
  "Avogadro's Number",
  "NA = 6.022 × 10²³ /mol"
 ],
 [
  "Physics",
  "Universal Gas Constant",
  "R = 8.31 J/(mol·K)"
 ],
 [
  "Physics",
  "Electron Mass",
  "me = 9.11 × 10⁻³¹ kg"
 ],
 [
  "Physics",
  "Proton Mass",
  "mp = 1.67 × 10⁻²⁷ kg"
 ],
 [
  "Physics",
  "Electron-Volt",
  "1 eV = 1.6 × 10⁻¹⁹ J"
 ],
 [
  "Physics",
  "Kilowatt-Hour",
  "1 kWh = 3.6 × 10⁶ J"
 ],
 [
  "Physics",
  "Calorie to Joule",
  "1 cal = 4.184 J"
 ],
 [
  "Physics",
  "Atmosphere to Pascal",
  "1 atm = 101325 Pa"
 ],
 [
  "Physics",
  "Light Year",
  "1 ly = 9.46 × 10¹⁵ m"
 ],
 [
  "Physics",
  "Celsius to Fahrenheit",
  "°F = (9/5) × °C + 32"
 ],
 [
  "Physics",
  "Nano Prefix",
  "1 nm = 10⁻⁹ m"
 ],
 [
  "Physics",
  "Micro Prefix",
  "1 μm = 10⁻⁶ m"
 ],
 [
  "Chemistry",
  "Number of Moles",
  "n = m / M"
 ],
 [
  "Chemistry",
  "Molarity",
  "M = n / V(L)"
 ],
 [
  "Chemistry",
  "Molality",
  "m = n / kg of solvent"
 ],
 [
  "Chemistry",
  "Mole Fraction",
  "xA = nA / n(total)"
 ],
 [
  "Chemistry",
  "Mass Percent",
  "% = (solute mass / solution mass) × 100"
 ],
 [
  "Chemistry",
  "Dilution Law",
  "M1 × V1 = M2 × V2"
 ],
 [
  "Chemistry",
  "Percent Composition",
  "% element = (element mass / molar mass) × 100"
 ],
 [
  "Chemistry",
  "Molecular Formula",
  "n = M(molecular) / M(empirical)"
 ],
 [
  "Chemistry",
  "Percent Yield",
  "% yield = (actual / theoretical) × 100"
 ],
 [
  "Chemistry",
  "Molar Volume at STP",
  "V = 22.4 L/mol at 0°C, 1 atm"
 ],
 [
  "Chemistry",
  "Ideal Gas Law",
  "P × V = n × R × T"
 ],
 [
  "Chemistry",
  "Combined Gas Law",
  "P1V1/T1 = P2V2/T2"
 ],
 [
  "Chemistry",
  "Dalton's Law",
  "P(total) = P1 + P2 + ..."
 ],
 [
  "Chemistry",
  "Partial Pressure",
  "Pi = xi × P(total)"
 ],
 [
  "Chemistry",
  "Graham's Law",
  "r1 / r2 = √(M2 / M1)"
 ],
 [
  "Chemistry",
  "Gas Density",
  "d = P × M / (R × T)"
 ],
 [
  "Chemistry",
  "Avogadro's Law",
  "V1 / n1 = V2 / n2"
 ],
 [
  "Chemistry",
  "Bohr Radius",
  "rn = n² × a0  (a0 = 0.529 Å)"
 ],
 [
  "Chemistry",
  "Electron Energy (Hydrogen)",
  "En = -13.6 / n² eV"
 ],
 [
  "Chemistry",
  "Rydberg Formula",
  "1/λ = RH × (1/n1² - 1/n2²)"
 ],
 [
  "Chemistry",
  "Planck's Equation",
  "E = h × ν"
 ],
 [
  "Chemistry",
  "Wave Equation",
  "c = λ × ν"
 ],
 [
  "Chemistry",
  "de Broglie Equation",
  "λ = h / (m × v)"
 ],
 [
  "Chemistry",
  "Heisenberg Uncertainty",
  "Δx × Δp ≥ h / (4π)"
 ],
 [
  "Chemistry",
  "Max Electrons per Shell",
  "2 × n²"
 ],
 [
  "Chemistry",
  "Bond Order",
  "(Nb - Na) / 2"
 ],
 [
  "Chemistry",
  "Formal Charge",
  "V - (N + B/2)"
 ],
 [
  "Chemistry",
  "Dipole Moment",
  "μ = q × d"
 ],
 [
  "Chemistry",
  "Raoult's Law",
  "P = xA × P°A + xB × P°B"
 ],
 [
  "Chemistry",
  "Freezing Point Depression",
  "ΔTf = Kf × m"
 ],
 [
  "Chemistry",
  "Boiling Point Elevation",
  "ΔTb = Kb × m"
 ],
 [
  "Chemistry",
  "Osmotic Pressure",
  "π = i × M × R × T"
 ],
 [
  "Chemistry",
  "Henry's Law",
  "C = k × P"
 ],
 [
  "Chemistry",
  "Bragg's Law",
  "n × λ = 2 × d × sin θ"
 ],
 [
  "Chemistry",
  "Unit Cell Density",
  "ρ = Z × M / (NA × a³)"
 ],
 [
  "Chemistry",
  "Enthalpy Change",
  "ΔH = ΣH(products) - ΣH(reactants)"
 ],
 [
  "Chemistry",
  "Hess's Law",
  "ΔH(total) = ΔH1 + ΔH2 + ..."
 ],
 [
  "Chemistry",
  "Bond Enthalpy Method",
  "ΔH = ΣBE(reactants) - ΣBE(products)"
 ],
 [
  "Chemistry",
  "Entropy Change",
  "ΔS = ΣS(products) - ΣS(reactants)"
 ],
 [
  "Chemistry",
  "Gibbs Free Energy",
  "ΔG = ΔH - T × ΔS"
 ],
 [
  "Chemistry",
  "Free Energy and K",
  "ΔG° = -R × T × ln K"
 ],
 [
  "Chemistry",
  "Equilibrium Constant",
  "Kc = [products] / [reactants]"
 ],
 [
  "Chemistry",
  "Kp and Kc Relation",
  "Kp = Kc × (R × T)^Δn"
 ],
 [
  "Chemistry",
  "pH",
  "pH = -log[H+]"
 ],
 [
  "Chemistry",
  "pOH",
  "pOH = -log[OH-]"
 ],
 [
  "Chemistry",
  "pH + pOH",
  "pH + pOH = 14 (at 25°C)"
 ],
 [
  "Chemistry",
  "Ionic Product of Water",
  "Kw = [H+][OH-] = 1.0 × 10⁻¹⁴"
 ],
 [
  "Chemistry",
  "Henderson-Hasselbalch",
  "pH = pKa + log([A-]/[HA])"
 ],
 [
  "Chemistry",
  "Solubility Product",
  "Ksp = [cation]^x [anion]^y"
 ],
 [
  "Chemistry",
  "Rate Law",
  "rate = k × [A]^m × [B]^n"
 ],
 [
  "Chemistry",
  "First-Order Integrated Law",
  "ln[A] = -k × t + ln[A]0"
 ],
 [
  "Chemistry",
  "First-Order Half-Life",
  "t(½) = 0.693 / k"
 ],
 [
  "Chemistry",
  "Arrhenius Equation",
  "k = A × e^(-Ea/(R×T))"
 ],
 [
  "Chemistry",
  "Faraday's First Law",
  "w = (M × I × t) / (n × F)"
 ],
 [
  "Chemistry",
  "Nernst Equation",
  "E = E° - (0.0592/n) × log Q"
 ],
 [
  "Chemistry",
  "Cell Free Energy",
  "ΔG° = -n × F × E°"
 ],
 [
  "Chemistry",
  "Faraday Constant",
  "F = 96500 C/mol"
 ],
 [
  "Chemistry",
  "Alkane General Formula",
  "Cn H2n+2"
 ],
 [
  "Chemistry",
  "Alkene General Formula",
  "Cn H2n"
 ],
 [
  "Chemistry",
  "Alkyne General Formula",
  "Cn H2n-2"
 ],
 [
  "Chemistry",
  "Degree of Unsaturation",
  "DU = C - H/2 + N/2 + 1"
 ],
 [
  "Chemistry",
  "Markovnikov's Rule",
  "H adds to the carbon already having more H atoms"
 ],
 [
  "Math",
  "Quadratic Formula",
  "x = (-b ± √(b² - 4ac)) / (2a)"
 ],
 [
  "Math",
  "Discriminant",
  "D = b² - 4ac"
 ],
 [
  "Math",
  "Sum of Roots",
  "α + β = -b / a"
 ],
 [
  "Math",
  "Product of Roots",
  "α × β = c / a"
 ],
 [
  "Math",
  "(a+b)²",
  "a² + 2ab + b²"
 ],
 [
  "Math",
  "(a-b)²",
  "a² - 2ab + b²"
 ],
 [
  "Math",
  "a²-b²",
  "(a - b)(a + b)"
 ],
 [
  "Math",
  "(a+b)³",
  "a³ + 3a²b + 3ab² + b³"
 ],
 [
  "Math",
  "a³+b³",
  "(a + b)(a² - ab + b²)"
 ],
 [
  "Math",
  "a³-b³",
  "(a - b)(a² + ab + b²)"
 ],
 [
  "Math",
  "Binomial Theorem",
  "(a+b)^n = Σ C(n,k) a^(n-k) b^k"
 ],
 [
  "Math",
  "nCr",
  "n! / (r! × (n-r)!)"
 ],
 [
  "Math",
  "nPr",
  "n! / (n-r)!"
 ],
 [
  "Math",
  "Exponent Law",
  "a^m × a^n = a^(m+n)"
 ],
 [
  "Math",
  "Power of Power",
  "(a^m)^n = a^(m×n)"
 ],
 [
  "Math",
  "Log of Product",
  "log(a×b) = log a + log b"
 ],
 [
  "Math",
  "Log of Quotient",
  "log(a/b) = log a - log b"
 ],
 [
  "Math",
  "Log of Power",
  "log(a^n) = n × log a"
 ],
 [
  "Math",
  "Change of Base",
  "log(a)b = log b / log a"
 ],
 [
  "Math",
  "Arithmetic nth Term",
  "an = a + (n-1) × d"
 ],
 [
  "Math",
  "Arithmetic Sum",
  "Sn = n/2 × (2a + (n-1)d)"
 ],
 [
  "Math",
  "Geometric nth Term",
  "an = a × r^(n-1)"
 ],
 [
  "Math",
  "Geometric Sum",
  "Sn = a × (r^n - 1) / (r - 1)"
 ],
 [
  "Math",
  "Infinite GP Sum",
  "S = a / (1 - r), |r| < 1"
 ],
 [
  "Math",
  "Sum of First n Naturals",
  "n × (n+1) / 2"
 ],
 [
  "Math",
  "Sum of Squares",
  "n(n+1)(2n+1) / 6"
 ],
 [
  "Math",
  "Sum of Cubes",
  "[n(n+1)/2]²"
 ],
 [
  "Math",
  "2×2 Determinant",
  "ad - bc"
 ],
 [
  "Math",
  "Matrix Inverse",
  "A⁻¹ = adj(A) / det(A)"
 ],
 [
  "Math",
  "Cramer's Rule",
  "x = Dx/D, y = Dy/D"
 ],
 [
  "Math",
  "Pythagorean Identity",
  "sin²θ + cos²θ = 1"
 ],
 [
  "Math",
  "tan-sec Identity",
  "1 + tan²θ = sec²θ"
 ],
 [
  "Math",
  "cot-csc Identity",
  "1 + cot²θ = csc²θ"
 ],
 [
  "Math",
  "sin(A+B)",
  "sin A cos B + cos A sin B"
 ],
 [
  "Math",
  "cos(A+B)",
  "cos A cos B - sin A sin B"
 ],
 [
  "Math",
  "tan(A+B)",
  "(tan A + tan B) / (1 - tan A tan B)"
 ],
 [
  "Math",
  "sin 2θ",
  "2 sin θ cos θ"
 ],
 [
  "Math",
  "cos 2θ",
  "cos²θ - sin²θ = 2cos²θ - 1"
 ],
 [
  "Math",
  "tan 2θ",
  "2 tan θ / (1 - tan²θ)"
 ],
 [
  "Math",
  "Sum to Product",
  "sin C + sin D = 2 sin((C+D)/2) cos((C-D)/2)"
 ],
 [
  "Math",
  "Law of Sines",
  "a/sin A = b/sin B = c/sin C = 2R"
 ],
 [
  "Math",
  "Law of Cosines",
  "a² = b² + c² - 2bc cos A"
 ],
 [
  "Math",
  "Triangle Area",
  "½ × a × b × sin C"
 ],
 [
  "Math",
  "Heron's Formula",
  "√[s(s-a)(s-b)(s-c)], s = (a+b+c)/2"
 ],
 [
  "Math",
  "Power Rule",
  "d/dx(x^n) = n × x^(n-1)"
 ],
 [
  "Math",
  "Product Rule",
  "(uv)' = u'v + uv'"
 ],
 [
  "Math",
  "Quotient Rule",
  "(u/v)' = (u'v - uv') / v²"
 ],
 [
  "Math",
  "Chain Rule",
  "dy/dx = dy/du × du/dx"
 ],
 [
  "Math",
  "Derivative of sin x",
  "cos x"
 ],
 [
  "Math",
  "Derivative of cos x",
  "-sin x"
 ],
 [
  "Math",
  "Derivative of e^x",
  "e^x"
 ],
 [
  "Math",
  "Derivative of ln x",
  "1/x"
 ],
 [
  "Math",
  "Integral of x^n",
  "x^(n+1)/(n+1) + C"
 ],
 [
  "Math",
  "Integral of sin x",
  "-cos x + C"
 ],
 [
  "Math",
  "Integral of cos x",
  "sin x + C"
 ],
 [
  "Math",
  "Integral of e^x",
  "e^x + C"
 ],
 [
  "Math",
  "Integral of 1/x",
  "ln|x| + C"
 ],
 [
  "Math",
  "Limit sin x / x",
  "lim(x→0) sin x / x = 1"
 ],
 [
  "Math",
  "Distance Formula",
  "d = √[(x2-x1)² + (y2-y1)²]"
 ],
 [
  "Math",
  "Midpoint Formula",
  "((x1+x2)/2, (y1+y2)/2)"
 ],
 [
  "Math",
  "Slope",
  "m = (y2-y1) / (x2-x1)"
 ],
 [
  "Math",
  "Slope-Intercept Form",
  "y = m × x + c"
 ],
 [
  "Math",
  "Point to Line Distance",
  "|ax1 + by1 + c| / √(a² + b²)"
 ],
 [
  "Math",
  "Circle Equation",
  "(x-h)² + (y-k)² = r²"
 ],
 [
  "Math",
  "Parabola",
  "y² = 4 × a × x"
 ],
 [
  "Math",
  "Ellipse",
  "x²/a² + y²/b² = 1"
 ],
 [
  "Math",
  "Hyperbola",
  "x²/a² - y²/b² = 1"
 ],
 [
  "Math",
  "Vector Magnitude",
  "|a| = √(a1² + a2² + a3²)"
 ],
 [
  "Math",
  "Dot Product",
  "a·b = |a||b| cos θ"
 ],
 [
  "Math",
  "Cross Product Magnitude",
  "|a×b| = |a||b| sin θ"
 ],
 [
  "Math",
  "Unit Vector",
  "a(unit) = a / |a|"
 ],
 [
  "Math",
  "Probability",
  "P(A) = favourable / total"
 ],
 [
  "Math",
  "Addition Rule",
  "P(A∪B) = P(A) + P(B) - P(A∩B)"
 ],
 [
  "Math",
  "Bayes' Theorem",
  "P(A|B) = P(B|A)P(A) / P(B)"
 ],
 [
  "Math",
  "Binomial Probability",
  "P(X=k) = C(n,k) p^k (1-p)^(n-k)"
 ],
 [
  "Math",
  "Variance",
  "σ² = Σ(x - μ)² / N"
 ],
 [
  "Math",
  "Complex Modulus",
  "|a + bi| = √(a² + b²)"
 ],
 [
  "Math",
  "De Moivre's Theorem",
  "(cos θ + i sin θ)^n = cos nθ + i sin nθ"
 ]
]
VOCAB = [
 [
  "Knowledge",
  "علم"
 ],
 [
  "Education",
  "تعلیم"
 ],
 [
  "Student",
  "طالب علم"
 ],
 [
  "Teacher",
  "استاد"
 ],
 [
  "Book",
  "کتاب"
 ],
 [
  "Lesson",
  "سبق"
 ],
 [
  "Exam",
  "امتحان"
 ],
 [
  "Question",
  "سوال"
 ],
 [
  "Answer",
  "جواب"
 ],
 [
  "School",
  "اسکول"
 ],
 [
  "College",
  "کالج"
 ],
 [
  "University",
  "یونیورسٹی"
 ],
 [
  "Classroom",
  "جماعت"
 ],
 [
  "Homework",
  "گھر کا کام"
 ],
 [
  "Notebook",
  "کاپی"
 ],
 [
  "Pen",
  "قلم"
 ],
 [
  "Pencil",
  "پنسل"
 ],
 [
  "Page",
  "صفحہ"
 ],
 [
  "Chapter",
  "باب"
 ],
 [
  "Syllabus",
  "نصاب"
 ],
 [
  "Result",
  "نتیجہ"
 ],
 [
  "Marks",
  "نمبر"
 ],
 [
  "Grade",
  "درجہ"
 ],
 [
  "Degree",
  "سند"
 ],
 [
  "Library",
  "لائبریری"
 ],
 [
  "Research",
  "تحقیق"
 ],
 [
  "Science",
  "سائنس"
 ],
 [
  "Experiment",
  "تجربہ"
 ],
 [
  "Theory",
  "نظریہ"
 ],
 [
  "Definition",
  "تعریف"
 ],
 [
  "Example",
  "مثال"
 ],
 [
  "Exercise",
  "مشق"
 ],
 [
  "Practice",
  "مشق"
 ],
 [
  "Memory",
  "یادداشت"
 ],
 [
  "Mind",
  "ذہن"
 ],
 [
  "Thought",
  "خیال"
 ],
 [
  "Idea",
  "تصور"
 ],
 [
  "Wisdom",
  "حکمت"
 ],
 [
  "Intelligence",
  "ذہانت"
 ],
 [
  "Diligence",
  "محنت"
 ],
 [
  "Effort",
  "کوشش"
 ],
 [
  "Success",
  "کامیابی"
 ],
 [
  "Failure",
  "ناکامی"
 ],
 [
  "Progress",
  "ترقی"
 ],
 [
  "Discipline",
  "نظم و ضبط"
 ],
 [
  "Go",
  "جانا"
 ],
 [
  "Come",
  "آنا"
 ],
 [
  "Eat",
  "کھانا"
 ],
 [
  "Drink",
  "پینا"
 ],
 [
  "Sleep",
  "سونا"
 ],
 [
  "Wake up",
  "جاگنا"
 ],
 [
  "Walk",
  "چلنا"
 ],
 [
  "Run",
  "دوڑنا"
 ],
 [
  "Sit",
  "بیٹھنا"
 ],
 [
  "Stand",
  "کھڑا ہونا"
 ],
 [
  "Read",
  "پڑھنا"
 ],
 [
  "Write",
  "لکھنا"
 ],
 [
  "Speak",
  "بولنا"
 ],
 [
  "Listen",
  "سننا"
 ],
 [
  "See",
  "دیکھنا"
 ],
 [
  "Watch",
  "غور سے دیکھنا"
 ],
 [
  "Learn",
  "سیکھنا"
 ],
 [
  "Teach",
  "سکھانا"
 ],
 [
  "Study",
  "مطالعہ کرنا"
 ],
 [
  "Understand",
  "سمجھنا"
 ],
 [
  "Know",
  "جاننا"
 ],
 [
  "Think",
  "سوچنا"
 ],
 [
  "Believe",
  "یقین کرنا"
 ],
 [
  "Remember",
  "یاد کرنا"
 ],
 [
  "Forget",
  "بھولنا"
 ],
 [
  "Work",
  "کام کرنا"
 ],
 [
  "Play",
  "کھیلنا"
 ],
 [
  "Rest",
  "آرام کرنا"
 ],
 [
  "Help",
  "مدد کرنا"
 ],
 [
  "Ask",
  "پوچھنا"
 ],
 [
  "Answer",
  "جواب دینا"
 ],
 [
  "Tell",
  "بتانا"
 ],
 [
  "Say",
  "کہنا"
 ],
 [
  "Call",
  "بلانا"
 ],
 [
  "Give",
  "دینا"
 ],
 [
  "Take",
  "لینا"
 ],
 [
  "Bring",
  "لانا"
 ],
 [
  "Carry",
  "لے جانا"
 ],
 [
  "Buy",
  "خریدنا"
 ],
 [
  "Sell",
  "بیچنا"
 ],
 [
  "Pay",
  "ادا کرنا"
 ],
 [
  "Open",
  "کھولنا"
 ],
 [
  "Close",
  "بند کرنا"
 ],
 [
  "Start",
  "شروع کرنا"
 ],
 [
  "Finish",
  "ختم کرنا"
 ],
 [
  "Stop",
  "رکنا"
 ],
 [
  "Wait",
  "انتظار کرنا"
 ],
 [
  "Hurry",
  "جلدی کرنا"
 ],
 [
  "Laugh",
  "ہنسنا"
 ],
 [
  "Cry",
  "رونا"
 ],
 [
  "Smile",
  "مسکرانا"
 ],
 [
  "Love",
  "پیار کرنا"
 ],
 [
  "Like",
  "پسند کرنا"
 ],
 [
  "Hate",
  "نفرت کرنا"
 ],
 [
  "Fear",
  "ڈرنا"
 ],
 [
  "Hope",
  "امید رکھنا"
 ],
 [
  "Wish",
  "خواہش کرنا"
 ],
 [
  "Try",
  "کوشش کرنا"
 ],
 [
  "Win",
  "جیتنا"
 ],
 [
  "Lose",
  "ہارنا"
 ],
 [
  "Find",
  "ڈھونڈنا"
 ],
 [
  "Search",
  "تلاش کرنا"
 ],
 [
  "Meet",
  "ملنا"
 ],
 [
  "Visit",
  "ملنے جانا"
 ],
 [
  "Travel",
  "سفر کرنا"
 ],
 [
  "Drive",
  "گاڑی چلانا"
 ],
 [
  "Ride",
  "سوار ہونا"
 ],
 [
  "Fly",
  "اڑنا"
 ],
 [
  "Swim",
  "تیرنا"
 ],
 [
  "Climb",
  "چڑھنا"
 ],
 [
  "Fall",
  "گرنا"
 ],
 [
  "Jump",
  "کودنا"
 ],
 [
  "Dance",
  "ناچنا"
 ],
 [
  "Sing",
  "گانا"
 ],
 [
  "Cook",
  "پکانا"
 ],
 [
  "Wash",
  "دھونا"
 ],
 [
  "Clean",
  "صاف کرنا"
 ],
 [
  "Build",
  "تعمیر کرنا"
 ],
 [
  "Break",
  "توڑنا"
 ],
 [
  "Fix",
  "مرمت کرنا"
 ],
 [
  "Grow",
  "بڑھنا"
 ],
 [
  "Plant",
  "پودا لگانا"
 ],
 [
  "Water",
  "پانی دینا"
 ],
 [
  "Shine",
  "چمکنا"
 ],
 [
  "Rain",
  "بارش ہونا"
 ],
 [
  "Big",
  "بڑا"
 ],
 [
  "Small",
  "چھوٹا"
 ],
 [
  "Tall",
  "لمبا"
 ],
 [
  "Short",
  "پست قد"
 ],
 [
  "Long",
  "لمبا"
 ],
 [
  "Wide",
  "چوڑا"
 ],
 [
  "Narrow",
  "تنگ"
 ],
 [
  "Thick",
  "موٹا"
 ],
 [
  "Thin",
  "پتلا"
 ],
 [
  "Heavy",
  "بھاری"
 ],
 [
  "Light",
  "ہلکا"
 ],
 [
  "Hard",
  "سخت"
 ],
 [
  "Soft",
  "نرم"
 ],
 [
  "Hot",
  "گرم"
 ],
 [
  "Cold",
  "ٹھنڈا"
 ],
 [
  "Warm",
  "نیم گرم"
 ],
 [
  "Dry",
  "خشک"
 ],
 [
  "Wet",
  "گیلا"
 ],
 [
  "Clean",
  "صاف"
 ],
 [
  "Dirty",
  "میلا"
 ],
 [
  "New",
  "نیا"
 ],
 [
  "Old",
  "پرانا"
 ],
 [
  "Young",
  "جوان"
 ],
 [
  "Beautiful",
  "خوبصورت"
 ],
 [
  "Ugly",
  "بدصورت"
 ],
 [
  "Good",
  "اچھا"
 ],
 [
  "Bad",
  "برا"
 ],
 [
  "Best",
  "بہترین"
 ],
 [
  "Worst",
  "بدترین"
 ],
 [
  "Rich",
  "امیر"
 ],
 [
  "Poor",
  "غریب"
 ],
 [
  "Happy",
  "خوش"
 ],
 [
  "Sad",
  "اداس"
 ],
 [
  "Angry",
  "غصے میں"
 ],
 [
  "Kind",
  "مہربان"
 ],
 [
  "Cruel",
  "ظالم"
 ],
 [
  "Brave",
  "بہادر"
 ],
 [
  "Coward",
  "بزدل"
 ],
 [
  "Honest",
  "ایماندار"
 ],
 [
  "Dishonest",
  "بے ایمان"
 ],
 [
  "True",
  "سچا"
 ],
 [
  "False",
  "جھوٹا"
 ],
 [
  "Strong",
  "طاقتور"
 ],
 [
  "Weak",
  "کمزور"
 ],
 [
  "Fast",
  "تیز"
 ],
 [
  "Slow",
  "سست"
 ],
 [
  "Early",
  "سویرے"
 ],
 [
  "Late",
  "دیر سے"
 ],
 [
  "High",
  "اونچا"
 ],
 [
  "Low",
  "نیچا"
 ],
 [
  "Deep",
  "گہرا"
 ],
 [
  "Shallow",
  "اتھلا"
 ],
 [
  "Full",
  "بھرا ہوا"
 ],
 [
  "Empty",
  "خالی"
 ],
 [
  "Bright",
  "روشن"
 ],
 [
  "Dark",
  "تاریک"
 ],
 [
  "Sweet",
  "میٹھا"
 ],
 [
  "Sour",
  "کھٹا"
 ],
 [
  "Bitter",
  "کڑوا"
 ],
 [
  "Salty",
  "نمکین"
 ],
 [
  "Spicy",
  "مصالحہ دار"
 ],
 [
  "Fresh",
  "تازہ"
 ],
 [
  "Stale",
  "باسی"
 ],
 [
  "Cheap",
  "سستا"
 ],
 [
  "Expensive",
  "مہنگا"
 ],
 [
  "Easy",
  "آسان"
 ],
 [
  "Difficult",
  "مشکل"
 ],
 [
  "Important",
  "اہم"
 ],
 [
  "Famous",
  "مشہور"
 ],
 [
  "Strange",
  "عجیب"
 ],
 [
  "Common",
  "عام"
 ],
 [
  "Special",
  "خاص"
 ],
 [
  "Different",
  "مختلف"
 ],
 [
  "Same",
  "ایک جیسا"
 ],
 [
  "Similar",
  "ملتا جلتا"
 ],
 [
  "Opposite",
  "الٹ"
 ],
 [
  "Near",
  "قریب"
 ],
 [
  "Far",
  "دور"
 ],
 [
  "Right",
  "صحیح"
 ],
 [
  "Wrong",
  "غلط"
 ],
 [
  "Ready",
  "تیار"
 ],
 [
  "Busy",
  "مصروف"
 ],
 [
  "Free",
  "فارغ"
 ],
 [
  "Tired",
  "تھکا ہوا"
 ],
 [
  "Water",
  "پانی"
 ],
 [
  "Food",
  "کھانا"
 ],
 [
  "House",
  "گھر"
 ],
 [
  "Room",
  "کمرہ"
 ],
 [
  "Door",
  "دروازہ"
 ],
 [
  "Window",
  "کھڑکی"
 ],
 [
  "Table",
  "میز"
 ],
 [
  "Chair",
  "کرسی"
 ],
 [
  "Bed",
  "بستر"
 ],
 [
  "Cloth",
  "کپڑا"
 ],
 [
  "Shirt",
  "قمیض"
 ],
 [
  "Shoes",
  "جوتے"
 ],
 [
  "Key",
  "چابی"
 ],
 [
  "Lock",
  "تالا"
 ],
 [
  "Money",
  "رقم"
 ],
 [
  "Bag",
  "تھیلا"
 ],
 [
  "Box",
  "ڈبہ"
 ],
 [
  "Bottle",
  "بوتل"
 ],
 [
  "Cup",
  "پیالی"
 ],
 [
  "Glass",
  "گلاس"
 ],
 [
  "Plate",
  "تھالی"
 ],
 [
  "Spoon",
  "چمچ"
 ],
 [
  "Knife",
  "چھری"
 ],
 [
  "Mirror",
  "آئینہ"
 ],
 [
  "Comb",
  "کنگھی"
 ],
 [
  "Soap",
  "صابن"
 ],
 [
  "Towel",
  "تولیہ"
 ],
 [
  "Lamp",
  "لیمپ"
 ],
 [
  "Candle",
  "موم بتی"
 ],
 [
  "Matchbox",
  "ماچس"
 ],
 [
  "Fan",
  "پنکھا"
 ],
 [
  "Clock",
  "گھڑی"
 ],
 [
  "Phone",
  "فون"
 ],
 [
  "Mobile",
  "موبائل"
 ],
 [
  "Television",
  "ٹیلی ویژن"
 ],
 [
  "Radio",
  "ریڈیو"
 ],
 [
  "Newspaper",
  "اخبار"
 ],
 [
  "Letter",
  "خط"
 ],
 [
  "Message",
  "پیغام"
 ],
 [
  "News",
  "خبر"
 ],
 [
  "Picture",
  "تصویر"
 ],
 [
  "Photo",
  "فوٹو"
 ],
 [
  "Map",
  "نقشہ"
 ],
 [
  "Ticket",
  "ٹکٹ"
 ],
 [
  "Market",
  "بازار"
 ],
 [
  "Shop",
  "دکان"
 ],
 [
  "Price",
  "قیمت"
 ],
 [
  "Gift",
  "تحفہ"
 ],
 [
  "Wedding",
  "شادی"
 ],
 [
  "Guest",
  "مہمان"
 ],
 [
  "Host",
  "میزبان"
 ],
 [
  "Neighbour",
  "پڑوسی"
 ],
 [
  "Stranger",
  "اجنبی"
 ],
 [
  "Journey",
  "سفر"
 ],
 [
  "Sun",
  "سورج"
 ],
 [
  "Moon",
  "چاند"
 ],
 [
  "Star",
  "ستارہ"
 ],
 [
  "Sky",
  "آسمان"
 ],
 [
  "Cloud",
  "بادل"
 ],
 [
  "Rain",
  "بارش"
 ],
 [
  "Storm",
  "طوفان"
 ],
 [
  "Wind",
  "ہوا"
 ],
 [
  "Air",
  "فضا"
 ],
 [
  "Thunder",
  "گرج"
 ],
 [
  "Lightning",
  "بجلی"
 ],
 [
  "Rainbow",
  "قوس قزح"
 ],
 [
  "Earth",
  "زمین"
 ],
 [
  "World",
  "دنیا"
 ],
 [
  "Mountain",
  "پہاڑ"
 ],
 [
  "Hill",
  "پہاڑی"
 ],
 [
  "Valley",
  "وادی"
 ],
 [
  "River",
  "دریا"
 ],
 [
  "Sea",
  "سمندر"
 ],
 [
  "Ocean",
  "بحر"
 ],
 [
  "Lake",
  "جھیل"
 ],
 [
  "Pond",
  "تالاب"
 ],
 [
  "Well",
  "کنواں"
 ],
 [
  "Spring",
  "چشمہ"
 ],
 [
  "Desert",
  "صحرا"
 ],
 [
  "Forest",
  "جنگل"
 ],
 [
  "Garden",
  "باغ"
 ],
 [
  "Tree",
  "درخت"
 ],
 [
  "Flower",
  "پھول"
 ],
 [
  "Leaf",
  "پتا"
 ],
 [
  "Branch",
  "شاخ"
 ],
 [
  "Root",
  "جڑ"
 ],
 [
  "Seed",
  "بیج"
 ],
 [
  "Fruit",
  "پھل"
 ],
 [
  "Grass",
  "گھاس"
 ],
 [
  "Stone",
  "پتھر"
 ],
 [
  "Sand",
  "ریت"
 ],
 [
  "Dust",
  "گرد"
 ],
 [
  "Smoke",
  "دھواں"
 ],
 [
  "Fire",
  "آگ"
 ],
 [
  "Head",
  "سر"
 ],
 [
  "Hair",
  "بال"
 ],
 [
  "Face",
  "چہرہ"
 ],
 [
  "Eye",
  "آنکھ"
 ],
 [
  "Ear",
  "کان"
 ],
 [
  "Nose",
  "ناک"
 ],
 [
  "Mouth",
  "منہ"
 ],
 [
  "Lip",
  "ہونٹ"
 ],
 [
  "Tooth",
  "دانت"
 ],
 [
  "Tongue",
  "زبان"
 ],
 [
  "Neck",
  "گردن"
 ],
 [
  "Shoulder",
  "کندھا"
 ],
 [
  "Arm",
  "بازو"
 ],
 [
  "Hand",
  "ہاتھ"
 ],
 [
  "Finger",
  "انگلی"
 ],
 [
  "Thumb",
  "انگوٹھا"
 ],
 [
  "Nail",
  "ناخن"
 ],
 [
  "Chest",
  "سینہ"
 ],
 [
  "Back",
  "پیٹھ"
 ],
 [
  "Stomach",
  "پیٹ"
 ],
 [
  "Heart",
  "دل"
 ],
 [
  "Blood",
  "خون"
 ],
 [
  "Bone",
  "ہڈی"
 ],
 [
  "Skin",
  "جلد"
 ],
 [
  "Leg",
  "ٹانگ"
 ],
 [
  "Foot",
  "پاؤں"
 ],
 [
  "Knee",
  "گھٹنا"
 ],
 [
  "Elbow",
  "کہنی"
 ],
 [
  "Body",
  "جسم"
 ],
 [
  "Brain",
  "دماغ"
 ],
 [
  "Father",
  "ابا"
 ],
 [
  "Mother",
  "امی"
 ],
 [
  "Brother",
  "بھائی"
 ],
 [
  "Sister",
  "بہن"
 ],
 [
  "Son",
  "بیٹا"
 ],
 [
  "Daughter",
  "بیٹی"
 ],
 [
  "Husband",
  "شوہر"
 ],
 [
  "Wife",
  "بیوی"
 ],
 [
  "Parents",
  "والدین"
 ],
 [
  "Child",
  "بچہ"
 ],
 [
  "Baby",
  "شیر خوار"
 ],
 [
  "Grandfather",
  "دادا"
 ],
 [
  "Grandmother",
  "دادی"
 ],
 [
  "Uncle",
  "چچا"
 ],
 [
  "Aunt",
  "چچی"
 ],
 [
  "Maternal uncle",
  "ماموں"
 ],
 [
  "Maternal aunt",
  "ممانی"
 ],
 [
  "Cousin",
  "کزن"
 ],
 [
  "Nephew",
  "بھتیجا"
 ],
 [
  "Niece",
  "بھتیجی"
 ],
 [
  "Father-in-law",
  "سسر"
 ],
 [
  "Mother-in-law",
  "ساس"
 ],
 [
  "Brother-in-law",
  "بہنوئی"
 ],
 [
  "Sister-in-law",
  "بھاوج"
 ],
 [
  "Family",
  "خاندان"
 ],
 [
  "Relative",
  "رشتہ دار"
 ],
 [
  "Friend",
  "دوست"
 ],
 [
  "Enemy",
  "دشمن"
 ],
 [
  "Master",
  "آقا"
 ],
 [
  "Servant",
  "نوکر"
 ],
 [
  "Bread",
  "روٹی"
 ],
 [
  "Rice",
  "چاول"
 ],
 [
  "Wheat",
  "گندم"
 ],
 [
  "Flour",
  "آٹا"
 ],
 [
  "Sugar",
  "چینی"
 ],
 [
  "Salt",
  "نمک"
 ],
 [
  "Oil",
  "تیل"
 ],
 [
  "Ghee",
  "گھی"
 ],
 [
  "Milk",
  "دودھ"
 ],
 [
  "Butter",
  "مکھن"
 ],
 [
  "Cheese",
  "پنیر"
 ],
 [
  "Egg",
  "انڈا"
 ],
 [
  "Meat",
  "گوشت"
 ],
 [
  "Chicken",
  "مرغی"
 ],
 [
  "Fish",
  "مچھلی"
 ],
 [
  "Vegetable",
  "سبزی"
 ],
 [
  "Potato",
  "آلو"
 ],
 [
  "Onion",
  "پیاز"
 ],
 [
  "Tomato",
  "ٹماٹر"
 ],
 [
  "Mango",
  "آم"
 ],
 [
  "Apple",
  "سیب"
 ],
 [
  "Banana",
  "کیلا"
 ],
 [
  "Orange",
  "مالٹا"
 ],
 [
  "Grapes",
  "انگور"
 ],
 [
  "Tea",
  "چائے"
 ],
 [
  "Coffee",
  "کافی"
 ],
 [
  "Juice",
  "جوس"
 ],
 [
  "Honey",
  "شہد"
 ],
 [
  "Sweet",
  "مٹھائی"
 ],
 [
  "Breakfast",
  "ناشتہ"
 ],
 [
  "Cat",
  "بلی"
 ],
 [
  "Dog",
  "کتا"
 ],
 [
  "Cow",
  "گائے"
 ],
 [
  "Buffalo",
  "بھینس"
 ],
 [
  "Goat",
  "بکری"
 ],
 [
  "Sheep",
  "بھیڑ"
 ],
 [
  "Horse",
  "گھوڑا"
 ],
 [
  "Donkey",
  "گدھا"
 ],
 [
  "Camel",
  "اونٹ"
 ],
 [
  "Elephant",
  "ہاتھی"
 ],
 [
  "Lion",
  "شیر"
 ],
 [
  "Tiger",
  "چیتا"
 ],
 [
  "Bear",
  "ریچھ"
 ],
 [
  "Monkey",
  "بندر"
 ],
 [
  "Rabbit",
  "خرگوش"
 ],
 [
  "Mouse",
  "چوہا"
 ],
 [
  "Squirrel",
  "گلہری"
 ],
 [
  "Snake",
  "سانپ"
 ],
 [
  "Frog",
  "مینڈک"
 ],
 [
  "Whale",
  "وہیل مچھلی"
 ],
 [
  "Bird",
  "پرندہ"
 ],
 [
  "Crow",
  "کوا"
 ],
 [
  "Sparrow",
  "چڑیا"
 ],
 [
  "Pigeon",
  "کبوتر"
 ],
 [
  "Parrot",
  "طوطا"
 ],
 [
  "Peacock",
  "مور"
 ],
 [
  "Duck",
  "بطخ"
 ],
 [
  "Eagle",
  "عقاب"
 ],
 [
  "Owl",
  "الّو"
 ],
 [
  "Bee",
  "شہد کی مکھی"
 ],
 [
  "Butterfly",
  "تتلی"
 ],
 [
  "Ant",
  "چیونٹی"
 ],
 [
  "Doctor",
  "ڈاکٹر"
 ],
 [
  "Nurse",
  "نرس"
 ],
 [
  "Professor",
  "پروفیسر"
 ],
 [
  "Engineer",
  "انجینئر"
 ],
 [
  "Lawyer",
  "وکیل"
 ],
 [
  "Judge",
  "جج"
 ],
 [
  "Farmer",
  "کسان"
 ],
 [
  "Shopkeeper",
  "دکاندار"
 ],
 [
  "Driver",
  "ڈرائیور"
 ],
 [
  "Pilot",
  "پائلٹ"
 ],
 [
  "Soldier",
  "سپاہی"
 ],
 [
  "Police",
  "پولیس"
 ],
 [
  "Clerk",
  "کلرک"
 ],
 [
  "Manager",
  "مینیجر"
 ],
 [
  "Cook",
  "باورچی"
 ],
 [
  "Tailor",
  "درزی"
 ],
 [
  "Barber",
  "نائی"
 ],
 [
  "Carpenter",
  "بڑھئی"
 ],
 [
  "Mason",
  "راج"
 ],
 [
  "Blacksmith",
  "لوہار"
 ],
 [
  "Goldsmith",
  "سنار"
 ],
 [
  "Washerman",
  "دھوبی"
 ],
 [
  "Gardener",
  "مالی"
 ],
 [
  "Shepherd",
  "چرواہا"
 ],
 [
  "Fisherman",
  "ماہی گیر"
 ],
 [
  "Writer",
  "مصنف"
 ],
 [
  "Poet",
  "شاعر"
 ],
 [
  "Singer",
  "گلوکار"
 ],
 [
  "Actor",
  "اداکار"
 ],
 [
  "Scientist",
  "سائنسدان"
 ],
 [
  "Time",
  "وقت"
 ],
 [
  "Day",
  "دن"
 ],
 [
  "Night",
  "رات"
 ],
 [
  "Morning",
  "صبح"
 ],
 [
  "Evening",
  "شام"
 ],
 [
  "Afternoon",
  "دوپہر"
 ],
 [
  "Midnight",
  "آدھی رات"
 ],
 [
  "Today",
  "آج"
 ],
 [
  "Tomorrow",
  "کل"
 ],
 [
  "Yesterday",
  "گزرا ہوا کل"
 ],
 [
  "Week",
  "ہفتہ"
 ],
 [
  "Month",
  "مہینہ"
 ],
 [
  "Year",
  "سال"
 ],
 [
  "Century",
  "صدی"
 ],
 [
  "Moment",
  "لمحہ"
 ],
 [
  "Second",
  "سیکنڈ"
 ],
 [
  "Minute",
  "منٹ"
 ],
 [
  "Hour",
  "گھنٹہ"
 ],
 [
  "Monday",
  "پیر"
 ],
 [
  "Tuesday",
  "منگل"
 ],
 [
  "Wednesday",
  "بدھ"
 ],
 [
  "Thursday",
  "جمعرات"
 ],
 [
  "Friday",
  "جمعہ"
 ],
 [
  "Saturday",
  "ہفتہ"
 ],
 [
  "Sunday",
  "اتوار"
 ],
 [
  "January",
  "جنوری"
 ],
 [
  "February",
  "فروری"
 ],
 [
  "March",
  "مارچ"
 ],
 [
  "April",
  "اپریل"
 ],
 [
  "May",
  "مئی"
 ],
 [
  "June",
  "جون"
 ],
 [
  "July",
  "جولائی"
 ],
 [
  "August",
  "اگست"
 ],
 [
  "September",
  "ستمبر"
 ],
 [
  "October",
  "اکتوبر"
 ],
 [
  "November",
  "نومبر"
 ],
 [
  "December",
  "دسمبر"
 ],
 [
  "Red",
  "سرخ"
 ],
 [
  "Blue",
  "نیلا"
 ],
 [
  "Green",
  "سبز"
 ],
 [
  "Yellow",
  "پیلا"
 ],
 [
  "Black",
  "کالا"
 ],
 [
  "White",
  "سفید"
 ],
 [
  "Orange",
  "نارنجی"
 ],
 [
  "Pink",
  "گلابی"
 ],
 [
  "Purple",
  "جامنی"
 ],
 [
  "Brown",
  "بھورا"
 ],
 [
  "Grey",
  "سرمئی"
 ],
 [
  "Golden",
  "سنہرا"
 ],
 [
  "Silver",
  "نقرئی"
 ],
 [
  "Dark blue",
  "گہرا نیلا"
 ],
 [
  "Light green",
  "ہلکا سبز"
 ],
 [
  "Colour",
  "رنگ"
 ],
 [
  "Bright",
  "چمکدار"
 ],
 [
  "Dull",
  "پھیکا"
 ],
 [
  "One",
  "ایک"
 ],
 [
  "Two",
  "دو"
 ],
 [
  "Three",
  "تین"
 ],
 [
  "Four",
  "چار"
 ],
 [
  "Five",
  "پانچ"
 ],
 [
  "Six",
  "چھ"
 ],
 [
  "Seven",
  "سات"
 ],
 [
  "Eight",
  "آٹھ"
 ],
 [
  "Nine",
  "نو"
 ],
 [
  "Ten",
  "دس"
 ],
 [
  "Eleven",
  "گیارہ"
 ],
 [
  "Twelve",
  "بارہ"
 ],
 [
  "Twenty",
  "بیس"
 ],
 [
  "Thirty",
  "تیس"
 ],
 [
  "Forty",
  "چالیس"
 ],
 [
  "Fifty",
  "پچاس"
 ],
 [
  "Hundred",
  "سو"
 ],
 [
  "Thousand",
  "ہزار"
 ],
 [
  "Million",
  "ملین"
 ],
 [
  "Number",
  "عدد"
 ],
 [
  "Happiness",
  "خوشی"
 ],
 [
  "Sadness",
  "غم"
 ],
 [
  "Joy",
  "مسرت"
 ],
 [
  "Sorrow",
  "دکھ"
 ],
 [
  "Love",
  "محبت"
 ],
 [
  "Hatred",
  "نفرت"
 ],
 [
  "Anger",
  "غصہ"
 ],
 [
  "Fear",
  "خوف"
 ],
 [
  "Hope",
  "امید"
 ],
 [
  "Despair",
  "مایوسی"
 ],
 [
  "Pride",
  "فخر"
 ],
 [
  "Shame",
  "شرم"
 ],
 [
  "Jealousy",
  "حسد"
 ],
 [
  "Envy",
  "رشک"
 ],
 [
  "Courage",
  "ہمت"
 ],
 [
  "Patience",
  "صبر"
 ],
 [
  "Kindness",
  "مہربانی"
 ],
 [
  "Mercy",
  "رحم"
 ],
 [
  "Gratitude",
  "شکر گزاری"
 ],
 [
  "Sympathy",
  "ہمدردی"
 ],
 [
  "Pain",
  "درد"
 ],
 [
  "Pleasure",
  "لطف"
 ],
 [
  "Surprise",
  "حیرت"
 ],
 [
  "Doubt",
  "شک"
 ],
 [
  "Trust",
  "بھروسہ"
 ],
 [
  "Honesty",
  "ایمانداری"
 ],
 [
  "Justice",
  "انصاف"
 ],
 [
  "Peace",
  "امن"
 ],
 [
  "War",
  "جنگ"
 ],
 [
  "Freedom",
  "آزادی"
 ],
 [
  "Slavery",
  "غلامی"
 ],
 [
  "Respect",
  "عزت"
 ],
 [
  "Insult",
  "بے عزتی"
 ],
 [
  "Laughter",
  "ہنسی"
 ],
 [
  "Tear",
  "آنسو"
 ],
 [
  "Mosque",
  "مسجد"
 ],
 [
  "Hospital",
  "ہسپتال"
 ],
 [
  "Bank",
  "بینک"
 ],
 [
  "Park",
  "پارک"
 ],
 [
  "Zoo",
  "چڑیا گھر"
 ],
 [
  "Museum",
  "عجائب گھر"
 ],
 [
  "Cinema",
  "سینما"
 ],
 [
  "Station",
  "اسٹیشن"
 ],
 [
  "Airport",
  "ہوائی اڈا"
 ],
 [
  "Port",
  "بندرگاہ"
 ],
 [
  "Bridge",
  "پل"
 ],
 [
  "Road",
  "سڑک"
 ],
 [
  "Street",
  "گلی"
 ],
 [
  "Village",
  "گاؤں"
 ],
 [
  "City",
  "شہر"
 ],
 [
  "Town",
  "قصبہ"
 ],
 [
  "Country",
  "ملک"
 ],
 [
  "Capital",
  "دارالحکومت"
 ],
 [
  "Office",
  "دفتر"
 ],
 [
  "Factory",
  "کارخانہ"
 ],
 [
  "Court",
  "عدالت"
 ],
 [
  "Prison",
  "جیل"
 ],
 [
  "Hotel",
  "ہوٹل"
 ],
 [
  "Restaurant",
  "ریستوران"
 ],
 [
  "Bakery",
  "نانبائی کی دکان"
 ],
 [
  "Post office",
  "ڈاک خانہ"
 ],
 [
  "Graveyard",
  "قبرستان"
 ],
 [
  "Playground",
  "کھیل کا میدان"
 ],
 [
  "Farm",
  "کھیت"
 ],
 [
  "Border",
  "سرحد"
 ],
 [
  "Truth",
  "سچ"
 ],
 [
  "Lie",
  "جھوٹ"
 ],
 [
  "Fact",
  "حقیقت"
 ],
 [
  "Opinion",
  "رائے"
 ],
 [
  "Reason",
  "دلیل"
 ],
 [
  "Cause",
  "سبب"
 ],
 [
  "Effect",
  "اثر"
 ],
 [
  "Outcome",
  "انجام"
 ],
 [
  "Problem",
  "مسئلہ"
 ],
 [
  "Solution",
  "حل"
 ],
 [
  "Difficulty",
  "دشواری"
 ],
 [
  "Explanation",
  "وضاحت"
 ],
 [
  "Meaning",
  "معنی"
 ],
 [
  "Word",
  "لفظ"
 ],
 [
  "Language",
  "زبان"
 ],
 [
  "Sentence",
  "جملہ"
 ],
 [
  "Paragraph",
  "پیراگراف"
 ],
 [
  "Topic",
  "موضوع"
 ],
 [
  "Subject",
  "مضمون"
 ],
 [
  "Unit",
  "اکائی"
 ],
 [
  "Nature",
  "فطرت"
 ],
 [
  "Character",
  "کردار"
 ],
 [
  "Habit",
  "عادت"
 ],
 [
  "Behaviour",
  "رویہ"
 ],
 [
  "Manners",
  "آداب"
 ],
 [
  "Custom",
  "رواج"
 ],
 [
  "Tradition",
  "روایت"
 ],
 [
  "Culture",
  "ثقافت"
 ],
 [
  "Civilization",
  "تہذیب"
 ],
 [
  "History",
  "تاریخ"
 ],
 [
  "Future",
  "مستقبل"
 ],
 [
  "Past",
  "ماضی"
 ],
 [
  "Present",
  "حال"
 ],
 [
  "Change",
  "تبدیلی"
 ],
 [
  "Improvement",
  "بہتری"
 ],
 [
  "Decline",
  "زوال"
 ],
 [
  "Rise",
  "عروج"
 ],
 [
  "Downfall",
  "پستی"
 ],
 [
  "Beginning",
  "آغاز"
 ],
 [
  "End",
  "اختتام"
 ],
 [
  "Middle",
  "درمیان"
 ],
 [
  "Part",
  "حصہ"
 ],
 [
  "Whole",
  "پورا"
 ],
 [
  "Half",
  "آدھا"
 ],
 [
  "Quarter",
  "چوتھائی"
 ],
 [
  "Amount",
  "مقدار"
 ],
 [
  "Quality",
  "معیار"
 ],
 [
  "Increase",
  "اضافہ"
 ],
 [
  "Decrease",
  "کمی"
 ],
 [
  "Difference",
  "فرق"
 ],
 [
  "Similarity",
  "مشابہت"
 ],
 [
  "Comparison",
  "موازنہ"
 ],
 [
  "Sample",
  "نمونہ"
 ],
 [
  "Rule",
  "اصول"
 ],
 [
  "Law",
  "قانون"
 ],
 [
  "Right",
  "حق"
 ],
 [
  "Duty",
  "فرض"
 ],
 [
  "Responsibility",
  "ذمہ داری"
 ],
 [
  "Power",
  "طاقت"
 ],
 [
  "Authority",
  "اختیار"
 ],
 [
  "Very",
  "بہت"
 ],
 [
  "Always",
  "ہمیشہ"
 ],
 [
  "Never",
  "کبھی نہیں"
 ],
 [
  "Sometimes",
  "کبھی کبھی"
 ],
 [
  "Often",
  "اکثر"
 ],
 [
  "Rarely",
  "شاذ و نادر"
 ],
 [
  "Soon",
  "جلد"
 ],
 [
  "Already",
  "پہلے سے"
 ],
 [
  "Yet",
  "ابھی تک"
 ],
 [
  "Still",
  "اب بھی"
 ],
 [
  "Again",
  "پھر"
 ],
 [
  "Together",
  "اکٹھے"
 ],
 [
  "Alone",
  "اکیلا"
 ],
 [
  "Quickly",
  "جلدی سے"
 ],
 [
  "Slowly",
  "آہستہ"
 ],
 [
  "Carefully",
  "احتیاط سے"
 ],
 [
  "Easily",
  "آسانی سے"
 ],
 [
  "Hardly",
  "مشکل سے"
 ],
 [
  "Almost",
  "تقریباً"
 ],
 [
  "Exactly",
  "عین"
 ],
 [
  "However",
  "تاہم"
 ],
 [
  "Therefore",
  "اس لیے"
 ],
 [
  "Because",
  "کیونکہ"
 ],
 [
  "Although",
  "اگرچہ"
 ],
 [
  "If",
  "اگر"
 ],
 [
  "abandon",
  "ترک کرنا"
 ],
 [
  "ability",
  "قابلیت"
 ],
 [
  "about",
  "کے بارے میں"
 ],
 [
  "above",
  "اوپر"
 ],
 [
  "accept",
  "قبول کرنا"
 ],
 [
  "accident",
  "حادثہ"
 ],
 [
  "achieve",
  "حاصل کرنا"
 ],
 [
  "across",
  "پار"
 ],
 [
  "act",
  "عمل کرنا"
 ],
 [
  "active",
  "فعال"
 ],
 [
  "activity",
  "سرگرمی"
 ],
 [
  "add",
  "جمع کرنا"
 ],
 [
  "address",
  "پتہ"
 ],
 [
  "admit",
  "تسلیم کرنا"
 ],
 [
  "advice",
  "مشورہ"
 ],
 [
  "affect",
  "اثر ڈالنا"
 ],
 [
  "afraid",
  "خوفزدہ"
 ],
 [
  "after",
  "بعد میں"
 ],
 [
  "again",
  "دوبارہ"
 ],
 [
  "against",
  "خلاف"
 ],
 [
  "age",
  "عمر"
 ],
 [
  "agree",
  "متفق ہونا"
 ],
 [
  "agriculture",
  "زراعت"
 ],
 [
  "air",
  "ہوا"
 ],
 [
  "allow",
  "اجازت دینا"
 ],
 [
  "almost",
  "تقریباً"
 ],
 [
  "alone",
  "اکیلا"
 ],
 [
  "also",
  "بھی"
 ],
 [
  "always",
  "ہمیشہ"
 ],
 [
  "amount",
  "مقدار"
 ],
 [
  "ancient",
  "قدیم"
 ],
 [
  "anger",
  "غصہ"
 ],
 [
  "animal",
  "جانور"
 ],
 [
  "announce",
  "اعلان کرنا"
 ],
 [
  "answer",
  "جواب"
 ],
 [
  "appear",
  "ظاہر ہونا"
 ],
 [
  "apple",
  "سیب"
 ],
 [
  "apply",
  "درخواست دینا"
 ],
 [
  "appoint",
  "مقرر کرنا"
 ],
 [
  "approve",
  "منظور کرنا"
 ],
 [
  "argue",
  "بحث کرنا"
 ],
 [
  "arrive",
  "پہنچنا"
 ],
 [
  "art",
  "فن"
 ],
 [
  "artist",
  "فنکار"
 ],
 [
  "ask",
  "پوچھنا"
 ],
 [
  "assume",
  "فرض کرنا"
 ],
 [
  "attack",
  "حملہ"
 ],
 [
  "attempt",
  "کوشش"
 ],
 [
  "attend",
  "حاضر ہونا"
 ],
 [
  "attention",
  "توجہ"
 ],
 [
  "author",
  "مصنف"
 ],
 [
  "autumn",
  "خزاں"
 ],
 [
  "available",
  "دستیاب"
 ],
 [
  "avoid",
  "بچنا"
 ],
 [
  "award",
  "انعام"
 ],
 [
  "aware",
  "آگاہ"
 ],
 [
  "baby",
  "بچہ"
 ],
 [
  "back",
  "پیچھے"
 ],
 [
  "bad",
  "برا"
 ],
 [
  "bag",
  "تھیلا"
 ],
 [
  "balance",
  "توازن"
 ],
 [
  "ball",
  "گیند"
 ],
 [
  "bank",
  "بینک"
 ],
 [
  "base",
  "بنیاد"
 ],
 [
  "basic",
  "بنیادی"
 ],
 [
  "battle",
  "جنگ"
 ],
 [
  "beach",
  "ساحل"
 ],
 [
  "bear",
  "برداشت کرنا"
 ],
 [
  "beauty",
  "خوبصورتی"
 ],
 [
  "because",
  "کیونکہ"
 ],
 [
  "become",
  "ہونا"
 ],
 [
  "bed",
  "بستر"
 ],
 [
  "before",
  "پہلے"
 ],
 [
  "begin",
  "شروع کرنا"
 ],
 [
  "behave",
  "برتاؤ کرنا"
 ],
 [
  "behind",
  "پیچھے"
 ],
 [
  "belief",
  "عقیدہ"
 ],
 [
  "believe",
  "یقین کرنا"
 ],
 [
  "below",
  "نیچے"
 ],
 [
  "benefit",
  "فائدہ"
 ],
 [
  "best",
  "بہترین"
 ],
 [
  "better",
  "بہتر"
 ],
 [
  "between",
  "درمیان"
 ],
 [
  "big",
  "بڑا"
 ],
 [
  "biography",
  "سوانح عمری"
 ],
 [
  "biology",
  "حیاتیات"
 ],
 [
  "bird",
  "پرندہ"
 ],
 [
  "birth",
  "پیدائش"
 ],
 [
  "black",
  "کالا"
 ],
 [
  "blame",
  "الزام"
 ],
 [
  "blood",
  "خون"
 ],
 [
  "blue",
  "نیلا"
 ],
 [
  "board",
  "تختہ"
 ],
 [
  "boat",
  "کشتی"
 ],
 [
  "body",
  "جسم"
 ],
 [
  "boil",
  "ابالنا"
 ],
 [
  "bold",
  "دلیر"
 ],
 [
  "bone",
  "ہڈی"
 ],
 [
  "book",
  "کتاب"
 ],
 [
  "border",
  "سرحد"
 ],
 [
  "borrow",
  "ادھار لینا"
 ],
 [
  "both",
  "دونوں"
 ],
 [
  "bottle",
  "بوتل"
 ],
 [
  "boundary",
  "حد"
 ],
 [
  "boy",
  "لڑکا"
 ],
 [
  "brain",
  "دماغ"
 ],
 [
  "branch",
  "شاخ"
 ],
 [
  "brave",
  "بہادر"
 ],
 [
  "bread",
  "روٹی"
 ],
 [
  "break",
  "توڑنا"
 ],
 [
  "breakfast",
  "ناشتہ"
 ],
 [
  "breath",
  "سانس"
 ],
 [
  "brick",
  "اینٹ"
 ],
 [
  "bridge",
  "پل"
 ],
 [
  "bright",
  "روشن"
 ],
 [
  "bring",
  "لانا"
 ],
 [
  "broad",
  "چوڑا"
 ],
 [
  "broken",
  "ٹوٹا ہوا"
 ],
 [
  "brother",
  "بھائی"
 ],
 [
  "brown",
  "بھورا"
 ],
 [
  "bucket",
  "بالٹی"
 ],
 [
  "budget",
  "بجٹ"
 ],
 [
  "build",
  "بنانا"
 ],
 [
  "building",
  "عمارت"
 ],
 [
  "burn",
  "جلنا"
 ],
 [
  "bury",
  "دفن کرنا"
 ],
 [
  "bus",
  "بس"
 ],
 [
  "business",
  "کاروبار"
 ],
 [
  "busy",
  "مصروف"
 ],
 [
  "but",
  "لیکن"
 ],
 [
  "butter",
  "مکھن"
 ],
 [
  "buy",
  "خریدنا"
 ],
 [
  "calculate",
  "حساب کرنا"
 ],
 [
  "calm",
  "پرسکون"
 ],
 [
  "camel",
  "اونٹ"
 ],
 [
  "camera",
  "کیمرہ"
 ],
 [
  "canal",
  "نہر"
 ],
 [
  "cancel",
  "منسوخ کرنا"
 ],
 [
  "candidate",
  "امیدوار"
 ],
 [
  "candle",
  "موم بتی"
 ],
 [
  "capable",
  "قابل"
 ],
 [
  "capital",
  "دارالحکومت"
 ],
 [
  "car",
  "گاڑی"
 ],
 [
  "carbon",
  "کاربن"
 ],
 [
  "care",
  "خیال رکھنا"
 ],
 [
  "career",
  "پیشہ"
 ],
 [
  "careful",
  "محتاط"
 ],
 [
  "carry",
  "اٹھانا"
 ],
 [
  "case",
  "مقدمہ"
 ],
 [
  "cash",
  "نقد"
 ],
 [
  "castle",
  "قلعہ"
 ],
 [
  "cat",
  "بلی"
 ],
 [
  "catch",
  "پکڑنا"
 ],
 [
  "cause",
  "سبب"
 ],
 [
  "caution",
  "احتیاط"
 ],
 [
  "celebrate",
  "منانا"
 ],
 [
  "cell",
  "خلیہ"
 ],
 [
  "center",
  "مرکز"
 ],
 [
  "century",
  "صدی"
 ],
 [
  "ceremony",
  "تقریب"
 ],
 [
  "certain",
  "یقینی"
 ],
 [
  "chain",
  "زنجیر"
 ],
 [
  "chair",
  "کرسی"
 ],
 [
  "chance",
  "موقع"
 ],
 [
  "change",
  "تبدیل کرنا"
 ],
 [
  "chapter",
  "باب"
 ],
 [
  "character",
  "کردار"
 ],
 [
  "charge",
  "الزام"
 ],
 [
  "charity",
  "خیرات"
 ],
 [
  "chart",
  "نقشہ"
 ],
 [
  "cheap",
  "سستا"
 ],
 [
  "cheat",
  "دھوکہ دینا"
 ],
 [
  "check",
  "جانچنا"
 ],
 [
  "cheese",
  "پنیر"
 ],
 [
  "chemistry",
  "کیمسٹری"
 ],
 [
  "chess",
  "شطرنج"
 ],
 [
  "chest",
  "سینہ"
 ],
 [
  "chief",
  "سردار"
 ],
 [
  "child",
  "بچہ"
 ],
 [
  "choice",
  "انتخاب"
 ],
 [
  "choose",
  "چننا"
 ],
 [
  "church",
  "گرجا"
 ],
 [
  "cinema",
  "سینما"
 ],
 [
  "circle",
  "دائرہ"
 ],
 [
  "citizen",
  "شہری"
 ],
 [
  "city",
  "شہر"
 ],
 [
  "claim",
  "دعویٰ"
 ],
 [
  "class",
  "جماعت"
 ],
 [
  "clean",
  "صاف"
 ],
 [
  "clear",
  "واضح"
 ],
 [
  "clever",
  "چالاک"
 ],
 [
  "client",
  "گاہک"
 ],
 [
  "climate",
  "آب و ہوا"
 ],
 [
  "climb",
  "چڑھنا"
 ],
 [
  "clock",
  "گھڑی"
 ],
 [
  "close",
  "بند کرنا"
 ],
 [
  "cloth",
  "کپڑا"
 ],
 [
  "clothes",
  "کپڑے"
 ],
 [
  "cloud",
  "بادل"
 ],
 [
  "club",
  "کلب"
 ],
 [
  "clue",
  "سراغ"
 ],
 [
  "coal",
  "کوئلہ"
 ],
 [
  "coast",
  "ساحل"
 ],
 [
  "coffee",
  "کافی"
 ],
 [
  "coin",
  "سکہ"
 ],
 [
  "cold",
  "ٹھنڈا"
 ],
 [
  "collapse",
  "گرنا"
 ],
 [
  "collect",
  "جمع کرنا"
 ],
 [
  "college",
  "کالج"
 ],
 [
  "color",
  "رنگ"
 ],
 [
  "column",
  "ستون"
 ],
 [
  "combine",
  "ملانا"
 ],
 [
  "come",
  "آنا"
 ],
 [
  "comfort",
  "آرام"
 ],
 [
  "command",
  "حکم"
 ],
 [
  "comment",
  "تبصرہ"
 ],
 [
  "commerce",
  "تجارت"
 ],
 [
  "committee",
  "کمیٹی"
 ],
 [
  "common",
  "عام"
 ],
 [
  "communicate",
  "بات چیت کرنا"
 ],
 [
  "community",
  "برادری"
 ],
 [
  "company",
  "کمپنی"
 ],
 [
  "compare",
  "موازنہ کرنا"
 ],
 [
  "compass",
  "قطب نما"
 ],
 [
  "compassion",
  "ہمدردی"
 ],
 [
  "compete",
  "مقابلہ کرنا"
 ],
 [
  "complain",
  "شکایت کرنا"
 ],
 [
  "complete",
  "مکمل"
 ],
 [
  "complex",
  "پیچیدہ"
 ],
 [
  "compose",
  "ترتیب دینا"
 ],
 [
  "compound",
  "مرکب"
 ],
 [
  "compromise",
  "سمجھوتہ"
 ],
 [
  "conceal",
  "چھپانا"
 ],
 [
  "concentrate",
  "توجہ مرکوز کرنا"
 ],
 [
  "concept",
  "تصور"
 ],
 [
  "concern",
  "فکر"
 ],
 [
  "conclude",
  "نتیجہ نکالنا"
 ],
 [
  "condition",
  "حالت"
 ],
 [
  "conduct",
  "چلانا"
 ],
 [
  "confess",
  "اعتراف کرنا"
 ],
 [
  "confidence",
  "اعتماد"
 ],
 [
  "confirm",
  "تصدیق کرنا"
 ],
 [
  "conflict",
  "تنازع"
 ],
 [
  "confuse",
  "الجھانا"
 ],
 [
  "congratulate",
  "مبارکباد دینا"
 ],
 [
  "connect",
  "جوڑنا"
 ],
 [
  "conquer",
  "فتح کرنا"
 ],
 [
  "conscience",
  "ضمیر"
 ],
 [
  "consent",
  "رضامندی"
 ],
 [
  "consequence",
  "نتیجہ"
 ],
 [
  "conserve",
  "محفوظ رکھنا"
 ],
 [
  "consider",
  "غور کرنا"
 ],
 [
  "consist",
  "مشتمل ہونا"
 ],
 [
  "conspire",
  "سازش کرنا"
 ],
 [
  "constant",
  "مستقل"
 ],
 [
  "constitute",
  "تشکیل دینا"
 ],
 [
  "construct",
  "تعمیر کرنا"
 ],
 [
  "consult",
  "مشورہ کرنا"
 ],
 [
  "consume",
  "خرچ کرنا"
 ],
 [
  "contact",
  "رابطہ"
 ],
 [
  "contain",
  "شامل ہونا"
 ],
 [
  "contemplate",
  "غور کرنا"
 ],
 [
  "contemporary",
  "ہم عصر"
 ],
 [
  "contest",
  "مقابلہ"
 ],
 [
  "context",
  "سیاق"
 ],
 [
  "continent",
  "براعظم"
 ],
 [
  "continue",
  "جاری رکھنا"
 ],
 [
  "contract",
  "معاہدہ"
 ],
 [
  "contradict",
  "تردید کرنا"
 ],
 [
  "contrary",
  "برعکس"
 ],
 [
  "contrast",
  "فرق"
 ],
 [
  "contribute",
  "حصہ ڈالنا"
 ],
 [
  "control",
  "قابو"
 ],
 [
  "controversy",
  "تنازع"
 ],
 [
  "convene",
  "بلانا"
 ],
 [
  "convenience",
  "سہولت"
 ],
 [
  "converse",
  "بات چیت کرنا"
 ],
 [
  "convert",
  "تبدیل کرنا"
 ],
 [
  "convey",
  "پہنچانا"
 ],
 [
  "convince",
  "قائل کرنا"
 ],
 [
  "cook",
  "پکانا"
 ],
 [
  "cool",
  "ٹھنڈا"
 ],
 [
  "cooperate",
  "تعاون کرنا"
 ],
 [
  "cope",
  "نبٹنا"
 ],
 [
  "copper",
  "تانبا"
 ],
 [
  "copy",
  "نقل"
 ],
 [
  "core",
  "مرکز"
 ],
 [
  "corn",
  "مکئی"
 ],
 [
  "corner",
  "کونا"
 ],
 [
  "correct",
  "درست"
 ],
 [
  "correspond",
  "خط کتابت کرنا"
 ],
 [
  "corrupt",
  "بدعنوان"
 ],
 [
  "cost",
  "لاگت"
 ],
 [
  "cottage",
  "جھونپڑی"
 ],
 [
  "cotton",
  "روئی"
 ],
 [
  "cough",
  "کھانسی"
 ],
 [
  "council",
  "کونسل"
 ],
 [
  "counsel",
  "مشورہ"
 ],
 [
  "count",
  "گنا"
 ],
 [
  "country",
  "ملک"
 ],
 [
  "couple",
  "جوڑا"
 ],
 [
  "courage",
  "ہمت"
 ],
 [
  "course",
  "نصاب"
 ],
 [
  "court",
  "عدالت"
 ],
 [
  "cousin",
  "چچا زاد"
 ],
 [
  "cover",
  "ڈھانپنا"
 ],
 [
  "cow",
  "گائے"
 ],
 [
  "coward",
  "بزدل"
 ],
 [
  "cozy",
  "آرام دہ"
 ],
 [
  "crack",
  "دراڑ"
 ],
 [
  "craft",
  "ہنر"
 ],
 [
  "crash",
  "ٹکر"
 ],
 [
  "crave",
  "ترسنا"
 ],
 [
  "crawl",
  "رینگنا"
 ],
 [
  "create",
  "پیدا کرنا"
 ],
 [
  "creation",
  "تخلیق"
 ],
 [
  "creature",
  "مخلوق"
 ],
 [
  "credit",
  "ساکھ"
 ],
 [
  "crew",
  "عملہ"
 ],
 [
  "cricket",
  "کرکٹ"
 ],
 [
  "crime",
  "جرم"
 ],
 [
  "criminal",
  "مجرم"
 ],
 [
  "crisis",
  "بحران"
 ],
 [
  "critic",
  "ناقد"
 ],
 [
  "critical",
  "نازک"
 ],
 [
  "criticize",
  "تنقید کرنا"
 ],
 [
  "crocodile",
  "مگرمچھ"
 ],
 [
  "crop",
  "فصل"
 ],
 [
  "cross",
  "پار کرنا"
 ],
 [
  "crow",
  "کوا"
 ],
 [
  "crowd",
  "بھیڑ"
 ],
 [
  "crown",
  "تاج"
 ],
 [
  "crucial",
  "اہم"
 ],
 [
  "cruel",
  "ظالم"
 ],
 [
  "cruise",
  "سیر"
 ],
 [
  "crush",
  "کچلنا"
 ],
 [
  "cry",
  "رونا"
 ],
 [
  "crystal",
  "بلور"
 ],
 [
  "cube",
  "مکعب"
 ],
 [
  "cucumber",
  "کھیرا"
 ],
 [
  "cue",
  "اشارہ"
 ],
 [
  "cultivate",
  "کاشت کرنا"
 ],
 [
  "culture",
  "ثقافت"
 ],
 [
  "cunning",
  "چالاک"
 ],
 [
  "cup",
  "پیالہ"
 ],
 [
  "cupboard",
  "الماری"
 ],
 [
  "cure",
  "علاج"
 ],
 [
  "curiosity",
  "تجسس"
 ],
 [
  "curious",
  "متجسس"
 ],
 [
  "currency",
  "کرنسی"
 ],
 [
  "current",
  "موجودہ"
 ],
 [
  "curriculum",
  "نصاب"
 ],
 [
  "curse",
  "لعنت"
 ],
 [
  "curtain",
  "پردہ"
 ],
 [
  "curve",
  "خم"
 ],
 [
  "custom",
  "رواج"
 ],
 [
  "customer",
  "گاہک"
 ],
 [
  "cut",
  "کاٹنا"
 ],
 [
  "cycle",
  "چکر"
 ],
 [
  "cyclone",
  "طوفان"
 ],
 [
  "experiment",
  "تجربہ"
 ],
 [
  "theory",
  "نظریہ"
 ],
 [
  "hypothesis",
  "مفروضہ"
 ],
 [
  "observe",
  "مشاہدہ کرنا"
 ],
 [
  "microscope",
  "خوردبین"
 ],
 [
  "telescope",
  "دوربین"
 ],
 [
  "gravity",
  "کشش ثقل"
 ],
 [
  "energy",
  "توانائی"
 ],
 [
  "matter",
  "مادہ"
 ],
 [
  "atom",
  "ایٹم"
 ],
 [
  "molecule",
  "سالمہ"
 ],
 [
  "element",
  "عنصر"
 ],
 [
  "solution",
  "محلول"
 ],
 [
  "acid",
  "تیزاب"
 ],
 [
  "oxygen",
  "آکسیجن"
 ],
 [
  "hydrogen",
  "ہائیڈروجن"
 ],
 [
  "photosynthesis",
  "ضیائی تالیف"
 ],
 [
  "respiration",
  "تنفس"
 ],
 [
  "digestion",
  "ہضم"
 ],
 [
  "skeleton",
  "ڈھانچہ"
 ],
 [
  "muscle",
  "پٹھا"
 ],
 [
  "nerve",
  "عصب"
 ],
 [
  "heart",
  "دل"
 ],
 [
  "planet",
  "سیارہ"
 ],
 [
  "star",
  "ستارہ"
 ],
 [
  "moon",
  "چاند"
 ],
 [
  "sun",
  "سورج"
 ],
 [
  "earth",
  "زمین"
 ],
 [
  "orbit",
  "مدار"
 ],
 [
  "eclipse",
  "گرہن"
 ],
 [
  "volcano",
  "آتش فشاں"
 ],
 [
  "earthquake",
  "زلزلہ"
 ],
 [
  "weather",
  "موسم"
 ],
 [
  "rain",
  "بارش"
 ],
 [
  "river",
  "دریا"
 ],
 [
  "mountain",
  "پہاڑ"
 ],
 [
  "desert",
  "صحرا"
 ],
 [
  "forest",
  "جنگل"
 ],
 [
  "ocean",
  "سمندر"
 ],
 [
  "lake",
  "جھیل"
 ],
 [
  "island",
  "جزیرہ"
 ],
 [
  "map",
  "نقشہ"
 ],
 [
  "diagram",
  "خاکہ"
 ],
 [
  "formula",
  "کلیہ"
 ],
 [
  "equation",
  "مساوات"
 ],
 [
  "fraction",
  "کسر"
 ],
 [
  "decimal",
  "اعشاریہ"
 ],
 [
  "percent",
  "فیصد"
 ],
 [
  "angle",
  "زاویہ"
 ],
 [
  "triangle",
  "مثلث"
 ],
 [
  "square",
  "مربع"
 ],
 [
  "area",
  "رقبہ"
 ],
 [
  "volume",
  "حجم"
 ],
 [
  "length",
  "لمبائی"
 ],
 [
  "width",
  "چوڑائی"
 ],
 [
  "height",
  "اونچائی"
 ],
 [
  "weight",
  "وزن"
 ],
 [
  "speed",
  "رفتار"
 ],
 [
  "force",
  "قوت"
 ],
 [
  "friction",
  "رگڑ"
 ],
 [
  "magnet",
  "مقناطیس"
 ],
 [
  "battery",
  "بیٹری"
 ],
 [
  "bulb",
  "بلب"
 ],
 [
  "circuit",
  "سرکٹ"
 ],
 [
  "wire",
  "تار"
 ],
 [
  "engine",
  "انجن"
 ],
 [
  "machine",
  "مشین"
 ],
 [
  "tool",
  "اوزار"
 ],
 [
  "laboratory",
  "تجربہ گاہ"
 ],
 [
  "research",
  "تحقیق"
 ],
 [
  "discovery",
  "دریافت"
 ],
 [
  "invent",
  "ایجاد کرنا"
 ],
 [
  "invention",
  "ایجاد"
 ],
 [
  "knowledge",
  "علم"
 ],
 [
  "learn",
  "سیکھنا"
 ],
 [
  "teach",
  "پڑھانا"
 ],
 [
  "teacher",
  "استاد"
 ],
 [
  "student",
  "طالب علم"
 ],
 [
  "school",
  "اسکول"
 ],
 [
  "lesson",
  "سبق"
 ],
 [
  "exam",
  "امتحان"
 ],
 [
  "result",
  "نتیجہ"
 ],
 [
  "question",
  "سوال"
 ],
 [
  "notebook",
  "کاپی"
 ],
 [
  "pencil",
  "پنسل"
 ],
 [
  "pen",
  "قلم"
 ],
 [
  "ink",
  "سیاہی"
 ],
 [
  "paper",
  "کاغذ"
 ],
 [
  "library",
  "لائبریری"
 ],
 [
  "degree",
  "ڈگری"
 ],
 [
  "scholar",
  "عالم"
 ],
 [
  "study",
  "مطالعہ کرنا"
 ],
 [
  "memory",
  "یادداشت"
 ],
 [
  "forget",
  "بھولنا"
 ],
 [
  "remember",
  "یاد کرنا"
 ],
 [
  "think",
  "سوچنا"
 ],
 [
  "thought",
  "خیال"
 ],
 [
  "idea",
  "خیال"
 ],
 [
  "mind",
  "ذہن"
 ],
 [
  "wise",
  "دانا"
 ],
 [
  "wisdom",
  "حکمت"
 ],
 [
  "science",
  "سائنس"
 ],
 [
  "mathematics",
  "ریاضی"
 ],
 [
  "physics",
  "طبیعیات"
 ],
 [
  "grammar",
  "گرامر"
 ],
 [
  "history",
  "تاریخ"
 ],
 [
  "geography",
  "جغرافیہ"
 ],
 [
  "language",
  "زبان"
 ],
 [
  "word",
  "لفظ"
 ],
 [
  "sentence",
  "جملہ"
 ],
 [
  "paragraph",
  "پیراگراف"
 ],
 [
  "essay",
  "مضمون"
 ],
 [
  "poem",
  "نظم"
 ],
 [
  "poet",
  "شاعر"
 ],
 [
  "story",
  "کہانی"
 ],
 [
  "novel",
  "ناول"
 ],
 [
  "translate",
  "ترجمہ کرنا"
 ],
 [
  "meaning",
  "معنی"
 ],
 [
  "define",
  "تعریف کرنا"
 ],
 [
  "explain",
  "وضاحت کرنا"
 ],
 [
  "example",
  "مثال"
 ],
 [
  "exercise",
  "مشق"
 ],
 [
  "practice",
  "مشق کرنا"
 ],
 [
  "test",
  "آزمائش"
 ],
 [
  "mark",
  "نمبر"
 ],
 [
  "grade",
  "درجہ"
 ],
 [
  "pass",
  "کامیاب ہونا"
 ],
 [
  "fail",
  "ناکام ہونا"
 ],
 [
  "success",
  "کامیابی"
 ],
 [
  "effort",
  "کوشش"
 ],
 [
  "hard",
  "مشکل"
 ],
 [
  "easy",
  "آسان"
 ],
 [
  "difficult",
  "مشکل"
 ],
 [
  "simple",
  "سادہ"
 ],
 [
  "dull",
  "کند"
 ],
 [
  "sharp",
  "تیز"
 ],
 [
  "slow",
  "آہستہ"
 ],
 [
  "fast",
  "تیز"
 ],
 [
  "quick",
  "جلدی"
 ],
 [
  "late",
  "دیر"
 ],
 [
  "early",
  "جلدی"
 ],
 [
  "now",
  "اب"
 ],
 [
  "then",
  "پھر"
 ],
 [
  "today",
  "آج"
 ],
 [
  "tomorrow",
  "کل"
 ],
 [
  "yesterday",
  "کل"
 ],
 [
  "day",
  "دن"
 ],
 [
  "night",
  "رات"
 ],
 [
  "morning",
  "صبح"
 ],
 [
  "evening",
  "شام"
 ],
 [
  "week",
  "ہفتہ"
 ],
 [
  "month",
  "مہینہ"
 ],
 [
  "year",
  "سال"
 ],
 [
  "time",
  "وقت"
 ],
 [
  "hour",
  "گھنٹہ"
 ],
 [
  "minute",
  "منٹ"
 ],
 [
  "second",
  "سیکنڈ"
 ],
 [
  "moment",
  "لمحہ"
 ],
 [
  "never",
  "کبھی نہیں"
 ],
 [
  "often",
  "اکثر"
 ],
 [
  "sometimes",
  "کبھی کبھی"
 ],
 [
  "usually",
  "عام طور پر"
 ],
 [
  "rarely",
  "شاذ و نادر"
 ],
 [
  "already",
  "پہلے سے"
 ],
 [
  "yet",
  "ابھی تک"
 ],
 [
  "still",
  "اب بھی"
 ],
 [
  "enough",
  "کافی"
 ],
 [
  "too",
  "بھی"
 ],
 [
  "very",
  "بہت"
 ],
 [
  "much",
  "زیادہ"
 ],
 [
  "many",
  "بہت سے"
 ],
 [
  "few",
  "چند"
 ],
 [
  "little",
  "تھوڑا"
 ],
 [
  "more",
  "مزید"
 ],
 [
  "less",
  "کم"
 ],
 [
  "most",
  "سب سے زیادہ"
 ],
 [
  "least",
  "سب سے کم"
 ],
 [
  "all",
  "سب"
 ],
 [
  "some",
  "کچھ"
 ],
 [
  "any",
  "کوئی"
 ],
 [
  "no",
  "نہیں"
 ],
 [
  "none",
  "کوئی نہیں"
 ],
 [
  "each",
  "ہر ایک"
 ],
 [
  "every",
  "ہر"
 ],
 [
  "other",
  "دوسرا"
 ],
 [
  "another",
  "ایک اور"
 ],
 [
  "same",
  "وہی"
 ],
 [
  "different",
  "مختلف"
 ],
 [
  "new",
  "نیا"
 ],
 [
  "old",
  "پرانا"
 ],
 [
  "young",
  "جوان"
 ],
 [
  "good",
  "اچھا"
 ],
 [
  "great",
  "عظیم"
 ],
 [
  "small",
  "چھوٹا"
 ],
 [
  "large",
  "بڑا"
 ],
 [
  "long",
  "لمبا"
 ],
 [
  "short",
  "چھوٹا"
 ],
 [
  "tall",
  "لمبا"
 ],
 [
  "high",
  "اونچا"
 ],
 [
  "low",
  "نیچا"
 ],
 [
  "deep",
  "گہرا"
 ],
 [
  "wide",
  "چوڑا"
 ],
 [
  "narrow",
  "تنگ"
 ],
 [
  "thick",
  "موٹا"
 ],
 [
  "thin",
  "پتلا"
 ],
 [
  "heavy",
  "بھاری"
 ],
 [
  "light",
  "ہلکا"
 ],
 [
  "strong",
  "مضبوط"
 ],
 [
  "weak",
  "کمزور"
 ],
 [
  "rich",
  "امیر"
 ],
 [
  "poor",
  "غریب"
 ],
 [
  "dirty",
  "گندہ"
 ],
 [
  "dry",
  "خشک"
 ],
 [
  "wet",
  "گیلا"
 ],
 [
  "hot",
  "گرم"
 ],
 [
  "warm",
  "نیم گرم"
 ],
 [
  "sweet",
  "میٹھا"
 ],
 [
  "bitter",
  "کڑوا"
 ],
 [
  "sour",
  "کھٹا"
 ],
 [
  "salty",
  "نمکین"
 ],
 [
  "fresh",
  "تازہ"
 ],
 [
  "stale",
  "باسی"
 ],
 [
  "ripe",
  "پکا ہوا"
 ],
 [
  "raw",
  "کچا"
 ],
 [
  "cooked",
  "پکا ہوا"
 ],
 [
  "full",
  "بھرا ہوا"
 ],
 [
  "empty",
  "خالی"
 ],
 [
  "open",
  "کھلا"
 ],
 [
  "closed",
  "بند"
 ],
 [
  "right",
  "دائیں"
 ],
 [
  "left",
  "بائیں"
 ],
 [
  "up",
  "اوپر"
 ],
 [
  "down",
  "نیچے"
 ],
 [
  "front",
  "سامنے"
 ],
 [
  "near",
  "قریب"
 ],
 [
  "far",
  "دور"
 ],
 [
  "inside",
  "اندر"
 ],
 [
  "outside",
  "باہر"
 ],
 [
  "here",
  "یہاں"
 ],
 [
  "there",
  "وہاں"
 ],
 [
  "where",
  "کہاں"
 ],
 [
  "when",
  "کب"
 ],
 [
  "why",
  "کیوں"
 ],
 [
  "how",
  "کیسے"
 ],
 [
  "what",
  "کیا"
 ],
 [
  "who",
  "کون"
 ],
 [
  "which",
  "کون سا"
 ],
 [
  "whose",
  "کس کا"
 ],
 [
  "whom",
  "کس کو"
 ],
 [
  "this",
  "یہ"
 ],
 [
  "that",
  "وہ"
 ],
 [
  "these",
  "یہ سب"
 ],
 [
  "those",
  "وہ سب"
 ],
 [
  "it",
  "یہ"
 ],
 [
  "we",
  "ہم"
 ],
 [
  "you",
  "تم"
 ],
 [
  "they",
  "وہ سب"
 ],
 [
  "he",
  "وہ"
 ],
 [
  "she",
  "وہ"
 ],
 [
  "I",
  "میں"
 ],
 [
  "me",
  "مجھے"
 ],
 [
  "my",
  "میرا"
 ],
 [
  "our",
  "ہمارا"
 ],
 [
  "your",
  "تمہارا"
 ],
 [
  "their",
  "ان کا"
 ],
 [
  "his",
  "اس کا"
 ],
 [
  "her",
  "اس کا"
 ],
 [
  "its",
  "اس کا"
 ],
 [
  "mine",
  "میرا"
 ],
 [
  "yours",
  "تمہارا"
 ],
 [
  "ours",
  "ہمارا"
 ],
 [
  "theirs",
  "ان کا"
 ],
 [
  "myself",
  "خود"
 ],
 [
  "yourself",
  "خود"
 ],
 [
  "himself",
  "خود"
 ],
 [
  "herself",
  "خود"
 ],
 [
  "itself",
  "خود"
 ],
 [
  "ourselves",
  "خود"
 ],
 [
  "themselves",
  "خود"
 ],
 [
  "am",
  "ہوں"
 ],
 [
  "is",
  "ہے"
 ],
 [
  "are",
  "ہیں"
 ],
 [
  "was",
  "تھا"
 ],
 [
  "were",
  "تھے"
 ],
 [
  "be",
  "ہونا"
 ],
 [
  "been",
  "ہوا"
 ],
 [
  "being",
  "ہوتے ہوئے"
 ],
 [
  "have",
  "رکھنا"
 ],
 [
  "has",
  "رکھتا ہے"
 ],
 [
  "had",
  "تھا"
 ],
 [
  "do",
  "کرنا"
 ],
 [
  "does",
  "کرتا ہے"
 ],
 [
  "did",
  "کیا"
 ],
 [
  "done",
  "کیا ہوا"
 ],
 [
  "will",
  "گا"
 ],
 [
  "shall",
  "گا"
 ],
 [
  "would",
  "گا"
 ],
 [
  "should",
  "چاہیے"
 ],
 [
  "can",
  "سکتا ہے"
 ],
 [
  "could",
  "سکتا تھا"
 ],
 [
  "may",
  "شاید"
 ],
 [
  "might",
  "شاید"
 ],
 [
  "must",
  "ضرور"
 ],
 [
  "ought",
  "چاہیے"
 ],
 [
  "need",
  "ضرورت"
 ],
 [
  "dare",
  "جرأت کرنا"
 ],
 [
  "used",
  "استعمال شدہ"
 ],
 [
  "get",
  "حاصل کرنا"
 ],
 [
  "give",
  "دینا"
 ],
 [
  "take",
  "لینا"
 ],
 [
  "make",
  "بنانا"
 ],
 [
  "say",
  "کہنا"
 ],
 [
  "tell",
  "بتانا"
 ],
 [
  "speak",
  "بولنا"
 ],
 [
  "talk",
  "بات کرنا"
 ],
 [
  "listen",
  "سننا"
 ],
 [
  "hear",
  "سننا"
 ],
 [
  "see",
  "دیکھنا"
 ],
 [
  "look",
  "دیکھنا"
 ],
 [
  "watch",
  "دیکھنا"
 ],
 [
  "show",
  "دکھانا"
 ],
 [
  "read",
  "پڑھنا"
 ],
 [
  "write",
  "لکھنا"
 ],
 [
  "draw",
  "بننا"
 ],
 [
  "paint",
  "رنگ کرنا"
 ],
 [
  "sing",
  "گانا"
 ],
 [
  "dance",
  "ناچنا"
 ],
 [
  "play",
  "کھیلنا"
 ],
 [
  "run",
  "دوڑنا"
 ],
 [
  "walk",
  "چلنا"
 ],
 [
  "stand",
  "کھڑا ہونا"
 ],
 [
  "sit",
  "بیٹھنا"
 ],
 [
  "lie",
  "لیٹنا"
 ],
 [
  "sleep",
  "سونا"
 ],
 [
  "wake",
  "جاگنا"
 ],
 [
  "eat",
  "کھانا"
 ],
 [
  "drink",
  "پینا"
 ],
 [
  "taste",
  "چکھنا"
 ],
 [
  "smell",
  "سونگھنا"
 ],
 [
  "touch",
  "چھونا"
 ],
 [
  "feel",
  "محسوس کرنا"
 ],
 [
  "laugh",
  "ہنسنا"
 ],
 [
  "smile",
  "مسکرانا"
 ],
 [
  "weep",
  "رونا"
 ],
 [
  "shout",
  "چلانا"
 ],
 [
  "whisper",
  "سرگوشی کرنا"
 ],
 [
  "call",
  "بلانا"
 ],
 [
  "invite",
  "دعوت دینا"
 ],
 [
  "visit",
  "ملنے جانا"
 ],
 [
  "meet",
  "ملنا"
 ],
 [
  "greet",
  "سلام کرنا"
 ],
 [
  "welcome",
  "خوش آمدید"
 ],
 [
  "thank",
  "شکریہ ادا کرنا"
 ],
 [
  "sorry",
  "معذرت"
 ],
 [
  "excuse",
  "معاف کرنا"
 ],
 [
  "forgive",
  "معاف کرنا"
 ],
 [
  "help",
  "مدد کرنا"
 ],
 [
  "save",
  "بچانا"
 ],
 [
  "protect",
  "حفاظت کرنا"
 ],
 [
  "defend",
  "دفاع کرنا"
 ],
 [
  "fight",
  "لڑنا"
 ],
 [
  "win",
  "جیتنا"
 ],
 [
  "lose",
  "ہارنا"
 ],
 [
  "defeat",
  "شکست دینا"
 ],
 [
  "victory",
  "فتح"
 ],
 [
  "peace",
  "امن"
 ],
 [
  "war",
  "جنگ"
 ],
 [
  "soldier",
  "سپاہی"
 ],
 [
  "weapon",
  "ہتھیار"
 ],
 [
  "sword",
  "تلوار"
 ],
 [
  "shield",
  "ڈھال"
 ],
 [
  "king",
  "بادشاہ"
 ],
 [
  "queen",
  "ملکہ"
 ],
 [
  "prince",
  "شہزادہ"
 ],
 [
  "princess",
  "شہزادی"
 ],
 [
  "minister",
  "وزیر"
 ],
 [
  "leader",
  "رہنما"
 ],
 [
  "ruler",
  "حکمران"
 ],
 [
  "government",
  "حکومت"
 ],
 [
  "law",
  "قانون"
 ],
 [
  "justice",
  "انصاف"
 ],
 [
  "judge",
  "جج"
 ],
 [
  "police",
  "پولیس"
 ],
 [
  "punishment",
  "سزا"
 ],
 [
  "prison",
  "جیل"
 ],
 [
  "freedom",
  "آزادی"
 ],
 [
  "duty",
  "فرض"
 ],
 [
  "responsibility",
  "ذمہ داری"
 ],
 [
  "promise",
  "وعدہ"
 ],
 [
  "oath",
  "قسم"
 ],
 [
  "truth",
  "سچ"
 ],
 [
  "honest",
  "ایماندار"
 ],
 [
  "dishonest",
  "بے ایمان"
 ],
 [
  "kind",
  "مہربان"
 ],
 [
  "generous",
  "سخی"
 ],
 [
  "selfish",
  "خود غرض"
 ],
 [
  "humble",
  "عاجز"
 ],
 [
  "proud",
  "مغرور"
 ],
 [
  "polite",
  "شائستہ"
 ],
 [
  "rude",
  "بدتمیز"
 ],
 [
  "gentle",
  "نرم"
 ],
 [
  "harsh",
  "سخت"
 ],
 [
  "patient",
  "صبور"
 ],
 [
  "impatient",
  "بے صبر"
 ],
 [
  "careless",
  "لاپرواہ"
 ],
 [
  "lazy",
  "سست"
 ],
 [
  "diligent",
  "محنتی"
 ],
 [
  "idle",
  "بیکار"
 ],
 [
  "free",
  "آزاد"
 ],
 [
  "bound",
  "پابند"
 ],
 [
  "safe",
  "محفوظ"
 ],
 [
  "dangerous",
  "خطرناک"
 ],
 [
  "risk",
  "خطرہ"
 ],
 [
  "fear",
  "خوف"
 ],
 [
  "hope",
  "امید"
 ],
 [
  "despair",
  "مایوسی"
 ],
 [
  "joy",
  "خوشی"
 ],
 [
  "sorrow",
  "غم"
 ],
 [
  "happiness",
  "خوشی"
 ],
 [
  "sadness",
  "اداسی"
 ],
 [
  "pleasure",
  "لذت"
 ],
 [
  "pain",
  "درد"
 ],
 [
  "trouble",
  "تکلیف"
 ],
 [
  "problem",
  "مسئلہ"
 ],
 [
  "difficulty",
  "مشکل"
 ],
 [
  "ease",
  "آسانی"
 ],
 [
  "rest",
  "آرام"
 ],
 [
  "work",
  "کام"
 ],
 [
  "job",
  "نوکری"
 ],
 [
  "trade",
  "تجارت"
 ],
 [
  "profit",
  "منافع"
 ],
 [
  "loss",
  "نقصان"
 ],
 [
  "gain",
  "فائدہ"
 ],
 [
  "price",
  "قیمت"
 ],
 [
  "expensive",
  "مہنگا"
 ],
 [
  "money",
  "پیسہ"
 ],
 [
  "wealth",
  "دولت"
 ],
 [
  "poverty",
  "غربت"
 ],
 [
  "debt",
  "قرض"
 ],
 [
  "loan",
  "قرض"
 ],
 [
  "interest",
  "سود"
 ],
 [
  "market",
  "بازار"
 ],
 [
  "shop",
  "دکان"
 ],
 [
  "seller",
  "بیچنے والا"
 ],
 [
  "buyer",
  "خریدار"
 ],
 [
  "bargain",
  "سودا"
 ],
 [
  "discount",
  "رعایت"
 ],
 [
  "bill",
  "بل"
 ],
 [
  "receipt",
  "رسید"
 ],
 [
  "account",
  "حساب"
 ],
 [
  "wage",
  "اجرت"
 ],
 [
  "salary",
  "تنخواہ"
 ],
 [
  "income",
  "آمدنی"
 ],
 [
  "expense",
  "خرچ"
 ],
 [
  "saving",
  "بچت"
 ],
 [
  "spend",
  "خرچ کرنا"
 ],
 [
  "earn",
  "کمانا"
 ],
 [
  "pay",
  "ادا کرنا"
 ],
 [
  "sell",
  "بیچنا"
 ],
 [
  "rent",
  "کرایہ"
 ],
 [
  "own",
  "ملکیت"
 ],
 [
  "property",
  "جائیداد"
 ],
 [
  "house",
  "گھر"
 ],
 [
  "home",
  "گھر"
 ],
 [
  "family",
  "خاندان"
 ],
 [
  "father",
  "والد"
 ],
 [
  "mother",
  "والدہ"
 ],
 [
  "parent",
  "والدین"
 ],
 [
  "son",
  "بیٹا"
 ],
 [
  "daughter",
  "بیٹی"
 ],
 [
  "sister",
  "بہن"
 ],
 [
  "uncle",
  "چچا"
 ],
 [
  "aunt",
  "خالہ"
 ],
 [
  "nephew",
  "بھتیجا"
 ],
 [
  "niece",
  "بھتیجی"
 ],
 [
  "husband",
  "شوہر"
 ],
 [
  "wife",
  "بیوی"
 ],
 [
  "marriage",
  "شادی"
 ],
 [
  "wedding",
  "شادی"
 ],
 [
  "divorce",
  "طلاق"
 ],
 [
  "death",
  "موت"
 ],
 [
  "life",
  "زندگی"
 ],
 [
  "alive",
  "زندہ"
 ],
 [
  "dead",
  "مردہ"
 ],
 [
  "health",
  "صحت"
 ],
 [
  "disease",
  "بیماری"
 ],
 [
  "illness",
  "بیماری"
 ],
 [
  "sick",
  "بیمار"
 ],
 [
  "well",
  "تندرست"
 ],
 [
  "doctor",
  "ڈاکٹر"
 ],
 [
  "nurse",
  "نرس"
 ],
 [
  "hospital",
  "ہسپتال"
 ],
 [
  "medicine",
  "دوا"
 ],
 [
  "treatment",
  "علاج"
 ],
 [
  "wound",
  "زخم"
 ],
 [
  "injury",
  "چوٹ"
 ],
 [
  "skin",
  "جلد"
 ],
 [
  "flesh",
  "گوشت"
 ],
 [
  "hair",
  "بال"
 ],
 [
  "head",
  "سر"
 ],
 [
  "face",
  "چہرہ"
 ],
 [
  "eye",
  "آنکھ"
 ],
 [
  "ear",
  "کان"
 ],
 [
  "nose",
  "ناک"
 ],
 [
  "mouth",
  "منہ"
 ],
 [
  "lip",
  "ہونٹ"
 ],
 [
  "tooth",
  "دانت"
 ],
 [
  "tongue",
  "زبان"
 ],
 [
  "throat",
  "گلا"
 ],
 [
  "neck",
  "گردن"
 ],
 [
  "shoulder",
  "کندھا"
 ],
 [
  "arm",
  "بازو"
 ],
 [
  "hand",
  "ہاتھ"
 ],
 [
  "finger",
  "انگلی"
 ],
 [
  "thumb",
  "انگوٹھا"
 ],
 [
  "stomach",
  "پیٹ"
 ],
 [
  "leg",
  "ٹانگ"
 ],
 [
  "foot",
  "پاؤں"
 ],
 [
  "toe",
  "پیر کی انگلی"
 ],
 [
  "knee",
  "گھٹنا"
 ],
 [
  "elbow",
  "کہنی"
 ],
 [
  "wrist",
  "کلائی"
 ],
 [
  "nail",
  "ناخن"
 ],
 [
  "beard",
  "داڑھی"
 ],
 [
  "moustache",
  "مونچھ"
 ],
 [
  "lung",
  "پھیپھڑا"
 ],
 [
  "liver",
  "جگر"
 ],
 [
  "kidney",
  "گردہ"
 ],
 [
  "intestine",
  "آنت"
 ],
 [
  "vein",
  "رگ"
 ],
 [
  "pulse",
  "نبض"
 ],
 [
  "sweat",
  "پسینہ"
 ],
 [
  "tear",
  "آنسو"
 ],
 [
  "food",
  "کھانا"
 ],
 [
  "meal",
  "کھانا"
 ],
 [
  "rice",
  "چاول"
 ],
 [
  "wheat",
  "گندم"
 ],
 [
  "flour",
  "آٹا"
 ],
 [
  "sugar",
  "چینی"
 ],
 [
  "salt",
  "نمک"
 ],
 [
  "oil",
  "تیل"
 ],
 [
  "ghee",
  "گھی"
 ],
 [
  "milk",
  "دودھ"
 ],
 [
  "egg",
  "انڈا"
 ],
 [
  "meat",
  "گوشت"
 ],
 [
  "fish",
  "مچھلی"
 ],
 [
  "chicken",
  "مرغی"
 ],
 [
  "fruit",
  "پھل"
 ],
 [
  "vegetable",
  "سبزی"
 ],
 [
  "mango",
  "آم"
 ],
 [
  "banana",
  "کیلا"
 ],
 [
  "orange",
  "سنگترہ"
 ],
 [
  "grape",
  "انگور"
 ],
 [
  "date",
  "کھجور"
 ],
 [
  "water",
  "پانی"
 ],
 [
  "juice",
  "رس"
 ],
 [
  "tea",
  "چائے"
 ],
 [
  "honey",
  "شہد"
 ],
 [
  "spice",
  "مصالحہ"
 ],
 [
  "pepper",
  "کالی مرچ"
 ],
 [
  "onion",
  "پیاز"
 ],
 [
  "garlic",
  "لہسن"
 ],
 [
  "potato",
  "آلو"
 ],
 [
  "tomato",
  "ٹماٹر"
 ],
 [
  "carrot",
  "گاجر"
 ],
 [
  "cabbage",
  "بند گوبھی"
 ],
 [
  "spinach",
  "پالک"
 ],
 [
  "lentil",
  "دال"
 ],
 [
  "pea",
  "مٹر"
 ],
 [
  "bean",
  "لوبیا"
 ],
 [
  "nut",
  "مغز"
 ],
 [
  "almond",
  "بادام"
 ],
 [
  "walnut",
  "اخروٹ"
 ],
 [
  "pistachio",
  "پستہ"
 ],
 [
  "coconut",
  "ناریل"
 ],
 [
  "dress",
  "لباس"
 ],
 [
  "shirt",
  "قمیض"
 ],
 [
  "trouser",
  "پتلون"
 ],
 [
  "coat",
  "کوٹ"
 ],
 [
  "shoe",
  "جوتا"
 ],
 [
  "sock",
  "موزہ"
 ],
 [
  "cap",
  "ٹوپی"
 ],
 [
  "hat",
  "ہیٹ"
 ],
 [
  "scarf",
  "دوپٹہ"
 ],
 [
  "glove",
  "دستانہ"
 ],
 [
  "belt",
  "کمر بند"
 ],
 [
  "button",
  "بٹن"
 ],
 [
  "pocket",
  "جیب"
 ],
 [
  "tailor",
  "درزی"
 ],
 [
  "wash",
  "دھونا"
 ],
 [
  "iron",
  "استری کرنا"
 ],
 [
  "sew",
  "سینا"
 ],
 [
  "silk",
  "ریشم"
 ],
 [
  "wool",
  "اون"
 ],
 [
  "leather",
  "چمڑا"
 ],
 [
  "gold",
  "سونا"
 ],
 [
  "silver",
  "چاندی"
 ],
 [
  "diamond",
  "ہیرا"
 ],
 [
  "pearl",
  "موتی"
 ],
 [
  "ring",
  "انگوٹھی"
 ],
 [
  "necklace",
  "ہار"
 ],
 [
  "bracelet",
  "کنگن"
 ],
 [
  "mirror",
  "آئینہ"
 ],
 [
  "comb",
  "کنگھی"
 ],
 [
  "soap",
  "صابن"
 ],
 [
  "towel",
  "تولیہ"
 ],
 [
  "pillow",
  "تکیہ"
 ],
 [
  "blanket",
  "کمبل"
 ],
 [
  "sheet",
  "چادر"
 ],
 [
  "mat",
  "چٹائی"
 ],
 [
  "carpet",
  "قالین"
 ],
 [
  "lamp",
  "چراغ"
 ],
 [
  "fan",
  "پنکھا"
 ],
 [
  "heater",
  "ہیٹر"
 ],
 [
  "door",
  "دروازہ"
 ],
 [
  "window",
  "کھڑکی"
 ],
 [
  "wall",
  "دیوار"
 ],
 [
  "roof",
  "چھت"
 ],
 [
  "floor",
  "فرش"
 ],
 [
  "room",
  "کمرہ"
 ],
 [
  "kitchen",
  "باورچی خانہ"
 ],
 [
  "bathroom",
  "غسل خانہ"
 ],
 [
  "garden",
  "باغ"
 ],
 [
  "yard",
  "صحن"
 ],
 [
  "fence",
  "باڑ"
 ],
 [
  "gate",
  "دروازہ"
 ],
 [
  "key",
  "چابی"
 ],
 [
  "lock",
  "تالا"
 ],
 [
  "bell",
  "گھنٹی"
 ],
 [
  "table",
  "میز"
 ],
 [
  "desk",
  "میز"
 ],
 [
  "sofa",
  "صوفہ"
 ],
 [
  "shelf",
  "طاق"
 ],
 [
  "box",
  "ڈبہ"
 ],
 [
  "basket",
  "ٹوکری"
 ],
 [
  "plate",
  "پلیٹ"
 ],
 [
  "spoon",
  "چمچ"
 ],
 [
  "fork",
  "کانٹا"
 ],
 [
  "knife",
  "چھری"
 ],
 [
  "pot",
  "دیگچی"
 ],
 [
  "pan",
  "کڑاہی"
 ],
 [
  "stove",
  "چولہا"
 ],
 [
  "rope",
  "رسی"
 ],
 [
  "ladder",
  "سیڑھی"
 ],
 [
  "hammer",
  "ہتھوڑا"
 ],
 [
  "screw",
  "پیچ"
 ],
 [
  "saw",
  "آری"
 ],
 [
  "axe",
  "کلہاڑی"
 ],
 [
  "spade",
  "بیلچہ"
 ],
 [
  "plough",
  "ہل"
 ],
 [
  "seed",
  "بیج"
 ],
 [
  "plant",
  "پودا"
 ],
 [
  "tree",
  "درخت"
 ],
 [
  "leaf",
  "پتہ"
 ],
 [
  "flower",
  "پھول"
 ],
 [
  "root",
  "جڑ"
 ],
 [
  "trunk",
  "تنے"
 ],
 [
  "bark",
  "چھال"
 ],
 [
  "thorn",
  "کانٹا"
 ],
 [
  "grass",
  "گھاس"
 ],
 [
  "weed",
  "جڑی بوٹی"
 ],
 [
  "harvest",
  "فصل کاٹنا"
 ],
 [
  "field",
  "کھیت"
 ],
 [
  "farm",
  "کھیت"
 ],
 [
  "farmer",
  "کسان"
 ],
 [
  "sow",
  "بونا"
 ],
 [
  "reap",
  "کاٹنا"
 ],
 [
  "thresh",
  "گاہنا"
 ],
 [
  "granary",
  "اناج کا گودام"
 ],
 [
  "irrigate",
  "آبپاشی کرنا"
 ],
 [
  "pond",
  "تالاب"
 ],
 [
  "stream",
  "ندی"
 ],
 [
  "brook",
  "نالہ"
 ],
 [
  "spring",
  "چشمہ"
 ],
 [
  "waterfall",
  "آبشار"
 ],
 [
  "dam",
  "بند"
 ],
 [
  "road",
  "سڑک"
 ],
 [
  "path",
  "راستہ"
 ],
 [
  "street",
  "گلی"
 ],
 [
  "lane",
  "گلی"
 ],
 [
  "highway",
  "شاہراہ"
 ],
 [
  "crossroad",
  "چوراہا"
 ],
 [
  "signpost",
  "راہنما"
 ],
 [
  "milestone",
  "سنگ میل"
 ],
 [
  "journey",
  "سفر"
 ],
 [
  "travel",
  "سفر کرنا"
 ],
 [
  "voyage",
  "بحری سفر"
 ],
 [
  "trip",
  "سیر"
 ],
 [
  "tour",
  "سیر"
 ],
 [
  "picnic",
  "پکنک"
 ],
 [
  "camp",
  "خیمہ"
 ],
 [
  "tent",
  "خیمہ زن"
 ],
 [
  "luggage",
  "سامان"
 ],
 [
  "ticket",
  "ٹکٹ"
 ],
 [
  "fare",
  "کرایہ"
 ],
 [
  "passenger",
  "مسافر"
 ],
 [
  "driver",
  "ڈرائیور"
 ],
 [
  "pilot",
  "پائلٹ"
 ],
 [
  "sailor",
  "ملاح"
 ],
 [
  "captain",
  "کپتان"
 ],
 [
  "station",
  "اسٹیشن"
 ],
 [
  "airport",
  "ہوائی اڈا"
 ],
 [
  "port",
  "بندرگاہ"
 ],
 [
  "train",
  "ریل گاڑی"
 ],
 [
  "truck",
  "ٹرک"
 ],
 [
  "bicycle",
  "سائیکل"
 ],
 [
  "motorcycle",
  "موٹر سائیکل"
 ],
 [
  "ship",
  "جہاز"
 ],
 [
  "aeroplane",
  "ہوائی جہاز"
 ],
 [
  "helicopter",
  "ہیلی کاپٹر"
 ],
 [
  "rocket",
  "راکٹ"
 ],
 [
  "wheel",
  "پہیہ"
 ],
 [
  "brake",
  "بریک"
 ],
 [
  "horn",
  "ہارن"
 ],
 [
  "signal",
  "اشارہ"
 ],
 [
  "traffic",
  "ٹریفک"
 ],
 [
  "jam",
  "بھیڑ"
 ],
 [
  "distance",
  "فاصلہ"
 ],
 [
  "guide",
  "رہنما"
 ],
 [
  "tourist",
  "سیاح"
 ],
 [
  "hotel",
  "ہوٹل"
 ],
 [
  "restaurant",
  "ریستوران"
 ],
 [
  "inn",
  "سرائے"
 ],
 [
  "guest",
  "مہمان"
 ],
 [
  "host",
  "میزبان"
 ],
 [
  "feast",
  "ضیافت"
 ],
 [
  "banquet",
  "دعوت"
 ],
 [
  "party",
  "پارٹی"
 ],
 [
  "festival",
  "تہوار"
 ],
 [
  "holiday",
  "چھٹی"
 ],
 [
  "vacation",
  "چھٹیاں"
 ],
 [
  "leisure",
  "فرصت"
 ],
 [
  "dream",
  "خواب"
 ],
 [
  "nightmare",
  "ڈراؤنا خواب"
 ],
 [
  "insomnia",
  "بے خوابی"
 ],
 [
  "yawn",
  "جمائی"
 ],
 [
  "snore",
  "خراٹے"
 ],
 [
  "bedtime",
  "سونے کا وقت"
 ],
 [
  "dawn",
  "فجر"
 ],
 [
  "dusk",
  "شام"
 ],
 [
  "noon",
  "دوپہر"
 ],
 [
  "midnight",
  "آدھی رات"
 ],
 [
  "sunrise",
  "طلوع آفتاب"
 ],
 [
  "sunset",
  "غروب آفتاب"
 ],
 [
  "season",
  "موسم"
 ],
 [
  "summer",
  "گرمی"
 ],
 [
  "winter",
  "سردی"
 ],
 [
  "monsoon",
  "برسات"
 ],
 [
  "drought",
  "قحط"
 ],
 [
  "flood",
  "سیلاب"
 ],
 [
  "storm",
  "طوفان"
 ],
 [
  "thunder",
  "گرج"
 ],
 [
  "lightning",
  "بجلی"
 ],
 [
  "hail",
  "اولے"
 ],
 [
  "snow",
  "برف"
 ],
 [
  "ice",
  "برف"
 ],
 [
  "frost",
  "پالا"
 ],
 [
  "dew",
  "شبنم"
 ],
 [
  "fog",
  "دھند"
 ],
 [
  "mist",
  "کہر"
 ],
 [
  "rainbow",
  "قوس قزح"
 ],
 [
  "wind",
  "ہوا"
 ],
 [
  "breeze",
  "ہوا کا جھونکا"
 ],
 [
  "gale",
  "آندھی"
 ],
 [
  "whirlwind",
  "بگولہ"
 ],
 [
  "temperature",
  "درجہ حرارت"
 ],
 [
  "thermometer",
  "تھرما میٹر"
 ],
 [
  "barometer",
  "بیرو میٹر"
 ],
 [
  "humidity",
  "نمی"
 ],
 [
  "forecast",
  "پیش گوئی"
 ],
 [
  "sky",
  "آسمان"
 ],
 [
  "horizon",
  "افق"
 ],
 [
  "comet",
  "دم دار ستارہ"
 ],
 [
  "meteor",
  "شہاب ثاقب"
 ],
 [
  "galaxy",
  "کہکشاں"
 ],
 [
  "universe",
  "کائنات"
 ],
 [
  "space",
  "خلا"
 ],
 [
  "satellite",
  "سیٹلائٹ"
 ],
 [
  "astronaut",
  "خلا باز"
 ],
 [
  "observatory",
  "رصد گاہ"
 ],
 [
  "astronomy",
  "فلکیات"
 ],
 [
  "astrology",
  "نجوم"
 ],
 [
  "zodiac",
  "برج"
 ],
 [
  "solar",
  "شمسی"
 ],
 [
  "lunar",
  "قمری"
 ],
 [
  "mass",
  "کمیت"
 ],
 [
  "density",
  "کثافت"
 ],
 [
  "pressure",
  "دباؤ"
 ],
 [
  "vacuum",
  "خلا"
 ],
 [
  "electron",
  "الیکٹران"
 ],
 [
  "proton",
  "پروٹان"
 ],
 [
  "neutron",
  "نیوٹران"
 ],
 [
  "nucleus",
  "مرکزہ"
 ],
 [
  "mixture",
  "آمیزہ"
 ],
 [
  "solvent",
  "حلال"
 ],
 [
  "solute",
  "منحل"
 ],
 [
  "alkali",
  "کھار"
 ],
 [
  "neutral",
  "بے اثر"
 ],
 [
  "reaction",
  "تعامل"
 ],
 [
  "catalyst",
  "عمل انگیز"
 ],
 [
  "oxidation",
  "تکسید"
 ],
 [
  "reduction",
  "تخفیف"
 ],
 [
  "distillation",
  "کشید"
 ],
 [
  "filtration",
  "چھناؤ"
 ],
 [
  "evaporation",
  "تبخیر"
 ],
 [
  "condensation",
  "تکثیف"
 ],
 [
  "freezing",
  "انجماد"
 ],
 [
  "melting",
  "پگھلاؤ"
 ],
 [
  "boiling",
  "ابال"
 ],
 [
  "sublimation",
  "تصعید"
 ],
 [
  "amorphous",
  "بے شکل"
 ],
 [
  "metal",
  "دھات"
 ],
 [
  "nonmetal",
  "غیر دھات"
 ],
 [
  "alloy",
  "بھرت"
 ],
 [
  "ore",
  "کچی دھات"
 ],
 [
  "mineral",
  "معدنیات"
 ],
 [
  "gem",
  "جواہر"
 ],
 [
  "fuel",
  "ایندھن"
 ],
 [
  "petroleum",
  "پٹرولیم"
 ],
 [
  "gas",
  "گیس"
 ],
 [
  "kerosene",
  "مٹی کا تیل"
 ],
 [
  "diesel",
  "ڈیزل"
 ],
 [
  "petrol",
  "پٹرول"
 ],
 [
  "lubricant",
  "چکنا کرنے والا"
 ],
 [
  "wax",
  "موم"
 ],
 [
  "plastic",
  "پلاسٹک"
 ],
 [
  "rubber",
  "ربڑ"
 ],
 [
  "glass",
  "شیشہ"
 ],
 [
  "ceramic",
  "چینی مٹی"
 ],
 [
  "cement",
  "سیمنٹ"
 ],
 [
  "concrete",
  "کنکریٹ"
 ],
 [
  "timber",
  "لکڑی"
 ],
 [
  "dye",
  "رنگ"
 ],
 [
  "varnish",
  "وارنش"
 ],
 [
  "adhesive",
  "گوند"
 ],
 [
  "tissue",
  "بافت"
 ],
 [
  "organ",
  "عضو"
 ],
 [
  "system",
  "نظام"
 ],
 [
  "function",
  "فعل"
 ],
 [
  "structure",
  "ساخت"
 ],
 [
  "growth",
  "نشوونما"
 ],
 [
  "development",
  "ترقی"
 ],
 [
  "reproduction",
  "تولید"
 ],
 [
  "heredity",
  "وراثت"
 ],
 [
  "gene",
  "جین"
 ],
 [
  "chromosome",
  "کروموسوم"
 ],
 [
  "evolution",
  "ارتقا"
 ],
 [
  "species",
  "نوع"
 ],
 [
  "genus",
  "جنس"
 ],
 [
  "order",
  "ترتیب"
 ],
 [
  "kingdom",
  "سلطنت"
 ],
 [
  "virus",
  "وائرس"
 ],
 [
  "bacteria",
  "جراثیم"
 ],
 [
  "fungus",
  "پھپھوندی"
 ],
 [
  "algae",
  "کائی"
 ],
 [
  "moss",
  "کائی"
 ],
 [
  "fern",
  "سرخس"
 ],
 [
  "pollen",
  "زرگل"
 ],
 [
  "nectar",
  "رس"
 ],
 [
  "herb",
  "جڑی بوٹی"
 ],
 [
  "shrub",
  "جھاڑی"
 ],
 [
  "jungle",
  "جنگل"
 ],
 [
  "meadow",
  "چراگاہ"
 ],
 [
  "pasture",
  "چراگاہ"
 ],
 [
  "swamp",
  "دلدل"
 ],
 [
  "marsh",
  "دلدل"
 ],
 [
  "oasis",
  "نخلستان"
 ],
 [
  "glacier",
  "گلیشیر"
 ],
 [
  "iceberg",
  "برفانی تودہ"
 ],
 [
  "tundra",
  "ٹنڈرا"
 ],
 [
  "savanna",
  "سوانا"
 ],
 [
  "prairie",
  "میدان"
 ],
 [
  "steppe",
  "میدان"
 ],
 [
  "valley",
  "وادی"
 ],
 [
  "plain",
  "میدان"
 ],
 [
  "plateau",
  "سطح مرتفع"
 ],
 [
  "hill",
  "پہاڑی"
 ],
 [
  "peak",
  "چوٹی"
 ],
 [
  "summit",
  "چوٹی"
 ],
 [
  "ridge",
  "پہاڑی سلسلہ"
 ],
 [
  "canyon",
  "گھاٹی"
 ],
 [
  "gorge",
  "تنگ گھاٹی"
 ],
 [
  "cave",
  "غار"
 ],
 [
  "cliff",
  "چٹان"
 ],
 [
  "rock",
  "چٹان"
 ],
 [
  "stone",
  "پتھر"
 ],
 [
  "pebble",
  "کنکر"
 ],
 [
  "sand",
  "ریت"
 ],
 [
  "dust",
  "گرد"
 ],
 [
  "mud",
  "کیچڑ"
 ],
 [
  "clay",
  "مٹی"
 ],
 [
  "soil",
  "مٹی"
 ],
 [
  "fertile",
  "زرخیز"
 ],
 [
  "barren",
  "بنجر"
 ],
 [
  "winnow",
  "پھٹکنا"
 ],
 [
  "barn",
  "کھلیان"
 ],
 [
  "silo",
  "سائلو"
 ],
 [
  "irrigation",
  "آبپاشی"
 ],
 [
  "fertilizer",
  "کھاد"
 ],
 [
  "pesticide",
  "کیڑے مار دوا"
 ],
 [
  "hybrid",
  "دوغلا"
 ],
 [
  "graft",
  "پیوند"
 ],
 [
  "prune",
  "چھانٹنا"
 ],
 [
  "nursery",
  "نرسری"
 ],
 [
  "greenhouse",
  "گرین ہاؤس"
 ],
 [
  "botany",
  "نباتیات"
 ],
 [
  "zoology",
  "حیوانیات"
 ],
 [
  "ecology",
  "ماحولیات"
 ],
 [
  "environment",
  "ماحول"
 ],
 [
  "habitat",
  "مسکن"
 ],
 [
  "niche",
  "طاق"
 ],
 [
  "foodchain",
  "غذائی زنجیر"
 ],
 [
  "predator",
  "شکاری"
 ],
 [
  "prey",
  "شکار"
 ],
 [
  "parasite",
  "طفیل"
 ],
 [
  "symbiosis",
  "ہم زیستی"
 ],
 [
  "adaptation",
  "مطابقت"
 ],
 [
  "camouflage",
  "بھیس"
 ],
 [
  "migration",
  "ہجرت"
 ],
 [
  "hibernation",
  "سرمائی نیند"
 ],
 [
  "extinct",
  "معدوم"
 ],
 [
  "endangered",
  "خطرے میں"
 ],
 [
  "conservation",
  "تحفظ"
 ],
 [
  "sanctuary",
  "پناہ گاہ"
 ],
 [
  "reserve",
  "محفوظ علاقہ"
 ],
 [
  "park",
  "پارک"
 ],
 [
  "orchard",
  "باغ"
 ],
 [
  "vineyard",
  "انگور کا باغ"
 ],
 [
  "ranch",
  "مویشی خانہ"
 ],
 [
  "dairy",
  "ڈیری"
 ],
 [
  "poultry",
  "مرغی خانہ"
 ],
 [
  "stable",
  "اصطبل"
 ],
 [
  "kennel",
  "کتے کا گھر"
 ],
 [
  "cage",
  "پنجرہ"
 ],
 [
  "trap",
  "پھندا"
 ],
 [
  "net",
  "جال"
 ],
 [
  "hook",
  "کانٹا"
 ],
 [
  "bait",
  "چارہ"
 ],
 [
  "hunt",
  "شکار کرنا"
 ],
 [
  "shoot",
  "گولی چلانا"
 ],
 [
  "aim",
  "نشانہ"
 ],
 [
  "target",
  "ہدف"
 ],
 [
  "arrow",
  "تیر"
 ],
 [
  "bow",
  "کمان"
 ],
 [
  "spear",
  "نیزہ"
 ],
 [
  "sling",
  "غلیل"
 ],
 [
  "catapult",
  "منجنیق"
 ],
 [
  "cannon",
  "توپ"
 ],
 [
  "rifle",
  "بندوق"
 ],
 [
  "pistol",
  "پستول"
 ],
 [
  "bullet",
  "گولی"
 ],
 [
  "gunpowder",
  "بارود"
 ],
 [
  "explosive",
  "دھماکہ خیز"
 ],
 [
  "bomb",
  "بم"
 ],
 [
  "missile",
  "میزائل"
 ],
 [
  "tank",
  "ٹینک"
 ],
 [
  "fighter",
  "لڑاکا"
 ],
 [
  "bomber",
  "بمبار"
 ],
 [
  "submarine",
  "آبدوز"
 ],
 [
  "warship",
  "جنگی جہاز"
 ],
 [
  "fleet",
  "بیڑا"
 ],
 [
  "anchor",
  "لنگر"
 ],
 [
  "harbor",
  "بندرگاہ"
 ],
 [
  "dock",
  "گودی"
 ],
 [
  "pier",
  "گھاٹ"
 ],
 [
  "lighthouse",
  "مینار نور"
 ],
 [
  "buoy",
  "تیرتا نشان"
 ],
 [
  "tide",
  "مدوجزر"
 ],
 [
  "wave",
  "لہر"
 ],
 [
  "whirlpool",
  "بھنور"
 ],
 [
  "hurricane",
  "سمندری طوفان"
 ],
 [
  "tornado",
  "بگولہ"
 ],
 [
  "typhoon",
  "سمندری طوفان"
 ],
 [
  "drizzle",
  "پھوار"
 ],
 [
  "shower",
  "بوچھاڑ"
 ],
 [
  "downpour",
  "موسلا دھار بارش"
 ],
 [
  "sleet",
  "برف باری"
 ],
 [
  "blizzard",
  "برفانی طوفان"
 ],
 [
  "avalanche",
  "برفانی تودہ"
 ],
 [
  "landslide",
  "زمین کھسکنا"
 ],
 [
  "erosion",
  "کٹاؤ"
 ],
 [
  "sediment",
  "تلچھٹ"
 ],
 [
  "delta",
  "ڈیلٹا"
 ],
 [
  "estuary",
  "دہانہ"
 ],
 [
  "tributary",
  "معاون دریا"
 ],
 [
  "source",
  "ماخذ"
 ],
 [
  "shore",
  "ساحل"
 ],
 [
  "bay",
  "خلیج"
 ],
 [
  "gulf",
  "خلیج"
 ],
 [
  "strait",
  "آبنائے"
 ],
 [
  "channel",
  "نہر"
 ],
 [
  "pool",
  "تالاب"
 ],
 [
  "reservoir",
  "ذخیرہ"
 ],
 [
  "dune",
  "ریت کا ٹیلہ"
 ],
 [
  "mirage",
  "سراب"
 ],
 [
  "caravan",
  "قافلہ"
 ],
 [
  "nomad",
  "خانہ بدوش"
 ],
 [
  "tribe",
  "قبیلہ"
 ],
 [
  "clan",
  "خاندان"
 ],
 [
  "caste",
  "ذات"
 ],
 [
  "race",
  "نسل"
 ],
 [
  "nation",
  "قوم"
 ],
 [
  "state",
  "ریاست"
 ],
 [
  "province",
  "صوبہ"
 ],
 [
  "district",
  "ضلع"
 ],
 [
  "division",
  "ڈویژن"
 ],
 [
  "tehsil",
  "تحصیل"
 ],
 [
  "village",
  "گاؤں"
 ],
 [
  "town",
  "قصبہ"
 ],
 [
  "metropolis",
  "عظیم شہر"
 ],
 [
  "suburb",
  "مضافات"
 ],
 [
  "downtown",
  "شہر کا مرکز"
 ],
 [
  "uptown",
  "شہر کا بالائی حصہ"
 ],
 [
  "slum",
  "کچی آبادی"
 ],
 [
  "ghetto",
  "بستی"
 ],
 [
  "colony",
  "کالونی"
 ],
 [
  "sector",
  "سیکٹر"
 ],
 [
  "block",
  "بلاک"
 ],
 [
  "avenue",
  "شاہراہ"
 ],
 [
  "boulevard",
  "شاہراہ"
 ],
 [
  "plaza",
  "چوک"
 ],
 [
  "bazaar",
  "بازار"
 ],
 [
  "mall",
  "مال"
 ],
 [
  "fair",
  "میلہ"
 ],
 [
  "exhibition",
  "نمائش"
 ],
 [
  "museum",
  "عجائب گھر"
 ],
 [
  "gallery",
  "گیلری"
 ],
 [
  "theater",
  "تھیٹر"
 ],
 [
  "concert",
  "محفل موسیقی"
 ],
 [
  "opera",
  "اوپیرا"
 ],
 [
  "ballet",
  "بیلے"
 ],
 [
  "drama",
  "ڈرامہ"
 ],
 [
  "comedy",
  "مزاحیہ"
 ],
 [
  "tragedy",
  "المیہ"
 ],
 [
  "satire",
  "طنز"
 ],
 [
  "parody",
  "نقل"
 ],
 [
  "mime",
  "اشاروں کا کھیل"
 ],
 [
  "puppet",
  "کٹھ پتلی"
 ],
 [
  "circus",
  "سرکس"
 ],
 [
  "carnival",
  "میلہ"
 ],
 [
  "parade",
  "پریڈ"
 ],
 [
  "procession",
  "جلوس"
 ],
 [
  "rally",
  "ریلی"
 ],
 [
  "demonstration",
  "مظاہرہ"
 ],
 [
  "protest",
  "احتجاج"
 ],
 [
  "strike",
  "ہڑتال"
 ],
 [
  "boycott",
  "بائیکاٹ"
 ],
 [
  "riot",
  "فساد"
 ],
 [
  "revolt",
  "بغاوت"
 ],
 [
  "revolution",
  "انقلاب"
 ],
 [
  "coup",
  "فوجی بغاوت"
 ],
 [
  "martial",
  "فوجی"
 ],
 [
  "curfew",
  "کرفیو"
 ],
 [
  "emergency",
  "ہنگامی حالت"
 ],
 [
  "refugee",
  "پناہ گزین"
 ],
 [
  "asylum",
  "پناہ"
 ],
 [
  "exile",
  "جلاوطنی"
 ],
 [
  "deport",
  "جلاوطن کرنا"
 ],
 [
  "immigrate",
  "ہجرت کرنا"
 ],
 [
  "emigrate",
  "ہجرت کرنا"
 ],
 [
  "visa",
  "ویزا"
 ],
 [
  "passport",
  "پاسپورٹ"
 ],
 [
  "customs",
  "کسٹم"
 ],
 [
  "checkpoint",
  "چوکی"
 ],
 [
  "embassy",
  "سفارت خانہ"
 ],
 [
  "consulate",
  "قونصل خانہ"
 ],
 [
  "ambassador",
  "سفیر"
 ],
 [
  "diplomat",
  "سفارت کار"
 ],
 [
  "treaty",
  "معاہدہ"
 ],
 [
  "alliance",
  "اتحاد"
 ],
 [
  "pact",
  "معاہدہ"
 ],
 [
  "accord",
  "معاہدہ"
 ],
 [
  "convention",
  "کنونشن"
 ],
 [
  "protocol",
  "پروٹوکول"
 ],
 [
  "conference",
  "کانفرنس"
 ],
 [
  "assembly",
  "اسمبلی"
 ],
 [
  "parliament",
  "پارلیمنٹ"
 ],
 [
  "senate",
  "سینٹ"
 ],
 [
  "congress",
  "کانگریس"
 ],
 [
  "cabinet",
  "کابینہ"
 ],
 [
  "ministry",
  "وزارت"
 ],
 [
  "department",
  "محکمہ"
 ],
 [
  "bureau",
  "دفتر"
 ],
 [
  "agency",
  "ادارہ"
 ],
 [
  "commission",
  "کمیشن"
 ],
 [
  "panel",
  "پینل"
 ],
 [
  "jury",
  "جیوری"
 ],
 [
  "tribunal",
  "عدالت"
 ],
 [
  "verdict",
  "فیصلہ"
 ],
 [
  "appeal",
  "اپیل"
 ],
 [
  "pardon",
  "معافی"
 ],
 [
  "amnesty",
  "عام معافی"
 ],
 [
  "reprieve",
  "مہلت"
 ],
 [
  "probation",
  "آزمائشی مدت"
 ],
 [
  "parole",
  "پیرول"
 ],
 [
  "bail",
  "ضمانت"
 ],
 [
  "warrant",
  "وارنٹ"
 ],
 [
  "summons",
  "طلبی"
 ],
 [
  "subpoena",
  "طلبی"
 ],
 [
  "indictment",
  "فرد جرم"
 ],
 [
  "trial",
  "مقدمہ"
 ],
 [
  "hearing",
  "سماعت"
 ],
 [
  "testimony",
  "گواہی"
 ],
 [
  "witness",
  "گواہ"
 ],
 [
  "evidence",
  "ثبوت"
 ],
 [
  "proof",
  "ثبوت"
 ],
 [
  "alibi",
  "غیر حاضری کا ثبوت"
 ],
 [
  "motive",
  "محرک"
 ],
 [
  "suspect",
  "مشتبہ"
 ],
 [
  "accused",
  "ملزم"
 ],
 [
  "defendant",
  "مدعا علیہ"
 ],
 [
  "plaintiff",
  "مدعی"
 ],
 [
  "prosecutor",
  "استغاثہ"
 ],
 [
  "defense",
  "دفاع"
 ],
 [
  "attorney",
  "وکیل"
 ],
 [
  "lawyer",
  "وکیل"
 ],
 [
  "barrister",
  "بیرسٹر"
 ],
 [
  "solicitor",
  "وکیل"
 ],
 [
  "notary",
  "نوٹری"
 ],
 [
  "clerk",
  "کلرک"
 ],
 [
  "bailiff",
  "ناظم"
 ],
 [
  "sheriff",
  "شیرف"
 ],
 [
  "constable",
  "کانسٹیبل"
 ],
 [
  "inspector",
  "انسپکٹر"
 ],
 [
  "sergeant",
  "سارجنٹ"
 ],
 [
  "officer",
  "افسر"
 ],
 [
  "commander",
  "کمانڈر"
 ],
 [
  "general",
  "جرنیل"
 ],
 [
  "colonel",
  "کرنل"
 ],
 [
  "major",
  "میجر"
 ],
 [
  "lieutenant",
  "لیفٹیننٹ"
 ],
 [
  "corporal",
  "نائیک"
 ],
 [
  "private",
  "سپاہی"
 ],
 [
  "recruit",
  "بھرتی"
 ],
 [
  "veteran",
  "سابق فوجی"
 ],
 [
  "martyr",
  "شہید"
 ],
 [
  "hero",
  "ہیرو"
 ],
 [
  "heroine",
  "ہیروئن"
 ],
 [
  "villain",
  "ولن"
 ],
 [
  "traitor",
  "غدار"
 ],
 [
  "spy",
  "جاسوس"
 ],
 [
  "agent",
  "ایجنٹ"
 ],
 [
  "informer",
  "مخبر"
 ],
 [
  "double",
  "دوہرا"
 ],
 [
  "disguise",
  "بھیس"
 ],
 [
  "mask",
  "نقاب"
 ],
 [
  "cloak",
  "چوغہ"
 ],
 [
  "code",
  "ضابطہ"
 ],
 [
  "cipher",
  "خفیہ لکھائی"
 ],
 [
  "message",
  "پیغام"
 ],
 [
  "letter",
  "خط"
 ],
 [
  "post",
  "ڈاک"
 ],
 [
  "mail",
  "ڈاک"
 ],
 [
  "stamp",
  "ٹکٹ"
 ],
 [
  "envelope",
  "لفافہ"
 ],
 [
  "parcel",
  "پارسل"
 ],
 [
  "courier",
  "قاصد"
 ],
 [
  "telegram",
  "تار"
 ],
 [
  "telephone",
  "ٹیلی فون"
 ],
 [
  "mobile",
  "موبائل"
 ],
 [
  "phone",
  "فون"
 ],
 [
  "dial",
  "ڈائل کرنا"
 ],
 [
  "hold",
  "انتظار"
 ],
 [
  "transfer",
  "منتقل کرنا"
 ],
 [
  "voicemail",
  "وائس میل"
 ],
 [
  "text",
  "پیغام"
 ],
 [
  "chat",
  "چیٹ"
 ],
 [
  "email",
  "ای میل"
 ],
 [
  "website",
  "ویب سائٹ"
 ],
 [
  "internet",
  "انٹرنیٹ"
 ],
 [
  "browser",
  "براؤزر"
 ],
 [
  "search",
  "تلاش"
 ],
 [
  "download",
  "ڈاؤن لوڈ"
 ],
 [
  "upload",
  "اپ لوڈ"
 ],
 [
  "install",
  "انسٹال کرنا"
 ],
 [
  "update",
  "اپ ڈیٹ"
 ],
 [
  "upgrade",
  "اپ گریڈ"
 ],
 [
  "backup",
  "بیک اپ"
 ],
 [
  "restore",
  "بحال کرنا"
 ],
 [
  "delete",
  "حذف کرنا"
 ],
 [
  "remove",
  "ہٹانا"
 ],
 [
  "erase",
  "مٹانا"
 ],
 [
  "format",
  "فارمیٹ"
 ],
 [
  "partition",
  "تقسیم"
 ],
 [
  "drive",
  "ڈرائیو"
 ],
 [
  "disk",
  "ڈسک"
 ],
 [
  "storage",
  "اسٹوریج"
 ],
 [
  "file",
  "فائل"
 ],
 [
  "folder",
  "فولڈر"
 ],
 [
  "document",
  "دستاویز"
 ],
 [
  "spreadsheet",
  "اسپریڈ شیٹ"
 ],
 [
  "presentation",
  "پریزنٹیشن"
 ],
 [
  "slide",
  "سلائیڈ"
 ],
 [
  "template",
  "سانچہ"
 ],
 [
  "font",
  "فونٹ"
 ],
 [
  "layout",
  "ترتیب"
 ],
 [
  "design",
  "ڈیزائن"
 ],
 [
  "draft",
  "مسودہ"
 ],
 [
  "edit",
  "ترمیم کرنا"
 ],
 [
  "revise",
  "نظر ثانی کرنا"
 ],
 [
  "proofread",
  "تصحیح کرنا"
 ],
 [
  "publish",
  "شائع کرنا"
 ],
 [
  "print",
  "چھاپنا"
 ],
 [
  "paste",
  "چسپاں کرنا"
 ],
 [
  "undo",
  "واپس کرنا"
 ],
 [
  "redo",
  "دوبارہ کرنا"
 ],
 [
  "exit",
  "باہر نکلنا"
 ],
 [
  "quit",
  "چھوڑنا"
 ],
 [
  "start",
  "شروع کرنا"
 ],
 [
  "stop",
  "رکنا"
 ],
 [
  "pause",
  "وقفہ"
 ],
 [
  "resume",
  "دوبارہ شروع کرنا"
 ],
 [
  "finish",
  "ختم کرنا"
 ],
 [
  "submit",
  "جمع کرانا"
 ],
 [
  "send",
  "بھیجنا"
 ],
 [
  "receive",
  "وصول کرنا"
 ],
 [
  "forward",
  "آگے بھیجنا"
 ],
 [
  "reply",
  "جواب دینا"
 ],
 [
  "respond",
  "جواب دینا"
 ],
 [
  "acknowledge",
  "تسلیم کرنا"
 ],
 [
  "verify",
  "تصدیق کرنا"
 ],
 [
  "validate",
  "توثیق کرنا"
 ],
 [
  "authenticate",
  "تصدیق کرنا"
 ],
 [
  "authorize",
  "اختیار دینا"
 ],
 [
  "permit",
  "اجازت"
 ],
 [
  "license",
  "لائسنس"
 ],
 [
  "patent",
  "پیٹنٹ"
 ],
 [
  "copyright",
  "کاپی رائٹ"
 ],
 [
  "trademark",
  "ٹریڈ مارک"
 ],
 [
  "brand",
  "برانڈ"
 ],
 [
  "logo",
  "لوگو"
 ],
 [
  "slogan",
  "نعرہ"
 ],
 [
  "advertise",
  "اشتہار دینا"
 ],
 [
  "promote",
  "ترقی دینا"
 ],
 [
  "campaign",
  "مہم"
 ],
 [
  "launch",
  "آغاز کرنا"
 ],
 [
  "release",
  "جاری کرنا"
 ],
 [
  "debut",
  "پہلی پیشکش"
 ],
 [
  "premiere",
  "پہلی نمائش"
 ],
 [
  "exhibit",
  "نمائش کرنا"
 ],
 [
  "display",
  "دکھانا"
 ],
 [
  "demonstrate",
  "مظاہرہ کرنا"
 ],
 [
  "illustrate",
  "واضح کرنا"
 ],
 [
  "depict",
  "بیان کرنا"
 ],
 [
  "portray",
  "تصویر کشی کرنا"
 ],
 [
  "describe",
  "بیان کرنا"
 ],
 [
  "narrate",
  "بیان کرنا"
 ],
 [
  "recite",
  "پڑھنا"
 ],
 [
  "quote",
  "اقتباس"
 ],
 [
  "cite",
  "حوالہ دینا"
 ],
 [
  "reference",
  "حوالہ"
 ],
 [
  "origin",
  "اصل"
 ],
 [
  "reason",
  "وجہ"
 ],
 [
  "purpose",
  "مقصد"
 ],
 [
  "goal",
  "ہدف"
 ],
 [
  "objective",
  "مقصد"
 ],
 [
  "mission",
  "مشن"
 ],
 [
  "vision",
  "وژن"
 ],
 [
  "ambition",
  "حوصلہ"
 ],
 [
  "aspiration",
  "تمنا"
 ],
 [
  "desire",
  "خواہش"
 ],
 [
  "wish",
  "خواہش"
 ],
 [
  "want",
  "چاہنا"
 ],
 [
  "require",
  "درکار ہونا"
 ],
 [
  "demand",
  "مطالبہ"
 ],
 [
  "request",
  "درخواست"
 ],
 [
  "beg",
  "بھیک مانگنا"
 ],
 [
  "plead",
  "التجا کرنا"
 ],
 [
  "urge",
  "زور دینا"
 ],
 [
  "insist",
  "اصرار کرنا"
 ],
 [
  "persist",
  "ڈٹے رہنا"
 ],
 [
  "persevere",
  "ثابت قدم رہنا"
 ],
 [
  "endure",
  "برداشت کرنا"
 ],
 [
  "tolerate",
  "برداشت کرنا"
 ],
 [
  "suffer",
  "تکلیف اٹھانا"
 ],
 [
  "undergo",
  "گزرنا"
 ],
 [
  "experience",
  "تجربہ"
 ],
 [
  "undertake",
  "بیڑا اٹھانا"
 ],
 [
  "try",
  "کوشش کرنا"
 ],
 [
  "endeavor",
  "کوشش"
 ],
 [
  "strive",
  "کوشش کرنا"
 ],
 [
  "struggle",
  "جدوجہد کرنا"
 ],
 [
  "combat",
  "لڑائی"
 ],
 [
  "crusade",
  "صلیبی جنگ"
 ],
 [
  "jihad",
  "جہاد"
 ],
 [
  "sacrifice",
  "قربانی"
 ],
 [
  "offer",
  "پیشکش"
 ],
 [
  "dedicate",
  "وقف کرنا"
 ],
 [
  "devote",
  "وقف کرنا"
 ],
 [
  "consecrate",
  "مقدس کرنا"
 ],
 [
  "bless",
  "برکت دینا"
 ],
 [
  "pray",
  "دعا کرنا"
 ],
 [
  "worship",
  "عبادت کرنا"
 ],
 [
  "praise",
  "تعریف کرنا"
 ],
 [
  "glorify",
  "بزرگی بیان کرنا"
 ],
 [
  "exalt",
  "بلند کرنا"
 ],
 [
  "honor",
  "عزت کرنا"
 ],
 [
  "respect",
  "احترام کرنا"
 ],
 [
  "revere",
  "تعظیم کرنا"
 ],
 [
  "adore",
  "پوجنا"
 ],
 [
  "idolize",
  "بت بنانا"
 ],
 [
  "deify",
  "خدا بنانا"
 ],
 [
  "sanctify",
  "پاک کرنا"
 ],
 [
  "purify",
  "c|صاف کرنا"
 ],
 [
  "cleanse",
  "صاف کرنا"
 ],
 [
  "rinse",
  "کھنگالنا"
 ],
 [
  "wipe",
  "پونچھنا"
 ],
 [
  "sweep",
  "جھاڑو دینا"
 ],
 [
  "mop",
  "پونچھا لگانا"
 ],
 [
  "polish",
  "پالش کرنا"
 ],
 [
  "scrub",
  "رگڑنا"
 ],
 [
  "scrape",
  "کھرچنا"
 ],
 [
  "peel",
  "چھیلنا"
 ],
 [
  "pare",
  "تراشنا"
 ],
 [
  "trim",
  "تراشنا"
 ],
 [
  "chop",
  "کاٹنا"
 ],
 [
  "slice",
  "قاش کرنا"
 ],
 [
  "dice",
  "ٹکڑے کرنا"
 ],
 [
  "mince",
  "قیمہ کرنا"
 ],
 [
  "grate",
  "کدوکش کرنا"
 ],
 [
  "grind",
  "پیسنا"
 ],
 [
  "pound",
  "کوٹنا"
 ],
 [
  "beat",
  "پھینٹنا"
 ],
 [
  "whisk",
  "پھینٹنا"
 ],
 [
  "stir",
  "ہلانا"
 ],
 [
  "mix",
  "ملانا"
 ],
 [
  "blend",
  "ملانا"
 ],
 [
  "merge",
  "ضم کرنا"
 ],
 [
  "fuse",
  "پگھل کر ملانا"
 ],
 [
  "weld",
  "ویلڈ کرنا"
 ],
 [
  "solder",
  "ٹانکا لگانا"
 ],
 [
  "glue",
  "گوند لگانا"
 ],
 [
  "stick",
  "چپکانا"
 ],
 [
  "attach",
  "جوڑنا"
 ],
 [
  "fasten",
  "باندھنا"
 ],
 [
  "tie",
  "باندھنا"
 ],
 [
  "bind",
  "باندھنا"
 ],
 [
  "knot",
  "گرہ"
 ],
 [
  "loop",
  "پھندا"
 ],
 [
  "clasp",
  "بکسل"
 ],
 [
  "buckle",
  "بکسل"
 ],
 [
  "zipper",
  "زپ"
 ],
 [
  "snap",
  "ٹک"
 ],
 [
  "pin",
  "پن"
 ],
 [
  "needle",
  "سوئی"
 ],
 [
  "thread",
  "دھاگا"
 ],
 [
  "yarn",
  "اون کا دھاگا"
 ],
 [
  "string",
  "ڈوری"
 ],
 [
  "cord",
  "رسی"
 ],
 [
  "link",
  "کڑی"
 ],
 [
  "moor",
  "لنگر ڈالنا"
 ],
 [
  "sail",
  "بادبان"
 ],
 [
  "oar",
  "چپو"
 ],
 [
  "paddle",
  "چپو"
 ],
 [
  "rudder",
  "پتوار"
 ],
 [
  "keel",
  "پیندا"
 ],
 [
  "hull",
  "ڈھانچہ"
 ],
 [
  "deck",
  "عرشہ"
 ],
 [
  "mast",
  "مستول"
 ],
 [
  "rigging",
  "رسیاں"
 ],
 [
  "cargo",
  "مال"
 ],
 [
  "freight",
  "مال برداری"
 ],
 [
  "shipment",
  "کھیپ"
 ],
 [
  "consignment",
  "کھیپ"
 ],
 [
  "load",
  "بوجھ"
 ],
 [
  "unload",
  "اتارنا"
 ],
 [
  "pack",
  "باندھنا"
 ],
 [
  "unpack",
  "کھولنا"
 ],
 [
  "wrap",
  "لپیٹنا"
 ],
 [
  "unwrap",
  "کھولنا"
 ],
 [
  "seal",
  "مہر لگانا"
 ],
 [
  "label",
  "لیبل"
 ],
 [
  "tag",
  "ٹیگ"
 ],
 [
  "ID",
  "شناختی کارڈ"
 ],
 [
  "certificate",
  "سند"
 ],
 [
  "diploma",
  "ڈپلومہ"
 ],
 [
  "transcript",
  "نقل"
 ],
 [
  "record",
  "ریکارڈ"
 ],
 [
  "register",
  "رجسٹر"
 ],
 [
  "enroll",
  "داخلہ لینا"
 ],
 [
  "graduate",
  "فارغ التحصیل ہونا"
 ],
 [
  "commence",
  "آغاز کرنا"
 ],
 [
  "convocation",
  "جلسہ تقسیم اسناد"
 ],
 [
  "alumni",
  "فارغ التحصیل"
 ],
 [
  "valedictorian",
  "اول نمبر"
 ],
 [
  "salutatorian",
  "دوم نمبر"
 ],
 [
  "distinction",
  "امتیاز"
 ],
 [
  "merit",
  "قابلیت"
 ],
 [
  "scholarship",
  "وظیفہ"
 ],
 [
  "fellowship",
  "فیلوشپ"
 ],
 [
  "grant",
  "گرانٹ"
 ],
 [
  "endowment",
  "وقف"
 ],
 [
  "donation",
  "عطیہ"
 ],
 [
  "philanthropy",
  "انسان دوستی"
 ],
 [
  "volunteer",
  "رضاکار"
 ],
 [
  "service",
  "خدمت"
 ],
 [
  "obligation",
  "ذمہ داری"
 ],
 [
  "commitment",
  "عزم"
 ],
 [
  "pledge",
  "عہد"
 ],
 [
  "vow",
  "منت"
 ],
 [
  "agreement",
  "معاہدہ"
 ],
 [
  "deal",
  "سودا"
 ],
 [
  "negotiate",
  "مذاکرات کرنا"
 ],
 [
  "mediate",
  "ثالثی کرنا"
 ],
 [
  "arbitrate",
  "ثالثی کرنا"
 ],
 [
  "settle",
  "طے کرنا"
 ],
 [
  "resolve",
  "حل کرنا"
 ],
 [
  "solve",
  "حل کرنا"
 ],
 [
  "response",
  "جواب"
 ],
 [
  "feedback",
  "آراء"
 ],
 [
  "remark",
  "تبصرہ"
 ],
 [
  "observation",
  "مشاہدہ"
 ],
 [
  "note",
  "نوٹ"
 ],
 [
  "memo",
  "یادداشت"
 ],
 [
  "report",
  "رپورٹ"
 ],
 [
  "summary",
  "خلاصہ"
 ],
 [
  "abstract",
  "خلاصہ"
 ],
 [
  "synopsis",
  "خلاصہ"
 ],
 [
  "outline",
  "خاکہ"
 ],
 [
  "manuscript",
  "مسودہ"
 ],
 [
  "script",
  "اسکرپٹ"
 ],
 [
  "content",
  "مواد"
 ],
 [
  "subject",
  "مضمون"
 ],
 [
  "topic",
  "موضوع"
 ],
 [
  "theme",
  "موضوع"
 ],
 [
  "title",
  "عنوان"
 ],
 [
  "heading",
  "سرخی"
 ],
 [
  "subtitle",
  "ذیلی عنوان"
 ],
 [
  "caption",
  "عنوان"
 ],
 [
  "legend",
  "علامتوں کی وضاحت"
 ],
 [
  "footnote",
  "حاشیہ"
 ],
 [
  "endnote",
  "آخری حاشیہ"
 ],
 [
  "bibliography",
  "کتابیات"
 ],
 [
  "index",
  "فہرست"
 ],
 [
  "glossary",
  "فرہنگ"
 ],
 [
  "appendix",
  "ضمیمہ"
 ],
 [
  "preface",
  "دیباچہ"
 ],
 [
  "foreword",
  "پیش لفظ"
 ],
 [
  "introduction",
  "تعارف"
 ],
 [
  "prologue",
  "تمہید"
 ],
 [
  "epilogue",
  "خاتمہ"
 ],
 [
  "section",
  "حصہ"
 ],
 [
  "part",
  "حصہ"
 ],
 [
  "edition",
  "اشاعت"
 ],
 [
  "issue",
  "شمارہ"
 ],
 [
  "reprint",
  "دوبارہ چھپائی"
 ],
 [
  "press",
  "پریس"
 ],
 [
  "publisher",
  "ناشر"
 ],
 [
  "editor",
  "مدیر"
 ],
 [
  "writer",
  "مصنف"
 ],
 [
  "journalist",
  "صحافی"
 ],
 [
  "reporter",
  "رپورٹر"
 ],
 [
  "correspondent",
  "نامہ نگار"
 ],
 [
  "columnist",
  "کالم نگار"
 ],
 [
  "reviewer",
  "تبصرہ نگار"
 ],
 [
  "blogger",
  "بلاگر"
 ],
 [
  "vlogger",
  "ویلاگر"
 ],
 [
  "influencer",
  "اثر انداز"
 ],
 [
  "follower",
  "پیروکار"
 ],
 [
  "subscriber",
  "رکن"
 ],
 [
  "member",
  "رکن"
 ],
 [
  "participant",
  "شریک"
 ],
 [
  "attendee",
  "حاضر"
 ],
 [
  "visitor",
  "ملاقاتی"
 ],
 [
  "traveler",
  "مسافر"
 ],
 [
  "commuter",
  "روزانہ سفر کرنے والا"
 ],
 [
  "pedestrian",
  "پیدل چلنے والا"
 ],
 [
  "cyclist",
  "سائیکل سوار"
 ],
 [
  "motorist",
  "موٹر چلانے والا"
 ],
 [
  "chauffeur",
  "ڈرائیور"
 ],
 [
  "staff",
  "عملہ"
 ],
 [
  "employee",
  "ملازم"
 ],
 [
  "employer",
  "آجر"
 ],
 [
  "boss",
  "مالک"
 ],
 [
  "manager",
  "مینیجر"
 ],
 [
  "supervisor",
  "نگران"
 ],
 [
  "director",
  "ڈائریکٹر"
 ],
 [
  "executive",
  "منتظم"
 ],
 [
  "assistant",
  "معاون"
 ],
 [
  "secretary",
  "سیکرٹری"
 ],
 [
  "receptionist",
  "استقبالیہ"
 ],
 [
  "accountant",
  "محاسب"
 ],
 [
  "auditor",
  "آڈیٹر"
 ],
 [
  "cashier",
  "خزانچی"
 ],
 [
  "teller",
  "خزانچی"
 ],
 [
  "banker",
  "بینکر"
 ],
 [
  "broker",
  "دلال"
 ],
 [
  "dealer",
  "تاجر"
 ],
 [
  "merchant",
  "سوداگر"
 ],
 [
  "trader",
  "تاجر"
 ],
 [
  "vendor",
  "بیچنے والا"
 ],
 [
  "hawker",
  "پھیری والا"
 ],
 [
  "peddler",
  "پھیری والا"
 ],
 [
  "shopkeeper",
  "دکاندار"
 ],
 [
  "grocer",
  "کریانہ فروش"
 ],
 [
  "butcher",
  "قصائی"
 ],
 [
  "baker",
  "نانبائی"
 ],
 [
  "confectioner",
  "حلوائی"
 ],
 [
  "florist",
  "پھول فروش"
 ],
 [
  "jeweler",
  "سنار"
 ],
 [
  "watchmaker",
  "گھڑی ساز"
 ],
 [
  "cobbler",
  "موچی"
 ],
 [
  "barber",
  "نائی"
 ],
 [
  "hairdresser",
  "نائی"
 ],
 [
  "beautician",
  "بیوٹیشن"
 ],
 [
  "masseur",
  "مالشی"
 ],
 [
  "launderer",
  "دھوبی"
 ],
 [
  "presser",
  "استری والا"
 ],
 [
  "cleaner",
  "صفائی کرنے والا"
 ],
 [
  "sweeper",
  "جھاڑو دینے والا"
 ],
 [
  "gardener",
  "مالی"
 ],
 [
  "watchman",
  "چوکیدار"
 ],
 [
  "guard",
  "پہرے دار"
 ],
 [
  "sentry",
  "پہرے دار"
 ],
 [
  "caretaker",
  "نگران"
 ],
 [
  "janitor",
  "دربان"
 ],
 [
  "porter",
  "قلی"
 ],
 [
  "coolie",
  "قلی"
 ],
 [
  "rickshaw",
  "رکشہ"
 ],
 [
  "taxi",
  "ٹیکسی"
 ],
 [
  "cab",
  "ٹیکسی"
 ],
 [
  "tip",
  "بخشش"
 ],
 [
  "bribe",
  "رشوت"
 ],
 [
  "fee",
  "فیس"
 ],
 [
  "toll",
  "محصول"
 ],
 [
  "tariff",
  "محصول"
 ],
 [
  "tax",
  "ٹیکس"
 ],
 [
  "levy",
  "محصول"
 ],
 [
  "fine",
  "جرمانہ"
 ],
 [
  "penalty",
  "سزا"
 ],
 [
  "forfeit",
  "ضبط"
 ],
 [
  "confiscate",
  "ضبط کرنا"
 ],
 [
  "seize",
  "پکڑنا"
 ],
 [
  "impound",
  "ضبط کرنا"
 ],
 [
  "garnish",
  "قرق کرنا"
 ],
 [
  "lien",
  "حق"
 ],
 [
  "mortgage",
  "رہن"
 ],
 [
  "collateral",
  "ضمانت"
 ],
 [
  "guarantee",
  "ضمانت"
 ],
 [
  "warranty",
  "گارنٹی"
 ],
 [
  "surety",
  "ضمانت"
 ],
 [
  "bond",
  "بانڈ"
 ],
 [
  "stock",
  "حصص"
 ],
 [
  "share",
  "حصہ"
 ],
 [
  "dividend",
  "منافع"
 ],
 [
  "equity",
  "حصص"
 ],
 [
  "asset",
  "اثاثہ"
 ],
 [
  "liability",
  "ذمہ داری"
 ],
 [
  "investment",
  "سرمایہ کاری"
 ],
 [
  "investor",
  "سرمایہ کار"
 ],
 [
  "speculator",
  "سٹے باز"
 ],
 [
  "bull",
  "تیز بازار"
 ],
 [
  "exchange",
  "تبادلہ"
 ],
 [
  "industry",
  "صنعت"
 ],
 [
  "factory",
  "کارخانہ"
 ],
 [
  "mill",
  "مل"
 ],
 [
  "workshop",
  "ورکشاپ"
 ],
 [
  "studio",
  "اسٹوڈیو"
 ],
 [
  "lab",
  "لیب"
 ],
 [
  "office",
  "دفتر"
 ],
 [
  "headquarters",
  "صدر دفتر"
 ],
 [
  "unit",
  "یونٹ"
 ],
 [
  "team",
  "ٹیم"
 ],
 [
  "group",
  "گروہ"
 ],
 [
  "faction",
  "دھڑا"
 ],
 [
  "wing",
  "شاخ"
 ],
 [
  "caucus",
  "اجلاس"
 ],
 [
  "lobby",
  "لابی"
 ],
 [
  "bloc",
  "بلاک"
 ],
 [
  "coalition",
  "اتحاد"
 ],
 [
  "federation",
  "وفاق"
 ],
 [
  "confederation",
  "کنفیڈریشن"
 ],
 [
  "union",
  "یونین"
 ],
 [
  "league",
  "لیگ"
 ],
 [
  "association",
  "انجمن"
 ],
 [
  "society",
  "سوسائٹی"
 ],
 [
  "fraternity",
  "برادری"
 ],
 [
  "sorority",
  "برادری"
 ],
 [
  "lodge",
  "لاج"
 ],
 [
  "guild",
  "انجمن"
 ],
 [
  "syndicate",
  "سنڈیکیٹ"
 ],
 [
  "cartel",
  "کارٹل"
 ],
 [
  "trust",
  "ٹرسٹ"
 ],
 [
  "monopoly",
  "اجارہ داری"
 ],
 [
  "oligopoly",
  "چند فروشی"
 ],
 [
  "competition",
  "مقابلہ"
 ],
 [
  "rivalry",
  "رقابت"
 ],
 [
  "tournament",
  "ٹورنامنٹ"
 ],
 [
  "championship",
  "چیمپئن شپ"
 ],
 [
  "match",
  "میچ"
 ],
 [
  "game",
  "کھیل"
 ],
 [
  "sport",
  "کھیل"
 ],
 [
  "athletics",
  "کھیل کود"
 ],
 [
  "gymnastics",
  "جمناسٹک"
 ],
 [
  "wrestling",
  "کشتی"
 ],
 [
  "boxing",
  "مکے بازی"
 ],
 [
  "fencing",
  "تیغ زنی"
 ],
 [
  "archery",
  "تیر اندازی"
 ],
 [
  "shooting",
  "نشانہ بازی"
 ],
 [
  "hunting",
  "شکار"
 ],
 [
  "fishing",
  "مچھلی پکڑنا"
 ],
 [
  "sailing",
  "کشتی رانی"
 ],
 [
  "rowing",
  "چپو چلانا"
 ],
 [
  "canoeing",
  "ڈونگی چلانا"
 ],
 [
  "kayaking",
  "کایاکنگ"
 ],
 [
  "surfing",
  "سرفنگ"
 ],
 [
  "swimming",
  "تیراکی"
 ],
 [
  "diving",
  "غوطہ خوری"
 ],
 [
  "waterpolo",
  "واٹر پولو"
 ],
 [
  "football",
  "فٹ بال"
 ],
 [
  "soccer",
  "فٹ بال"
 ],
 [
  "rugby",
  "رگبی"
 ],
 [
  "hockey",
  "ہاکی"
 ],
 [
  "tennis",
  "ٹینس"
 ],
 [
  "badminton",
  "بیڈمنٹن"
 ],
 [
  "squash",
  "اسکواش"
 ],
 [
  "tabletennis",
  "ٹیبل ٹینس"
 ],
 [
  "volleyball",
  "والی بال"
 ],
 [
  "basketball",
  "باسکٹ بال"
 ],
 [
  "baseball",
  "بیس بال"
 ],
 [
  "golf",
  "گولف"
 ],
 [
  "polo",
  "پولو"
 ],
 [
  "kabaddi",
  "کبڈی"
 ],
 [
  "carrom",
  "کیرم"
 ],
 [
  "ludo",
  "لڈو"
 ],
 [
  "cards",
  "تاش"
 ],
 [
  "poker",
  "پوکر"
 ],
 [
  "rummy",
  "رمی"
 ],
 [
  "domino",
  "ڈومینو"
 ],
 [
  "puzzle",
  "پہیلی"
 ],
 [
  "riddle",
  "پہیلی"
 ],
 [
  "quiz",
  "کوئز"
 ],
 [
  "trivia",
  "معلومات"
 ],
 [
  "crossword",
  "کراس ورڈ"
 ],
 [
  "sudoku",
  "سوڈوکو"
 ],
 [
  "jigsaw",
  "جیگسا"
 ],
 [
  "maze",
  "بھول بھلیاں"
 ],
 [
  "toy",
  "کھلونا"
 ],
 [
  "doll",
  "گڑیا"
 ],
 [
  "kite",
  "پتنگ"
 ],
 [
  "balloon",
  "غبارہ"
 ],
 [
  "marble",
  "گولی"
 ],
 [
  "top",
  "لٹو"
 ],
 [
  "yo-yo",
  "یو یو"
 ],
 [
  "frisbee",
  "فرسبی"
 ],
 [
  "skateboard",
  "اسکیٹ بورڈ"
 ],
 [
  "tricycle",
  "تین پہیہ"
 ],
 [
  "scooter",
  "اسکوٹر"
 ],
 [
  "moped",
  "موپیڈ"
 ],
 [
  "motorbike",
  "موٹر بائیک"
 ],
 [
  "van",
  "وین"
 ],
 [
  "lorry",
  "ٹرک"
 ],
 [
  "trailer",
  "ٹرالر"
 ],
 [
  "tanker",
  "ٹینکر"
 ],
 [
  "ambulance",
  "ایمبولینس"
 ],
 [
  "fireengine",
  "فائر انجن"
 ],
 [
  "policecar",
  "پولیس کی گاڑی"
 ],
 [
  "limousine",
  "لموزین"
 ],
 [
  "convertible",
  "کھلی چھت والی گاڑی"
 ],
 [
  "sedan",
  "سیڈان"
 ],
 [
  "hatchback",
  "ہیچ بیک"
 ],
 [
  "SUV",
  "ایس یو وی"
 ],
 [
  "coupe",
  "کوپ"
 ],
 [
  "wagon",
  "ویگن"
 ],
 [
  "pickup",
  "پک اپ"
 ],
 [
  "jeep",
  "جیپ"
 ],
 [
  "humvee",
  "ہموی"
 ],
 [
  "APC",
  "بکتر بند گاڑی"
 ],
 [
  "artillery",
  "توپ خانہ"
 ],
 [
  "mortar",
  "مارٹر"
 ],
 [
  "howitzer",
  "ہووٹزر"
 ],
 [
  "machinegun",
  "مشین گن"
 ],
 [
  "grenade",
  "دستی بم"
 ],
 [
  "torpedo",
  "ٹارپیڈو"
 ],
 [
  "depthcharge",
  "ڈیپتھ چارج"
 ],
 [
  "sonar",
  "سونار"
 ],
 [
  "radar",
  "ریڈار"
 ],
 [
  "drone",
  "ڈرون"
 ],
 [
  "UAV",
  "بغیر پائلٹ طیارہ"
 ],
 [
  "transport",
  "نقل و حمل"
 ],
 [
  "refuel",
  "ایندھن بھرنا"
 ],
 [
  "airbase",
  "ہوائی اڈا"
 ],
 [
  "hangar",
  "ہینگر"
 ],
 [
  "runway",
  "رن وے"
 ],
 [
  "taxiway",
  "ٹیکسی وے"
 ],
 [
  "tower",
  "مینار"
 ],
 [
  "approach",
  "نزدیک آنا"
 ],
 [
  "landing",
  "اترنا"
 ],
 [
  "takeoff",
  "اڑنا"
 ],
 [
  "altitude",
  "بلندی"
 ],
 [
  "airspeed",
  "ہوائی رفتار"
 ],
 [
  "bearing",
  "سمت"
 ],
 [
  "route",
  "راستہ"
 ],
 [
  "waypoint",
  "نقطہ"
 ],
 [
  "destination",
  "منزل"
 ],
 [
  "departure",
  "روانگی"
 ],
 [
  "arrival",
  "آمد"
 ],
 [
  "delay",
  "تاخیر"
 ],
 [
  "divert",
  "موڑنا"
 ],
 [
  "mayday",
  "مدد کی پکار"
 ],
 [
  "distress",
  "مصیبت"
 ],
 [
  "rescue",
  "بچاؤ"
 ],
 [
  "evacuate",
  "خالی کرنا"
 ],
 [
  "shelter",
  "پناہ"
 ],
 [
  "refuge",
  "پناہ"
 ],
 [
  "haven",
  "پناہ گاہ"
 ],
 [
  "wharf",
  "گھاٹ"
 ],
 [
  "quay",
  "گھاٹ"
 ],
 [
  "jetty",
  "گھاٹ"
 ],
 [
  "breakwater",
  "بند"
 ],
 [
  "seawall",
  "سمندری دیوار"
 ],
 [
  "beacon",
  "اشارہ"
 ],
 [
  "passage",
  "گزرگاہ"
 ],
 [
  "corridor",
  "راہداری"
 ],
 [
  "aisle",
  "راہ"
 ],
 [
  "hallway",
  "برآمدہ"
 ],
 [
  "foyer",
  "دالان"
 ],
 [
  "vestibule",
  "دالان"
 ],
 [
  "atrium",
  "صحن"
 ],
 [
  "courtyard",
  "صحن"
 ],
 [
  "patio",
  "صحن"
 ],
 [
  "terrace",
  "چھت"
 ],
 [
  "balcony",
  "بالکونی"
 ],
 [
  "veranda",
  "برآمدہ"
 ],
 [
  "porch",
  "دالان"
 ],
 [
  "attic",
  "اٹاری"
 ],
 [
  "basement",
  "تہ خانہ"
 ],
 [
  "cellar",
  "تہ خانہ"
 ],
 [
  "garage",
  "گیراج"
 ],
 [
  "shed",
  "چھپر"
 ],
 [
  "coop",
  "مرغی خانہ"
 ],
 [
  "hutch",
  "پنجرہ"
 ],
 [
  "aviary",
  "پرندوں کا گھر"
 ],
 [
  "aquarium",
  "مچھلی گھر"
 ],
 [
  "terrarium",
  "ٹیریریم"
 ],
 [
  "vivarium",
  "ویویریم"
 ],
 [
  "zoo",
  "چڑیا گھر"
 ],
 [
  "safari",
  "سفاری"
 ],
 [
  "lawn",
  "لان"
 ],
 [
  "range",
  "چراگاہ"
 ],
 [
  "taiga",
  "تائیگا"
 ],
 [
  "rainforest",
  "بارانی جنگل"
 ],
 [
  "woodland",
  "جنگل"
 ],
 [
  "thicket",
  "جھاڑی"
 ],
 [
  "copse",
  "جھاڑی"
 ],
 [
  "grove",
  "باغ"
 ],
 [
  "plantation",
  "باغ"
 ],
 [
  "estate",
  "جائیداد"
 ],
 [
  "manor",
  "حویلی"
 ],
 [
  "palace",
  "محل"
 ],
 [
  "fort",
  "قلعہ"
 ],
 [
  "citadel",
  "قلعہ"
 ],
 [
  "rampart",
  "فصیل"
 ],
 [
  "bastion",
  "برج"
 ],
 [
  "turret",
  "برج"
 ],
 [
  "spire",
  "مینار"
 ],
 [
  "dome",
  "گنبد"
 ],
 [
  "arch",
  "محراب"
 ],
 [
  "vault",
  "طاق"
 ],
 [
  "pillar",
  "ستون"
 ],
 [
  "beam",
  "شہتیر"
 ],
 [
  "joist",
  "شہتیر"
 ],
 [
  "rafter",
  "شہتیر"
 ],
 [
  "truss",
  "فریم"
 ],
 [
  "frame",
  "ڈھانچہ"
 ],
 [
  "scaffold",
  "ٹھٹھر"
 ],
 [
  "foundation",
  "بنیاد"
 ],
 [
  "footing",
  "بنیاد"
 ],
 [
  "piling",
  "ستون"
 ],
 [
  "abutment",
  "سہارا"
 ],
 [
  "buttress",
  "سہارا"
 ],
 [
  "keystone",
  "مرکزی پتھر"
 ],
 [
  "lintel",
  "شہتیر"
 ],
 [
  "sill",
  "چوکھٹ"
 ],
 [
  "jamb",
  "چوکھٹ"
 ],
 [
  "threshold",
  "دہلیز"
 ],
 [
  "doorstep",
  "دہلیز"
 ],
 [
  "rug",
  "قالین"
 ],
 [
  "tapestry",
  "دیوار کا پردہ"
 ],
 [
  "blind",
  "پردہ"
 ],
 [
  "shade",
  "سایہ"
 ],
 [
  "awning",
  "سائبان"
 ],
 [
  "canopy",
  "شامیانہ"
 ],
 [
  "umbrella",
  "چھتری"
 ],
 [
  "parasol",
  "چھتری"
 ],
 [
  "pavilion",
  "پویلین"
 ],
 [
  "kiosk",
  "کیوسک"
 ],
 [
  "stall",
  "اسٹال"
 ],
 [
  "booth",
  "کیبن"
 ],
 [
  "counter",
  "کاؤنٹر"
 ],
 [
  "rack",
  "ریک"
 ],
 [
  "wardrobe",
  "الماری"
 ],
 [
  "dresser",
  "سنگھار میز"
 ],
 [
  "vanity",
  "سنگھار میز"
 ],
 [
  "chandelier",
  "فانوس"
 ],
 [
  "sconce",
  "دیوار کا چراغ"
 ],
 [
  "lantern",
  "لالٹین"
 ],
 [
  "torch",
  "مشعل"
 ],
 [
  "wick",
  "بتی"
 ],
 [
  "lighter",
  "لائٹر"
 ],
 [
  "flint",
  "چقماق"
 ],
 [
  "spark",
  "چنگاری"
 ],
 [
  "flame",
  "شعلہ"
 ],
 [
  "fire",
  "آگ"
 ],
 [
  "blaze",
  "شعلہ"
 ],
 [
  "inferno",
  "دوزخ"
 ],
 [
  "bonfire",
  "الاؤ"
 ],
 [
  "campfire",
  "الاؤ"
 ],
 [
  "hearth",
  "آتش دان"
 ],
 [
  "fireplace",
  "آتش دان"
 ],
 [
  "chimney",
  "دھواں کش"
 ],
 [
  "flue",
  "دھواں کش"
 ],
 [
  "smoke",
  "دھواں"
 ],
 [
  "soot",
  "کاجل"
 ],
 [
  "ash",
  "راکھ"
 ],
 [
  "ember",
  "انگارہ"
 ],
 [
  "charcoal",
  "کوئلہ"
 ],
 [
  "peat",
  "پیٹ"
 ],
 [
  "coke",
  "کوک"
 ],
 [
  "slag",
  "دھات کا میل"
 ],
 [
  "clinker",
  "کلنکر"
 ],
 [
  "cinder",
  "انگارہ"
 ],
 [
  "kindling",
  "ایندھن"
 ],
 [
  "tinder",
  "آتش گیر"
 ],
 [
  "propellant",
  "ایندھن"
 ],
 [
  "oxidizer",
  "تکسید کار"
 ],
 [
  "combustion",
  "احتراق"
 ],
 [
  "ignition",
  "اگنیشن"
 ],
 [
  "detonation",
  "دھماکہ"
 ],
 [
  "explosion",
  "دھماکہ"
 ],
 [
  "blast",
  "دھماکہ"
 ],
 [
  "shockwave",
  "جھٹکے کی لہر"
 ],
 [
  "fallout",
  "تابکاری گرد"
 ],
 [
  "radiation",
  "تابکاری"
 ],
 [
  "nuclear",
  "جوہری"
 ],
 [
  "atomic",
  "ایٹمی"
 ],
 [
  "fission",
  "انشقاق"
 ],
 [
  "fusion",
  "انضمام"
 ],
 [
  "reactor",
  "ری ایکٹر"
 ],
 [
  "rod",
  "سلاخ"
 ],
 [
  "moderator",
  "معتدل کار"
 ],
 [
  "coolant",
  "ٹھنڈا کرنے والا"
 ],
 [
  "containment",
  "احاطہ"
 ],
 [
  "meltdown",
  "پگھلاؤ"
 ],
 [
  "criticality",
  "نازک حالت"
 ],
 [
  "half-life",
  "نصف عمر"
 ],
 [
  "isotope",
  "ہم جاء"
 ],
 [
  "ion",
  "آئن"
 ],
 [
  "plasma",
  "پلازما"
 ],
 [
  "quark",
  "کوارک"
 ],
 [
  "lepton",
  "لیپٹان"
 ],
 [
  "boson",
  "بوسان"
 ],
 [
  "fermion",
  "فرمیان"
 ],
 [
  "hadron",
  "ہیڈران"
 ],
 [
  "meson",
  "میسان"
 ],
 [
  "baryon",
  "بیریان"
 ],
 [
  "photon",
  "فوٹان"
 ],
 [
  "gluon",
  "گلوآن"
 ],
 [
  "graviton",
  "گریویٹان"
 ],
 [
  "neutrino",
  "نیوٹرینو"
 ],
 [
  "antimatter",
  "ضد مادہ"
 ],
 [
  "darkmatter",
  "تاریک مادہ"
 ],
 [
  "darkenergy",
  "تاریک توانائی"
 ],
 [
  "blackhole",
  "سیاہ سوراخ"
 ],
 [
  "wormhole",
  "سرنگ"
 ],
 [
  "singularity",
  "وحدانیت"
 ],
 [
  "eventhorizon",
  "واقعہ افق"
 ],
 [
  "accretion",
  "جمع"
 ],
 [
  "pulsar",
  "پلسار"
 ],
 [
  "quasar",
  "کواسار"
 ],
 [
  "nebula",
  "سحابیہ"
 ],
 [
  "supernova",
  "سپر نووا"
 ],
 [
  "whitedwarf",
  "سفید بونا"
 ],
 [
  "redgiant",
  "سرخ دیو"
 ],
 [
  "neutronstar",
  "نیوٹران ستارہ"
 ],
 [
  "exoplanet",
  "بیرونی سیارہ"
 ],
 [
  "habitable",
  "قابل رہائش"
 ],
 [
  "terraform",
  "زمین جیسا بنانا"
 ],
 [
  "colonize",
  "آباد کرنا"
 ],
 [
  "pioneer",
  "پیش رو"
 ],
 [
  "explorer",
  "مہم جو"
 ],
 [
  "voyager",
  "مسافر"
 ],
 [
  "cosmonaut",
  "خلا باز"
 ],
 [
  "taikonaut",
  "خلا باز"
 ],
 [
  "liftoff",
  "اڑان"
 ],
 [
  "stage",
  "مرحلہ"
 ],
 [
  "booster",
  "بوسٹر"
 ],
 [
  "payload",
  "پے لوڈ"
 ],
 [
  "capsule",
  "کیپسول"
 ],
 [
  "module",
  "ماڈیول"
 ],
 [
  "shuttle",
  "شٹل"
 ],
 [
  "probe",
  "تحقیقات"
 ],
 [
  "rover",
  "روور"
 ],
 [
  "lander",
  "لینڈر"
 ],
 [
  "orbiter",
  "مدار گرد"
 ],
 [
  "flyby",
  "پاس سے گزرنا"
 ],
 [
  "rendezvous",
  "ملاقات"
 ],
 [
  "docking",
  "جوڑنا"
 ],
 [
  "EVA",
  "خلائی چہل قدمی"
 ],
 [
  "spacewalk",
  "خلائی چہل قدمی"
 ],
 [
  "airlock",
  "ہوائی تالا"
 ],
 [
  "suit",
  "لباس"
 ],
 [
  "helmet",
  "ہیلمٹ"
 ],
 [
  "visor",
  "نقاب"
 ],
 [
  "tether",
  "رسی"
 ],
 [
  "jetpack",
  "جیٹ پیک"
 ],
 [
  "thruster",
  "تھرسٹر"
 ],
 [
  "gyroscope",
  "جائروسکوپ"
 ],
 [
  "telemetry",
  "ٹیلی میٹری"
 ],
 [
  "tracking",
  "نگرانی"
 ],
 [
  "guidance",
  "رہنمائی"
 ],
 [
  "navigation",
  "نیویگیشن"
 ],
 [
  "autopilot",
  "خودکار پائلٹ"
 ],
 [
  "flybywire",
  "فلائی بائی وائر"
 ],
 [
  "avionics",
  "ایویونکس"
 ],
 [
  "cockpit",
  "کاک پٹ"
 ],
 [
  "fuselage",
  "بدن"
 ],
 [
  "aileron",
  "ایلران"
 ],
 [
  "elevator",
  "لفٹ"
 ],
 [
  "flap",
  "فلیپ"
 ],
 [
  "slat",
  "سلیٹ"
 ],
 [
  "spoiler",
  "اسپوائلر"
 ],
 [
  "landinggear",
  "لینڈنگ گیئر"
 ],
 [
  "tire",
  "ٹائر"
 ],
 [
  "parachute",
  "پیراشوٹ"
 ],
 [
  "ejection",
  "اخراج"
 ],
 [
  "seat",
  "نشست"
 ],
 [
  "harness",
  "بیلٹ"
 ],
 [
  "regulator",
  "ریگولیٹر"
 ],
 [
  "valve",
  "والو"
 ],
 [
  "pump",
  "پمپ"
 ],
 [
  "hose",
  "نلی"
 ],
 [
  "nozzle",
  "نوزل"
 ],
 [
  "filter",
  "فلٹر"
 ],
 [
  "strainer",
  "چھلنی"
 ],
 [
  "sieve",
  "چھلنی"
 ],
 [
  "funnel",
  "قیف"
 ],
 [
  "beaker",
  "بی کر"
 ],
 [
  "flask",
  "فلاسک"
 ],
 [
  "testtube",
  "ٹیسٹ ٹیوب"
 ],
 [
  "pipette",
  "پپیٹ"
 ],
 [
  "burette",
  "بیوریٹ"
 ],
 [
  "graduated",
  "درجہ بند"
 ],
 [
  "cylinder",
  "سلنڈر"
 ],
 [
  "petridish",
  "پیٹری ڈش"
 ],
 [
  "coverslip",
  "کور سلپ"
 ],
 [
  "lens",
  "عدسہ"
 ],
 [
  "eyepiece",
  "آئی پیس"
 ],
 [
  "focus",
  "فوکس"
 ],
 [
  "magnification",
  "بڑھاوا"
 ],
 [
  "resolution",
  "وضاحت"
 ],
 [
  "stain",
  "داغ"
 ],
 [
  "fixative",
  "فکسیٹو"
 ],
 [
  "mount",
  "لگانا"
 ],
 [
  "microtome",
  "مائیکروٹوم"
 ],
 [
  "centrifuge",
  "سینٹری فیوج"
 ],
 [
  "incubator",
  "انکیوبیٹر"
 ],
 [
  "autoclave",
  "آٹوکلیو"
 ],
 [
  "sterilize",
  "جراثیم سے پاک کرنا"
 ],
 [
  "disinfect",
  "جراثیم کش کرنا"
 ],
 [
  "antiseptic",
  "جراثیم کش"
 ],
 [
  "aseptic",
  "جراثیم سے پاک"
 ],
 [
  "medium",
  "میڈیم"
 ],
 [
  "agar",
  "اگر"
 ],
 [
  "broth",
  "شوربہ"
 ],
 [
  "inoculate",
  "ٹیکہ لگانا"
 ],
 [
  "incubate",
  "سینچنا"
 ],
 [
  "strain",
  "قسم"
 ],
 [
  "isolate",
  "الگ کرنا"
 ],
 [
  "extract",
  "نکالنا"
 ],
 [
  "distill",
  "کشید کرنا"
 ],
 [
  "crystallize",
  "بلور بنانا"
 ],
 [
  "precipitate",
  "تہ نشین کرنا"
 ],
 [
  "filtrate",
  "چھنا ہوا"
 ],
 [
  "residue",
  "باقیات"
 ],
 [
  "supernatant",
  "اوپری محلول"
 ],
 [
  "pellet",
  "گولی"
 ],
 [
  "lyse",
  "توڑنا"
 ],
 [
  "homogenize",
  "یکساں کرنا"
 ],
 [
  "sonicate",
  "سونیکیٹ کرنا"
 ],
 [
  "vortex",
  "بھنور"
 ],
 [
  "spin",
  "گھمانا"
 ],
 [
  "elute",
  "نکالنا"
 ],
 [
  "chromatography",
  "کرومیٹوگرافی"
 ],
 [
  "electrophoresis",
  "الیکٹروفورسس"
 ],
 [
  "spectroscopy",
  "طیف بینی"
 ],
 [
  "microscopy",
  "خوردبینی"
 ],
 [
  "calorimetry",
  "حرارت پیمائی"
 ],
 [
  "titration",
  "ٹائٹریشن"
 ],
 [
  "endpoint",
  "آخری نقطہ"
 ],
 [
  "indicator",
  "اشارہ"
 ],
 [
  "buffer",
  "بفر"
 ],
 [
  "pH",
  "پی ایچ"
 ],
 [
  "acidic",
  "تیزابی"
 ],
 [
  "molarity",
  "مولرٹی"
 ],
 [
  "molality",
  "مولیلٹی"
 ],
 [
  "normality",
  "نارملٹی"
 ],
 [
  "ppm",
  "پی پی ایم"
 ],
 [
  "dilution",
  "تخفیف"
 ],
 [
  "aliquot",
  "حصہ"
 ],
 [
  "sample",
  "نمونہ"
 ],
 [
  "specimen",
  "نمونہ"
 ],
 [
  "blank",
  "خالی"
 ],
 [
  "standard",
  "معیار"
 ],
 [
  "calibration",
  "پیمائش"
 ],
 [
  "accuracy",
  "درستگی"
 ],
 [
  "precision",
  "صحت"
 ],
 [
  "error",
  "غلطی"
 ],
 [
  "uncertainty",
  "غیر یقینی"
 ],
 [
  "tolerance",
  "برداشت"
 ],
 [
  "deviation",
  "انحراف"
 ],
 [
  "variance",
  "تغیر"
 ],
 [
  "mean",
  "اوسط"
 ],
 [
  "median",
  "وسطانیہ"
 ],
 [
  "mode",
  "بھاؤ"
 ],
 [
  "quartile",
  "چوتھائی"
 ],
 [
  "percentile",
  "فیصدی"
 ],
 [
  "histogram",
  "ہسٹوگرام"
 ],
 [
  "bar",
  "بار"
 ],
 [
  "pie",
  "پائی"
 ],
 [
  "line",
  "لکیر"
 ],
 [
  "scatter",
  "بکھرا ہوا"
 ],
 [
  "trend",
  "رجحان"
 ],
 [
  "correlation",
  "رابطہ"
 ],
 [
  "regression",
  "رجعت"
 ],
 [
  "slope",
  "ڈھال"
 ],
 [
  "intercept",
  "قطع"
 ],
 [
  "asymptote",
  "مجانب"
 ],
 [
  "derivative",
  "مشتق"
 ],
 [
  "integral",
  "تکامل"
 ],
 [
  "limit",
  "حد"
 ],
 [
  "continuity",
  "تسلسل"
 ],
 [
  "differentiable",
  "قابل تفریق"
 ],
 [
  "integrable",
  "قابل تکامل"
 ],
 [
  "series",
  "سلسلہ"
 ],
 [
  "sequence",
  "ترتیب"
 ],
 [
  "convergence",
  "ہم آہنگی"
 ],
 [
  "divergence",
  "انحراف"
 ],
 [
  "partial",
  "جزوی"
 ],
 [
  "total",
  "کل"
 ],
 [
  "sum",
  "جمع"
 ],
 [
  "product",
  "حاصل ضرب"
 ],
 [
  "quotient",
  "خارج قسمت"
 ],
 [
  "remainder",
  "باقی"
 ],
 [
  "divisor",
  "مقسم علیہ"
 ],
 [
  "factor",
  "عامل"
 ],
 [
  "multiple",
  "اضعاف"
 ],
 [
  "prime",
  "مفرد"
 ],
 [
  "composite",
  "مرکب"
 ],
 [
  "even",
  "جفت"
 ],
 [
  "odd",
  "طاق"
 ],
 [
  "integer",
  "صحیح عدد"
 ],
 [
  "rational",
  "ناطق"
 ],
 [
  "irrational",
  "غیر ناطق"
 ],
 [
  "real",
  "حقیقی"
 ],
 [
  "imaginary",
  "خیالی"
 ],
 [
  "conjugate",
  "مرافق"
 ],
 [
  "modulus",
  "مطلق قیمت"
 ],
 [
  "argument",
  "دلیل"
 ],
 [
  "polar",
  "قطبی"
 ],
 [
  "cartesian",
  "کارتیسی"
 ],
 [
  "vector",
  "سمت"
 ],
 [
  "scalar",
  "عددی"
 ],
 [
  "matrix",
  "میٹرکس"
 ],
 [
  "determinant",
  "دترمیننٹ"
 ],
 [
  "eigenvalue",
  "ذاتی قیمت"
 ],
 [
  "eigenvector",
  "ذاتی سمت"
 ],
 [
  "transpose",
  "منتقل"
 ],
 [
  "inverse",
  "معکوس"
 ],
 [
  "identity",
  "وحدانی"
 ],
 [
  "zero",
  "صفر"
 ],
 [
  "null",
  "خالی"
 ],
 [
  "singular",
  "واحد"
 ],
 [
  "nonsingular",
  "غیر واحد"
 ],
 [
  "rank",
  "درجہ"
 ],
 [
  "trace",
  "نشان"
 ],
 [
  "norm",
  "معیار"
 ],
 [
  "inner",
  "اندرونی"
 ],
 [
  "outer",
  "بیرونی"
 ],
 [
  "dot",
  "نقطی"
 ],
 [
  "projection",
  "تصویر"
 ],
 [
  "orthogonal",
  "عمودی"
 ],
 [
  "orthonormal",
  "معیاری عمودی"
 ],
 [
  "basis",
  "اساس"
 ],
 [
  "span",
  "پھیلاؤ"
 ],
 [
  "dimension",
  "بعد"
 ],
 [
  "subspace",
  "ذیلی فضا"
 ],
 [
  "linear",
  "خطی"
 ],
 [
  "nonlinear",
  "غیر خطی"
 ],
 [
  "affine",
  "افائن"
 ],
 [
  "convex",
  "محدب"
 ],
 [
  "concave",
  "مقعر"
 ],
 [
  "monotonic",
  "یک رخی"
 ],
 [
  "periodic",
  "دوری"
 ],
 [
  "bounded",
  "محدود"
 ],
 [
  "unbounded",
  "غیر محدود"
 ],
 [
  "continuous",
  "مسلسل"
 ],
 [
  "discrete",
  "مجرد"
 ],
 [
  "smooth",
  "ہموار"
 ],
 [
  "analytic",
  "تحلیلی"
 ],
 [
  "holomorphic",
  "ہولومورفک"
 ],
 [
  "harmonic",
  "ہم آہنگ"
 ],
 [
  "exponential",
  "نمایاں"
 ],
 [
  "logarithmic",
  "لوگارتھمی"
 ],
 [
  "trigonometric",
  "مثلثی"
 ],
 [
  "hyperbolic",
  "ہائپربولک"
 ],
 [
  "piecewise",
  "ٹکڑوں میں"
 ],
 [
  "step",
  "سیڑھی"
 ],
 [
  "sawtooth",
  "آری دانت"
 ],
 [
  "squarewave",
  "مربع لہر"
 ],
 [
  "sine",
  "سائن"
 ],
 [
  "cosine",
  "کوسائن"
 ],
 [
  "tangent",
  "ٹینجنٹ"
 ],
 [
  "secant",
  "c|قاطع"
 ],
 [
  "cosecant",
  "قاطع معکوس"
 ],
 [
  "cotangent",
  "ظل معکوس"
 ],
 [
  "arcsin",
  "معکوس سائن"
 ],
 [
  "arccos",
  "معکوس کوسائن"
 ],
 [
  "arctan",
  "معکوس ٹینجنٹ"
 ],
 [
  "radian",
  "ریڈین"
 ],
 [
  "gradian",
  "گریڈین"
 ],
 [
  "turn",
  "چکر"
 ],
 [
  "rotation",
  "گردش"
 ],
 [
  "reflection",
  "عکس"
 ],
 [
  "translation",
  "منتقلی"
 ],
 [
  "dilation",
  "پھیلاؤ"
 ],
 [
  "shear",
  "کतरن"
 ],
 [
  "spiral",
  "حلزونی"
 ],
 [
  "helix",
  "حلزون"
 ],
 [
  "torus",
  "ٹورس"
 ],
 [
  "sphere",
  "کرہ"
 ],
 [
  "ellipsoid",
  "بیضوی"
 ],
 [
  "paraboloid",
  "سہموی"
 ],
 [
  "hyperboloid",
  "ہائپربولائڈ"
 ],
 [
  "cone",
  "مخروط"
 ],
 [
  "prism",
  "منشور"
 ],
 [
  "pyramid",
  "ہرام"
 ],
 [
  "tetrahedron",
  "چار سطحی"
 ],
 [
  "octahedron",
  "آٹھ سطحی"
 ],
 [
  "dodecahedron",
  "بارہ سطحی"
 ],
 [
  "icosahedron",
  "بیس سطحی"
 ],
 [
  "polyhedron",
  "کثیر سطحی"
 ],
 [
  "polygon",
  "کثیر الاضلاع"
 ],
 [
  "quadrilateral",
  "چار ضلعی"
 ],
 [
  "pentagon",
  "پنج ضلعی"
 ],
 [
  "hexagon",
  "شش ضلعی"
 ],
 [
  "heptagon",
  "ہفت ضلعی"
 ],
 [
  "octagon",
  "آٹھ ضلعی"
 ],
 [
  "nonagon",
  "نو ضلعی"
 ],
 [
  "decagon",
  "دس ضلعی"
 ],
 [
  "ellipse",
  "بیضہ"
 ],
 [
  "parabola",
  "سہم"
 ],
 [
  "hyperbola",
  "ہائپربولا"
 ],
 [
  "directrix",
  "ہادی"
 ],
 [
  "eccentricity",
  "مرکزیت"
 ],
 [
  "chord",
  "وتر"
 ],
 [
  "arc",
  "قوس"
 ],
 [
  "segment",
  "قطعہ"
 ],
 [
  "normal",
  "عمود"
 ],
 [
  "diameter",
  "قطر"
 ],
 [
  "radius",
  "نصف قطر"
 ],
 [
  "circumference",
  "محیط"
 ],
 [
  "perimeter",
  "محیط"
 ],
 [
  "surface",
  "سطح"
 ],
 [
  "lateral",
  "پہلو"
 ],
 [
  "capacity",
  "گنجائش"
 ],
 [
  "displacement",
  "ہٹاؤ"
 ],
 [
  "buoyancy",
  "اچھال"
 ],
 [
  "archimedes",
  "ارشمیدس"
 ],
 [
  "pascal",
  "پاسکل"
 ],
 [
  "bernoulli",
  "برنولی"
 ],
 [
  "venturi",
  "وینچوری"
 ],
 [
  "pitot",
  "پٹوٹ"
 ],
 [
  "manometer",
  "مینومیٹر"
 ],
 [
  "anemometer",
  "ہوا پیما"
 ],
 [
  "hygrometer",
  "نمی پیما"
 ],
 [
  "pyrometer",
  "پائرومیٹر"
 ],
 [
  "calorimeter",
  "کیلوری میٹر"
 ],
 [
  "spectrometer",
  "سپیکٹرومیٹر"
 ],
 [
  "interferometer",
  "انٹرفیرومیٹر"
 ],
 [
  "polarimeter",
  "پولاریمیٹر"
 ],
 [
  "refractometer",
  "ریفریکٹومیٹر"
 ],
 [
  "tensiometer",
  "ٹینسیومیٹر"
 ],
 [
  "viscometer",
  "وسکومیٹر"
 ],
 [
  "rheometer",
  "ریومیٹر"
 ],
 [
  "dynamometer",
  "ڈائنامومیٹر"
 ],
 [
  "seismometer",
  "زلزلہ پیما"
 ],
 [
  "gravimeter",
  "کشش پیما"
 ],
 [
  "magnetometer",
  "مقناطیس پیما"
 ],
 [
  "electrometer",
  "برق پیما"
 ],
 [
  "galvanometer",
  "گیلوانومیٹر"
 ],
 [
  "ammeter",
  "ایمیٹر"
 ],
 [
  "voltmeter",
  "وولٹ میٹر"
 ],
 [
  "ohmmeter",
  "اوہم میٹر"
 ],
 [
  "wattmeter",
  "واٹ میٹر"
 ],
 [
  "oscilloscope",
  "آسیلوسکوپ"
 ],
 [
  "multimeter",
  "ملٹی میٹر"
 ],
 [
  "protoboard",
  "پروٹو بورڈ"
 ],
 [
  "breadboard",
  "بریڈ بورڈ"
 ],
 [
  "flux",
  "فلکس"
 ],
 [
  "desolder",
  "ٹانکا ہٹانا"
 ],
 [
  "rework",
  "دوبارہ کام"
 ],
 [
  "ESD",
  "ای ایس ڈی"
 ],
 [
  "ground",
  "زمین"
 ],
 [
  "live",
  "براہ راست"
 ],
 [
  "phase",
  "فیز"
 ],
 [
  "singlephase",
  "سنگل فیز"
 ],
 [
  "threephase",
  "تھری فیز"
 ],
 [
  "AC",
  "اے سی"
 ],
 [
  "DC",
  "ڈی سی"
 ],
 [
  "RMS",
  "آر ایم ایس"
 ],
 [
  "peaktopeak",
  "چوٹی سے چوٹی"
 ],
 [
  "average",
  "اوسط"
 ],
 [
  "formfactor",
  "شکل عامل"
 ],
 [
  "crestfactor",
  "چوٹی عامل"
 ],
 [
  "powerfactor",
  "پاور فیکٹر"
 ],
 [
  "watt",
  "واٹ"
 ],
 [
  "volt",
  "وولٹ"
 ],
 [
  "ampere",
  "ایمپئر"
 ],
 [
  "ohm",
  "اوہم"
 ],
 [
  "siemens",
  "سیمنز"
 ],
 [
  "farad",
  "فیراڈ"
 ],
 [
  "henry",
  "ہنری"
 ],
 [
  "weber",
  "ویبر"
 ],
 [
  "tesla",
  "ٹیسلا"
 ],
 [
  "gauss",
  "گاؤس"
 ],
 [
  "oersted",
  "اورسٹڈ"
 ],
 [
  "maxwell",
  "میکسویل"
 ],
 [
  "coulomb",
  "کولمب"
 ],
 [
  "joule",
  "جول"
 ],
 [
  "electronvolt",
  "الیکٹران وولٹ"
 ],
 [
  "calorie",
  "کیلوری"
 ],
 [
  "BTU",
  "بی ٹی یو"
 ],
 [
  "horsepower",
  "ہارس پاور"
 ],
 [
  "decibel",
  "ڈیسیبل"
 ],
 [
  "bel",
  "بیل"
 ],
 [
  "neper",
  "نیپر"
 ],
 [
  "octave",
  "آکٹیو"
 ],
 [
  "decade",
  "دہائی"
 ],
 [
  "phon",
  "s|فون"
 ],
 [
  "sone",
  "سون"
 ],
 [
  "mel",
  "میل"
 ],
 [
  "ERB",
  "ای آر بی"
 ],
 [
  "criticalband",
  "نازک پٹی"
 ],
 [
  "masking",
  "ماسکنگ"
 ],
 [
  "absolute",
  "مطلق"
 ],
 [
  "differential",
  "تفریقی"
 ],
 [
  "JND",
  "جے این ڈی"
 ],
 [
  "fechner",
  "فیشنر"
 ],
 [
  "stevens",
  "اسٹیونز"
 ],
 [
  "psychophysics",
  "نفسی طبیعیات"
 ],
 [
  "noise",
  "شور"
 ],
 [
  "SNR",
  "ایس این آر"
 ],
 [
  "distortion",
  "بگاڑ"
 ],
 [
  "clipping",
  "کلپنگ"
 ],
 [
  "saturation",
  "سیر شدگی"
 ],
 [
  "aliasing",
  "ایلیسنگ"
 ],
 [
  "quantization",
  "مقداریت"
 ],
 [
  "dither",
  "ڈتھر"
 ],
 [
  "jitter",
  "جٹر"
 ],
 [
  "wow",
  "واہ"
 ],
 [
  "flutter",
  "پھڑپھڑاہٹ"
 ],
 [
  "rumble",
  "گڑگڑاہٹ"
 ],
 [
  "hum",
  "بھنبھناہٹ"
 ],
 [
  "buzz",
  "بھنبھناہٹ"
 ],
 [
  "hiss",
  "سرسراہٹ"
 ],
 [
  "crackle",
  "چٹخناہٹ"
 ],
 [
  "pop",
  "پھٹنا"
 ],
 [
  "thump",
  "دھمک"
 ],
 [
  "boom",
  "دھماکہ"
 ],
 [
  "bang",
  "دھماکہ"
 ],
 [
  "smash",
  "توڑنا"
 ],
 [
  "shatter",
  "چکنا چور کرنا"
 ],
 [
  "splinter",
  "پھانس"
 ],
 [
  "fragment",
  "ٹکڑا"
 ],
 [
  "debris",
  "ملبہ"
 ],
 [
  "wreckage",
  "تباہ شدہ"
 ],
 [
  "ruin",
  "کھنڈر"
 ],
 [
  "remnant",
  "باقیات"
 ],
 [
  "relic",
  "یادگار"
 ],
 [
  "artifact",
  "نوادرات"
 ],
 [
  "fossil",
  "حفریہ"
 ],
 [
  "stratum",
  "تہہ"
 ],
 [
  "weathering",
  "موسمی کٹاؤ"
 ],
 [
  "deposition",
  "تہ نشینی"
 ],
 [
  "lithification",
  "پتھریلا ہونا"
 ],
 [
  "metamorphism",
  "استحالہ"
 ],
 [
  "igneous",
  "آتشی"
 ],
 [
  "sedimentary",
  "تہہ دار"
 ],
 [
  "metamorphic",
  "استحال شدہ"
 ],
 [
  "granite",
  "گرینائٹ"
 ],
 [
  "basalt",
  "بیسالٹ"
 ],
 [
  "obsidian",
  "آبسیڈین"
 ],
 [
  "pumice",
  "جھاگ پتھر"
 ],
 [
  "rhyolite",
  "رائولائٹ"
 ],
 [
  "andesite",
  "اینڈیسائٹ"
 ],
 [
  "diorite",
  "ڈائورائٹ"
 ],
 [
  "gabbro",
  "گیبرو"
 ],
 [
  "peridotite",
  "پیرڈوٹائٹ"
 ],
 [
  "sandstone",
  "ریت کا پتھر"
 ],
 [
  "shale",
  "شیل"
 ],
 [
  "limestone",
  "چونے کا پتھر"
 ],
 [
  "dolomite",
  "ڈولومائٹ"
 ],
 [
  "chalk",
  "چاک"
 ],
 [
  "chert",
  "چرٹ"
 ],
 [
  "conglomerate",
  "کنکریٹ"
 ],
 [
  "breccia",
  "بریشیا"
 ],
 [
  "arkose",
  "آرکوز"
 ],
 [
  "graywacke",
  "گری ویک"
 ],
 [
  "siltstone",
  "سلٹ اسٹون"
 ],
 [
  "mudstone",
  "مڈ اسٹون"
 ],
 [
  "claystone",
  "کلے اسٹون"
 ],
 [
  "evaporite",
  "بخارات"
 ],
 [
  "halite",
  "نمک"
 ],
 [
  "gypsum",
  "جپسم"
 ],
 [
  "anhydrite",
  "اینہائیڈرائٹ"
 ],
 [
  "slate",
  "سلیٹ"
 ],
 [
  "schist",
  "شسٹ"
 ],
 [
  "gneiss",
  "نیس"
 ],
 [
  "quartzite",
  "کوارٹزائٹ"
 ],
 [
  "hornfels",
  "ہارن فیلز"
 ],
 [
  "skarn",
  "اسکارن"
 ],
 [
  "mylonite",
  "مائلونائٹ"
 ],
 [
  "cataclasite",
  "کیٹاکلاسائٹ"
 ],
 [
  "pseudotachylyte",
  "سیوڈوٹیکائلائٹ"
 ],
 [
  "impactite",
  "امپیکٹائٹ"
 ],
 [
  "tektite",
  "ٹیکٹائٹ"
 ],
 [
  "meteorite",
  "شہابیہ"
 ],
 [
  "chondrite",
  "کونڈرائٹ"
 ],
 [
  "achondrite",
  "ایکونڈرائٹ"
 ],
 [
  "stonyiron",
  "پتھریلا لوہا"
 ],
 [
  "pallasite",
  "پیلاسائٹ"
 ],
 [
  "mesosiderite",
  "میسوسائیڈرائٹ"
 ],
 [
  "carbonaceous",
  "کاربنی"
 ],
 [
  "enstatite",
  "اینسٹیٹائٹ"
 ],
 [
  "ordinary",
  "عام"
 ],
 [
  "rumuruti",
  "رموروٹی"
 ],
 [
  "kakangari",
  "کانگاری"
 ],
 [
  "ureilite",
  "یوریلائٹ"
 ],
 [
  "aubrite",
  "آبرائٹ"
 ],
 [
  "angrite",
  "اینگرائٹ"
 ],
 [
  "brachinite",
  "بریشینائٹ"
 ],
 [
  "winonaite",
  "وینونائٹ"
 ],
 [
  "martian",
  "مریخی"
 ],
 [
  "howardite",
  "ہورڈائٹ"
 ],
 [
  "eucrite",
  "یوکرائٹ"
 ],
 [
  "diogenite",
  "ڈائوجینائٹ"
 ],
 [
  "shergottite",
  "شرگوٹائٹ"
 ],
 [
  "nakhlite",
  "نخلائٹ"
 ],
 [
  "chassignite",
  "چاسگنائٹ"
 ],
 [
  "ALH",
  "اے ایل ایچ 84001"
 ],
 [
  "tagishlake",
  "ٹیگش جھیل"
 ],
 [
  "murchison",
  "مرچیسن"
 ],
 [
  "allende",
  "ایلینڈے"
 ],
 [
  "orgueil",
  "آرگوئی"
 ],
 [
  "ivuna",
  "ایونا"
 ],
 [
  "CI",
  "سی آئی"
 ],
 [
  "CM",
  "سی ایم"
 ],
 [
  "CR",
  "سی آر"
 ],
 [
  "CH",
  "سی ایچ"
 ],
 [
  "CB",
  "سی بی"
 ],
 [
  "CK",
  "سی کے"
 ],
 [
  "CO",
  "سی او"
 ],
 [
  "CV",
  "سی وی"
 ],
 [
  "K",
  "کے"
 ],
 [
  "L",
  "L"
 ],
 [
  "LL",
  "ایل ایل"
 ],
 [
  "H",
  "ایچ"
 ],
 [
  "EH",
  "ای ایچ"
 ],
 [
  "EL",
  "ای ایل"
 ],
 [
  "R",
  "آر"
 ],
 [
  "F",
  "ایف"
 ],
 [
  "Acapulcoite",
  "اکاپولکوائٹ"
 ],
 [
  "Lodranite",
  "لوڈرانائٹ"
 ],
 [
  "IAB",
  "آئی اے بی"
 ],
 [
  "IIAB",
  "آئی آئی اے بی"
 ],
 [
  "IIC",
  "آئی آئی سی"
 ],
 [
  "IID",
  "آئی آئی ڈی"
 ],
 [
  "IIE",
  "آئی آئی ای"
 ],
 [
  "IIF",
  "آئی آئی ایف"
 ],
 [
  "IIG",
  "آئی آئی جی"
 ],
 [
  "IIIAB",
  "آئی آئی آئی اے بی"
 ],
 [
  "IIICD",
  "آئی آئی آئی سی ڈی"
 ],
 [
  "IIIE",
  "آئی آئی آئی ای"
 ],
 [
  "IIIF",
  "آئی آئی آئی ایف"
 ],
 [
  "IVA",
  "آئی وی اے"
 ],
 [
  "IVB",
  "آئی وی بی"
 ],
 [
  "ataxite",
  "ایٹیکسائٹ"
 ],
 [
  "hexahedrite",
  "ہیکساہیڈرائٹ"
 ],
 [
  "octahedrite",
  "آکٹاہیڈرائٹ"
 ],
 [
  "plessite",
  "پلیسائٹ"
 ],
 [
  "kamacite",
  "کاماسائٹ"
 ],
 [
  "taenite",
  "ٹینائٹ"
 ],
 [
  "tetrataenite",
  "ٹیٹراٹینائٹ"
 ],
 [
  "schreibersite",
  "شرائبرسائٹ"
 ],
 [
  "cohenite",
  "کوہنائٹ"
 ],
 [
  "troilite",
  "ٹرائلائٹ"
 ],
 [
  "daubreelite",
  "ڈابریلائٹ"
 ],
 [
  "oldhamite",
  "اولڈہامائٹ"
 ],
 [
  "niningerite",
  "نننجرائٹ"
 ],
 [
  "alabandite",
  "الابنڈائٹ"
 ],
 [
  "sphalerite",
  "اسفیلرائٹ"
 ],
 [
  "wurtzite",
  "ورٹزائٹ"
 ],
 [
  "galena",
  "گیلینا"
 ],
 [
  "pyrite",
  "پائرائٹ"
 ],
 [
  "marcasite",
  "مارکاسائٹ"
 ],
 [
  "pyrrhotite",
  "پائرہوٹائٹ"
 ],
 [
  "chalcopyrite",
  "چالکوپائرائٹ"
 ],
 [
  "bornite",
  "بورنائٹ"
 ],
 [
  "covellite",
  "کوویلائٹ"
 ],
 [
  "chalcocite",
  "چالکوسائٹ"
 ],
 [
  "digenite",
  "ڈائجینائٹ"
 ],
 [
  "anilite",
  "اینلائٹ"
 ],
 [
  "djurleite",
  "جرلائٹ"
 ],
 [
  "geerite",
  "جیرائٹ"
 ],
 [
  "spionkopite",
  "اسپائنکوپائٹ"
 ],
 [
  "yarrowite",
  "یاروائٹ"
 ],
 [
  "blaubleibend",
  "بلاؤبلائبنڈ"
 ],
 [
  "covelline",
  "کوویلین"
 ],
 [
  "klockmannite",
  "کلوکمینائٹ"
 ],
 [
  "clausthalite",
  "کلاستھالائٹ"
 ],
 [
  "altaite",
  "الٹائٹ"
 ],
 [
  "telluride",
  "ٹیلورائڈ"
 ],
 [
  "sylvanite",
  "سلوانائٹ"
 ],
 [
  "krennerite",
  "کرینرائٹ"
 ],
 [
  "calaverite",
  "کیلاویرائٹ"
 ],
 [
  "nagyagite",
  "ناگیاجائٹ"
 ],
 [
  "petzite",
  "پیٹزائٹ"
 ],
 [
  "hessite",
  "ہیسائٹ"
 ],
 [
  "stuetzite",
  "اسٹیوٹزائٹ"
 ],
 [
  "empressite",
  "ایمپریسائٹ"
 ],
 [
  "rickardite",
  "رکارڈائٹ"
 ],
 [
  "weissite",
  "ویسائٹ"
 ],
 [
  "vulcanite",
  "ولکینائٹ"
 ],
 [
  "montbrayite",
  "مونٹبریائٹ"
 ],
 [
  "molybdenite",
  "مولبڈینائٹ"
 ],
 [
  "tungstenite",
  "ٹنگسٹینائٹ"
 ],
 [
  "drysdallite",
  "ڈرائسڈالائٹ"
 ],
 [
  "joridisite",
  "جوریڈیسائٹ"
 ],
 [
  "merenskyite",
  "مرنسکائٹ"
 ],
 [
  "michenerite",
  "مچینرائٹ"
 ],
 [
  "moncheite",
  "مونکائٹ"
 ],
 [
  "kotulskite",
  "کوٹلسکائٹ"
 ],
 [
  "sobolevskite",
  "سوبولیوسکائٹ"
 ],
 [
  "sudburyite",
  "سڈبریائٹ"
 ],
 [
  "temagamite",
  "ٹیماگامائٹ"
 ],
 [
  "testibiunite",
  "ٹیسٹیبیونائٹ"
 ],
 [
  "palladoarsenide",
  "پیلیڈوآرسینائڈ"
 ],
 [
  "palladobismutharsenide",
  "پیلیڈوبسمتھآرسینائڈ"
 ],
 [
  "palladodymite",
  "پیلیڈوڈائمائٹ"
 ],
 [
  "palarstanide",
  "پیلرسٹینائڈ"
 ],
 [
  "polarite",
  "پولارائٹ"
 ],
 [
  "froodite",
  "فرودائٹ"
 ],
 [
  "insizwaite",
  "انسزوائٹ"
 ],
 [
  "niggliite",
  "نگلائٹ"
 ],
 [
  "tulameenite",
  "ٹولامائنائٹ"
 ],
 [
  "ferronickelplatinum",
  "فیرونکلپلاٹینم"
 ],
 [
  "tetraferroplatinum",
  "ٹیٹرافیروپلاٹینم"
 ],
 [
  "isoferroplatinum",
  "آئسوفیروپلاٹینم"
 ],
 [
  "rustenburgite",
  "رسٹنبرگائٹ"
 ],
 [
  "atelestite",
  "ایٹیلیسٹائٹ"
 ],
 [
  "braggite",
  "بریگائٹ"
 ],
 [
  "cooperite",
  "کوپرائٹ"
 ],
 [
  "vysotskite",
  "ویسوٹسکائٹ"
 ],
 [
  "laurite",
  "لورائٹ"
 ],
 [
  "erlichmanite",
  "ارلکمینائٹ"
 ],
 [
  "osarsite",
  "اوسارسائٹ"
 ],
 [
  "ruarsite",
  "روارسائٹ"
 ],
 [
  "irarsite",
  "ائرارسائٹ"
 ],
 [
  "hollingworthite",
  "ہالنگورتھائٹ"
 ],
 [
  "platarsite",
  "پلاٹارسائٹ"
 ],
 [
  "sperrylite",
  "اسپیرلائٹ"
 ],
 [
  "stillwaterite",
  "اسٹل واٹرائٹ"
 ]
]
GRAMMAR = {
 "English": [
  {
   "title": "\"Tenses (12)\"",
   "body": "",
   "icon": "e1"
  },
  {
   "title": "\"Active / Passive Voice\"",
   "body": "",
   "icon": "e2"
  },
  {
   "title": "\"Direct / Indirect Speech\"",
   "body": "",
   "icon": "e3"
  },
  {
   "title": "\"Parts of Speech (8)\"",
   "body": "",
   "icon": "e4"
  },
  {
   "title": "\"Articles (a / an / the)\"",
   "body": "",
   "icon": "e5"
  },
  {
   "title": "\"Prepositions\"",
   "body": "",
   "icon": "e6"
  },
  {
   "title": "\"Common Errors (10)\"",
   "body": "",
   "icon": "e7"
  }
 ],
 "Urdu": [
  {
   "title": "\"اسم کی اقسام\"",
   "body": "",
   "icon": "s1"
  },
  {
   "title": "\"فعل کی اقسام\"",
   "body": "",
   "icon": "s2"
  },
  {
   "title": "\"حرف\"",
   "body": "",
   "icon": "s3"
  },
  {
   "title": "\"جملے کی اقسام\"",
   "body": "",
   "icon": "s4"
  },
  {
   "title": "\"مذکر مونث\"",
   "body": "",
   "icon": "s5"
  },
  {
   "title": "\"واحد جمع\"",
   "body": "",
   "icon": "s6"
  },
  {
   "title": "\"متضاد الفاظ (20)\"",
   "body": "",
   "icon": "s7"
  },
  {
   "title": "\"مترادف الفاظ (15)\"",
   "body": "",
   "icon": "s8"
  },
  {
   "title": "\"محاورات (15)\"",
   "body": "",
   "icon": "s9"
  },
  {
   "title": "\"ضرب الامثال (10)\"",
   "body": "",
   "icon": "s10"
  }
 ],
 "Guide": [
  {
   "title": "Tenses Overview",
   "body": "The 12 English tenses = 3 times (Present, Past, Future) x 4 aspects (Simple, Continuous, Perfect, Perfect Continuous).\nPresent Simple: Subject + base verb (he/she/it + s/es) -- I play, He plays.\nPresent Continuous: am/is/are + verb-ing -- I am playing.\nPresent Perfect: have/has + past participle -- I have played.\nPresent Perfect Continuous: have/has been + verb-ing -- I have been playing.\nPast Simple: 2nd form of verb -- I played.\nPast Continuous: was/were + verb-ing -- I was playing.\nPast Perfect: had + past participle -- I had played.\nPast Perfect Continuous: had been + verb-ing -- I had been playing.\nFuture Simple: will + base verb -- I will play.\nFuture Continuous: will be + verb-ing -- I will be playing.\nFuture Perfect: will have + past participle -- I will have played.\nFuture Perfect Continuous: will have been + verb-ing -- I will have been playing.",
   "icon": "📖"
  },
  {
   "title": "Present Simple",
   "body": "Structure: Subject + verb (add s/es with he, she, it and singular nouns).\nUses: habits and routines (I wake up at 6), universal truths (The sun rises in the east), timetables (The train leaves at 9), feelings and opinions (I like tea).\nNegative: do/does + not + base verb -- He does not play.\nQuestion: Do/Does + subject + base verb? -- Does he play?\nSignal words: always, usually, often, sometimes, never, every day.",
   "icon": "📖"
  },
  {
   "title": "Present Continuous",
   "body": "Structure: am/is/are + verb-ing.\nUses: actions happening now (I am writing), temporary situations (She is staying with us this week), planned future (We are leaving tomorrow), changing situations (Prices are rising).\nNegative: am/is/are + not + verb-ing.\nQuestion: Am/Is/Are + subject + verb-ing?\nSignal words: now, at the moment, currently, Look!, Listen!\nNote: stative verbs (know, like, want, believe, own) are NOT used in continuous tenses.",
   "icon": "📖"
  },
  {
   "title": "Present Perfect",
   "body": "Structure: have/has + past participle (3rd form).\nUses: finished actions with a present result (I have lost my keys -- they are still lost), life experiences (She has visited Lahore), actions that started in the past and continue now (We have lived here since 2010).\nNegative: have/has + not + past participle.\nQuestion: Have/Has + subject + past participle?\nSignal words: just, already, yet, ever, never, since, for, so far.\nSince = starting point (since Monday); For = duration (for two days).",
   "icon": "📖"
  },
  {
   "title": "Past Simple",
   "body": "Structure: Subject + 2nd form of verb.\nUses: finished past actions (I met him yesterday), past habits (We played cricket daily), historical facts (Quaid-e-Azam was born in 1876).\nNegative: did + not + base verb -- He did not come.\nQuestion: Did + subject + base verb? -- Did he come?\nSignal words: yesterday, last night/week/year, in 2010, ago.\nRegular verbs add -ed; learn common irregular verbs (go-went-gone, eat-ate-eaten, write-wrote-written).",
   "icon": "📖"
  },
  {
   "title": "Past Continuous",
   "body": "Structure: was/were + verb-ing.\nUses: action in progress at a past moment (I was sleeping at 10 pm), an interrupted past action (I was cooking when he arrived), two parallel past actions (While I was reading, she was writing).\nNegative: was/were + not + verb-ing.\nQuestion: Was/Were + subject + verb-ing?\nSignal words: while, when, at that time, all day yesterday.",
   "icon": "📖"
  },
  {
   "title": "Past Perfect",
   "body": "Structure: had + past participle.\nUses: the EARLIER of two past actions (When I reached the station, the train had left), reported past (She said she had finished her work).\nThe later action stays in Past Simple.\nNegative: had + not + past participle.\nQuestion: Had + subject + past participle?\nSignal words: before, after, already, by the time, when.",
   "icon": "📖"
  },
  {
   "title": "Future Simple and Going To",
   "body": "Future Simple: will + base verb. Uses: instant decisions (I will help you), promises (I will call you), predictions without evidence (It will rain tomorrow).\nGoing to: am/is/are + going to + base verb. Uses: plans (I am going to study medicine), predictions WITH evidence (Look at the clouds -- it is going to rain).\nNegative: will not (won't) + base verb.\nQuestion: Will + subject + base verb?\nSignal words: tomorrow, next week, soon, in 2030.",
   "icon": "📖"
  },
  {
   "title": "Active and Passive Voice",
   "body": "Active: Subject + Verb + Object -- The boy kicked the ball.\nPassive: Object + be + past participle (+ by subject) -- The ball was kicked by the boy.\nPresent Simple: is/am/are + 3rd form -- English is spoken here.\nPast Simple: was/were + 3rd form -- The work was done yesterday.\nFuture Simple: will be + 3rd form -- The prize will be given tomorrow.\nPresent Continuous: is/am/are + being + 3rd form -- The road is being repaired.\nPast Continuous: was/were + being + 3rd form -- The road was being repaired.\nPresent Perfect: have/has + been + 3rd form -- The task has been completed.\nRules: only transitive verbs (verbs with objects) change voice; the 'by' phrase is often dropped; interrogative and imperative sentences follow the same tense pattern.",
   "icon": "📖"
  },
  {
   "title": "Direct and Indirect Speech",
   "body": "Direct: He said, 'I am tired.'  Indirect: He said that he was tired.\nReporting verb: said becomes told when an object follows (He told me that...).\nTense backshift: Present Simple -> Past Simple; Present Continuous -> Past Continuous; Present Perfect -> Past Perfect; Past Simple -> Past Perfect; will -> would; can -> could; may -> might.\nPronouns change: I -> he/she, my -> his/her, we -> they.\nTime/place words: now -> then, today -> that day, yesterday -> the previous day, tomorrow -> the next day, here -> there, this -> that.\nNo backshift for universal truths: He said that the sun rises in the east.\nQuestions: said -> asked; use if/whether for yes-no questions; keep the WH-word for WH-questions; the question becomes statement word order.\nCommands: said -> ordered/requested/advised + to-infinitive: He said, 'Open the door.' -> He ordered me to open the door.",
   "icon": "📖"
  },
  {
   "title": "Articles (A, An, The)",
   "body": "A: first mention of a singular countable noun with a consonant SOUND -- a book, a university (u sounds like 'you'), a one-rupee note.\nAn: vowel SOUND -- an apple, an hour (h is silent), an honest man, an M.A.\nThe: specific or already known nouns (the book on the table), unique things (the sun, the Holy Quran), superlatives (the best boy), rivers and seas (the Indus, the Arabian Sea), country names with plural or 'united' (the USA, the Philippines).\nNo article: plural nouns in general (Books are useful), meals (dinner is ready), languages (She speaks Urdu), most proper names, abstract nouns in a general sense (Honesty is the best policy).\nTrick: sound matters, not spelling -- a European, an heir, a useful book, an umbrella.",
   "icon": "📖"
  },
  {
   "title": "Prepositions",
   "body": "Time: at (exact time -- at 5 o'clock, at night, at noon), on (days and dates -- on Monday, on 14th August), in (longer periods -- in 2026, in winter, in the morning).\nPlace: at (a point -- at the station, at home), on (a surface -- on the table, on the wall), in (enclosed space -- in the room, in Pakistan, in the box).\nCommon fixed pairs: afraid of, interested in, good at, angry with (a person) / angry at (a thing), married to, depend on, believe in, listen to, wait for, look at / look after / look for, consist of, die of (disease) / die from (cause), different from, senior to, prefer tea to coffee.\nBetween = two things; among = more than two.\nNo preposition: before 'home' with go/come (go home), and before yesterday, tomorrow, last, next.",
   "icon": "📖"
  },
  {
   "title": "Subject-Verb Agreement",
   "body": "Singular subject -> singular verb (He plays); plural subject -> plural verb (They play).\nEach, every, everyone, nobody, either, neither take SINGULAR verbs: Everyone is ready. Neither of the boys was late.\nSubjects joined by 'and' take a plural verb (Ali and Ahmed are friends) -- except one single idea: Bread and butter is my breakfast.\nWith or/nor, the verb agrees with the NEARER subject: Neither the teacher nor the students were present.\nCollective nouns: singular for one unit (The team is winning), plural for individuals (The team are arguing among themselves).\n'One of the boys is absent' -- the verb agrees with 'one', not 'boys'.\nUncountable nouns take singular verbs: Water is precious. The news is shocking.",
   "icon": "📖"
  },
  {
   "title": "Conditionals",
   "body": "Zero Conditional: If + Present Simple, Present Simple -- facts and truths: If you heat ice, it melts.\nFirst Conditional: If + Present Simple, will + base verb -- real future possibility: If it rains, we will stay at home.\nSecond Conditional: If + Past Simple, would + base verb -- unreal present: If I were rich, I would help the poor. (Use 'were' for all subjects.)\nThird Conditional: If + Past Perfect, would have + past participle -- unreal past: If you had studied hard, you would have passed.\nUnless = if not: Unless you hurry, you will miss the bus.\nMixed conditional: If + Past Perfect, would + base verb (past condition, present result): If you had slept well, you would feel fresh now.",
   "icon": "📖"
  },
  {
   "title": "Modal Verbs",
   "body": "Can: ability or permission (She can swim. You can go now.) Could: past ability or polite request (He could run fast. Could you help me?).\nMay: permission or possibility (May I come in? It may rain today.) Might: weaker possibility (It might rain).\nMust: strong obligation (You must wear a helmet); mustn't = prohibition (You mustn't smoke here).\nHave to: external obligation (I have to reach school by 8). Should: advice (You should take rest).\nWould: polite request or past habit (Would you open the door? When I was young, I would play daily).\nShall: offers and suggestions with I/we (Shall I open the window?).\nNeedn't: no necessity (You needn't hurry). Dare: challenge (How dare you touch my bag!).\nRule: modals are always followed by the BASE verb, never by to + verb.",
   "icon": "📖"
  },
  {
   "title": "Parts of Speech Overview",
   "body": "The 8 parts of speech:\n1. Noun -- names a person, place, thing or idea (Ali, Lahore, book, honesty).\n2. Pronoun -- replaces a noun (he, she, it, they).\n3. Verb -- action or state (run, is, have).\n4. Adjective -- describes a noun (tall boy, red car).\n5. Adverb -- describes a verb, adjective or adverb (runs fast, very tall).\n6. Preposition -- shows relation (in, on, under, between).\n7. Conjunction -- joins words or clauses (and, but, because).\n8. Interjection -- sudden feeling (Oh!, Alas!, Hurrah!, Bravo!).\nNote: the same word can be different parts of speech -- 'book' is a noun but 'book a ticket' is a verb; 'fast' is both adjective and adverb.",
   "icon": "📖"
  },
  {
   "title": "Nouns: Types and Number",
   "body": "Types: Proper (Ali, Pakistan -- capital letter), Common (boy, city), Collective (team, army, family), Material (gold, water, rice), Abstract (honesty, beauty, courage).\nCountable vs Uncountable: books and chairs are countable; water, rice, advice, furniture, information, news are uncountable -- no plural, no a/an (not 'informations').\nPlural rules: add -s (book-books); words ending in s/sh/ch/x/o take -es (box-boxes, mango-mangoes); consonant + y becomes -ies (city-cities, baby-babies); f/fe becomes -ves (wife-wives, knife-knives); irregular (man-men, woman-women, child-children, tooth-teeth, foot-feet, mouse-mice).\nPossessive: singular boy's book; plural boys' hostel; irregular children's park.",
   "icon": "📖"
  },
  {
   "title": "Pronouns",
   "body": "Personal: I, we, you, he, she, it, they (subject); me, us, you, him, her, it, them (object); my, our, your, his, her, its, their (possessive adjectives); mine, ours, yours, his, hers, theirs (possessive pronouns -- no apostrophe).\nReflexive: myself, yourself, himself, herself, itself, ourselves, yourselves, themselves -- The boy hurt himself. Do it yourself.\nDemonstrative: this, that (singular); these, those (plural) -- This is my pen; those are yours.\nInterrogative: who, whom, whose, which, what -- Whose bag is this?\nRelative: who (person), which (thing), that (both), whose (possession) -- The boy who won the prize is my friend.\nIndefinite: someone, anyone, nobody, each, either, neither, all, some, many.",
   "icon": "📖"
  },
  {
   "title": "Adjectives and Degrees",
   "body": "Positive: tall. Comparative: taller (than). Superlative: tallest (the +).\nOne-syllable: add -er/-est (small-smaller-smallest); ending in y becomes -ier (happy-happier-happiest); double the final consonant (big-bigger-biggest).\nLong adjectives: more/most (beautiful -- more beautiful -- most beautiful; interesting -- most interesting).\nIrregular: good-better-best, bad-worse-worst, much/many-more-most, little-less-least, far-farther-farthest.\nOrder of adjectives: opinion, size, age, colour, origin, material -- a beautiful small old red Pakistani wooden box.\nComparative pattern: The higher you go, the colder it gets.\nNever double the comparative: say 'taller' or 'much taller', never 'more taller'.",
   "icon": "📖"
  },
  {
   "title": "Adverbs",
   "body": "Types: manner (slowly, well, carefully), time (now, yesterday, soon), place (here, there, everywhere), frequency (always, never, often), degree (very, too, quite, almost).\nFormation: adjective + -ly (slow-slowly); -y becomes -ily (happy-happily); irregular (good-well, fast-fast, hard-hard, late-late).\nPosition: manner adverbs go after the verb (She sings sweetly); frequency adverbs go before the main verb but after 'be' (He always comes late; She is always late).\nToo vs Very: too = more than enough, negative sense (It is too hot to touch); very = simply much (It is very hot today).\nEnough comes AFTER the adjective: tall enough, old enough (not 'enough tall').",
   "icon": "📖"
  },
  {
   "title": "Conjunctions",
   "body": "Coordinating (FANBOYS): for, and, nor, but, or, yet, so -- join equal parts: I like tea and coffee. He is rich but unhappy.\nSubordinating: because, although, if, when, while, since, unless, until, as, though -- join a dependent clause: Although he was tired, he kept working.\nCorrelative pairs: either...or, neither...nor, both...and, not only...but also -- Either Ali or Ahmed will come. She is not only intelligent but also hardworking.\nWith neither...nor, the verb agrees with the nearer subject.\nSentence connectors: however, therefore, moreover, furthermore, nevertheless, consequently -- used between sentences with correct punctuation.",
   "icon": "📖"
  },
  {
   "title": "Phrases and Clauses",
   "body": "Phrase: a group of words WITHOUT a subject + verb -- in the morning, very tall, under the table.\nClause: a group of words WITH a subject + verb.\nIndependent clause: complete sense on its own -- She laughed.\nDependent clause: incomplete sense -- because she was happy.\nBy function: Noun clause (What he said is true), Adjective clause (The book that I bought is lost), Adverb clause (We stayed inside because it rained).\nBy structure: Simple sentence = one independent clause; Compound = two independent clauses joined by a conjunction; Complex = one independent + one or more dependent clauses.",
   "icon": "📖"
  },
  {
   "title": "Sentence Types",
   "body": "By structure: Simple (one clause -- Birds fly), Compound (two clauses -- I tried hard, but he kept sleeping), Complex (main + subordinate -- I slept after he had left).\nBy purpose:\nAssertive/Declarative: statement -- She is a kind girl.\nInterrogative: question -- Is she a kind girl?\nImperative: command or request -- Be kind. / Please sit down.\nExclamatory: strong feeling -- How kind she is! / What a kind girl she is!\nOptative: wish or prayer -- May you live long! / Would that I were rich!\nChanging forms: Assertive to Interrogative (add do/does/did + question mark); Affirmative to Negative (add not with the helping verb); Exclamatory to Assertive (What a + noun becomes 'very' + adjective).",
   "icon": "📖"
  },
  {
   "title": "Question Tags",
   "body": "Structure: statement + comma + short question.\nPositive statement -> negative tag: You are tired, aren't you?\nNegative statement -> positive tag: He didn't come, did he?\nThe tag uses the SAME helping verb and a pronoun: She can swim, can't she? They have left, haven't they?\nNo helping verb in the statement -> use do/does/did: He plays well, doesn't he? They went home, didn't they?\n'I am' takes 'aren't I': I am late, aren't I?\nImperative -> will you: Open the door, will you? Don't be late, will you?\n'Let's' -> shall we: Let's go for a walk, shall we?\nIntonation: falling tone checks information; rising tone asks a real question.",
   "icon": "📖"
  },
  {
   "title": "Gerunds and Infinitives",
   "body": "Gerund = verb-ing used as a NOUN: Swimming is good for health. I enjoy reading novels.\nInfinitive = to + base verb: I want to learn Arabic. To err is human.\nVerbs followed by gerund only: enjoy, avoid, finish, mind, practise, suggest, admit, deny, keep, miss -- She finished writing.\nVerbs followed by infinitive only: want, decide, promise, agree, hope, learn, plan, refuse, ask, offer -- He promised to help.\nBoth possible with a change of meaning: 'remember doing' = past memory (I remember meeting him); 'remember to do' = future duty (Remember to post the letter). 'Stop smoking' = quit the habit; 'stop to smoke' = pause in order to smoke.\nAfter any preposition, use the gerund: interested in learning, good at playing, afraid of falling.",
   "icon": "📖"
  },
  {
   "title": "Punctuation Rules",
   "body": "Full stop (.) ends a statement. Question mark (?) ends a direct question. Exclamation mark (!) shows strong feeling -- use only one.\nComma (,): in lists (apples, bananas and grapes), after introductory words (However, we stayed), around extra information (My brother, who is a doctor, lives in Karachi).\nApostrophe ('): possession (Ali's book, girls' hostel, children's park) and contractions (don't = do not, it's = it is, who's = who is).\nColon (:): introduces a list or explanation -- Bring these: a pen, a book and a bag.\nSemicolon (;): joins two related independent clauses -- He worked hard; he passed.\nQuotation marks: for direct speech -- He said, 'I am busy today.'\nCapitals: start of a sentence, proper nouns, days and months, the word 'I', titles (Mr., Dr.), first word inside quotation marks.",
   "icon": "📖"
  },
  {
   "title": "Common Exam Errors",
   "body": "'informations / furnitures' -- WRONG: information, furniture, advice, news are uncountable and have no plural.\n'I have visited Murree last year' -- WRONG: with a finished time use Past Simple -- I visited Murree last year.\n'He is more taller than me' -- WRONG: double comparative; say 'taller than me' or 'much taller than me'.\n'Discuss about the topic' -- WRONG: discuss is transitive -- discuss the topic.\n'Return back / repeat again' -- WRONG: repetition; say return, repeat.\n'According to me' -- weak English; say 'In my opinion'.\n'He gave the exam' -- WRONG: He took the exam / He appeared in the exam.\n'good in English' -- WRONG: good AT English; weak IN English.\n'My all friends' -- WRONG: All my friends.\n'Despite of rain' -- WRONG: despite the rain / in spite of the rain.",
   "icon": "📖"
  },
  {
   "title": "Essay Writing Rules",
   "body": "Structure: Introduction (define the topic, give your thesis), Body (3-4 paragraphs, one main idea each), Conclusion (summary + your personal view).\nEach paragraph: topic sentence, explanation, example, linking sentence.\nUse connectives: firstly, moreover, however, therefore, in conclusion, on the other hand.\nVary sentence length; avoid repeating the same word -- use synonyms.\nStrengthen with examples from Pakistan: quotes of Quaid-e-Azam and Allama Iqbal suit many topics.\nBoard word limits: about 200-250 words for class 10, 300-400 for class 12.\nNeat handwriting, leave a margin, underline key quotations, avoid cutting and overwriting.\nCommon board topics: My Aim in Life, Science and Technology, A Cricket Match, My Best Friend, Importance of Education, My Hobby.",
   "icon": "📖"
  },
  {
   "title": "Letter and Application Format",
   "body": "Application format for board exams:\n1. Sender's address (top left)  2. Date (below the address)  3. Receiver's designation and address  4. Subject line  5. Salutation (Respected Sir,)  6. Body in 3 short paragraphs -- purpose, details, request  7. Closing (Yours obediently,)  8. Name, class and roll number.\nKeep it brief and formal; one paragraph = one idea; no spelling mistakes in the subject line.\nLetter to a friend: address and date at top right, salutation (Dear Ahmed,), warm friendly tone, end with 'Your loving friend' + name.\nFor leave applications mention exact dates and the reason clearly.",
   "icon": "📖"
  },
  {
   "title": "Story Writing Tips",
   "body": "Read the given outline, proverb or idiom carefully and build the whole story around it.\nGive the story a title and underline it.\nWrite in Past Simple tense; keep the sequence logical: beginning -> problem -> climax -> solution.\nAdd one or two short dialogues to make it lively; keep the story 150-200 words.\nWrite the MORAL on a separate line at the end: MORAL: ...\nFamous morals: Greed is a curse; Honesty is the best policy; Slow and steady wins the race; Union is strength; Pride hath a fall; A friend in need is a friend indeed.\nDo not mix tenses and do not add irrelevant events.",
   "icon": "📖"
  },
  {
   "title": "Comprehension Solving Tips",
   "body": "Read the passage TWICE before looking at the questions; underline key lines as you read.\nAnswer in YOUR OWN words -- copying whole lines from the passage loses marks.\nFor vocabulary questions, first guess the meaning from the context, then confirm.\nKeep answers short and to the point; quote from the passage only when the question asks for it.\nFor title or summary questions: catch the central idea -- a title is 5-8 words.\nAttempt every question -- never leave a blank; if short of time, write a brief answer.\nManage time: about 20 minutes for one comprehension in board exams.",
   "icon": "📖"
  },
  {
   "title": "Ism (اسم)",
   "body": "اسم: وہ کلمہ جو کسی شخص، جگہ، چیز یا تصور کا نام ہو۔ مثلاً: احمد، کراچی، قلم، محبت۔\nاقسام: (1) اسمِ معرفہ -- خاص نام (علامہ اقبال، پاکستان) (2) اسمِ نکرہ -- عام نام (شہر، لڑکا) (3) اسمِ جمع -- گروہ کا نام (فوج، قافلہ) (4) اسمِ مادہ -- دھات یا مائع (سونا، دودھ) (5) اسمِ کیفیت -- خوبی یا حالت (بہادری، غربت)۔\nجملے میں اسم فاعل بنتا ہے (لڑکا دوڑا)، مفعول بنتا ہے (لڑکے نے گیند پکڑی) یا مسند الیہ بنتا ہے۔\nاسم کی پہچان: جس کلمے سے پہلے 'یہ/وہ' لگ سکے وہ عموماً اسم ہوتا ہے۔",
   "icon": "📖"
  },
  {
   "title": "Fail (فعل)",
   "body": "فعل: وہ کلمہ جس سے کسی کام کا کرنا یا ہونا معلوم ہو اور اس میں زمانہ پایا جائے۔ مثلاً: کھایا، کھاتا ہے، کھائے گا۔\nفعلِ ماضی: گزرا ہوا کام -- اس نے سبق پڑھا۔\nفعلِ حال: موجودہ زمانے کا کام -- وہ سبق پڑھتا ہے۔\nفعلِ مستقبل: آنے والے زمانے کا کام -- وہ سبق پڑھے گا۔\nفعلِ لازم: جسے مفعول کی ضرورت نہ ہو -- بچہ سویا۔\nفعلِ متعدی: جسے مفعول چاہیے -- بچے نے دودھ پیا۔\nامر: حکم دینا -- بیٹھو۔ نہی: منع کرنا -- شور مت کرو۔",
   "icon": "📖"
  },
  {
   "title": "Sifat (صفت)",
   "body": "صفت: وہ کلمہ جو اسم کی خوبی، خامی، تعداد یا حالت بیان کرے۔ مثلاً: اچھا لڑکا، تین کتابیں، لال پھول۔\nاقسام: صفتِ ذاتی (لمبا، چھوٹا)، صفتِ عددی (دو، پہلا)، صفتِ مقداری (تھوڑا، بہت)، صفتِ اشارہ (یہ کتاب، وہ قلم)۔\nجس اسم کی صفت بیان کی جائے اسے موصوف کہتے ہیں: 'ذہین طالب علم' میں طالب علم موصوف اور ذہین صفت ہے۔\nدرجات: عام درجہ (اچھا)، تقابلی درجہ (زیادہ اچھا)، اعلیٰ درجہ (سب سے اچھا)۔\nصفت ہمیشہ موصوف کے مطابق آتی ہے اور اس کی وضاحت کرتی ہے۔",
   "icon": "📖"
  },
  {
   "title": "Zameer (ضمیر)",
   "body": "ضمیر: وہ کلمہ جو اسم کی جگہ استعمال ہو تاکہ دہراؤ سے بچا جا سکے۔ مثلاً: میں، تم، وہ، یہ۔\nاقسام: ضمیرِ شخصی (میں، تم، وہ، ہم)، ضمیرِ اشارہ (یہ، وہ)، ضمیرِ استفہام (کون، کیا، کونسا)، ضمیرِ موصولہ (جو، جس، جنہوں نے)۔\nمثال: 'علی بیمار ہے، وہ آج اسکول نہیں آیا' -- یہاں 'وہ' ضمیر ہے جو علی کی جگہ آیا ہے۔\nضمیرِ غائب 'وہ' واحد اور جمع دونوں کے لیے آتا ہے، سیاق سے فرق معلوم ہوتا ہے۔\nمرجع کا واضح ہونا ضروری ہے ورنہ جملہ مبہم ہو جاتا ہے۔",
   "icon": "📖"
  },
  {
   "title": "Harf (حرف)",
   "body": "حرف: وہ کلمہ جو اکیلے مکمل معنی نہ دے بلکہ دوسرے کلموں سے مل کر معنی پیدا کرے۔ مثلاً: میں، پر، سے، تک، کا، کی، اور۔\nحروفِ جار: میں، پر، سے، تک، پاس، درمیان -- 'کتاب میز پر ہے'، 'وہ گھر سے آیا'۔\nحروفِ عطف: اور، یا، لیکن، بلکہ -- 'علی اور احمد آئے'۔\nحروفِ شرط: اگر، جب، چاہے -- 'اگر بارش ہوئی تو میچ نہیں ہوگا'۔\nحروفِ نفی: نہ، نہیں، مت -- 'وہ نہیں آیا'۔\nحرف ہمیشہ اسم یا ضمیر کے ساتھ مل کر استعمال ہوتا ہے، اکیلا جملہ نہیں بناتا۔",
   "icon": "📖"
  },
  {
   "title": "Wahid aur Jama (واحد اور جمع)",
   "body": "واحد: ایک چیز کا نام -- کتاب، لڑکا، قلم۔\nجمع: ایک سے زیادہ کا نام -- کتابیں، لڑکے، قلموں۔\nجمع بنانے کے عام طریقے: (1) آخر میں 'یں' بڑھانا -- کتاب/کتابیں، بچی/بچیاں (2) 'ے' بڑھانا -- لڑکا/لڑکے، کتا/کتے (3) 'وں' بڑھانا -- گھر/گھروں (4) 'ات' بڑھانا -- سوال/سوالات، خیال/خیالات۔\nبعض الفاظ واحد اور جمع میں ایک جیسے رہتے ہیں: پانی، دودھ، چاول۔\nجمع بناتے وقت املا کا خاص خیال رکھیں کیونکہ بورڈ امتحان میں واحد کی جمع اور جمع کا واحد پوچھا جاتا ہے۔",
   "icon": "📖"
  },
  {
   "title": "Muzakkar aur Muannas (مذکر و مؤنث)",
   "body": "مذکر: نر جنس کے لیے -- لڑکا، باپ، شیر، استاد۔\nمؤنث: مادہ جنس کے لیے -- لڑکی، ماں، شیرنی، استانی۔\nعام پہچان: 'ا' پر ختم ہونے والے اکثر مذکر (لڑکا) اور 'ی' پر ختم ہونے والے اکثر مؤنث (لڑکی) -- مگر استثنا بھی ہیں: دریا مذکر ہے، کرسی مؤنث ہے۔\nتانیث کے طریقے: لڑکا/لڑکی، استاد/استانی، شیر/شیرنی، باپ/ماں، چچا/چچی۔\nبے جان چیزوں کی تذکیر و تانیث رواج سے طے ہے: قلم مذکر، کتاب مؤنث، پانی مذکر، آگ مؤنث، چاند مذکر، زمین مؤنث۔\nفعل اور صفت جنس کے مطابق بدلتے ہیں: 'لڑکا آیا'، 'لڑکی آئی'۔",
   "icon": "📖"
  },
  {
   "title": "Jumlay ki Iqsam (جملے کی اقسام)",
   "body": "جملہ: ایسے کلموں کا مجموعہ جو مکمل معنی دے -- 'بچہ کھیلتا ہے'۔\n(1) جملہِ خبریہ: خبر دے -- آج بارش ہوئی۔\n(2) جملہِ استفہامیہ: سوال پوچھے -- تم کہاں گئے تھے؟\n(3) جملہِ امریہ: حکم دے -- بیٹھ جاؤ۔\n(4) جملہِ نہیہ: منع کرے -- شور مت کرو۔\n(5) جملہِ انشائیہ: خواہش، دعا یا جذبات -- کاش وہ آ جائے! اللہ تمہیں خوش رکھے!\nسادہ جملہ: ایک مسند الیہ + ایک مسند -- 'پرندہ اڑتا ہے'۔\nمرکب جملہ: دو جملوں کا مجموعہ -- 'وہ آیا اور میں چلا گیا'۔",
   "icon": "📖"
  },
  {
   "title": "Murakkab (مرکب)",
   "body": "مرکب: دو یا زیادہ کلموں کا ایسا مجموعہ جو مل کر ایک مفہوم ادا کرے۔\nمرکبِ ناقص: نامکمل مفہوم دے، جملہ نہیں بنتا -- شیرِ پنجاب، کتابِ علم۔\nمرکبِ تام: مکمل مفہوم دے، یہی جملہ کہلاتا ہے -- شیر دھاڑا۔\nمرکبِ اضافی: مضاف + مضاف الیہ -- 'قلمِ احمد' میں قلم مضاف اور احمد مضاف الیہ ہے۔\nمرکبِ توصیفی: موصوف + صفت -- 'سرخ پھول'، 'ذہین لڑکا'۔\nمرکبِ عطفی: دو اسموں کو 'اور' یا 'و' سے جوڑنا -- 'علم و عمل'، 'دین و دنیا'۔\nمرکبِ جاری: حرفِ جار کے ساتھ -- 'میز پر'، 'گھر سے'۔",
   "icon": "📖"
  },
  {
   "title": "Tashbeeh aur Isteara (تشبیہ و استعارہ)",
   "body": "تشبیہ: کسی چیز کو کسی دوسری چیز جیسا قرار دینا۔\nارکانِ تشبیہ: مشبہ (جسے تشبیہ دی جائے)، مشبہ بہ (جس سے دی جائے)، وجہِ شبہ (مشترک خوبی)، حرفِ تشبیہ (جیسا، مانند، طرح، سا)۔\nمثال: 'چاند جیسا چہرہ' -- چہرہ مشبہ، چاند مشبہ بہ، خوبصورتی وجہِ شبہ، 'جیسا' حرفِ تشبیہ۔\nاستعارہ: حرفِ تشبیہ کے بغیر تشبیہ -- 'وہ تو چاند ہے' (یعنی چہرہ چاند جیسا ہے)۔\nکنایہ: غیر مستقیم اشارہ -- 'اس کا ہاتھ تنگ ہے' (کنجوس ہونے کی طرف اشارہ)۔\nتشبیہ اور استعارے کا فرق بورڈ امتحان میں اکثر پوچھا جاتا ہے۔",
   "icon": "📖"
  },
  {
   "title": "Mahawaray (محاورے)",
   "body": "محاورہ: ایسا مرکب جو اپنے لغوی معنوں کے بجائے ایک خاص مفہوم دے۔\nمثال: 'آنکھوں کا تارا' یعنی بہت پیارا؛ 'ناک کٹنا' یعنی بے عزت ہونا۔\nضرب المثل: مکمل جملہ جو کہاوت بن جائے -- 'جتنی چادر دیکھو اتنے پاؤں پھیلاؤ'۔\nامتحان میں محاورے جملوں میں استعمال کرنے کو کہا جاتا ہے -- پہلے معنی لکھیں، پھر جملہ بنائیں۔\nمشہور محاورے: آستین کا سانپ (دوست نما دشمن)، باغ باغ ہونا (بہت خوش ہونا)، چار چاند لگانا (شہرت بڑھانا)، ٹس سے مس نہ ہونا (کوئی اثر نہ لینا)، دال نہ گلنا (کامیاب نہ ہونا)، نو دو گیارہ ہونا (بھاگ جانا)۔",
   "icon": "📖"
  },
  {
   "title": "Mazmoon Nigari (مضمون نگاری)",
   "body": "مضمون کے تین حصے: تمہید (موضوع کا تعارف)، نفسِ مضمون (تفصیل)، خاتمہ (نتیجہ اور رائے)۔\nتمہید میں موضوع کی تعریف اور اہمیت لکھیں؛ نفسِ مضمون میں 3-4 نکات الگ الگ پیراگراف میں بیان کریں؛ خاتمے میں خلاصہ اور اپنی رائے دیں۔\nاشعار اور اقوال سے مضمون خوبصورت بنتا ہے -- اقبال اور غالب کے مناسب اشعار یاد رکھیں۔\nزبان سادہ اور رواں ہو، جملے چھوٹے ہوں، املا درست ہو۔\nمشہور موضوعات: علم کے فائدے، میرا نصب العین، کھیلوں کی اہمیت، ماحولیاتی آلودگی، وقت کی پابندی۔\nسرخی لکھ کر اسے خط کشیدہ (underline) کریں۔",
   "icon": "📖"
  },
  {
   "title": "Darkhwast aur Khat (درخواست و خط)",
   "body": "درخواست کا ڈھانچہ:\n(1) اوپر دائیں طرف تاریخ (2) مخاطب کا عہدہ اور پتہ (3) موضوع کی سرخی (4) آداب -- جنابِ عالیٰ (5) متن -- تین پیرے: تعارف و مقصد، تفصیل، گزارش (6) اختتام -- 'عین نوازش ہوگی' (7) دستخط، نام، جماعت، رول نمبر۔\nزبان باادب اور مختصر رکھیں؛ ایک درخواست میں ایک ہی موضوع بیان کریں۔\nخط کا ڈھانچہ: پتہ اور تاریخ اوپر دائیں، آداب (پیارے دوست!)، حال احوال، اصل بات، دعا، آخر میں 'تمہارا دوست' کے ساتھ نام۔\nدرخواست میں 'برائے مہربانی' اور خط میں گرمجوش لہجہ استعمال کریں۔",
   "icon": "📖"
  }
 ]
}
BANKS = {
 "PHYSICS10": [
  {
   "q": "The SI unit of force is:",
   "opts": [
    "Newton",
    "Joule",
    "Watt",
    "Pascal"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Speed of light in vacuum is:",
   "opts": [
    "3×10⁸ m/s",
    "3×10⁶ m/s",
    "1.5×10⁸ m/s",
    "3×10¹⁰ m/s"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "1 kWh is equal to:",
   "opts": [
    "3.6 MJ",
    "3600 J",
    "1000 J",
    "3.6 kJ"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "The value of g is about:",
   "opts": [
    "9.8 m/s²",
    "8.9 m/s²",
    "10.8 m/s²",
    "6.8 m/s²"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Which is a vector quantity?",
   "opts": [
    "Velocity",
    "Speed",
    "Distance",
    "Mass"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Ohm's law states V =",
   "opts": [
    "IR",
    "I/R",
    "R/I",
    "I²R"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "The unit of electric current is:",
   "opts": [
    "Volt",
    "Ampere",
    "Ohm",
    "Watt"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Sound waves are:",
   "opts": [
    "Transverse",
    "Longitudinal",
    "Electromagnetic",
    "Standing"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Power is defined as:",
   "opts": [
    "Force × time",
    "Work / time",
    "Energy × time",
    "Mass × velocity"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "The SI unit of pressure is:",
   "opts": [
    "Newton",
    "Pascal",
    "Joule",
    "Bar"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Newton's first law is also called:",
   "opts": [
    "Law of action",
    "Law of inertia",
    "Law of momentum",
    "Law of energy"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Which is a scalar quantity?",
   "opts": [
    "Velocity",
    "Force",
    "Speed",
    "Displacement"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Momentum equals:",
   "opts": [
    "Force × distance",
    "Mass × acceleration",
    "Mass × velocity",
    "Velocity / mass"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Kinetic energy of mass m with velocity v:",
   "opts": [
    "mv²",
    "2mv²",
    "½mv²",
    "mv"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The image formed by a plane mirror is:",
   "opts": [
    "Real and inverted",
    "Real and erect",
    "Virtual and erect",
    "Virtual and inverted"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Frequency is measured in:",
   "opts": [
    "Decibel",
    "Watt",
    "Tesla",
    "Hertz"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Least count of a vernier calliper is usually:",
   "opts": [
    "0.1 cm",
    "0.001 cm",
    "1 cm",
    "0.01 cm"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "A body in free fall accelerates at:",
   "opts": [
    "0",
    "Increasing rate",
    "Decreasing rate",
    "g"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Resistance of a wire depends on:",
   "opts": [
    "Only its colour",
    "Only its mass",
    "Length and thickness",
    "Only temperature"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Work is done when:",
   "opts": [
    "Body is at rest",
    "No motion occurs",
    "Force causes displacement",
    "Force is zero"
   ],
   "correct": 2,
   "expl": ""
  }
 ],
 "CHEMISTRY10": [
  {
   "q": "Symbol of sodium is:",
   "opts": [
    "Na",
    "So",
    "Sd",
    "Sm"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Atomic number of carbon is:",
   "opts": [
    "6",
    "12",
    "4",
    "8"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "pH of a neutral solution is:",
   "opts": [
    "7",
    "0",
    "14",
    "1"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "The lightest element is:",
   "opts": [
    "Helium",
    "Hydrogen",
    "Lithium",
    "Oxygen"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "The most abundant gas in air is:",
   "opts": [
    "Oxygen",
    "Nitrogen",
    "Carbon dioxide",
    "Hydrogen"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "An acid turns blue litmus:",
   "opts": [
    "Green",
    "Red",
    "Yellow",
    "No change"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Valency of calcium is:",
   "opts": [
    "1",
    "2",
    "3",
    "4"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Chemical formula of common salt:",
   "opts": [
    "KCl",
    "NaCl",
    "Na₂CO₃",
    "CaCl₂"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Atomic mass of oxygen is:",
   "opts": [
    "8",
    "32",
    "16",
    "12"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Electrons in the outermost shell of neon:",
   "opts": [
    "2",
    "10",
    "8",
    "0"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Diamond is an allotrope of:",
   "opts": [
    "Silicon",
    "Sulphur",
    "Carbon",
    "Phosphorus"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Which metal is liquid at room temperature?",
   "opts": [
    "Iron",
    "Copper",
    "Mercury",
    "Zinc"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The cathode is the:",
   "opts": [
    "Positive electrode",
    "Neutral electrode",
    "Negative electrode",
    "Salt bridge"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Baking soda is:",
   "opts": [
    "Na₂CO₃",
    "NaOH",
    "NaHCO₃",
    "CaCO₃"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Rusting of iron needs:",
   "opts": [
    "Only oxygen",
    "Only water",
    "Oxygen and water",
    "Carbon dioxide"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The gas released when acid reacts with a metal:",
   "opts": [
    "Oxygen",
    "Carbon dioxide",
    "Chlorine",
    "Hydrogen"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Molar mass of H₂SO₄ is:",
   "opts": [
    "49 g/mol",
    "96 g/mol",
    "100 g/mol",
    "98 g/mol"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Which is a noble gas?",
   "opts": [
    "Oxygen",
    "Nitrogen",
    "Chlorine",
    "Helium"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Chemical formula of water:",
   "opts": [
    "HO₂",
    "OH₂",
    "H₂O₂",
    "H₂O"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Isotopes of an element have the same:",
   "opts": [
    "Mass number",
    "Neutrons",
    "Physical properties",
    "Atomic number"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "BIOLOGY10": [
  {
   "q": "Powerhouse of the cell:",
   "opts": [
    "Mitochondria",
    "Nucleus",
    "Ribosome",
    "Vacuole"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Photosynthesis occurs in:",
   "opts": [
    "Chloroplast",
    "Mitochondria",
    "Nucleus",
    "Cytoplasm"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Functional unit of the kidney:",
   "opts": [
    "Nephron",
    "Neuron",
    "Alveolus",
    "Glomerulus"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "The universal blood donor group is:",
   "opts": [
    "O",
    "AB",
    "A",
    "B"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "The largest organ of the human body:",
   "opts": [
    "Liver",
    "Skin",
    "Heart",
    "Lung"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Human body cells have ___ chromosomes:",
   "opts": [
    "44",
    "46",
    "48",
    "23"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Insulin is secreted by:",
   "opts": [
    "Liver",
    "Pancreas",
    "Kidney",
    "Thyroid"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Xylem in plants transports:",
   "opts": [
    "Food",
    "Water",
    "Hormones",
    "Minerals only"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Which vitamin helps blood clotting?",
   "opts": [
    "Vitamin C",
    "Vitamin K",
    "Vitamin D",
    "Vitamin A"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "The part of the brain controlling balance:",
   "opts": [
    "Cerebrum",
    "Cerebellum",
    "Medulla",
    "Hypothalamus"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Red blood cells carry:",
   "opts": [
    "Carbon dioxide",
    "Hormones",
    "Oxygen",
    "Enzymes"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Enzymes are made of:",
   "opts": [
    "Fats",
    "Carbohydrates",
    "Proteins",
    "Vitamins"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The structural and functional unit of life:",
   "opts": [
    "Tissue",
    "Organ",
    "Cell",
    "Atom"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Stomata are present on:",
   "opts": [
    "Roots",
    "Stem",
    "Leaves",
    "Flowers"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The pigment in red blood cells:",
   "opts": [
    "Chlorophyll",
    "Melanin",
    "Haemoglobin",
    "Keratin"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Aerobic respiration needs:",
   "opts": [
    "Carbon dioxide",
    "Nitrogen",
    "Oxygen",
    "Hydrogen"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "DNA is found in the:",
   "opts": [
    "Ribosome",
    "Cell wall",
    "Vacuole",
    "Nucleus"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "The gas plants take in for photosynthesis:",
   "opts": [
    "Oxygen",
    "Nitrogen",
    "Hydrogen",
    "Carbon dioxide"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Osmosis is the movement of:",
   "opts": [
    "Solute only",
    "Air",
    "Blood",
    "Water across a membrane"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Bacteria are:",
   "opts": [
    "Multicellular",
    "Viruses",
    "Fungi",
    "Single-celled organisms"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "MATH10": [
  {
   "q": "√144 =",
   "opts": [
    "12",
    "14",
    "24",
    "72"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "15% of 200 is:",
   "opts": [
    "30",
    "15",
    "35",
    "20"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "If x + 5 = 12, then x =",
   "opts": [
    "7",
    "5",
    "17",
    "6"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Sum of angles of a triangle:",
   "opts": [
    "180°",
    "90°",
    "360°",
    "270°"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "2³ =",
   "opts": [
    "8",
    "6",
    "9",
    "4"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "LCM of 4 and 6 is:",
   "opts": [
    "24",
    "12",
    "6",
    "2"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "The next prime number after 7 is:",
   "opts": [
    "9",
    "11",
    "13",
    "10"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Area of a circle of radius r:",
   "opts": [
    "2πr",
    "πr²",
    "πd",
    "πr"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Slope of a horizontal line:",
   "opts": [
    "1",
    "0",
    "Undefined",
    "-1"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Median of 2, 5, 8 is:",
   "opts": [
    "2",
    "8",
    "5",
    "15"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "(a+b)² =",
   "opts": [
    "a²+b²",
    "a²-2ab+b²",
    "a²+2ab+b²",
    "2a+2b"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "If 3x = 21, then x =",
   "opts": [
    "6",
    "8",
    "7",
    "63"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Degree of a quadratic equation:",
   "opts": [
    "1",
    "3",
    "2",
    "4"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Value of π is approximately:",
   "opts": [
    "2.718",
    "1.414",
    "3.0",
    "3.1416"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Number of sides in a hexagon:",
   "opts": [
    "5",
    "7",
    "8",
    "6"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "ENGLISH10": [
  {
   "q": "Synonym of 'brave':",
   "opts": [
    "Courageous",
    "Coward",
    "Weak",
    "Timid"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "He ___ to school daily.",
   "opts": [
    "goes",
    "go",
    "going",
    "gone"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Plural of 'child':",
   "opts": [
    "Children",
    "Childs",
    "Childes",
    "Childrens"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "'Quickly' is a/an:",
   "opts": [
    "Adverb",
    "Adjective",
    "Noun",
    "Verb"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "She has been ill ___ Monday.",
   "opts": [
    "since",
    "for",
    "from",
    "by"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Antonym of 'honest':",
   "opts": [
    "Truthful",
    "Dishonest",
    "Loyal",
    "Sincere"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Choose the correct spelling:",
   "opts": [
    "Beautifull",
    "Beautiful",
    "Beutiful",
    "Buetiful"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Opposite of 'ancient':",
   "opts": [
    "Old",
    "Modern",
    "Aged",
    "Antique"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Comparative degree of 'good':",
   "opts": [
    "Gooder",
    "Better",
    "Best",
    "More good"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "He is afraid ___ dogs.",
   "opts": [
    "from",
    "of",
    "by",
    "with"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Synonym of 'begin':",
   "opts": [
    "End",
    "Finish",
    "Start",
    "Close"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "'They' is a:",
   "opts": [
    "Noun",
    "Verb",
    "Pronoun",
    "Adverb"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Choose the noun:",
   "opts": [
    "Happy",
    "Happily",
    "Happiness",
    "Happen"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Passive of 'He writes a letter':",
   "opts": [
    "A letter was written by him",
    "A letter is being written",
    "He is written a letter",
    "A letter is written by him"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "He do not like tea.",
    "He does not likes tea.",
    "He not like tea.",
    "He does not like tea."
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "URDU10": [
  {
   "q": "لفظ 'علم' کا متضاد ہے:",
   "opts": [
    "جہالت",
    "دانش",
    "فہم",
    "عقل"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "'کتاب' کی جمع ہے:",
   "opts": [
    "کتب",
    "کتابیں",
    "کتابوں",
    "کتابات"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "اردو کا پہلا صاحبِ دیوان شاعر:",
   "opts": [
    "قلی قطب شاہ",
    "میر تقی میر",
    "غالب",
    "اقبال"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "حمد کس کی تعریف میں کہی جاتی ہے:",
   "opts": [
    "اللہ تعالٰ",
    "نبی کریم ﷻ",
    "ولی",
    "بادشاہ"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "غزل کے پہلے شعر کو کہتے ہیں:",
   "opts": [
    "مطلع",
    "مقطع",
    "ردیف",
    "قافیہ"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "'پانی' کا مترادف ہے:",
   "opts": [
    "آگ",
    "آب",
    "ہوا",
    "مٹی"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "لفظ 'سچ' کا مترادف:",
   "opts": [
    "جھوٹ",
    "حق",
    "باطل",
    "فریب"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "نعت کس کی شان میں کہی جاتی ہے:",
   "opts": [
    "اللہ تعالٰ",
    "صحابہ کرام",
    "حضور ﷻ",
    "اولیاء"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "'دوست' کا متضاد:",
   "opts": [
    "ساتھی",
    "رفیق",
    "دشمن",
    "ہمدم"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "'محنت' کا متضاد:",
   "opts": [
    "کوشش",
    "جدوجہد",
    "سستی",
    "کام"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "اقبال کا مشہور مجموعۂ کلام:",
   "opts": [
    "دیوانِ غالب",
    "شاہنامہ",
    "بانگِ درا",
    "گلستان"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "'خوشی' کا مترادف:",
   "opts": [
    "غم",
    "رنج",
    "مسرت",
    "الم"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "اردو حروفِ تہجی کی تعداد:",
   "opts": [
    "38",
    "36",
    "40",
    "39"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "کہانی کے آخر کو کہتے ہیں:",
   "opts": [
    "آغاز",
    "وسط",
    "عنوان",
    "اختتام"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "مثنوی کس زبان کا لفظ ہے:",
   "opts": [
    "فارسی",
    "ترکی",
    "ہندی",
    "عربی"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "ISLAMIAT10": [
  {
   "q": "پہلی وحی کہاں نازل ہوئی:",
   "opts": [
    "غارِ حرا",
    "غارِ ثور",
    "مسجدِ نبوی",
    "مدینہ منورہ"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "قرآن مجید میں سورتوں کی تعداد:",
   "opts": [
    "114",
    "110",
    "116",
    "120"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "نماز دن میں کتنی فرض ہیں:",
   "opts": [
    "5",
    "4",
    "6",
    "3"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "حج کس مہینے میں ادا ہوتا ہے:",
   "opts": [
    "ذوالحجہ",
    "رمضان",
    "شوال",
    "محرم"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "قرآن مجید کی سب سے لمبی سورت:",
   "opts": [
    "البقرہ",
    "آلِ عمران",
    "النساء",
    "المائدہ"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "پہلے خلیفۂ راشد:",
   "opts": [
    "حضرت ابوبکر صدیقؓ",
    "حضرت عمر فاروقؓ",
    "حضرت عثمانؓ",
    "حضرت علیؓ"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "غزوہِ بدر کب ہوا:",
   "opts": [
    "3 ہجری",
    "2 ہجری",
    "5 ہجری",
    "8 ہجری"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "روزے کس مہینے میں فرض ہیں:",
   "opts": [
    "شعبان",
    "رمضان",
    "رجب",
    "محرم"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "فتحِ مکہ کب ہوا:",
   "opts": [
    "6 ہجری",
    "8 ہجری",
    "10 ہجری",
    "2 ہجری"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "وضو میں فرائض کتنے ہیں:",
   "opts": [
    "3",
    "5",
    "4",
    "6"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "کلمۂ طیبہ کے کتنے حصے ہیں:",
   "opts": [
    "3",
    "4",
    "2",
    "1"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "قرآن مجید کتنے عرصے میں نازل ہوا:",
   "opts": [
    "20 سال",
    "25 سال",
    "23 سال",
    "13 سال"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "زکوٰۃ کا نصاب سونے میں:",
   "opts": [
    "ساڑھے پانچ تولہ",
    "دس تولہ",
    "ساڑھے سات تولہ",
    "پانچ تولہ"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "آخری نبی:",
   "opts": [
    "حضرت عیسٰؑ",
    "حضرت موسٰؑ",
    "حضرت محمد ﷻ",
    "حضرت ابراہیمؑ"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "پہلی اسلامی ریاست کا دارالحکومت:",
   "opts": [
    "مکہ مکرمہ",
    "طائف",
    "خیبر",
    "مدینہ منورہ"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "PAKSTUDY10": [
  {
   "q": "پاکستان کب معرضِ وجود میں آیا:",
   "opts": [
    "14 اگسٹ 1947",
    "15 اگسٹ 1947",
    "23 مارچ 1940",
    "3 جون 1947"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "پاکستان کا دارالحکومت:",
   "opts": [
    "اسلام آباد",
    "کراچی",
    "لاہور",
    "راولپنڌی"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "قراردادِ پاکستان کب منظور ہوئی:",
   "opts": [
    "23 مارچ 1940",
    "14 اگسٹ 1947",
    "3 جون 1947",
    "23 مارچ 1956"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "پاکستان کا قومی کھیل:",
   "opts": [
    "ہاکی",
    "کرکٹ",
    "فٹ بال",
    "کبڈی"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "بانیِ پاکستان:",
   "opts": [
    "قائداعظم محمد علی جناح",
    "علامہ اقبال",
    "لیاقت علی خان",
    "سر سید احمد خان"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "پاکستان کا قومی جانور:",
   "opts": [
    "شیر",
    "مارخور",
    "ہاتھی",
    "چیتا"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "رقبے کے لحاظ سے سب سے بڑا صوبہ:",
   "opts": [
    "پنجاب",
    "بلوچستان",
    "سندھ",
    "خیبر پختونخوا"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "پاکستان کا قومی پھول:",
   "opts": [
    "گلاب",
    "چنبیلی",
    "سورج مکھی",
    "گیندا"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "پاکستان کی قومی زبان:",
   "opts": [
    "انگریزی",
    "اردو",
    "پنجابی",
    "سندھی"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "شاعرِ مشرق:",
   "opts": [
    "فیض احمد فیض",
    "علامہ اقبال",
    "میر تقی میر",
    "احمد فراز"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "پہلا آئین کب نافذ ہوا:",
   "opts": [
    "1962",
    "1973",
    "1956",
    "1947"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "کے ٹو کی بلندی:",
   "opts": [
    "8848 میٹر",
    "8125 میٹر",
    "8611 میٹر",
    "8012 میٹر"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "موجودہ آئین کب نافذ ہوا:",
   "opts": [
    "1956",
    "1962",
    "1973",
    "1985"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "قومی ترانے کے خالق:",
   "opts": [
    "علامہ اقبال",
    "احمد ندیم قاسمی",
    "حفیظ جالندھری",
    "فیض احمد فیض"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "دریائے سندھ کہاں سے نکلتا ہے:",
   "opts": [
    "کشمیر",
    "ہمالیہ",
    "قراقرم",
    "تبت"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "PHYSICS12": [
  {
   "q": "The SI unit of capacitance is:",
   "opts": [
    "Farad",
    "Henry",
    "Weber",
    "Tesla"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Speed of electromagnetic waves:",
   "opts": [
    "3×10⁸ m/s",
    "3×10⁶ m/s",
    "1.5×10⁸ m/s",
    "3×10¹⁰ m/s"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Photoelectric effect proves light behaves as:",
   "opts": [
    "Particle",
    "Wave",
    "Both",
    "Neither"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "de Broglie wavelength λ =",
   "opts": [
    "h/p",
    "h·p",
    "p/h",
    "h/p²"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Half-life is the time for:",
   "opts": [
    "Half the nuclei to decay",
    "All nuclei to decay",
    "One nucleus to decay",
    "Quarter to decay"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "The unit of electric flux:",
   "opts": [
    "V/m",
    "N·m²/C",
    "C/m²",
    "J/C"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "The SI unit of magnetic flux:",
   "opts": [
    "Tesla",
    "Weber",
    "Henry",
    "Gauss"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "A transformer works on:",
   "opts": [
    "Coulomb's law",
    "Mutual induction",
    "Ohm's law",
    "Lenz's law"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Energy of a photon E =",
   "opts": [
    "hc/λ²",
    "hf",
    "h/f",
    "mc³"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Kirchhoff's first rule is based on:",
   "opts": [
    "Conservation of energy",
    "Conservation of charge",
    "Conservation of momentum",
    "Newton's law"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Magnetic field inside a solenoid is:",
   "opts": [
    "Zero",
    "Varying",
    "Uniform",
    "Circular"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "A PN-junction diode conducts in:",
   "opts": [
    "Reverse bias",
    "Both biases",
    "Forward bias",
    "No bias"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "An AND gate gives high output when:",
   "opts": [
    "Any input is high",
    "Inputs are different",
    "All inputs are high",
    "All inputs are low"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "LASER light is produced by:",
   "opts": [
    "Spontaneous emission",
    "Photoelectric effect",
    "Thermionic emission",
    "Stimulated emission of radiation"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Coulomb's law: F =",
   "opts": [
    "kq₁q₂/r",
    "kq₁q₂/r³",
    "kq₁r²/q₂",
    "kq₁q₂/r²"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "CHEMISTRY12": [
  {
   "q": "Hybridization in CH₄ (methane):",
   "opts": [
    "sp³",
    "sp²",
    "sp",
    "dsp²"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "pH of 0.01 M HCl solution:",
   "opts": [
    "2",
    "1",
    "4",
    "12"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Which is a transition metal?",
   "opts": [
    "Iron",
    "Sodium",
    "Calcium",
    "Aluminium"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "IUPAC name of CH₃COOH:",
   "opts": [
    "Ethanoic acid",
    "Methanoic acid",
    "Propanoic acid",
    "Butanoic acid"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Avogadro's number is:",
   "opts": [
    "6.022×10²³",
    "3.01×10²³",
    "1.6×10⁻¹⁹",
    "9.1×10⁻³¹"
   ],
   "correct": 0,
   "expl": ""
  },
  {
   "q": "Rate of a reaction depends on:",
   "opts": [
    "Colour of reactants",
    "Concentration of reactants",
    "Shape of container",
    "Smell of products"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Standard electrode potential of hydrogen:",
   "opts": [
    "1.00 V",
    "0.00 V",
    "-1.00 V",
    "0.76 V"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Benzene molecule has ___ π bonds:",
   "opts": [
    "6",
    "3",
    "1",
    "12"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Tollen's reagent test is used for:",
   "opts": [
    "Ketones",
    "Aldehydes",
    "Alcohols",
    "Carboxylic acids"
   ],
   "correct": 1,
   "expl": ""
  },
  {
   "q": "Which gas turns lime water milky?",
   "opts": [
    "Oxygen",
    "Hydrogen",
    "CO₂",
    "Nitrogen"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "Oxidation is defined as:",
   "opts": [
    "Gain of electrons",
    "Loss of protons",
    "Loss of electrons",
    "Gain of neutrons"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The catalyst used in Haber's process:",
   "opts": [
    "Nickel",
    "Platinum",
    "Iron",
    "Vanadium"
   ],
   "correct": 2,
   "expl": ""
  },
  {
   "q": "The -OH functional group is present in:",
   "opts": [
    "Aldehydes",
    "Ketones",
    "Ethers",
    "Alcohols"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Esterification: an acid reacts with:",
   "opts": [
    "Base",
    "Salt",
    "Water",
    "Alcohol"
   ],
   "correct": 3,
   "expl": ""
  },
  {
   "q": "Saponification of fats gives:",
   "opts": [
    "Soap and water",
    "Glycerol only",
    "Ester and water",
    "Soap and glycerol"
   ],
   "correct": 3,
   "expl": ""
  }
 ],
 "PHYSICS9": [
  {
   "q": "The SI unit of length is:",
   "opts": [
    "Metre",
    "Kilogram",
    "Second",
    "Ampere"
   ],
   "correct": 0,
   "expl": "Metre (m) is the SI base unit of length."
  },
  {
   "q": "The SI unit of mass is:",
   "opts": [
    "Metre",
    "Kilogram",
    "Second",
    "Kelvin"
   ],
   "correct": 1,
   "expl": "Kilogram (kg) is the SI base unit of mass."
  },
  {
   "q": "The SI unit of time is:",
   "opts": [
    "Metre",
    "Kilogram",
    "Second",
    "Ampere"
   ],
   "correct": 2,
   "expl": "Second (s) is the SI base unit of time."
  },
  {
   "q": "The SI unit of force is:",
   "opts": [
    "Newton",
    "Joule",
    "Watt",
    "Pascal"
   ],
   "correct": 0,
   "expl": "Force is measured in newtons (N = kg m/s²)."
  },
  {
   "q": "The least count of a vernier caliper is:",
   "opts": [
    "0.1 mm",
    "1 mm",
    "0.01 mm",
    "0.5 mm"
   ],
   "correct": 0,
   "expl": "A standard vernier caliper reads up to 0.1 mm (one-tenth of a millimetre)."
  },
  {
   "q": "A speedometer of a vehicle measures:",
   "opts": [
    "Speed",
    "Distance",
    "Acceleration",
    "Time"
   ],
   "correct": 0,
   "expl": "A speedometer shows the instantaneous speed of the vehicle."
  },
  {
   "q": "Displacement is a:",
   "opts": [
    "Vector quantity",
    "Scalar quantity",
    "Base quantity",
    "Derived unit"
   ],
   "correct": 0,
   "expl": "Displacement has both magnitude and direction, so it is a vector."
  },
  {
   "q": "The SI unit of acceleration is:",
   "opts": [
    "m/s",
    "m/s²",
    "m²/s",
    "N/s"
   ],
   "correct": 1,
   "expl": "Acceleration is the rate of change of velocity, measured in metres per second squared."
  },
  {
   "q": "In uniform circular motion, the acceleration is directed:",
   "opts": [
    "Away from the centre",
    "Towards the centre",
    "Along the tangent",
    "Opposite to velocity"
   ],
   "correct": 1,
   "expl": "Centripetal acceleration always points towards the centre of the circle."
  },
  {
   "q": "Newton's first law of motion is also called the law of:",
   "opts": [
    "Inertia",
    "Momentum",
    "Gravitation",
    "Action-reaction"
   ],
   "correct": 0,
   "expl": "The first law states that a body keeps its state of rest or motion unless acted upon, which is inertia."
  },
  {
   "q": "The SI unit of momentum is:",
   "opts": [
    "kg m/s",
    "kg m/s²",
    "N s²",
    "J s"
   ],
   "correct": 0,
   "expl": "Momentum p = mv, so its unit is kilogram-metre per second."
  },
  {
   "q": "The formula of linear momentum is:",
   "opts": [
    "p = mv",
    "p = m/v",
    "p = F/t",
    "p = ma²"
   ],
   "correct": 0,
   "expl": "Momentum equals the product of mass and velocity."
  },
  {
   "q": "Friction always acts:",
   "opts": [
    "In the direction of motion",
    "Opposite to the direction of motion",
    "Perpendicular to motion",
    "Along the normal"
   ],
   "correct": 1,
   "expl": "Friction opposes the relative motion between two surfaces."
  },
  {
   "q": "The direction of centripetal force is:",
   "opts": [
    "Away from the centre",
    "Towards the centre",
    "Tangent to the circle",
    "Downward"
   ],
   "correct": 1,
   "expl": "Centripetal force pulls the body towards the centre to keep it in circular motion."
  },
  {
   "q": "Torque is the product of force and:",
   "opts": [
    "Time",
    "Moment arm",
    "Velocity",
    "Mass"
   ],
   "correct": 1,
   "expl": "Torque = force × perpendicular distance (moment arm) from the pivot."
  },
  {
   "q": "Clockwise torque is conventionally taken as:",
   "opts": [
    "Positive",
    "Negative",
    "Zero",
    "Infinite"
   ],
   "correct": 1,
   "expl": "By convention anticlockwise torque is positive and clockwise is negative."
  },
  {
   "q": "A couple produces:",
   "opts": [
    "Linear motion only",
    "Rotation only",
    "Both translation and rotation",
    "No motion"
   ],
   "correct": 1,
   "expl": "A couple is two equal opposite parallel forces that cause rotation without translation."
  },
  {
   "q": "The first condition of equilibrium is that the sum of:",
   "opts": [
    "Torques is zero",
    "Forces is zero",
    "Momenta is zero",
    "Energies is zero"
   ],
   "correct": 1,
   "expl": "For translational equilibrium the vector sum of all forces must be zero."
  },
  {
   "q": "The second condition of equilibrium is that the sum of:",
   "opts": [
    "Forces is zero",
    "Torques is zero",
    "Masses is zero",
    "Velocities is zero"
   ],
   "correct": 1,
   "expl": "For rotational equilibrium the sum of torques about any point must be zero."
  },
  {
   "q": "The SI unit of the gravitational constant G is:",
   "opts": [
    "N m²/kg²",
    "N/kg",
    "m/s²",
    "J/kg"
   ],
   "correct": 0,
   "expl": "From F = G m₁m₂/r², G has units N m²/kg²."
  },
  {
   "q": "The value of acceleration due to gravity g is:",
   "opts": [
    "9.8 m/s²",
    "8.9 m/s²",
    "10.8 m/s²",
    "9.8 m/s"
   ],
   "correct": 0,
   "expl": "Near Earth's surface g is approximately 9.8 metres per second squared."
  },
  {
   "q": "Weight of a body is given by:",
   "opts": [
    "W = mg",
    "W = m/g",
    "W = g/m",
    "W = mv"
   ],
   "correct": 0,
   "expl": "Weight is the gravitational force on a mass, equal to mass times g."
  },
  {
   "q": "Which quantity remains the same everywhere for a body?",
   "opts": [
    "Weight",
    "Mass",
    "Gravitational force",
    "Apparent weight"
   ],
   "correct": 1,
   "expl": "Mass is the amount of matter and does not change with location, unlike weight."
  },
  {
   "q": "The law of gravitation was given by:",
   "opts": [
    "Galileo",
    "Newton",
    "Einstein",
    "Kepler"
   ],
   "correct": 1,
   "expl": "Newton formulated the universal law of gravitation."
  },
  {
   "q": "The SI unit of work is:",
   "opts": [
    "Watt",
    "Joule",
    "Newton",
    "Pascal"
   ],
   "correct": 1,
   "expl": "Work = force × distance, measured in joules."
  },
  {
   "q": "The SI unit of power is:",
   "opts": [
    "Joule",
    "Watt",
    "Newton",
    "Erg"
   ],
   "correct": 1,
   "expl": "Power is the rate of doing work, measured in watts."
  },
  {
   "q": "One horsepower is equal to:",
   "opts": [
    "746 W",
    "746 J",
    "746 N",
    "746 Pa"
   ],
   "correct": 0,
   "expl": "1 hp is defined as 746 watts."
  },
  {
   "q": "The formula of kinetic energy is:",
   "opts": [
    "mv²",
    "mv²/2",
    "mgh",
    "Fd"
   ],
   "correct": 1,
   "expl": "Kinetic energy equals half the product of mass and velocity squared."
  },
  {
   "q": "Potential energy of a 2 kg mass at 5 m height (g = 10 m/s²) is:",
   "opts": [
    "50 J",
    "100 J",
    "10 J",
    "20 J"
   ],
   "correct": 1,
   "expl": "PE = mgh = 2 × 10 × 5 = 100 J."
  },
  {
   "q": "Efficiency of a machine is:",
   "opts": [
    "Input/Output × 100%",
    "Output/Input × 100%",
    "Input × Output",
    "Work × Time"
   ],
   "correct": 1,
   "expl": "Efficiency is the ratio of useful output to input, expressed as a percentage."
  },
  {
   "q": "The SI unit of pressure is:",
   "opts": [
    "Bar",
    "Pascal",
    "Atmosphere",
    "Torr"
   ],
   "correct": 1,
   "expl": "Pressure = force/area, measured in pascals."
  },
  {
   "q": "Atmospheric pressure at sea level is about:",
   "opts": [
    "1.013 × 10⁵ Pa",
    "1.013 × 10³ Pa",
    "760 Pa",
    "1.013 Pa"
   ],
   "correct": 0,
   "expl": "Standard atmospheric pressure is 1.013 × 10⁵ Pa (760 mmHg)."
  },
  {
   "q": "The density of water is:",
   "opts": [
    "100 kg/m³",
    "1000 kg/m³",
    "10 kg/m³",
    "13600 kg/m³"
   ],
   "correct": 1,
   "expl": "Water has a density of 1000 kilograms per cubic metre."
  },
  {
   "q": "Hooke's law is expressed as:",
   "opts": [
    "F = kx",
    "F = ma",
    "F = mv",
    "F = kx²"
   ],
   "correct": 0,
   "expl": "Within the elastic limit, the stretching force is proportional to extension."
  },
  {
   "q": "The SI unit of stress is:",
   "opts": [
    "Newton",
    "Pascal",
    "Joule",
    "Metre"
   ],
   "correct": 1,
   "expl": "Stress is force per unit area, measured in pascals."
  },
  {
   "q": "The boiling point of water at standard pressure is:",
   "opts": [
    "90°C",
    "100°C",
    "0°C",
    "37°C"
   ],
   "correct": 1,
   "expl": "Water boils at 100°C under standard atmospheric pressure."
  },
  {
   "q": "The melting point of ice is:",
   "opts": [
    "0°C",
    "100°C",
    "-10°C",
    "4°C"
   ],
   "correct": 0,
   "expl": "Ice melts at 0°C under standard pressure."
  },
  {
   "q": "The specific heat of water is:",
   "opts": [
    "420 J/(kg K)",
    "4200 J/(kg K)",
    "42 J/(kg K)",
    "42000 J/(kg K)"
   ],
   "correct": 1,
   "expl": "Water's high specific heat of 4200 J/(kg K) moderates climate."
  },
  {
   "q": "A thermometer works on the principle of:",
   "opts": [
    "Thermal expansion",
    "Conduction",
    "Radiation",
    "Convection"
   ],
   "correct": 0,
   "expl": "Most thermometers use the expansion of a liquid with temperature."
  },
  {
   "q": "Convection takes place in:",
   "opts": [
    "Solids only",
    "Liquids and gases",
    "Vacuum",
    "Plasma only"
   ],
   "correct": 1,
   "expl": "Convection needs a fluid medium whose particles can move."
  },
  {
   "q": "Heat can travel through vacuum by:",
   "opts": [
    "Conduction",
    "Convection",
    "Radiation",
    "Diffusion"
   ],
   "correct": 2,
   "expl": "Radiation needs no material medium, so the Sun's heat reaches Earth this way."
  },
  {
   "q": "Bodies falling freely towards Earth have:",
   "opts": [
    "Different accelerations",
    "The same acceleration",
    "Zero acceleration",
    "Increasing mass"
   ],
   "correct": 1,
   "expl": "In free fall (no air resistance) all bodies accelerate at g regardless of mass."
  },
  {
   "q": "Average speed is calculated as:",
   "opts": [
    "Total distance / total time",
    "Total displacement / total time",
    "Distance × time",
    "Velocity + time"
   ],
   "correct": 0,
   "expl": "Average speed equals the total path length divided by total time."
  },
  {
   "q": "The slope of a distance-time graph gives:",
   "opts": [
    "Acceleration",
    "Speed",
    "Force",
    "Displacement"
   ],
   "correct": 1,
   "expl": "Slope = change in distance / change in time, which is speed."
  },
  {
   "q": "The slope of a velocity-time graph gives:",
   "opts": [
    "Speed",
    "Displacement",
    "Acceleration",
    "Force"
   ],
   "correct": 2,
   "expl": "Slope = change in velocity / change in time, which is acceleration."
  },
  {
   "q": "The area under a velocity-time graph gives:",
   "opts": [
    "Speed",
    "Acceleration",
    "Displacement",
    "Force"
   ],
   "correct": 2,
   "expl": "Area = velocity × time, which equals displacement."
  },
  {
   "q": "Which of the following is a scalar quantity?",
   "opts": [
    "Velocity",
    "Speed",
    "Displacement",
    "Force"
   ],
   "correct": 1,
   "expl": "Speed has magnitude only, while the others have direction too."
  },
  {
   "q": "1 km/h is equal to:",
   "opts": [
    "5/18 m/s",
    "18/5 m/s",
    "3.6 m/s",
    "10 m/s"
   ],
   "correct": 0,
   "expl": "Converting kilometres per hour to m/s uses the factor 5/18."
  },
  {
   "q": "Terminal velocity is reached when:",
   "opts": [
    "Drag force equals weight",
    "Drag force is zero",
    "Weight is zero",
    "Acceleration is maximum"
   ],
   "correct": 0,
   "expl": "At terminal velocity the upward drag balances the weight, so net force is zero."
  },
  {
   "q": "Linear thermal expansion is given by:",
   "opts": [
    "ΔL = αLΔT",
    "ΔL = L/αT",
    "ΔL = α/ΔT",
    "L = αΔT²"
   ],
   "correct": 0,
   "expl": "The change in length is proportional to original length and temperature change."
  }
 ],
 "CHEMISTRY9": [
  {
   "q": "The atomic number of carbon is:",
   "opts": [
    "4",
    "6",
    "8",
    "12"
   ],
   "correct": 1,
   "expl": "Carbon has 6 protons, and atomic number equals the number of protons."
  },
  {
   "q": "Mass number of an atom equals:",
   "opts": [
    "Protons only",
    "Neutrons only",
    "Protons + neutrons",
    "Electrons + protons"
   ],
   "correct": 2,
   "expl": "The mass number is the total count of protons and neutrons in the nucleus."
  },
  {
   "q": "The electron was discovered by:",
   "opts": [
    "Rutherford",
    "J.J. Thomson",
    "Chadwick",
    "Goldstein"
   ],
   "correct": 1,
   "expl": "J.J. Thomson discovered the electron through cathode-ray tube experiments."
  },
  {
   "q": "The proton was discovered by:",
   "opts": [
    "Goldstein",
    "Thomson",
    "Chadwick",
    "Bohr"
   ],
   "correct": 0,
   "expl": "Goldstein discovered positive canal rays, the protons."
  },
  {
   "q": "The neutron was discovered by:",
   "opts": [
    "Rutherford",
    "Thomson",
    "Chadwick",
    "Dalton"
   ],
   "correct": 2,
   "expl": "James Chadwick discovered the neutral neutron in 1932."
  },
  {
   "q": "The nucleus of the atom was discovered by:",
   "opts": [
    "Thomson",
    "Rutherford",
    "Bohr",
    "Dalton"
   ],
   "correct": 1,
   "expl": "Rutherford's gold-foil experiment revealed the dense central nucleus."
  },
  {
   "q": "The pH of a neutral solution at 25°C is:",
   "opts": [
    "0",
    "1",
    "7",
    "14"
   ],
   "correct": 2,
   "expl": "Pure water has equal H⁺ and OH⁻ concentrations, giving pH 7."
  },
  {
   "q": "An acid turns blue litmus paper:",
   "opts": [
    "Blue",
    "Red",
    "Green",
    "Colourless"
   ],
   "correct": 1,
   "expl": "Acids change blue litmus to red, a classic test for acidity."
  },
  {
   "q": "A base turns red litmus paper:",
   "opts": [
    "Red",
    "Blue",
    "Green",
    "Yellow"
   ],
   "correct": 1,
   "expl": "Bases change red litmus to blue."
  },
  {
   "q": "The chemical formula of common salt is:",
   "opts": [
    "NaCl",
    "KCl",
    "CaCl₂",
    "MgCl₂"
   ],
   "correct": 0,
   "expl": "Common salt is sodium chloride, NaCl."
  },
  {
   "q": "The chemical formula of water is:",
   "opts": [
    "H₂O₂",
    "HO",
    "H₂O",
    "H₃O"
   ],
   "correct": 2,
   "expl": "Each water molecule has two hydrogen atoms and one oxygen atom."
  },
  {
   "q": "A covalent bond is formed by:",
   "opts": [
    "Transfer of electrons",
    "Sharing of electrons",
    "Donation of protons",
    "Loss of neutrons"
   ],
   "correct": 1,
   "expl": "Covalent bonding involves the mutual sharing of electron pairs."
  },
  {
   "q": "An ionic bond is formed by:",
   "opts": [
    "Sharing of electrons",
    "Complete transfer of electrons",
    "Sharing of protons",
    "Overlap of orbitals"
   ],
   "correct": 1,
   "expl": "Ionic bonds form when one atom completely transfers electrons to another."
  },
  {
   "q": "The octet rule states that atoms tend to have:",
   "opts": [
    "2 electrons in valence shell",
    "8 electrons in valence shell",
    "18 electrons in valence shell",
    "Full K shell"
   ],
   "correct": 1,
   "expl": "Atoms are most stable with eight electrons in their outermost shell."
  },
  {
   "q": "Atomic number of an element equals the number of:",
   "opts": [
    "Neutrons",
    "Protons",
    "Nucleons",
    "Isotopes"
   ],
   "correct": 1,
   "expl": "Atomic number is defined as the number of protons in the nucleus."
  },
  {
   "q": "Isotopes of an element have the same number of:",
   "opts": [
    "Neutrons",
    "Protons",
    "Nucleons",
    "Mass number"
   ],
   "correct": 1,
   "expl": "Isotopes differ in neutrons but share the same proton count."
  },
  {
   "q": "The maximum electrons in the M shell (n=3) is:",
   "opts": [
    "8",
    "10",
    "18",
    "32"
   ],
   "correct": 2,
   "expl": "By the 2n² rule, the M shell holds 2 × 3² = 18 electrons."
  },
  {
   "q": "Avogadro's number is:",
   "opts": [
    "6.022 × 10²³",
    "3.011 × 10²³",
    "1.602 × 10⁻¹⁹",
    "9.11 × 10⁻³¹"
   ],
   "correct": 0,
   "expl": "One mole contains 6.022 × 10²³ particles."
  },
  {
   "q": "The molar mass of water is:",
   "opts": [
    "16 g/mol",
    "18 g/mol",
    "20 g/mol",
    "36 g/mol"
   ],
   "correct": 1,
   "expl": "H₂O = 2(1) + 16 = 18 g/mol."
  },
  {
   "q": "The empirical formula of glucose is:",
   "opts": [
    "C₆H₁₂O₆",
    "CH₂O",
    "CHO₂",
    "C₂H₄O₂"
   ],
   "correct": 1,
   "expl": "The simplest whole-number ratio of C:H:O in glucose is 1:2:1."
  },
  {
   "q": "The molecular formula of glucose is:",
   "opts": [
    "C₆H₁₂O₆",
    "CH₂O",
    "C₁₂H₂₂O₁₁",
    "C₃H₆O₃"
   ],
   "correct": 0,
   "expl": "Glucose is a six-carbon sugar with formula C₆H₁₂O₆."
  },
  {
   "q": "Electrolysis of water produces:",
   "opts": [
    "H₂ and O₂",
    "H₂ only",
    "O₂ only",
    "H₂O₂"
   ],
   "correct": 0,
   "expl": "Water splits into hydrogen at the cathode and oxygen at the anode."
  },
  {
   "q": "Oxidation is defined as:",
   "opts": [
    "Gain of electrons",
    "Loss of electrons",
    "Gain of protons",
    "Loss of neutrons"
   ],
   "correct": 1,
   "expl": "Oxidation is the loss of electrons (OIL: oxidation is loss)."
  },
  {
   "q": "Reduction is defined as:",
   "opts": [
    "Loss of electrons",
    "Gain of electrons",
    "Loss of protons",
    "Gain of neutrons"
   ],
   "correct": 1,
   "expl": "Reduction is the gain of electrons (RIG: reduction is gain)."
  },
  {
   "q": "In an electrolytic cell, the cathode is:",
   "opts": [
    "Positive",
    "Negative",
    "Neutral",
    "Alternating"
   ],
   "correct": 1,
   "expl": "The cathode is connected to the negative terminal and attracts cations."
  },
  {
   "q": "Which of the following is a metalloid?",
   "opts": [
    "Sodium",
    "Silicon",
    "Chlorine",
    "Calcium"
   ],
   "correct": 1,
   "expl": "Silicon has properties between metals and non-metals."
  },
  {
   "q": "Group 1 elements are called:",
   "opts": [
    "Alkaline earth metals",
    "Alkali metals",
    "Halogens",
    "Noble gases"
   ],
   "correct": 1,
   "expl": "Group 1 metals form alkaline solutions, hence alkali metals."
  },
  {
   "q": "Group 17 elements are called:",
   "opts": [
    "Alkali metals",
    "Halogens",
    "Noble gases",
    "Transition metals"
   ],
   "correct": 1,
   "expl": "Group 17 elements are the highly reactive halogens."
  },
  {
   "q": "Group 18 elements are called:",
   "opts": [
    "Halogens",
    "Alkali metals",
    "Noble gases",
    "Lanthanides"
   ],
   "correct": 2,
   "expl": "Group 18 gases have full shells and are chemically inert."
  },
  {
   "q": "The period number of an element equals the number of:",
   "opts": [
    "Protons",
    "Electron shells",
    "Valence electrons",
    "Isotopes"
   ],
   "correct": 1,
   "expl": "Elements in the same period have the same number of occupied shells."
  },
  {
   "q": "Atomic radius down a group:",
   "opts": [
    "Decreases",
    "Increases",
    "Remains same",
    "First increases then decreases"
   ],
   "correct": 1,
   "expl": "Each new shell added down a group makes the atom larger."
  },
  {
   "q": "Electronegativity across a period (left to right):",
   "opts": [
    "Decreases",
    "Increases",
    "Remains same",
    "Becomes zero"
   ],
   "correct": 1,
   "expl": "Increasing nuclear charge pulls bonding electrons more strongly."
  },
  {
   "q": "The spreading of gas molecules is described by:",
   "opts": [
    "Boyle's law",
    "Charles's law",
    "Graham's law of diffusion",
    "Dalton's law"
   ],
   "correct": 2,
   "expl": "Graham's law relates diffusion rate to molar mass."
  },
  {
   "q": "Plasma is best described as:",
   "opts": [
    "Solid crystals",
    "Ionized gas",
    "Liquid metal",
    "Compressed air"
   ],
   "correct": 1,
   "expl": "Plasma is a high-energy state of ionized gas."
  },
  {
   "q": "A solution is a:",
   "opts": [
    "Heterogeneous mixture",
    "Homogeneous mixture",
    "Pure compound",
    "Colloid always"
   ],
   "correct": 1,
   "expl": "A solution has uniform composition throughout."
  },
  {
   "q": "In a solution, the component present in larger amount is the:",
   "opts": [
    "Solute",
    "Solvent",
    "Colloid",
    "Suspension"
   ],
   "correct": 1,
   "expl": "The solvent dissolves the solute and is present in greater quantity."
  },
  {
   "q": "A saturated solution:",
   "opts": [
    "Dissolves more solute easily",
    "Cannot dissolve more solute at that temperature",
    "Has no solute",
    "Is always coloured"
   ],
   "correct": 1,
   "expl": "At saturation the solution holds the maximum dissolved solute."
  },
  {
   "q": "Molarity is defined as:",
   "opts": [
    "Moles per kg of solvent",
    "Moles per dm³ of solution",
    "Grams per litre",
    "Moles per mole"
   ],
   "correct": 1,
   "expl": "Molarity = moles of solute per cubic decimetre of solution."
  },
  {
   "q": "One mole of NaCl weighs about:",
   "opts": [
    "23 g",
    "35.5 g",
    "58.5 g",
    "117 g"
   ],
   "correct": 2,
   "expl": "Na (23) + Cl (35.5) = 58.5 g/mol."
  },
  {
   "q": "The chemical symbol of gold is:",
   "opts": [
    "Ag",
    "Au",
    "Gd",
    "Go"
   ],
   "correct": 1,
   "expl": "Gold's symbol Au comes from the Latin aurum."
  },
  {
   "q": "The chemical symbol of silver is:",
   "opts": [
    "Si",
    "Ag",
    "Sr",
    "Sv"
   ],
   "correct": 1,
   "expl": "Silver's symbol Ag comes from the Latin argentum."
  },
  {
   "q": "The chemical symbol of iron is:",
   "opts": [
    "Ir",
    "In",
    "Fe",
    "I"
   ],
   "correct": 2,
   "expl": "Iron's symbol Fe comes from the Latin ferrum."
  },
  {
   "q": "The valency of carbon is:",
   "opts": [
    "2",
    "3",
    "4",
    "6"
   ],
   "correct": 2,
   "expl": "Carbon needs four more electrons to complete its octet."
  },
  {
   "q": "The chemical formula of washing soda is:",
   "opts": [
    "NaHCO₃",
    "Na₂CO₃·10H₂O",
    "CaCO₃",
    "NaOH"
   ],
   "correct": 1,
   "expl": "Washing soda is hydrated sodium carbonate."
  },
  {
   "q": "The chemical formula of baking soda is:",
   "opts": [
    "Na₂CO₃",
    "NaHCO₃",
    "KHCO₃",
    "Ca(HCO₃)₂"
   ],
   "correct": 1,
   "expl": "Baking soda is sodium hydrogen carbonate."
  },
  {
   "q": "Lemon juice is:",
   "opts": [
    "Neutral",
    "Acidic",
    "Basic",
    "A salt"
   ],
   "correct": 1,
   "expl": "Citric acid gives lemon juice a pH below 7."
  },
  {
   "q": "Which of the following is a strong acid?",
   "opts": [
    "CH₃COOH",
    "HCl",
    "H₂CO₃",
    "NH₄OH"
   ],
   "correct": 1,
   "expl": "Hydrochloric acid ionizes completely in water."
  },
  {
   "q": "The law of conservation of mass was given by:",
   "opts": [
    "Dalton",
    "Lavoisier",
    "Proust",
    "Avogadro"
   ],
   "correct": 1,
   "expl": "Lavoisier showed that mass is neither created nor destroyed in reactions."
  },
  {
   "q": "The pH of blood is about:",
   "opts": [
    "6.4",
    "7.4",
    "8.4",
    "5.4"
   ],
   "correct": 1,
   "expl": "Human blood is slightly alkaline at pH 7.4."
  },
  {
   "q": "Which gas turns lime water milky?",
   "opts": [
    "Oxygen",
    "Hydrogen",
    "Carbon dioxide",
    "Nitrogen"
   ],
   "correct": 2,
   "expl": "CO₂ forms insoluble calcium carbonate with lime water."
  }
 ],
 "BIOLOGY9": [
  {
   "q": "The study of plants is called:",
   "opts": [
    "Zoology",
    "Botany",
    "Ecology",
    "Anatomy"
   ],
   "correct": 1,
   "expl": "Botany is the branch of biology dealing with plants."
  },
  {
   "q": "The study of animals is called:",
   "opts": [
    "Botany",
    "Zoology",
    "Mycology",
    "Entomology"
   ],
   "correct": 1,
   "expl": "Zoology is the branch of biology dealing with animals."
  },
  {
   "q": "The power house of the cell is:",
   "opts": [
    "Nucleus",
    "Ribosome",
    "Mitochondria",
    "Chloroplast"
   ],
   "correct": 2,
   "expl": "Mitochondria release energy from food as ATP."
  },
  {
   "q": "The control centre of the cell is:",
   "opts": [
    "Nucleus",
    "Vacuole",
    "Lysosome",
    "Cell wall"
   ],
   "correct": 0,
   "expl": "The nucleus holds DNA and controls cell activities."
  },
  {
   "q": "Photosynthesis takes place in the:",
   "opts": [
    "Mitochondria",
    "Chloroplast",
    "Nucleus",
    "Ribosome"
   ],
   "correct": 1,
   "expl": "Chloroplasts contain chlorophyll that traps sunlight."
  },
  {
   "q": "The cell was discovered by:",
   "opts": [
    "Robert Brown",
    "Robert Hooke",
    "Schleiden",
    "Schwann"
   ],
   "correct": 1,
   "expl": "Robert Hooke saw cork cells in 1665 and named them cells."
  },
  {
   "q": "Cell theory was proposed by:",
   "opts": [
    "Watson and Crick",
    "Schleiden and Schwann",
    "Darwin and Wallace",
    "Hooke and Brown"
   ],
   "correct": 1,
   "expl": "Schleiden and Schwann stated that all organisms are made of cells."
  },
  {
   "q": "The basic structural and functional unit of life is the:",
   "opts": [
    "Tissue",
    "Organ",
    "Cell",
    "System"
   ],
   "correct": 2,
   "expl": "All living things are built from cells."
  },
  {
   "q": "The plasma membrane is:",
   "opts": [
    "Fully permeable",
    "Selectively permeable",
    "Impermeable",
    "Rigid"
   ],
   "correct": 1,
   "expl": "It allows only selected substances to pass through."
  },
  {
   "q": "Ribosomes are the site of:",
   "opts": [
    "Photosynthesis",
    "Protein synthesis",
    "Lipid storage",
    "Energy release"
   ],
   "correct": 1,
   "expl": "Ribosomes join amino acids to make proteins."
  },
  {
   "q": "Lysosomes are called suicide bags because they:",
   "opts": [
    "Store water",
    "Digest the cell's own material",
    "Make proteins",
    "Produce energy"
   ],
   "correct": 1,
   "expl": "Their enzymes can digest worn-out organelles and the cell itself."
  },
  {
   "q": "Enzymes are chemically:",
   "opts": [
    "Carbohydrates",
    "Proteins",
    "Lipids",
    "Nucleic acids"
   ],
   "correct": 1,
   "expl": "Most enzymes are protein molecules that speed up reactions."
  },
  {
   "q": "The raw materials of photosynthesis are:",
   "opts": [
    "Glucose and oxygen",
    "Carbon dioxide and water",
    "Starch and sunlight",
    "Oxygen and water"
   ],
   "correct": 1,
   "expl": "Plants combine CO₂ and water using light energy."
  },
  {
   "q": "The products of photosynthesis are:",
   "opts": [
    "Glucose and oxygen",
    "Carbon dioxide and water",
    "Starch and nitrogen",
    "Proteins and fats"
   ],
   "correct": 0,
   "expl": "Photosynthesis produces glucose and releases oxygen."
  },
  {
   "q": "ATP is called the:",
   "opts": [
    "Building block of proteins",
    "Energy currency of the cell",
    "Genetic material",
    "Cell membrane lipid"
   ],
   "correct": 1,
   "expl": "ATP stores and supplies energy for cellular work."
  },
  {
   "q": "Chlorophyll mainly absorbs:",
   "opts": [
    "Green light",
    "Red and blue light",
    "Yellow light",
    "Infrared"
   ],
   "correct": 1,
   "expl": "Chlorophyll absorbs red and blue light and reflects green."
  },
  {
   "q": "Gaseous exchange in leaves occurs through the:",
   "opts": [
    "Xylem",
    "Phloem",
    "Stomata",
    "Lenticels"
   ],
   "correct": 2,
   "expl": "Stomata are tiny pores that let CO₂ in and O₂ out."
  },
  {
   "q": "Xylem tissue transports:",
   "opts": [
    "Food",
    "Water and minerals",
    "Hormones",
    "Oxygen"
   ],
   "correct": 1,
   "expl": "Xylem carries water and dissolved minerals from roots to leaves."
  },
  {
   "q": "Phloem tissue transports:",
   "opts": [
    "Water",
    "Food (sugars)",
    "Minerals only",
    "Gases"
   ],
   "correct": 1,
   "expl": "Phloem distributes manufactured food to all plant parts."
  },
  {
   "q": "The human heart has:",
   "opts": [
    "2 chambers",
    "3 chambers",
    "4 chambers",
    "1 chamber"
   ],
   "correct": 2,
   "expl": "Two atria and two ventricles make four chambers."
  },
  {
   "q": "Mature red blood cells lack:",
   "opts": [
    "Haemoglobin",
    "Nucleus",
    "Cell membrane",
    "Iron"
   ],
   "correct": 1,
   "expl": "Losing the nucleus gives RBCs more space for haemoglobin."
  },
  {
   "q": "White blood cells mainly:",
   "opts": [
    "Carry oxygen",
    "Fight infection",
    "Clot blood",
    "Carry hormones"
   ],
   "correct": 1,
   "expl": "WBCs defend the body against germs."
  },
  {
   "q": "Blood platelets help in:",
   "opts": [
    "Oxygen transport",
    "Blood clotting",
    "Immunity",
    "Digestion"
   ],
   "correct": 1,
   "expl": "Platelets plug wounds and trigger clot formation."
  },
  {
   "q": "The universal blood donor group is:",
   "opts": [
    "AB positive",
    "O negative",
    "A positive",
    "B negative"
   ],
   "correct": 1,
   "expl": "O negative blood can be given to people of any group."
  },
  {
   "q": "The universal blood recipient group is:",
   "opts": [
    "O negative",
    "AB positive",
    "A negative",
    "O positive"
   ],
   "correct": 1,
   "expl": "AB positive people can receive blood of any group."
  },
  {
   "q": "Digestion of starch begins in the:",
   "opts": [
    "Stomach",
    "Mouth",
    "Small intestine",
    "Large intestine"
   ],
   "correct": 1,
   "expl": "Salivary amylase in the mouth starts starch digestion."
  },
  {
   "q": "Bile juice is produced by the:",
   "opts": [
    "Pancreas",
    "Liver",
    "Gall bladder",
    "Stomach"
   ],
   "correct": 1,
   "expl": "The liver makes bile, which is stored in the gall bladder."
  },
  {
   "q": "Insulin is secreted by the:",
   "opts": [
    "Liver",
    "Pancreas",
    "Thyroid",
    "Adrenal gland"
   ],
   "correct": 1,
   "expl": "Pancreatic beta cells release insulin to lower blood sugar."
  },
  {
   "q": "Deficiency of insulin causes:",
   "opts": [
    "Goitre",
    "Diabetes",
    "Rickets",
    "Anaemia"
   ],
   "correct": 1,
   "expl": "Without insulin, blood glucose stays dangerously high."
  },
  {
   "q": "Deficiency of vitamin C causes:",
   "opts": [
    "Rickets",
    "Night blindness",
    "Scurvy",
    "Beri-beri"
   ],
   "correct": 2,
   "expl": "Lack of vitamin C leads to bleeding gums and scurvy."
  },
  {
   "q": "Deficiency of vitamin D causes:",
   "opts": [
    "Scurvy",
    "Rickets",
    "Anaemia",
    "Goitre"
   ],
   "correct": 1,
   "expl": "Vitamin D is needed for calcium absorption and strong bones."
  },
  {
   "q": "Deficiency of vitamin A causes:",
   "opts": [
    "Scurvy",
    "Rickets",
    "Night blindness",
    "Pellagra"
   ],
   "correct": 2,
   "expl": "Vitamin A maintains the retina; its lack causes night blindness."
  },
  {
   "q": "Deficiency of iodine causes:",
   "opts": [
    "Anaemia",
    "Goitre",
    "Rickets",
    "Scurvy"
   ],
   "correct": 1,
   "expl": "Iodine is needed for thyroid hormones; deficiency swells the gland."
  },
  {
   "q": "Deficiency of iron causes:",
   "opts": [
    "Goitre",
    "Scurvy",
    "Anaemia",
    "Rickets"
   ],
   "correct": 2,
   "expl": "Iron is part of haemoglobin; its lack reduces red blood cells."
  },
  {
   "q": "Mitosis produces:",
   "opts": [
    "2 identical daughter cells",
    "4 different daughter cells",
    "2 different cells",
    "8 identical cells"
   ],
   "correct": 0,
   "expl": "Mitosis divides one cell into two genetically identical cells."
  },
  {
   "q": "Meiosis produces:",
   "opts": [
    "2 identical cells",
    "4 cells with half chromosomes",
    "2 cells with double chromosomes",
    "1 cell"
   ],
   "correct": 1,
   "expl": "Meiosis forms four haploid gametes for sexual reproduction."
  },
  {
   "q": "Chromosomes are made of:",
   "opts": [
    "Lipids and proteins",
    "DNA and proteins",
    "Carbohydrates and DNA",
    "RNA only"
   ],
   "correct": 1,
   "expl": "Chromatin consists of DNA wrapped around histone proteins."
  },
  {
   "q": "The double-helix model of DNA was proposed by:",
   "opts": [
    "Darwin and Wallace",
    "Watson and Crick",
    "Schleiden and Schwann",
    "Lamarck and Mendel"
   ],
   "correct": 1,
   "expl": "Watson and Crick described DNA's double helix in 1953."
  },
  {
   "q": "The five-kingdom system of classification was given by:",
   "opts": [
    "Linnaeus",
    "Whittaker",
    "Aristotle",
    "Darwin"
   ],
   "correct": 1,
   "expl": "Whittaker proposed Monera, Protista, Fungi, Plantae and Animalia."
  },
  {
   "q": "Binomial nomenclature was introduced by:",
   "opts": [
    "Darwin",
    "Linnaeus",
    "Whittaker",
    "Mendel"
   ],
   "correct": 1,
   "expl": "Linnaeus gave every species a two-part Latin name."
  },
  {
   "q": "The scientific name of humans is:",
   "opts": [
    "Homo erectus",
    "Homo sapiens",
    "Pan troglodytes",
    "Australopithecus"
   ],
   "correct": 1,
   "expl": "Modern humans are classified as Homo sapiens."
  },
  {
   "q": "The bacterial cell wall is made of:",
   "opts": [
    "Cellulose",
    "Chitin",
    "Peptidoglycan (murein)",
    "Pectin"
   ],
   "correct": 2,
   "expl": "Peptidoglycan gives bacterial walls their strength."
  },
  {
   "q": "The fungal cell wall is made of:",
   "opts": [
    "Cellulose",
    "Chitin",
    "Peptidoglycan",
    "Starch"
   ],
   "correct": 1,
   "expl": "Fungi use chitin, unlike plants which use cellulose."
  },
  {
   "q": "Viruses were discovered by:",
   "opts": [
    "Fleming",
    "Ivanovsky",
    "Pasteur",
    "Koch"
   ],
   "correct": 1,
   "expl": "Ivanovsky found the first virus while studying tobacco mosaic disease."
  },
  {
   "q": "Penicillin was discovered by:",
   "opts": [
    "Alexander Fleming",
    "Louis Pasteur",
    "Robert Koch",
    "Edward Jenner"
   ],
   "correct": 0,
   "expl": "Fleming noticed Penicillium mould killing bacteria in 1928."
  },
  {
   "q": "Malaria is caused by:",
   "opts": [
    "Bacteria",
    "Plasmodium",
    "Virus",
    "Fungus"
   ],
   "correct": 1,
   "expl": "The Plasmodium parasite causes malaria and spreads via mosquitoes."
  },
  {
   "q": "Dengue fever spreads through the bite of:",
   "opts": [
    "Anopheles mosquito",
    "Aedes mosquito",
    "Housefly",
    "Tsetse fly"
   ],
   "correct": 1,
   "expl": "The Aedes mosquito is the vector of dengue virus."
  },
  {
   "q": "Antibiotics are obtained from:",
   "opts": [
    "Viruses only",
    "Fungi and bacteria",
    "Plants only",
    "Animals only"
   ],
   "correct": 1,
   "expl": "Many antibiotics come from moulds and soil bacteria."
  },
  {
   "q": "Oxygen released during photosynthesis comes from:",
   "opts": [
    "Carbon dioxide",
    "Water",
    "Glucose",
    "Chlorophyll"
   ],
   "correct": 1,
   "expl": "Photolysis splits water, releasing oxygen as a by-product."
  },
  {
   "q": "The loss of water vapour from leaves is called:",
   "opts": [
    "Transpiration",
    "Translocation",
    "Respiration",
    "Guttation"
   ],
   "correct": 0,
   "expl": "Transpiration is the evaporation of water from leaf surfaces."
  }
 ],
 "MATH9": [
  {
   "q": "(a + b)² equals:",
   "opts": [
    "a² + b²",
    "a² + 2ab + b²",
    "a² - 2ab + b²",
    "2a² + 2b²"
   ],
   "correct": 1,
   "expl": "Expanding (a+b)(a+b) gives a² + 2ab + b²."
  },
  {
   "q": "(a - b)² equals:",
   "opts": [
    "a² - b²",
    "a² + 2ab + b²",
    "a² - 2ab + b²",
    "a² + b²"
   ],
   "correct": 2,
   "expl": "Expanding (a-b)(a-b) gives a² - 2ab + b²."
  },
  {
   "q": "a² - b² factorises as:",
   "opts": [
    "(a + b)²",
    "(a - b)²",
    "(a + b)(a - b)",
    "(a + b)(a + b)"
   ],
   "correct": 2,
   "expl": "The difference of squares splits into conjugate factors."
  },
  {
   "q": "(a + b)³ equals:",
   "opts": [
    "a³ + b³",
    "a³ + 3a²b + 3ab² + b³",
    "a³ - 3a²b + 3ab² - b³",
    "3a³ + 3b³"
   ],
   "correct": 1,
   "expl": "The cube of a binomial expands with binomial coefficients 1, 3, 3, 1."
  },
  {
   "q": "log(mn) equals:",
   "opts": [
    "log m + log n",
    "log m - log n",
    "log m × log n",
    "n log m"
   ],
   "correct": 0,
   "expl": "The log of a product is the sum of the logs."
  },
  {
   "q": "log(m/n) equals:",
   "opts": [
    "log m + log n",
    "log m - log n",
    "log m × log n",
    "log n - log m"
   ],
   "correct": 1,
   "expl": "The log of a quotient is the difference of the logs."
  },
  {
   "q": "log(mⁿ) equals:",
   "opts": [
    "m log n",
    "n log m",
    "log m + n",
    "(log m)ⁿ"
   ],
   "correct": 1,
   "expl": "The log of a power brings the exponent down as a multiplier."
  },
  {
   "q": "The value of log₁₀10 is:",
   "opts": [
    "0",
    "1",
    "10",
    "-1"
   ],
   "correct": 1,
   "expl": "Log of the base itself is always 1."
  },
  {
   "q": "The value of log 1 is:",
   "opts": [
    "1",
    "0",
    "10",
    "Undefined"
   ],
   "correct": 1,
   "expl": "Any number raised to power 0 is 1, so log 1 = 0."
  },
  {
   "q": "A matrix with equal number of rows and columns is:",
   "opts": [
    "Rectangular",
    "Square",
    "Row",
    "Column"
   ],
   "correct": 1,
   "expl": "A square matrix has the same number of rows and columns."
  },
  {
   "q": "An identity matrix has:",
   "opts": [
    "All elements 1",
    "Diagonal elements 1, others 0",
    "All elements 0",
    "First row 1"
   ],
   "correct": 1,
   "expl": "The identity matrix has ones on the main diagonal and zeros elsewhere."
  },
  {
   "q": "A null (zero) matrix has:",
   "opts": [
    "All elements 0",
    "All elements 1",
    "Diagonal 1",
    "No elements"
   ],
   "correct": 0,
   "expl": "Every entry of a null matrix is zero."
  },
  {
   "q": "The determinant of |a b; c d| is:",
   "opts": [
    "ad + bc",
    "ad - bc",
    "ac - bd",
    "ab - cd"
   ],
   "correct": 1,
   "expl": "For a 2×2 matrix, determinant = ad - bc."
  },
  {
   "q": "(Aᵗ)ᵗ equals:",
   "opts": [
    "-A",
    "A",
    "Aᵗ + A",
    "2A"
   ],
   "correct": 1,
   "expl": "Transposing a matrix twice returns the original matrix."
  },
  {
   "q": "The sum of interior angles of a triangle is:",
   "opts": [
    "90°",
    "180°",
    "270°",
    "360°"
   ],
   "correct": 1,
   "expl": "The three interior angles of any triangle add to 180°."
  },
  {
   "q": "In a right triangle, c² equals (c = hypotenuse):",
   "opts": [
    "a² - b²",
    "a² + b²",
    "a + b",
    "2ab"
   ],
   "correct": 1,
   "expl": "Pythagoras theorem states hypotenuse² = sum of squares of the other sides."
  },
  {
   "q": "Two complementary angles sum to:",
   "opts": [
    "90°",
    "180°",
    "270°",
    "360°"
   ],
   "correct": 0,
   "expl": "Complementary angles add up to a right angle."
  },
  {
   "q": "Two supplementary angles sum to:",
   "opts": [
    "90°",
    "180°",
    "270°",
    "360°"
   ],
   "correct": 1,
   "expl": "Supplementary angles add up to a straight angle."
  },
  {
   "q": "Vertically opposite angles are:",
   "opts": [
    "Supplementary",
    "Complementary",
    "Equal",
    "Unequal"
   ],
   "correct": 2,
   "expl": "When two lines cross, opposite angles formed are equal."
  },
  {
   "q": "A rational number can be written in the form:",
   "opts": [
    "p/q (q ≠ 0)",
    "p²/q",
    "p + qi",
    "Only integers"
   ],
   "correct": 0,
   "expl": "Rational numbers are ratios of integers with non-zero denominator."
  },
  {
   "q": "π (pi) is a/an:",
   "opts": [
    "Rational number",
    "Irrational number",
    "Integer",
    "Natural number"
   ],
   "correct": 1,
   "expl": "Pi is a non-terminating, non-repeating decimal."
  },
  {
   "q": "√2 is a/an:",
   "opts": [
    "Rational number",
    "Integer",
    "Irrational number",
    "Whole number"
   ],
   "correct": 2,
   "expl": "The square root of 2 cannot be written as a fraction."
  },
  {
   "q": "A complex number has the form:",
   "opts": [
    "a + b",
    "a - b",
    "a + bi",
    "ab²"
   ],
   "correct": 2,
   "expl": "Complex numbers combine a real part a and imaginary part bi."
  },
  {
   "q": "The value of i² is:",
   "opts": [
    "1",
    "-1",
    "i",
    "0"
   ],
   "correct": 1,
   "expl": "By definition the imaginary unit satisfies i² = -1."
  },
  {
   "q": "The conjugate of a + bi is:",
   "opts": [
    "a - bi",
    "-a + bi",
    "a + bi",
    "-a - bi"
   ],
   "correct": 0,
   "expl": "Conjugation changes the sign of the imaginary part."
  },
  {
   "q": "The modulus |a + bi| equals:",
   "opts": [
    "√(a² + b²)",
    "√(a + b)",
    "a² + b²",
    "|a| + |b|"
   ],
   "correct": 0,
   "expl": "Modulus is the distance from the origin in the complex plane."
  },
  {
   "q": "The solution of 2x + 3 = 7 is:",
   "opts": [
    "x = 1",
    "x = 2",
    "x = 3",
    "x = 5"
   ],
   "correct": 1,
   "expl": "Subtracting 3 gives 2x = 4, so x = 2."
  },
  {
   "q": "The solution of x - 5 = 0 is:",
   "opts": [
    "x = -5",
    "x = 0",
    "x = 5",
    "x = 1/5"
   ],
   "correct": 2,
   "expl": "Adding 5 to both sides gives x = 5."
  },
  {
   "q": "The HCF of 12 and 18 is:",
   "opts": [
    "3",
    "6",
    "9",
    "36"
   ],
   "correct": 1,
   "expl": "The greatest common divisor of 12 and 18 is 6."
  },
  {
   "q": "The LCM of 4 and 6 is:",
   "opts": [
    "10",
    "12",
    "24",
    "2"
   ],
   "correct": 1,
   "expl": "The smallest common multiple of 4 and 6 is 12."
  },
  {
   "q": "x² - 9 factorises as:",
   "opts": [
    "(x + 9)(x - 9)",
    "(x + 3)(x - 3)",
    "(x + 3)²",
    "(x - 3)²"
   ],
   "correct": 1,
   "expl": "It is a difference of squares: 9 = 3²."
  },
  {
   "q": "x² + 5x + 6 factorises as:",
   "opts": [
    "(x + 1)(x + 6)",
    "(x + 2)(x + 3)",
    "(x - 2)(x - 3)",
    "(x + 5)(x + 1)"
   ],
   "correct": 1,
   "expl": "Two numbers with product 6 and sum 5 are 2 and 3."
  },
  {
   "q": "x³ - 8 factorises as:",
   "opts": [
    "(x - 2)(x² + 2x + 4)",
    "(x + 2)(x² - 2x + 4)",
    "(x - 2)³",
    "(x - 8)(x² + 1)"
   ],
   "correct": 0,
   "expl": "It is a difference of cubes: a³ - b³ = (a-b)(a²+ab+b²)."
  },
  {
   "q": "The degree of the polynomial 4x³ + 2x is:",
   "opts": [
    "2",
    "3",
    "4",
    "1"
   ],
   "correct": 1,
   "expl": "The degree is the highest power of x, which is 3."
  },
  {
   "q": "Which of the following is a surd?",
   "opts": [
    "√4",
    "√9",
    "√3",
    "√16"
   ],
   "correct": 2,
   "expl": "√3 is irrational, while the others simplify to integers."
  },
  {
   "q": "The rationalising factor of √a is:",
   "opts": [
    "a",
    "√a",
    "1/a",
    "-a"
   ],
   "correct": 1,
   "expl": "Multiplying √a by √a gives the rational number a."
  },
  {
   "q": "log₂8 equals:",
   "opts": [
    "2",
    "3",
    "4",
    "8"
   ],
   "correct": 1,
   "expl": "Since 2³ = 8, log₂8 = 3."
  },
  {
   "q": "log₃27 equals:",
   "opts": [
    "2",
    "9",
    "3",
    "27"
   ],
   "correct": 2,
   "expl": "Since 3³ = 27, log₃27 = 3."
  },
  {
   "q": "If log x = 2 (base 10), then x equals:",
   "opts": [
    "2",
    "20",
    "100",
    "1000"
   ],
   "correct": 2,
   "expl": "x = 10² = 100 by the definition of logarithm."
  },
  {
   "q": "Two parallel lines have:",
   "opts": [
    "One solution",
    "No solution",
    "Infinite solutions",
    "Two solutions"
   ],
   "correct": 1,
   "expl": "Parallel lines never meet, so the system is inconsistent."
  },
  {
   "q": "Two intersecting lines have:",
   "opts": [
    "No solution",
    "A unique solution",
    "Infinite solutions",
    "Two solutions"
   ],
   "correct": 1,
   "expl": "They meet at exactly one point."
  },
  {
   "q": "Two coincident lines have:",
   "opts": [
    "No solution",
    "One solution",
    "Infinitely many solutions",
    "Two solutions"
   ],
   "correct": 2,
   "expl": "Coincident lines share every point."
  },
  {
   "q": "The elimination method is used to solve:",
   "opts": [
    "Quadratic equations",
    "Simultaneous linear equations",
    "Cubic equations",
    "Inequalities"
   ],
   "correct": 1,
   "expl": "Elimination removes one variable from a pair of equations."
  },
  {
   "q": "An angle bisector divides an angle into:",
   "opts": [
    "Three equal parts",
    "Two equal parts",
    "Two unequal parts",
    "Four parts"
   ],
   "correct": 1,
   "expl": "A bisector splits a quantity into two equal halves."
  },
  {
   "q": "The perpendicular bisector of a segment:",
   "opts": [
    "Passes through an endpoint",
    "Passes through the midpoint at 90°",
    "Is parallel to the segment",
    "Bisects the angle"
   ],
   "correct": 1,
   "expl": "It crosses the midpoint perpendicularly."
  },
  {
   "q": "A median of a triangle joins a vertex to the:",
   "opts": [
    "Opposite vertex",
    "Midpoint of the opposite side",
    "Circumcentre",
    "Incentre"
   ],
   "correct": 1,
   "expl": "A median connects a vertex to the midpoint of the opposite side."
  },
  {
   "q": "Each angle of an equilateral triangle measures:",
   "opts": [
    "45°",
    "60°",
    "90°",
    "120°"
   ],
   "correct": 1,
   "expl": "180° divided equally among three angles gives 60° each."
  },
  {
   "q": "An isosceles triangle has:",
   "opts": [
    "No equal sides",
    "Two equal sides",
    "All sides equal",
    "One right angle"
   ],
   "correct": 1,
   "expl": "Isosceles means two sides (and two base angles) are equal."
  },
  {
   "q": "The sum of exterior angles of any polygon is:",
   "opts": [
    "180°",
    "270°",
    "360°",
    "90°"
   ],
   "correct": 2,
   "expl": "Walking once around any polygon turns you through 360°."
  },
  {
   "q": "In a right triangle, the hypotenuse is the:",
   "opts": [
    "Shortest side",
    "Longest side",
    "Side opposite 30°",
    "Adjacent side"
   ],
   "correct": 1,
   "expl": "The hypotenuse lies opposite the largest angle (90°)."
  }
 ],
 "ENGLISH9": [
  {
   "q": "Choose the synonym of BRAVE:",
   "opts": [
    "Timid",
    "Courageous",
    "Cowardly",
    "Weak"
   ],
   "correct": 1,
   "expl": "Courageous means showing bravery."
  },
  {
   "q": "Choose the antonym of ANCIENT:",
   "opts": [
    "Old",
    "Antique",
    "Modern",
    "Aged"
   ],
   "correct": 2,
   "expl": "Modern is the opposite of ancient."
  },
  {
   "q": "She ___ to school daily.",
   "opts": [
    "go",
    "goes",
    "going",
    "gone"
   ],
   "correct": 1,
   "expl": "With third-person singular 'she', the verb takes -s."
  },
  {
   "q": "They ___ playing now.",
   "opts": [
    "is",
    "are",
    "was",
    "has"
   ],
   "correct": 1,
   "expl": "'They' takes the plural verb 'are' in present continuous."
  },
  {
   "q": "I have ___ my homework.",
   "opts": [
    "do",
    "done",
    "did",
    "doing"
   ],
   "correct": 1,
   "expl": "Present perfect uses have + past participle 'done'."
  },
  {
   "q": "___ apple a day keeps the doctor away.",
   "opts": [
    "A",
    "An",
    "The",
    "No article"
   ],
   "correct": 1,
   "expl": "'An' is used before vowel sounds like 'apple'."
  },
  {
   "q": "He is ___ university student.",
   "opts": [
    "a",
    "an",
    "the",
    "no article"
   ],
   "correct": 0,
   "expl": "'A' is used because 'university' begins with a 'yu' consonant sound."
  },
  {
   "q": "He is fond ___ music.",
   "opts": [
    "of",
    "in",
    "at",
    "for"
   ],
   "correct": 0,
   "expl": "The adjective 'fond' is followed by 'of'."
  },
  {
   "q": "She is afraid ___ dogs.",
   "opts": [
    "from",
    "of",
    "by",
    "with"
   ],
   "correct": 1,
   "expl": "'Afraid' takes the preposition 'of'."
  },
  {
   "q": "He died ___ cancer.",
   "opts": [
    "from",
    "of",
    "by",
    "with"
   ],
   "correct": 1,
   "expl": "We say 'die of' a disease."
  },
  {
   "q": "Choose the passive voice: She writes a letter.",
   "opts": [
    "A letter is written by her.",
    "A letter was written by her.",
    "A letter has been written by her.",
    "She is written by a letter."
   ],
   "correct": 0,
   "expl": "Present simple passive uses is + past participle."
  },
  {
   "q": "Choose the passive voice: He broke the glass.",
   "opts": [
    "The glass is broken by him.",
    "The glass was broken by him.",
    "The glass has broken by him.",
    "He was broken by the glass."
   ],
   "correct": 1,
   "expl": "Past simple passive uses was/were + past participle."
  },
  {
   "q": "Choose the indirect speech: He said, “I am tired.”",
   "opts": [
    "He said that he is tired.",
    "He said that he was tired.",
    "He said that I was tired.",
    "He says that he was tired."
   ],
   "correct": 1,
   "expl": "In reported speech, present simple shifts to past simple."
  },
  {
   "q": "The noun form of DECIDE is:",
   "opts": [
    "Decisive",
    "Decision",
    "Decided",
    "Deciding"
   ],
   "correct": 1,
   "expl": "'Decision' is the noun made from the verb 'decide'."
  },
  {
   "q": "The adjective form of BEAUTY is:",
   "opts": [
    "Beautify",
    "Beautiful",
    "Beautifully",
    "Beautician"
   ],
   "correct": 1,
   "expl": "'Beautiful' describes a noun, so it is the adjective."
  },
  {
   "q": "The adverb form of QUICK is:",
   "opts": [
    "Quicker",
    "Quickest",
    "Quickly",
    "Quickness"
   ],
   "correct": 2,
   "expl": "Adding -ly to the adjective forms the adverb."
  },
  {
   "q": "The plural of CHILD is:",
   "opts": [
    "Childs",
    "Childes",
    "Children",
    "Childrens"
   ],
   "correct": 2,
   "expl": "'Children' is the irregular plural of 'child'."
  },
  {
   "q": "The plural of TOOTH is:",
   "opts": [
    "Tooths",
    "Teeth",
    "Toothes",
    "Toothies"
   ],
   "correct": 1,
   "expl": "'Teeth' is the irregular plural of 'tooth'."
  },
  {
   "q": "The plural of MOUSE (animal) is:",
   "opts": [
    "Mouses",
    "Mice",
    "Meese",
    "Mousen"
   ],
   "correct": 1,
   "expl": "'Mice' is the irregular plural of 'mouse'."
  },
  {
   "q": "The feminine of KING is:",
   "opts": [
    "Queen",
    "Kingship",
    "Lady",
    "Mistress"
   ],
   "correct": 0,
   "expl": "'Queen' is the female counterpart of 'king'."
  },
  {
   "q": "The feminine of ACTOR is:",
   "opts": [
    "Actress",
    "Actoress",
    "Actrix",
    "Female actor"
   ],
   "correct": 0,
   "expl": "'Actress' is the feminine form of 'actor'."
  },
  {
   "q": "The comparative degree of GOOD is:",
   "opts": [
    "Gooder",
    "Better",
    "Best",
    "More good"
   ],
   "correct": 1,
   "expl": "'Better' is the irregular comparative of 'good'."
  },
  {
   "q": "The superlative degree of BAD is:",
   "opts": [
    "Bader",
    "Worst",
    "Worse",
    "Baddest"
   ],
   "correct": 1,
   "expl": "'Worst' is the superlative of 'bad'."
  },
  {
   "q": "Neither of the answers ___ correct.",
   "opts": [
    "are",
    "is",
    "were",
    "have"
   ],
   "correct": 1,
   "expl": "'Neither' is singular, so it takes a singular verb."
  },
  {
   "q": "Each of the boys ___ present.",
   "opts": [
    "were",
    "are",
    "was",
    "have"
   ],
   "correct": 2,
   "expl": "'Each' is singular and takes a singular verb."
  },
  {
   "q": "Choose the correctly spelt word:",
   "opts": [
    "Recieve",
    "Receive",
    "Riceive",
    "Receeve"
   ],
   "correct": 1,
   "expl": "'Receive' follows the i-before-e-except-after-c rule."
  },
  {
   "q": "Choose the correctly spelt word:",
   "opts": [
    "Beautifull",
    "Beautiful",
    "Beutiful",
    "Beautifel"
   ],
   "correct": 1,
   "expl": "'Beautiful' is the correct spelling."
  },
  {
   "q": "Choose the synonym of RAPID:",
   "opts": [
    "Slow",
    "Fast",
    "Late",
    "Calm"
   ],
   "correct": 1,
   "expl": "'Rapid' means happening quickly, like 'fast'."
  },
  {
   "q": "Choose the antonym of VICTORY:",
   "opts": [
    "Win",
    "Triumph",
    "Defeat",
    "Success"
   ],
   "correct": 2,
   "expl": "'Defeat' is the opposite of 'victory'."
  },
  {
   "q": "One who can use both hands equally well is:",
   "opts": [
    "Versatile",
    "Ambidextrous",
    "Ambiguous",
    "Bilingual"
   ],
   "correct": 1,
   "expl": "'Ambidextrous' literally means right-handed on both sides."
  },
  {
   "q": "A place where birds are kept is:",
   "opts": [
    "Apiary",
    "Aviary",
    "Aquarium",
    "Stable"
   ],
   "correct": 1,
   "expl": "An aviary houses birds."
  },
  {
   "q": "“I had finished before he came” is in:",
   "opts": [
    "Past simple",
    "Past perfect",
    "Present perfect",
    "Past continuous"
   ],
   "correct": 1,
   "expl": "'Had + past participle' marks the past perfect tense."
  },
  {
   "q": "“She will have left by then” is in:",
   "opts": [
    "Future simple",
    "Future continuous",
    "Future perfect",
    "Present perfect"
   ],
   "correct": 2,
   "expl": "'Will have + past participle' marks the future perfect."
  },
  {
   "q": "Choose the active voice: The cake was baked by mother.",
   "opts": [
    "Mother baked the cake.",
    "Mother bakes the cake.",
    "The cake baked mother.",
    "Mother was baked by the cake."
   ],
   "correct": 0,
   "expl": "Active voice puts the doer 'mother' as the subject."
  },
  {
   "q": "He said to me, “Are you ill?” (indirect):",
   "opts": [
    "He asked me if I was ill.",
    "He said me am I ill.",
    "He asked me was I ill.",
    "He told me I am ill."
   ],
   "correct": 0,
   "expl": "Yes/no questions are reported with if/whether and past tense."
  },
  {
   "q": "He jumped ___ the river.",
   "opts": [
    "in",
    "into",
    "on",
    "at"
   ],
   "correct": 1,
   "expl": "'Into' shows movement from outside to inside."
  },
  {
   "q": "Divide the money ___ the two brothers.",
   "opts": [
    "among",
    "between",
    "amid",
    "within"
   ],
   "correct": 1,
   "expl": "'Between' is used for two persons."
  },
  {
   "q": "Divide the sweets ___ the three children.",
   "opts": [
    "between",
    "among",
    "amidst",
    "into"
   ],
   "correct": 1,
   "expl": "'Among' is used for more than two."
  },
  {
   "q": "“Give up” means:",
   "opts": [
    "Lift",
    "Quit",
    "Distribute",
    "Continue"
   ],
   "correct": 1,
   "expl": "'Give up' is a phrasal verb meaning to stop or quit."
  },
  {
   "q": "“Look after” means:",
   "opts": [
    "Search",
    "Take care of",
    "Ignore",
    "Watch"
   ],
   "correct": 1,
   "expl": "'Look after' means to take care of someone."
  },
  {
   "q": "“Break the ice” means:",
   "opts": [
    "Break frozen water",
    "Start a conversation",
    "End friendship",
    "Feel cold"
   ],
   "correct": 1,
   "expl": "The idiom means to make a start and ease tension."
  },
  {
   "q": "“A blessing in disguise” means:",
   "opts": [
    "A hidden benefit",
    "A religious gift",
    "A curse",
    "A prayer"
   ],
   "correct": 0,
   "expl": "It describes something good hidden in apparent misfortune."
  },
  {
   "q": "They lost ___ books.",
   "opts": [
    "their",
    "there",
    "they're",
    "theirselves"
   ],
   "correct": 0,
   "expl": "'Their' is the possessive adjective needed here."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "He don't like tea.",
    "He doesn't like tea.",
    "He not like tea.",
    "He doesn't likes tea."
   ],
   "correct": 1,
   "expl": "Third-person singular needs 'doesn't' + base verb."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "I am agree with you.",
    "I agree with you.",
    "I agrees with you.",
    "I am agreed with you."
   ],
   "correct": 1,
   "expl": "'Agree' is a verb and needs no helping verb here."
  },
  {
   "q": "The sun rises in the east. The article is used because:",
   "opts": [
    "Sun is countable",
    "East is a unique direction",
    "Sun is a proper noun",
    "It is a habit"
   ],
   "correct": 1,
   "expl": "'The' is used with unique things and fixed directions."
  },
  {
   "q": "She has ___ books. (many/much)",
   "opts": [
    "much",
    "many",
    "more much",
    "most"
   ],
   "correct": 1,
   "expl": "'Many' is used with countable plural nouns."
  },
  {
   "q": "You are coming, ___?",
   "opts": [
    "isn't you",
    "aren't you",
    "don't you",
    "isn't it"
   ],
   "correct": 1,
   "expl": "The tag for 'you are' is 'aren't you'."
  },
  {
   "q": "AFFECT is a ___, while EFFECT is usually a ___.",
   "opts": [
    "noun, verb",
    "verb, noun",
    "adjective, verb",
    "verb, adjective"
   ],
   "correct": 1,
   "expl": "'Affect' means to influence (verb); 'effect' means a result (noun)."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "He go to school.",
    "He goes to school.",
    "He going to school.",
    "He gone to school."
   ],
   "correct": 1,
   "expl": "Third-person singular 'he' needs the -s form 'goes'."
  }
 ],
 "URDU9": [
  {
   "q": "خوشی کا متضاد ہے:",
   "opts": [
    "مسرت",
    "غمی",
    "راحت",
    "آرام"
   ],
   "correct": 1,
   "expl": "خوشی کا الٹ غمی ہے۔"
  },
  {
   "q": "سچ کا متضاد ہے:",
   "opts": [
    "حق",
    "جھوٹ",
    "درست",
    "نیک"
   ],
   "correct": 1,
   "expl": "سچ کا الٹ جھوٹ ہے۔"
  },
  {
   "q": "روشن کا متضاد ہے:",
   "opts": [
    "چمکدار",
    "تاریک",
    "نورانی",
    "صاف"
   ],
   "correct": 1,
   "expl": "روشن کا الٹ تاریک (اندھیرا) ہے۔"
  },
  {
   "q": "کتاب کی جمع ہے:",
   "opts": [
    "کتابیں",
    "کتب",
    "کتابوں",
    "کتابیات"
   ],
   "correct": 1,
   "expl": "کتاب کی جمع کتب ہے۔"
  },
  {
   "q": "لڑکا کی جمع ہے:",
   "opts": [
    "لڑکے",
    "لڑکیاں",
    "لڑکوں",
    "لڑکیان"
   ],
   "correct": 0,
   "expl": "لڑکا کی جمع لڑکے ہے۔"
  },
  {
   "q": "علم کے معنی ہیں:",
   "opts": [
    "دولت",
    "جاننا / دانش",
    "طاقت",
    "حکومت"
   ],
   "correct": 1,
   "expl": "علم کا مطلب جاننا یا دانش ہے۔"
  },
  {
   "q": "شجاع کے معنی ہیں:",
   "opts": [
    "بزدل",
    "بہادر",
    "کمزور",
    "سست"
   ],
   "correct": 1,
   "expl": "شجاع بہادر کو کہتے ہیں۔"
  },
  {
   "q": "دوست کا مترادف ہے:",
   "opts": [
    "دشمن",
    "رفیق",
    "عدو",
    "حریف"
   ],
   "correct": 1,
   "expl": "رفیق دوست کا ہم معنی لفظ ہے۔"
  },
  {
   "q": "دشمن کا مترادف ہے:",
   "opts": [
    "دوست",
    "عدو",
    "رفیق",
    "یار"
   ],
   "correct": 1,
   "expl": "عدو دشمن کا مترادف ہے۔"
  },
  {
   "q": "وہ ضمیر کی کون سی قسم ہے؟",
   "opts": [
    "ضمیر متکلم",
    "ضمیر حاضر",
    "ضمیر غائب",
    "ضمیر موصول"
   ],
   "correct": 2,
   "expl": "وہ غائب شخص کے لیے استعمال ہوتا ہے۔"
  },
  {
   "q": "میں اور ہم ضمیر کی کون سی قسم ہیں؟",
   "opts": [
    "ضمیر متکلم",
    "ضمیر حاضر",
    "ضمیر غائب",
    "ضمیر اشارہ"
   ],
   "correct": 0,
   "expl": "میں اور ہم بولنے والے کے لیے آتے ہیں۔"
  },
  {
   "q": "تم اور آپ ضمیر کی کون سی قسم ہیں؟",
   "opts": [
    "ضمیر متکلم",
    "ضمیر حاضر",
    "ضمیر غائب",
    "ضمیر استفہام"
   ],
   "correct": 1,
   "expl": "تم اور آپ مخاطب کے لیے استعمال ہوتے ہیں۔"
  },
  {
   "q": "جو اسم کسی خاص شخص یا چیز کا نام ہو اسے کہتے ہیں:",
   "opts": [
    "اسم نکرہ",
    "اسم معرفہ",
    "اسم صفت",
    "اسم ضمیر"
   ],
   "correct": 1,
   "expl": "خاص نام والے اسم کو اسم معرفہ کہتے ہیں۔"
  },
  {
   "q": "پڑھتا ہے میں زمانہ ہے:",
   "opts": [
    "ماضی",
    "حال",
    "مستقبل",
    "امر"
   ],
   "correct": 1,
   "expl": "تا ہے والا فعل زمانہ حال کو ظاہر کرتا ہے۔"
  },
  {
   "q": "پڑھے گا میں زمانہ ہے:",
   "opts": [
    "ماضی",
    "حال",
    "مستقبل",
    "حال مطلق"
   ],
   "correct": 2,
   "expl": "گا والا فعل آئندہ زمانے کو ظاہر کرتا ہے۔"
  },
  {
   "q": "چکا یا تھا والا فعل زمانہ ماضی کی پہچان ہے۔",
   "opts": [
    "صحیح",
    "غلط",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "ماضی کے فعل کے ساتھ چکا یا تھا آتا ہے۔"
  },
  {
   "q": "محاورہ آنکھوں کا تارا کا مطلب ہے:",
   "opts": [
    "بہت پیارا",
    "بہت دور",
    "روشن چیز",
    "ناپسندیدہ"
   ],
   "correct": 0,
   "expl": "آنکھوں کا تارا بہت پیارے بچے کو کہتے ہیں۔"
  },
  {
   "q": "ناک میں دم کرنا کا مطلب ہے:",
   "opts": [
    "خوش کرنا",
    "تنگ کرنا",
    "مدد کرنا",
    "بھاگ جانا"
   ],
   "correct": 1,
   "expl": "یہ محاورہ کسی کو تنگ کرنے کے لیے استعمال ہوتا ہے۔"
  },
  {
   "q": "چار چاند لگانا کا مطلب ہے:",
   "opts": [
    "روشنی کرنا",
    "رونق بڑھانا",
    "چاند دیکھنا",
    "اندھیرا کرنا"
   ],
   "correct": 1,
   "expl": "چار چاند لگانا رونق بڑھانے کو کہتے ہیں۔"
  },
  {
   "q": "باغ باغ ہونا کا مطلب ہے:",
   "opts": [
    "بہت خوش ہونا",
    "باغ میں جانا",
    "پھول توڑنا",
    "درخت لگانا"
   ],
   "correct": 0,
   "expl": "باغ باغ ہونا بہت خوش ہونے کو کہتے ہیں۔"
  },
  {
   "q": "اونٹ کے منہ میں زیرہ کا مطلب ہے:",
   "opts": [
    "بہت زیادہ",
    "بہت کم",
    "مناسب مقدار",
    "کوچھ نہیں"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل بہت کم مقدار کے لیے ہے۔"
  },
  {
   "q": "نو دو گیارہ ہونا کا مطلب ہے:",
   "opts": [
    "حاضر ہونا",
    "بھاگ جانا",
    "آنا",
    "جانا"
   ],
   "correct": 1,
   "expl": "نو دو گیارہ ہونا چپکے سے بھاگ جانے کو کہتے ہیں۔"
  },
  {
   "q": "جیسا کرو گے ویسا بھرو گے یہ ہے:",
   "opts": [
    "محاورہ",
    "ضرب المثل",
    "روزمرہ",
    "تلمیح"
   ],
   "correct": 1,
   "expl": "یہ مشہور ضرب المثل ہے کہ اعمال کا بدلہ ملتا ہے۔"
  },
  {
   "q": "اسم صفت وہ لفظ ہے جو:",
   "opts": [
    "کام کو ظاہر کرے",
    "اسم کی خوبی یا خامی بیان کرے",
    "زمانہ بتائے",
    "جگہ بتائے"
   ],
   "correct": 1,
   "expl": "اسم صفت اسم کی خوبی یا خامی بیان کرتا ہے۔"
  },
  {
   "q": "اچھا لڑکا میں صفت ہے:",
   "opts": [
    "اچھا",
    "لڑکا",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "اچھا لڑکے کی خوبی بیان کر رہا ہے۔"
  },
  {
   "q": "حرف جار کی مثال ہے:",
   "opts": [
    "میں، پر، سے",
    "کیا، کب",
    "وہ، یہ",
    "اور، لیکن"
   ],
   "correct": 0,
   "expl": "میں، پر، سے حروف جار ہیں۔"
  },
  {
   "q": "مسجد کی جمع ہے:",
   "opts": [
    "مساجد",
    "مسجدوں",
    "مسجدیں",
    "مسجدیات"
   ],
   "correct": 0,
   "expl": "مسجد کی جمع مساجد ہے۔"
  },
  {
   "q": "دعا کی جمع ہے:",
   "opts": [
    "دعویں",
    "دعائیں",
    "ادعیہ",
    "دعات"
   ],
   "correct": 1,
   "expl": "دعا کی جمع دعائیں ہے۔"
  },
  {
   "q": "بچہ کی جمع ہے:",
   "opts": [
    "بچوں",
    "بچے",
    "بچیاں",
    "بچیوں"
   ],
   "correct": 1,
   "expl": "بچہ کی جمع بچے ہے۔"
  },
  {
   "q": "کتاب تذکیر یا تانیث؟",
   "opts": [
    "مذکر",
    "مونث",
    "--",
    "--"
   ],
   "correct": 1,
   "expl": "کتاب مونث ہے۔"
  },
  {
   "q": "قلم تذکیر یا تانیث؟",
   "opts": [
    "مذکر",
    "مونث",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "قلم مذکر ہے۔"
  },
  {
   "q": "دروازہ تذکیر یا تانیث؟",
   "opts": [
    "مذکر",
    "مونث",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "دروازہ مذکر ہے۔"
  },
  {
   "q": "کرسی تذکیر یا تانیث؟",
   "opts": [
    "مذکر",
    "مونث",
    "--",
    "--"
   ],
   "correct": 1,
   "expl": "کرسی مونث ہے۔"
  },
  {
   "q": "سابقہ بد کا مطلب ہے:",
   "opts": [
    "اچھا",
    "برا",
    "نیا",
    "پرانا"
   ],
   "correct": 1,
   "expl": "بد کا مطلب برا ہے جیسے بدتمیز۔"
  },
  {
   "q": "لاحقہ دار کا مطلب ہے:",
   "opts": [
    "دینے والا",
    "رکھنے والا",
    "والا",
    "بنانے والا"
   ],
   "correct": 2,
   "expl": "دار کا مطلب والا ہے جیسے زمیندار۔"
  },
  {
   "q": "خوش کا متضاد ہے:",
   "opts": [
    "ناخوش",
    "مسرور",
    "شاد",
    "مست"
   ],
   "correct": 0,
   "expl": "خوش کا الٹ ناخوش ہے۔"
  },
  {
   "q": "امیری کا متضاد ہے:",
   "opts": [
    "دولت مندی",
    "غریبی",
    "تنگدستی",
    "فقیری"
   ],
   "correct": 1,
   "expl": "امیری کا الٹ غریبی ہے۔"
  },
  {
   "q": "دن کا متضاد ہے:",
   "opts": [
    "صبح",
    "شام",
    "رات",
    "دوپہر"
   ],
   "correct": 2,
   "expl": "دن کا الٹ رات ہے۔"
  },
  {
   "q": "آسمان کا متضاد ہے:",
   "opts": [
    "بادل",
    "ستارہ",
    "زمین",
    "سمندر"
   ],
   "correct": 2,
   "expl": "آسمان کا الٹ زمین ہے۔"
  },
  {
   "q": "زندگی کا متضاد ہے:",
   "opts": [
    "حیات",
    "موت",
    "نیند",
    "بیداری"
   ],
   "correct": 1,
   "expl": "زندگی کا الٹ موت ہے۔"
  },
  {
   "q": "آغاز کا متضاد ہے:",
   "opts": [
    "شروع",
    "انجام",
    "ابتدا",
    "پہلا"
   ],
   "correct": 1,
   "expl": "آغاز کا الٹ انجام ہے۔"
  },
  {
   "q": "کامیابی کا متضاد ہے:",
   "opts": [
    "فتح",
    "ناکامی",
    "عزت",
    "شہرت"
   ],
   "correct": 1,
   "expl": "کامیابی کا الٹ ناکامی ہے۔"
  },
  {
   "q": "محبت کا متضاد ہے:",
   "opts": [
    "الفت",
    "نفرت",
    "پیار",
    "دوستی"
   ],
   "correct": 1,
   "expl": "محبت کا الٹ نفرت ہے۔"
  },
  {
   "q": "سرد کا متضاد ہے:",
   "opts": [
    "ٹھنڈا",
    "گرم",
    "نم",
    "خشک"
   ],
   "correct": 1,
   "expl": "سرد کا الٹ گرم ہے۔"
  },
  {
   "q": "نیکی کا متضاد ہے:",
   "opts": [
    "ثواب",
    "بدی",
    "اجر",
    "حسنہ"
   ],
   "correct": 1,
   "expl": "نیکی کا الٹ بدی ہے۔"
  },
  {
   "q": "صبح کا متضاد ہے:",
   "opts": [
    "سحر",
    "شام",
    "دوپہر",
    "رات"
   ],
   "correct": 1,
   "expl": "صبح کا الٹ شام ہے۔"
  },
  {
   "q": "درخت کی جمع ہے:",
   "opts": [
    "درختوں",
    "اشجار",
    "درختیں",
    "درختان"
   ],
   "correct": 1,
   "expl": "درخت کی جمع اشجار ہے۔"
  },
  {
   "q": "شہر کی جمع ہے:",
   "opts": [
    "شہروں",
    "شہر",
    "شہریں",
    "شہریات"
   ],
   "correct": 1,
   "expl": "شہر کی جمع بھی شہر ہے۔"
  },
  {
   "q": "سوال کی جمع ہے:",
   "opts": [
    "سوالوں",
    "سوالات",
    "سوالیات",
    "اسئلہ"
   ],
   "correct": 1,
   "expl": "سوال کی جمع سوالات ہے۔"
  },
  {
   "q": "درخت کی جمع اشجار ہے۔ (صحیح/غلط)",
   "opts": [
    "صحیح",
    "غلط",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "درخت کی جمع اشجار ہے۔"
  }
 ],
 "ISLAMIAT9": [
  {
   "q": "The first revelation upon the Holy Prophet ﷻ was:",
   "opts": [
    "Surah Al-Fatiha",
    "Surah Al-Alaq",
    "Surah Al-Ikhlas",
    "Surah Al-Nas"
   ],
   "correct": 1,
   "expl": "The first five verses of Surah Al-Alaq were revealed in Cave Hira."
  },
  {
   "q": "The first word revealed of the Holy Quran was:",
   "opts": [
    "Qul",
    "Iqra",
    "Alhamd",
    "Bismillah"
   ],
   "correct": 1,
   "expl": "The revelation began with the command 'Iqra' meaning 'Read'."
  },
  {
   "q": "The first revelation took place in:",
   "opts": [
    "Cave Hira",
    "Masjid Nabawi",
    "Cave Thaur",
    "Mount Uhud"
   ],
   "correct": 0,
   "expl": "The Prophet ﷻ received the first revelation in Cave Hira."
  },
  {
   "q": "The Holy Quran was revealed over a period of:",
   "opts": [
    "10 years",
    "13 years",
    "23 years",
    "40 years"
   ],
   "correct": 2,
   "expl": "Revelation continued throughout the 23 years of prophethood."
  },
  {
   "q": "Makki Surahs were revealed in:",
   "opts": [
    "Madinah",
    "Makkah",
    "Taif",
    "Jerusalem"
   ],
   "correct": 1,
   "expl": "Surahs revealed before the Hijrah are called Makki."
  },
  {
   "q": "Madani Surahs were revealed in:",
   "opts": [
    "Makkah",
    "Madinah",
    "Yemen",
    "Syria"
   ],
   "correct": 1,
   "expl": "Surahs revealed after the Hijrah are called Madani."
  },
  {
   "q": "The total number of Surahs in the Holy Quran is:",
   "opts": [
    "110",
    "112",
    "114",
    "116"
   ],
   "correct": 2,
   "expl": "The Holy Quran contains 114 Surahs."
  },
  {
   "q": "The longest Surah of the Holy Quran is:",
   "opts": [
    "Al-Imran",
    "Al-Baqarah",
    "An-Nisa",
    "Al-Ma'idah"
   ],
   "correct": 1,
   "expl": "Surah Al-Baqarah has 286 verses, the most of any Surah."
  },
  {
   "q": "The shortest Surah of the Holy Quran is:",
   "opts": [
    "Al-Ikhlas",
    "Al-Kausar",
    "Al-Asr",
    "Al-Fil"
   ],
   "correct": 1,
   "expl": "Surah Al-Kausar has only three verses."
  },
  {
   "q": "The first Surah of the Holy Quran is:",
   "opts": [
    "Al-Baqarah",
    "Al-Fatiha",
    "Al-Ikhlas",
    "Ya-Sin"
   ],
   "correct": 1,
   "expl": "The Quran opens with Surah Al-Fatiha."
  },
  {
   "q": "The last Surah of the Holy Quran is:",
   "opts": [
    "Al-Falaq",
    "Al-Ikhlas",
    "Al-Nas",
    "Al-Lahab"
   ],
   "correct": 2,
   "expl": "Surah An-Nas is the 114th and final Surah."
  },
  {
   "q": "The Quran was compiled in book form during the caliphate of:",
   "opts": [
    "Hazrat Umar (R.A.)",
    "Hazrat Abu Bakr (R.A.)",
    "Hazrat Usman (R.A.)",
    "Hazrat Ali (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Abu Bakr (R.A.) ordered the first compilation after Yamama."
  },
  {
   "q": "The standardized copy of the Quran (Mushaf Usmani) was prepared under:",
   "opts": [
    "Hazrat Abu Bakr (R.A.)",
    "Hazrat Umar (R.A.)",
    "Hazrat Usman (R.A.)",
    "Hazrat Ali (R.A.)"
   ],
   "correct": 2,
   "expl": "Hazrat Usman (R.A.) standardized the text to prevent differences."
  },
  {
   "q": "The Holy Prophet ﷻ was born in:",
   "opts": [
    "570 A.D.",
    "571 A.D.",
    "572 A.D.",
    "573 A.D."
   ],
   "correct": 1,
   "expl": "He was born in Makkah in 571 A.D., the Year of the Elephant."
  },
  {
   "q": "The year of the Prophet's ﷻ birth is called:",
   "opts": [
    "Aam-ul-Huzn",
    "Aam-ul-Feel",
    "Aam-ul-Wufud",
    "Aam-ul-Jama'ah"
   ],
   "correct": 1,
   "expl": "It is called the Year of the Elephant after Abraha's attack."
  },
  {
   "q": "The father of the Holy Prophet ﷻ was:",
   "opts": [
    "Abdul Muttalib",
    "Abdullah",
    "Abu Talib",
    "Hamza"
   ],
   "correct": 1,
   "expl": "His father Abdullah passed away before his birth."
  },
  {
   "q": "The mother of the Holy Prophet ﷻ was:",
   "opts": [
    "Halima",
    "Amina",
    "Khadija",
    "Fatima"
   ],
   "correct": 1,
   "expl": "His mother was Amina bint Wahb."
  },
  {
   "q": "The foster mother of the Holy Prophet ﷻ was:",
   "opts": [
    "Amina",
    "Halima Sadia",
    "Khadija",
    "Asma"
   ],
   "correct": 1,
   "expl": "Halima Sadia of Banu Sa'd nursed him in childhood."
  },
  {
   "q": "The first wife of the Holy Prophet ﷻ was:",
   "opts": [
    "Hazrat Aisha (R.A.)",
    "Hazrat Khadija (R.A.)",
    "Hazrat Hafsa (R.A.)",
    "Hazrat Sawda (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Khadija (R.A.) was his first wife and first believer."
  },
  {
   "q": "The age of the Prophet ﷻ at the first revelation was:",
   "opts": [
    "33 years",
    "35 years",
    "40 years",
    "45 years"
   ],
   "correct": 2,
   "expl": "He received prophethood at the age of forty."
  },
  {
   "q": "The Hijrah (migration) to Madinah took place in:",
   "opts": [
    "620 A.D.",
    "621 A.D.",
    "622 A.D.",
    "623 A.D."
   ],
   "correct": 2,
   "expl": "The Hijrah in 622 A.D. marks the start of the Islamic calendar."
  },
  {
   "q": "The Battle of Badr was fought in:",
   "opts": [
    "1 Hijri",
    "2 Hijri",
    "3 Hijri",
    "5 Hijri"
   ],
   "correct": 1,
   "expl": "Badr, the first major battle, occurred in 2 A.H."
  },
  {
   "q": "The Battle of Uhud was fought in:",
   "opts": [
    "2 Hijri",
    "3 Hijri",
    "4 Hijri",
    "5 Hijri"
   ],
   "correct": 1,
   "expl": "Uhud took place in 3 A.H."
  },
  {
   "q": "The Conquest of Makkah took place in:",
   "opts": [
    "6 Hijri",
    "7 Hijri",
    "8 Hijri",
    "10 Hijri"
   ],
   "correct": 2,
   "expl": "Makkah was conquered peacefully in 8 A.H."
  },
  {
   "q": "The Farewell Sermon was delivered in:",
   "opts": [
    "8 Hijri",
    "9 Hijri",
    "10 Hijri",
    "11 Hijri"
   ],
   "correct": 2,
   "expl": "The Prophet ﷻ gave the farewell sermon during Hajjat-ul-Wida in 10 A.H."
  },
  {
   "q": "The Holy Prophet ﷻ passed away in:",
   "opts": [
    "10 Hijri",
    "11 Hijri",
    "12 Hijri",
    "13 Hijri"
   ],
   "correct": 1,
   "expl": "He passed away in Madinah in 11 A.H. (632 A.D.)."
  },
  {
   "q": "The first caliph of Islam was:",
   "opts": [
    "Hazrat Umar (R.A.)",
    "Hazrat Abu Bakr (R.A.)",
    "Hazrat Usman (R.A.)",
    "Hazrat Ali (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Abu Bakr Siddiq (R.A.) was the first caliph."
  },
  {
   "q": "The second caliph of Islam was:",
   "opts": [
    "Hazrat Abu Bakr (R.A.)",
    "Hazrat Umar (R.A.)",
    "Hazrat Usman (R.A.)",
    "Hazrat Ali (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Umar Farooq (R.A.) was the second caliph."
  },
  {
   "q": "The third caliph of Islam was:",
   "opts": [
    "Hazrat Umar (R.A.)",
    "Hazrat Ali (R.A.)",
    "Hazrat Usman (R.A.)",
    "Hazrat Talha (R.A.)"
   ],
   "correct": 2,
   "expl": "Hazrat Usman Ghani (R.A.) was the third caliph."
  },
  {
   "q": "The fourth caliph of Islam was:",
   "opts": [
    "Hazrat Usman (R.A.)",
    "Hazrat Ali (R.A.)",
    "Hazrat Zubair (R.A.)",
    "Hazrat Muawiya (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Ali (R.A.) was the fourth caliph."
  },
  {
   "q": "The number of pillars of Islam is:",
   "opts": [
    "4",
    "5",
    "6",
    "7"
   ],
   "correct": 1,
   "expl": "The five pillars are Shahadah, Salah, Zakat, Sawm and Hajj."
  },
  {
   "q": "The first pillar of Islam is:",
   "opts": [
    "Namaz",
    "Kalma (Shahadah)",
    "Zakat",
    "Roza"
   ],
   "correct": 1,
   "expl": "The declaration of faith is the foundation of Islam."
  },
  {
   "q": "Muslims offer Namaz:",
   "opts": [
    "3 times daily",
    "5 times daily",
    "7 times daily",
    "2 times daily"
   ],
   "correct": 1,
   "expl": "Five daily prayers are obligatory on every Muslim."
  },
  {
   "q": "The rate of Zakat on cash and gold is:",
   "opts": [
    "1.5%",
    "2.5%",
    "5%",
    "10%"
   ],
   "correct": 1,
   "expl": "Zakat is one-fortieth (2.5%) of qualifying wealth."
  },
  {
   "q": "The Nisab of Zakat for gold is:",
   "opts": [
    "5 tola",
    "7.5 tola",
    "10 tola",
    "12 tola"
   ],
   "correct": 1,
   "expl": "Zakat becomes due on 7.5 tolas of gold."
  },
  {
   "q": "Fasting is observed in the month of:",
   "opts": [
    "Shawwal",
    "Ramadan",
    "Zil-Hajj",
    "Muharram"
   ],
   "correct": 1,
   "expl": "Muslims fast during the holy month of Ramadan."
  },
  {
   "q": "Hajj is performed in the month of:",
   "opts": [
    "Ramadan",
    "Shawwal",
    "Zil-Hajj",
    "Rabi-ul-Awwal"
   ],
   "correct": 2,
   "expl": "Hajj rites take place in Zil-Hajj."
  },
  {
   "q": "Fasting (Roza) is the ___ pillar of Islam:",
   "opts": [
    "2nd",
    "3rd",
    "4th",
    "5th"
   ],
   "correct": 1,
   "expl": "After Shahadah and Salah, Sawm is the third pillar."
  },
  {
   "q": "Zakat is the ___ pillar of Islam:",
   "opts": [
    "2nd",
    "3rd",
    "4th",
    "5th"
   ],
   "correct": 2,
   "expl": "Zakat comes fourth after Shahadah, Salah and Sawm."
  },
  {
   "q": "Hajj is the ___ pillar of Islam:",
   "opts": [
    "3rd",
    "4th",
    "5th",
    "2nd"
   ],
   "correct": 2,
   "expl": "Hajj is the fifth and final pillar."
  },
  {
   "q": "Wudu has ___ Farz (obligatory acts):",
   "opts": [
    "3",
    "4",
    "5",
    "6"
   ],
   "correct": 1,
   "expl": "Wudu has four Farz: face, arms, head wipe and feet."
  },
  {
   "q": "Ghusl has ___ Farz (obligatory acts):",
   "opts": [
    "2",
    "3",
    "4",
    "5"
   ],
   "correct": 1,
   "expl": "Ghusl has three Farz: gargling, nose rinse and full body wash."
  },
  {
   "q": "Tayammum is performed with:",
   "opts": [
    "Water",
    "Clean earth/dust",
    "Oil",
    "Snow only"
   ],
   "correct": 1,
   "expl": "When water is unavailable, dry ablution uses clean earth."
  },
  {
   "q": "Azan is called for:",
   "opts": [
    "Hajj",
    "Namaz",
    "Zakat",
    "Fasting"
   ],
   "correct": 1,
   "expl": "The Azan announces the time of each prayer."
  },
  {
   "q": "Jumu'ah prayer is offered on:",
   "opts": [
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
   ],
   "correct": 1,
   "expl": "The congregational Jumu'ah prayer is on Friday."
  },
  {
   "q": "The number of Eid prayers in a year is:",
   "opts": [
    "1",
    "2",
    "3",
    "4"
   ],
   "correct": 1,
   "expl": "Eid-ul-Fitr and Eid-ul-Azha are the two Eids."
  },
  {
   "q": "Taraweeh prayers are offered in:",
   "opts": [
    "Muharram",
    "Ramadan",
    "Zil-Hajj",
    "Rabi-ul-Awwal"
   ],
   "correct": 1,
   "expl": "Taraweeh is the special night prayer of Ramadan."
  },
  {
   "q": "Tahajjud is a:",
   "opts": [
    "Farz prayer",
    "Night (late) prayer",
    "Eid prayer",
    "Funeral prayer"
   ],
   "correct": 1,
   "expl": "Tahajjud is offered in the last part of the night."
  },
  {
   "q": "Hadith means the:",
   "opts": [
    "Verses of the Quran",
    "Sayings and actions of the Prophet ﷻ",
    "Stories of caliphs",
    "Islamic laws only"
   ],
   "correct": 1,
   "expl": "Hadith records the Prophet's ﷻ words, deeds and approvals."
  },
  {
   "q": "Sunnah refers to the:",
   "opts": [
    "Prophet's ﷻ way and practice",
    "Quranic verses",
    "Caliphs' orders",
    "Angels' duties"
   ],
   "correct": 0,
   "expl": "Sunnah is the practical example set by the Prophet ﷻ."
  }
 ],
 "PAKSTUDY9": [
  {
   "q": "The ideology of Pakistan is based on:",
   "opts": [
    "Nationalism",
    "Islam",
    "Socialism",
    "Secularism"
   ],
   "correct": 1,
   "expl": "Pakistan was created as a homeland where Muslims could live by Islam."
  },
  {
   "q": "The Two-Nation Theory was first presented by:",
   "opts": [
    "Quaid-e-Azam",
    "Sir Syed Ahmad Khan",
    "Allama Iqbal",
    "Liaquat Ali Khan"
   ],
   "correct": 1,
   "expl": "Sir Syed laid its foundation after the Urdu-Hindi controversy of 1867."
  },
  {
   "q": "The Pakistan Resolution was passed on:",
   "opts": [
    "23 March 1940",
    "14 August 1947",
    "3 June 1947",
    "26 January 1940"
   ],
   "correct": 0,
   "expl": "The Lahore Resolution of 23 March 1940 demanded separate Muslim states."
  },
  {
   "q": "The Pakistan Resolution was presented by:",
   "opts": [
    "Quaid-e-Azam",
    "Liaquat Ali Khan",
    "A.K. Fazlul Haq",
    "Ch. Rehmat Ali"
   ],
   "correct": 2,
   "expl": "Sher-e-Bengal A.K. Fazlul Haq moved the resolution."
  },
  {
   "q": "The 1940 Lahore session was presided over by:",
   "opts": [
    "Liaquat Ali Khan",
    "Quaid-e-Azam",
    "A.K. Fazlul Haq",
    "Nawab Salimullah"
   ],
   "correct": 1,
   "expl": "Quaid-e-Azam presided over the historic session."
  },
  {
   "q": "Pakistan came into being on:",
   "opts": [
    "15 August 1947",
    "14 August 1947",
    "23 March 1940",
    "26 January 1950"
   ],
   "correct": 1,
   "expl": "Pakistan gained independence on 14 August 1947."
  },
  {
   "q": "Quaid-e-Azam was born on:",
   "opts": [
    "25 December 1876",
    "25 December 1875",
    "11 September 1948",
    "14 August 1947"
   ],
   "correct": 0,
   "expl": "Muhammad Ali Jinnah was born in Karachi on 25 December 1876."
  },
  {
   "q": "Quaid-e-Azam passed away on:",
   "opts": [
    "14 August 1948",
    "11 September 1948",
    "25 December 1948",
    "23 March 1949"
   ],
   "correct": 1,
   "expl": "He died in Karachi on 11 September 1948."
  },
  {
   "q": "The first Governor General of Pakistan was:",
   "opts": [
    "Liaquat Ali Khan",
    "Quaid-e-Azam",
    "Khawaja Nazimuddin",
    "Ghulam Muhammad"
   ],
   "correct": 1,
   "expl": "Quaid-e-Azam became the first Governor General."
  },
  {
   "q": "The first Prime Minister of Pakistan was:",
   "opts": [
    "Quaid-e-Azam",
    "Khawaja Nazimuddin",
    "Liaquat Ali Khan",
    "H.S. Suhrawardy"
   ],
   "correct": 2,
   "expl": "Liaquat Ali Khan was the first Prime Minister."
  },
  {
   "q": "Liaquat Ali Khan was assassinated in:",
   "opts": [
    "Lahore",
    "Karachi",
    "Rawalpindi",
    "Peshawar"
   ],
   "correct": 2,
   "expl": "He was martyred at Company Bagh, Rawalpindi on 16 October 1951."
  },
  {
   "q": "The national language of Pakistan is:",
   "opts": [
    "Punjabi",
    "Urdu",
    "English",
    "Sindhi"
   ],
   "correct": 1,
   "expl": "Urdu is the national language of Pakistan."
  },
  {
   "q": "The national anthem of Pakistan was written by:",
   "opts": [
    "Allama Iqbal",
    "Hafeez Jalandhari",
    "Faiz Ahmad Faiz",
    "Ahmed Faraz"
   ],
   "correct": 1,
   "expl": "Hafeez Jalandhari wrote the lyrics of the Qaumi Tarana."
  },
  {
   "q": "The music of the national anthem was composed by:",
   "opts": [
    "Nusrat Fateh Ali Khan",
    "Ahmed G. Chagla",
    "Sohail Rana",
    "M. Ashraf"
   ],
   "correct": 1,
   "expl": "Ahmed Ghulamali Chagla composed the anthem's music."
  },
  {
   "q": "The national poet of Pakistan is:",
   "opts": [
    "Mir Taqi Mir",
    "Allama Iqbal",
    "Ghalib",
    "Faiz Ahmad Faiz"
   ],
   "correct": 1,
   "expl": "Allama Muhammad Iqbal is the national poet."
  },
  {
   "q": "Allama Iqbal was born on:",
   "opts": [
    "9 November 1877",
    "9 November 1876",
    "21 April 1938",
    "25 December 1876"
   ],
   "correct": 0,
   "expl": "Iqbal was born in Sialkot on 9 November 1877."
  },
  {
   "q": "The Allahabad Address was delivered in:",
   "opts": [
    "1928",
    "1929",
    "1930",
    "1931"
   ],
   "correct": 2,
   "expl": "Iqbal's 1930 address proposed a separate Muslim homeland."
  },
  {
   "q": "The Khilafat Movement started in:",
   "opts": [
    "1916",
    "1919",
    "1922",
    "1924"
   ],
   "correct": 1,
   "expl": "It began in 1919 to protect the Ottoman Caliphate."
  },
  {
   "q": "The Lucknow Pact was signed in:",
   "opts": [
    "1906",
    "1916",
    "1920",
    "1928"
   ],
   "correct": 1,
   "expl": "The 1916 pact united Congress and the Muslim League."
  },
  {
   "q": "The Simla Deputation met the Viceroy in:",
   "opts": [
    "1905",
    "1906",
    "1907",
    "1908"
   ],
   "correct": 1,
   "expl": "The 1906 deputation demanded separate electorates for Muslims."
  },
  {
   "q": "The All-India Muslim League was founded in:",
   "opts": [
    "1905",
    "1906",
    "1916",
    "1940"
   ],
   "correct": 1,
   "expl": "It was founded at Dhaka in December 1906."
  },
  {
   "q": "The Cabinet Mission arrived in India in:",
   "opts": [
    "1942",
    "1945",
    "1946",
    "1947"
   ],
   "correct": 2,
   "expl": "The 1946 mission proposed a united India plan."
  },
  {
   "q": "The 3rd June Plan was announced in:",
   "opts": [
    "1946",
    "1947",
    "1948",
    "1945"
   ],
   "correct": 1,
   "expl": "Lord Mountbatten's plan of 3 June 1947 led to partition."
  },
  {
   "q": "The boundary between Pakistan and India was drawn by:",
   "opts": [
    "Mountbatten",
    "Radcliffe",
    "Cripps",
    "Wavell"
   ],
   "correct": 1,
   "expl": "Sir Cyril Radcliffe headed the Boundary Commission."
  },
  {
   "q": "The Objective Resolution was passed on:",
   "opts": [
    "23 March 1949",
    "12 March 1949",
    "14 August 1949",
    "25 December 1949"
   ],
   "correct": 1,
   "expl": "It laid the Islamic and democratic foundations of the constitution."
  },
  {
   "q": "The first constitution of Pakistan was enforced in:",
   "opts": [
    "1949",
    "1956",
    "1962",
    "1973"
   ],
   "correct": 1,
   "expl": "Pakistan's first constitution came in 1956."
  },
  {
   "q": "The second constitution of Pakistan was enforced in:",
   "opts": [
    "1956",
    "1958",
    "1962",
    "1973"
   ],
   "correct": 2,
   "expl": "Ayub Khan's presidential constitution came in 1962."
  },
  {
   "q": "The third (current) constitution was enforced in:",
   "opts": [
    "1962",
    "1971",
    "1973",
    "1985"
   ],
   "correct": 2,
   "expl": "The 1973 constitution was enforced on 14 August 1973."
  },
  {
   "q": "The capital of Pakistan is:",
   "opts": [
    "Karachi",
    "Lahore",
    "Islamabad",
    "Rawalpindi"
   ],
   "correct": 2,
   "expl": "Islamabad is the federal capital."
  },
  {
   "q": "The largest province of Pakistan by area is:",
   "opts": [
    "Punjab",
    "Sindh",
    "Khyber Pakhtunkhwa",
    "Balochistan"
   ],
   "correct": 3,
   "expl": "Balochistan covers about 44% of Pakistan's area."
  },
  {
   "q": "The national animal of Pakistan is:",
   "opts": [
    "Lion",
    "Markhor",
    "Snow leopard",
    "Tiger"
   ],
   "correct": 1,
   "expl": "The Markhor is Pakistan's national animal."
  },
  {
   "q": "The national bird of Pakistan is:",
   "opts": [
    "Eagle",
    "Chakor",
    "Peacock",
    "Falcon"
   ],
   "correct": 1,
   "expl": "The Chakor partridge is the national bird."
  },
  {
   "q": "The national flower of Pakistan is:",
   "opts": [
    "Rose",
    "Jasmine",
    "Sunflower",
    "Tulip"
   ],
   "correct": 1,
   "expl": "Jasmine is the national flower."
  },
  {
   "q": "The national tree of Pakistan is:",
   "opts": [
    "Mango",
    "Deodar",
    "Neem",
    "Peepal"
   ],
   "correct": 1,
   "expl": "Deodar cedar is the national tree."
  },
  {
   "q": "The national game of Pakistan is:",
   "opts": [
    "Cricket",
    "Field hockey",
    "Squash",
    "Football"
   ],
   "correct": 1,
   "expl": "Field hockey is the national game."
  },
  {
   "q": "The national dress of Pakistan is:",
   "opts": [
    "Kurta pajama",
    "Shalwar kameez",
    "Sherwani",
    "Dhoti kurta"
   ],
   "correct": 1,
   "expl": "Shalwar kameez is the national dress."
  },
  {
   "q": "The national fruit of Pakistan is:",
   "opts": [
    "Apple",
    "Mango",
    "Banana",
    "Orange"
   ],
   "correct": 1,
   "expl": "Mango is the national fruit."
  },
  {
   "q": "The highest peak of Pakistan is:",
   "opts": [
    "Nanga Parbat",
    "K-2",
    "Tirich Mir",
    "Broad Peak"
   ],
   "correct": 1,
   "expl": "K-2 (8,611 m) is the highest peak in Pakistan."
  },
  {
   "q": "The longest river of Pakistan is:",
   "opts": [
    "Jhelum",
    "Chenab",
    "Indus",
    "Ravi"
   ],
   "correct": 2,
   "expl": "The Indus is the longest river flowing through Pakistan."
  },
  {
   "q": "The currency of Pakistan is:",
   "opts": [
    "Taka",
    "Rupee",
    "Dinar",
    "Riyal"
   ],
   "correct": 1,
   "expl": "The Pakistani Rupee is the official currency."
  },
  {
   "q": "Independence Day of Pakistan is celebrated on:",
   "opts": [
    "23 March",
    "14 August",
    "6 September",
    "25 December"
   ],
   "correct": 1,
   "expl": "14 August marks independence from British rule."
  },
  {
   "q": "Pakistan Day is celebrated on:",
   "opts": [
    "14 August",
    "23 March",
    "6 September",
    "9 November"
   ],
   "correct": 1,
   "expl": "23 March commemorates the 1940 Lahore Resolution."
  },
  {
   "q": "Defence Day of Pakistan is observed on:",
   "opts": [
    "6 September",
    "14 August",
    "23 March",
    "16 December"
   ],
   "correct": 0,
   "expl": "6 September honours the 1965 war defence."
  },
  {
   "q": "Quaid Day is celebrated on:",
   "opts": [
    "11 September",
    "25 December",
    "14 August",
    "23 March"
   ],
   "correct": 1,
   "expl": "25 December is Quaid-e-Azam's birthday."
  },
  {
   "q": "Iqbal Day is celebrated on:",
   "opts": [
    "21 April",
    "9 November",
    "25 December",
    "23 March"
   ],
   "correct": 1,
   "expl": "9 November is Allama Iqbal's birthday."
  },
  {
   "q": "The mother tongue of the majority of Pakistanis is:",
   "opts": [
    "Urdu",
    "Punjabi",
    "Sindhi",
    "Pashto"
   ],
   "correct": 1,
   "expl": "Punjabi is spoken by the largest share of the population."
  },
  {
   "q": "The total area of Pakistan is about:",
   "opts": [
    "796,096 sq km",
    "696,096 sq km",
    "896,096 sq km",
    "596,096 sq km"
   ],
   "correct": 0,
   "expl": "Pakistan covers approximately 796,096 square kilometres."
  },
  {
   "q": "Pakistan is located in:",
   "opts": [
    "Central Asia",
    "South Asia",
    "Middle East",
    "East Asia"
   ],
   "correct": 1,
   "expl": "Pakistan lies in South Asia."
  },
  {
   "q": "The first constituent assembly of Pakistan met in:",
   "opts": [
    "1946",
    "1947",
    "1949",
    "1956"
   ],
   "correct": 1,
   "expl": "It convened in Karachi in August 1947."
  },
  {
   "q": "The national motto of Pakistan is:",
   "opts": [
    "Faith, Unity, Discipline",
    "Unity, Faith, Discipline",
    "Peace, Progress, Prosperity",
    "Strength, Honour, Faith"
   ],
   "correct": 0,
   "expl": "Quaid-e-Azam gave the motto: Faith, Unity, Discipline."
  }
 ],
 "PHYSICS11": [
  {
   "q": "Speed is a scalar while velocity is a:",
   "opts": [
    "Scalar",
    "Vector",
    "Tensor",
    "Unit"
   ],
   "correct": 1,
   "expl": "Velocity has both magnitude and direction, so it is a vector."
  },
  {
   "q": "The dot product of two vectors gives a:",
   "opts": [
    "Vector",
    "Scalar",
    "Tensor",
    "Matrix"
   ],
   "correct": 1,
   "expl": "A · B = |A||B|cosθ, which is a single number."
  },
  {
   "q": "The cross product of two vectors gives a:",
   "opts": [
    "Scalar",
    "Vector",
    "Number",
    "Constant"
   ],
   "correct": 1,
   "expl": "A × B is a vector perpendicular to both A and B."
  },
  {
   "q": "The magnitude of a unit vector is:",
   "opts": [
    "0",
    "1",
    "10",
    "Infinite"
   ],
   "correct": 1,
   "expl": "A unit vector has magnitude exactly one."
  },
  {
   "q": "A null vector has:",
   "opts": [
    "Unit magnitude",
    "Zero magnitude",
    "Infinite magnitude",
    "Negative magnitude"
   ],
   "correct": 1,
   "expl": "The null vector has zero length and undefined direction."
  },
  {
   "q": "The resultant of two vectors is maximum when the angle between them is:",
   "opts": [
    "90°",
    "180°",
    "0°",
    "45°"
   ],
   "correct": 2,
   "expl": "Vectors add fully when they point in the same direction."
  },
  {
   "q": "The rectangular components of a force F at angle θ are:",
   "opts": [
    "Fx = F sinθ, Fy = F cosθ",
    "Fx = F cosθ, Fy = F sinθ",
    "Fx = Fy = F",
    "Fx = F tanθ"
   ],
   "correct": 1,
   "expl": "The adjacent component uses cosine and the opposite uses sine."
  },
  {
   "q": "The angle of projection for maximum range is:",
   "opts": [
    "30°",
    "45°",
    "60°",
    "90°"
   ],
   "correct": 1,
   "expl": "Range = v₀²sin2θ/g is maximum when sin2θ = 1, i.e. θ = 45°."
  },
  {
   "q": "At the highest point of a projectile, the vertical velocity is:",
   "opts": [
    "Maximum",
    "Zero",
    "Equal to initial",
    "Negative"
   ],
   "correct": 1,
   "expl": "The vertical component momentarily becomes zero at the peak."
  },
  {
   "q": "The time of flight of a projectile is:",
   "opts": [
    "2v₀sinθ/g",
    "v₀sinθ/g",
    "v₀²sinθ/g",
    "2v₀cosθ/g"
   ],
   "correct": 0,
   "expl": "Upward and downward journeys each take v₀sinθ/g."
  },
  {
   "q": "The horizontal range of a projectile is:",
   "opts": [
    "v₀²sinθ/g",
    "v₀²sin2θ/g",
    "v₀sin2θ/g",
    "2v₀²cosθ/g"
   ],
   "correct": 1,
   "expl": "Range = horizontal velocity × time of flight."
  },
  {
   "q": "Newton's second law states that:",
   "opts": [
    "F = mv",
    "F = ma",
    "F = m/a",
    "F = v/a"
   ],
   "correct": 1,
   "expl": "Force equals the rate of change of momentum, F = ma."
  },
  {
   "q": "Linear momentum is defined as:",
   "opts": [
    "p = mv",
    "p = m/v",
    "p = Ft",
    "p = ma"
   ],
   "correct": 0,
   "expl": "Momentum is the product of mass and velocity."
  },
  {
   "q": "Impulse equals the:",
   "opts": [
    "Change in velocity",
    "Change in momentum",
    "Change in energy",
    "Change in force"
   ],
   "correct": 1,
   "expl": "Impulse J = FΔt = Δp."
  },
  {
   "q": "In an elastic collision, which is conserved?",
   "opts": [
    "Only momentum",
    "Only kinetic energy",
    "Both momentum and kinetic energy",
    "Neither"
   ],
   "correct": 2,
   "expl": "Elastic collisions conserve both momentum and kinetic energy."
  },
  {
   "q": "Work done is zero when the angle between force and displacement is:",
   "opts": [
    "0°",
    "45°",
    "90°",
    "180°"
   ],
   "correct": 2,
   "expl": "W = Fd cosθ, and cos90° = 0."
  },
  {
   "q": "The SI unit of power is:",
   "opts": [
    "Joule",
    "Newton",
    "Watt",
    "Erg"
   ],
   "correct": 2,
   "expl": "Power is work per unit time, measured in watts."
  },
  {
   "q": "The escape velocity from Earth is about:",
   "opts": [
    "7.9 km/s",
    "11.2 km/s",
    "9.8 km/s",
    "3 × 10⁸ m/s"
   ],
   "correct": 1,
   "expl": "A speed of 11.2 km/s lets a body escape Earth's gravity."
  },
  {
   "q": "The SI unit of angular velocity is:",
   "opts": [
    "m/s",
    "rad/s",
    "rev/s²",
    "Hz"
   ],
   "correct": 1,
   "expl": "Angular velocity measures angle swept per second."
  },
  {
   "q": "The relation between linear and angular velocity is:",
   "opts": [
    "v = ω/r",
    "v = ωr",
    "v = r/ω",
    "ω = v²r"
   ],
   "correct": 1,
   "expl": "A point at radius r moves with speed ωr."
  },
  {
   "q": "Centripetal acceleration equals:",
   "opts": [
    "v²/r",
    "vr²",
    "v/r²",
    "ωr²"
   ],
   "correct": 0,
   "expl": "Circular motion needs inward acceleration v²/r."
  },
  {
   "q": "Moment of inertia depends on:",
   "opts": [
    "Mass only",
    "Mass distribution about the axis",
    "Velocity",
    "Force"
   ],
   "correct": 1,
   "expl": "How mass is spread from the axis decides rotational inertia."
  },
  {
   "q": "Angular momentum is given by:",
   "opts": [
    "L = Iω",
    "L = mv",
    "L = Fr",
    "L = I/ω"
   ],
   "correct": 0,
   "expl": "Angular momentum equals moment of inertia times angular velocity."
  },
  {
   "q": "Torque equals:",
   "opts": [
    "τ = rFsinθ",
    "τ = rFcosθ",
    "τ = F/r",
    "τ = r²F"
   ],
   "correct": 0,
   "expl": "Torque is the cross product of radius and force vectors."
  },
  {
   "q": "Simple harmonic motion obeys:",
   "opts": [
    "F = kx",
    "F = -kx",
    "F = ma²",
    "F = -mv"
   ],
   "correct": 1,
   "expl": "The restoring force is opposite and proportional to displacement."
  },
  {
   "q": "The time period of a simple pendulum is:",
   "opts": [
    "T = 2π√(g/l)",
    "T = 2π√(l/g)",
    "T = 2πl/g",
    "T = π√(l/g)"
   ],
   "correct": 1,
   "expl": "A longer pendulum swings more slowly: T = 2π√(l/g)."
  },
  {
   "q": "Frequency and time period are related by:",
   "opts": [
    "f = T",
    "f = 1/T",
    "f = 2T",
    "f = T²"
   ],
   "correct": 1,
   "expl": "Frequency is the number of cycles per second, the reciprocal of period."
  },
  {
   "q": "Wave speed is given by:",
   "opts": [
    "v = f/λ",
    "v = fλ",
    "v = λ/f",
    "v = f + λ"
   ],
   "correct": 1,
   "expl": "Speed equals frequency times wavelength."
  },
  {
   "q": "Sound waves in air are:",
   "opts": [
    "Transverse",
    "Longitudinal",
    "Electromagnetic",
    "Standing only"
   ],
   "correct": 1,
   "expl": "Sound travels as compressions and rarefactions along its path."
  },
  {
   "q": "Light waves are:",
   "opts": [
    "Longitudinal",
    "Transverse electromagnetic",
    "Mechanical",
    "Matter waves"
   ],
   "correct": 1,
   "expl": "Light is a transverse EM wave needing no medium."
  },
  {
   "q": "The speed of light in vacuum is:",
   "opts": [
    "3 × 10⁶ m/s",
    "3 × 10⁷ m/s",
    "3 × 10⁸ m/s",
    "3 × 10⁹ m/s"
   ],
   "correct": 2,
   "expl": "Light travels at 3 × 10⁸ m/s in vacuum."
  },
  {
   "q": "The speed of sound in air at room temperature is about:",
   "opts": [
    "343 m/s",
    "1500 m/s",
    "300 m/s",
    "5000 m/s"
   ],
   "correct": 0,
   "expl": "Sound travels roughly 343 m/s in air."
  },
  {
   "q": "The Doppler effect is the change in:",
   "opts": [
    "Amplitude",
    "Frequency due to relative motion",
    "Speed of sound",
    "Wavelength in vacuum"
   ],
   "correct": 1,
   "expl": "Motion of source or observer shifts the observed frequency."
  },
  {
   "q": "Beats are produced by:",
   "opts": [
    "A single wave",
    "Two waves of slightly different frequencies",
    "Reflection",
    "Diffraction"
   ],
   "correct": 1,
   "expl": "Interference of close frequencies gives periodic loudness variation."
  },
  {
   "q": "The first law of thermodynamics states:",
   "opts": [
    "ΔU = Q + W",
    "ΔU = Q - W",
    "Q = ΔU + W",
    "ΔU = W - Q"
   ],
   "correct": 1,
   "expl": "The change in internal energy equals heat added minus work done by the system."
  },
  {
   "q": "In an isothermal process:",
   "opts": [
    "ΔT = 0",
    "Q = 0",
    "W = 0",
    "ΔU is maximum"
   ],
   "correct": 0,
   "expl": "Temperature stays constant, so internal energy is unchanged."
  },
  {
   "q": "In an adiabatic process:",
   "opts": [
    "Q = 0",
    "ΔT = 0",
    "W = 0",
    "P = 0"
   ],
   "correct": 0,
   "expl": "No heat enters or leaves the system."
  },
  {
   "q": "The efficiency of a Carnot engine is:",
   "opts": [
    "1 - T₁/T₂",
    "1 - T₂/T₁",
    "T₂/T₁",
    "T₁/T₂"
   ],
   "correct": 1,
   "expl": "Carnot efficiency depends only on the hot and cold reservoir temperatures."
  },
  {
   "q": "Coulomb's law: F equals:",
   "opts": [
    "kq₁q₂/r",
    "kq₁q₂/r²",
    "kq₁q₂r",
    "kq₁q₂r²"
   ],
   "correct": 1,
   "expl": "Electrostatic force follows the inverse-square law."
  },
  {
   "q": "The SI unit of electric charge is:",
   "opts": [
    "Volt",
    "Ampere",
    "Coulomb",
    "Farad"
   ],
   "correct": 2,
   "expl": "Charge is measured in coulombs."
  },
  {
   "q": "The SI unit of electric field intensity is:",
   "opts": [
    "N/C",
    "C/N",
    "V·m",
    "J/C²"
   ],
   "correct": 0,
   "expl": "Field is force per unit charge, N/C (or V/m)."
  },
  {
   "q": "The SI unit of electric potential is:",
   "opts": [
    "Ohm",
    "Volt",
    "Farad",
    "Tesla"
   ],
   "correct": 1,
   "expl": "Potential (work per charge) is measured in volts."
  },
  {
   "q": "The SI unit of capacitance is:",
   "opts": [
    "Henry",
    "Farad",
    "Ohm",
    "Siemens"
   ],
   "correct": 1,
   "expl": "Capacitance C = Q/V is measured in farads."
  },
  {
   "q": "Ohm's law states:",
   "opts": [
    "V = IR",
    "V = I/R",
    "V = R/I",
    "I = VR"
   ],
   "correct": 0,
   "expl": "Voltage equals current times resistance."
  },
  {
   "q": "The SI unit of resistance is:",
   "opts": [
    "Volt",
    "Ampere",
    "Ohm",
    "Watt"
   ],
   "correct": 2,
   "expl": "Resistance is measured in ohms (Ω)."
  },
  {
   "q": "Kirchhoff's current law states that at a junction:",
   "opts": [
    "Voltage is zero",
    "Sum of currents is zero",
    "Resistance is zero",
    "Power is maximum"
   ],
   "correct": 1,
   "expl": "Charge conservation means incoming currents equal outgoing ones."
  },
  {
   "q": "The drift velocity of electrons is:",
   "opts": [
    "Very large (~10⁶ m/s)",
    "Very small (~10⁻⁴ m/s)",
    "Equal to light speed",
    "Zero"
   ],
   "correct": 1,
   "expl": "Electrons drift slowly even though the signal travels fast."
  },
  {
   "q": "A thermistor is a resistor whose resistance:",
   "opts": [
    "Is constant",
    "Changes with temperature",
    "Changes with light",
    "Is zero"
   ],
   "correct": 1,
   "expl": "Thermistors are temperature-sensitive resistors."
  },
  {
   "q": "The dimensional formula of force is:",
   "opts": [
    "[MLT⁻²]",
    "[MLT⁻¹]",
    "[ML²T⁻²]",
    "[ML⁻¹T]"
   ],
   "correct": 0,
   "expl": "From F = ma, dimensions are mass × length / time²."
  },
  {
   "q": "One electron-volt equals:",
   "opts": [
    "1.6 × 10⁻¹⁹ J",
    "1.6 × 10⁻¹⁸ J",
    "3.2 × 10⁻¹⁹ J",
    "1 J"
   ],
   "correct": 0,
   "expl": "An electron accelerated through 1 V gains 1.6 × 10⁻¹⁹ J."
  }
 ],
 "CHEMISTRY11": [
  {
   "q": "One mole of a substance contains:",
   "opts": [
    "6.022 × 10²² particles",
    "6.022 × 10²³ particles",
    "3.011 × 10²³ particles",
    "1.602 × 10⁻¹⁹ particles"
   ],
   "correct": 1,
   "expl": "A mole is defined by Avogadro's number of particles."
  },
  {
   "q": "Empirical formula represents the:",
   "opts": [
    "Actual number of atoms",
    "Simplest whole-number ratio of atoms",
    "Total mass",
    "Isotopic composition"
   ],
   "correct": 1,
   "expl": "It gives the simplest ratio, e.g. CH₂O for glucose."
  },
  {
   "q": "The limiting reactant is the one that:",
   "opts": [
    "Is in excess",
    "Is consumed first",
    "Has largest mass",
    "Is a catalyst"
   ],
   "correct": 1,
   "expl": "It limits the amount of product formed."
  },
  {
   "q": "Percentage yield equals:",
   "opts": [
    "Theoretical/actual × 100",
    "Actual/theoretical × 100",
    "Actual + theoretical",
    "Moles × 100"
   ],
   "correct": 1,
   "expl": "Yield compares obtained product with the maximum possible."
  },
  {
   "q": "Boyle's law states that at constant temperature:",
   "opts": [
    "P ∝ V",
    "P ∝ 1/V",
    "P ∝ T",
    "V ∝ T"
   ],
   "correct": 1,
   "expl": "Pressure and volume of a gas are inversely proportional."
  },
  {
   "q": "Charles's law states that at constant pressure:",
   "opts": [
    "V ∝ 1/T",
    "V ∝ T",
    "P ∝ T",
    "P ∝ V"
   ],
   "correct": 1,
   "expl": "Gas volume is directly proportional to absolute temperature."
  },
  {
   "q": "The ideal gas equation is:",
   "opts": [
    "PV = nRT",
    "P = nRT/V²",
    "V = nP/RT",
    "RT = P/nV²"
   ],
   "correct": 0,
   "expl": "It combines Boyle's, Charles's and Avogadro's laws."
  },
  {
   "q": "The value of R in SI units is:",
   "opts": [
    "0.0821 dm³·atm/mol·K",
    "8.314 J/mol·K",
    "1.38 × 10⁻²³ J/K",
    "6.022 × 10²³"
   ],
   "correct": 1,
   "expl": "In SI units the gas constant is 8.314 J/mol·K."
  },
  {
   "q": "The molar volume of an ideal gas at STP is:",
   "opts": [
    "11.2 dm³",
    "22.4 dm³",
    "24.0 dm³",
    "44.8 dm³"
   ],
   "correct": 1,
   "expl": "One mole of gas occupies 22.4 dm³ at STP."
  },
  {
   "q": "Dalton's law of partial pressures states that total pressure equals:",
   "opts": [
    "Product of partial pressures",
    "Sum of partial pressures",
    "Average of partial pressures",
    "Difference of partial pressures"
   ],
   "correct": 1,
   "expl": "Each gas contributes its own partial pressure independently."
  },
  {
   "q": "Graham's law: the rate of diffusion is:",
   "opts": [
    "Directly proportional to √M",
    "Inversely proportional to √M",
    "Proportional to M²",
    "Independent of M"
   ],
   "correct": 1,
   "expl": "Lighter gases diffuse faster: rate ∝ 1/√M."
  },
  {
   "q": "Real gases deviate most from ideal behaviour at:",
   "opts": [
    "High T, low P",
    "Low T, high P",
    "High T, high P",
    "Low T, low P"
   ],
   "correct": 1,
   "expl": "Molecules are close together and attractions matter there."
  },
  {
   "q": "Plasma is called the:",
   "opts": [
    "First state of matter",
    "Fourth state of matter",
    "Fifth state of matter",
    "Solid state"
   ],
   "correct": 1,
   "expl": "Ionized gas is regarded as the fourth state."
  },
  {
   "q": "Hydrogen bonding is strongest in:",
   "opts": [
    "NH₃",
    "H₂O",
    "HF",
    "CH₄"
   ],
   "correct": 2,
   "expl": "Fluorine's high electronegativity makes the HF hydrogen bond strongest."
  },
  {
   "q": "London dispersion forces exist in:",
   "opts": [
    "Polar molecules only",
    "All molecules",
    "Ionic solids only",
    "Metals only"
   ],
   "correct": 1,
   "expl": "Temporary dipoles induce attractions in every substance."
  },
  {
   "q": "Boiling point of non-polar substances increases with:",
   "opts": [
    "Decreasing molar mass",
    "Increasing molar mass",
    "Colour",
    "Odour"
   ],
   "correct": 1,
   "expl": "Larger electron clouds give stronger dispersion forces."
  },
  {
   "q": "The four quantum numbers are:",
   "opts": [
    "n, l, m, s",
    "n, p, d, f",
    "x, y, z, t",
    "a, b, c, d"
   ],
   "correct": 0,
   "expl": "Principal, azimuthal, magnetic and spin quantum numbers describe an electron."
  },
  {
   "q": "The shape of an s-orbital is:",
   "opts": [
    "Dumb-bell",
    "Spherical",
    "Double dumb-bell",
    "Planar"
   ],
   "correct": 1,
   "expl": "s-orbitals are spherically symmetric around the nucleus."
  },
  {
   "q": "The number of p-orbitals is:",
   "opts": [
    "1",
    "3",
    "5",
    "7"
   ],
   "correct": 1,
   "expl": "The p subshell has three orientations: px, py, pz."
  },
  {
   "q": "The number of d-orbitals is:",
   "opts": [
    "3",
    "5",
    "7",
    "10"
   ],
   "correct": 1,
   "expl": "The d subshell contains five orbitals."
  },
  {
   "q": "Aufbau principle states that electrons fill orbitals in order of:",
   "opts": [
    "Increasing energy",
    "Decreasing energy",
    "Alphabetical labels",
    "Random choice"
   ],
   "correct": 0,
   "expl": "Lower-energy orbitals are filled first."
  },
  {
   "q": "Hund's rule states that degenerate orbitals are filled with:",
   "opts": [
    "Paired electrons first",
    "Maximum unpaired electrons",
    "Only s electrons",
    "Alternating spins"
   ],
   "correct": 1,
   "expl": "Unpaired arrangement minimizes electron repulsion."
  },
  {
   "q": "Pauli's exclusion principle allows at most:",
   "opts": [
    "1 electron per orbital",
    "2 electrons per orbital",
    "3 electrons per orbital",
    "4 electrons per orbital"
   ],
   "correct": 1,
   "expl": "Two electrons in one orbital must have opposite spins."
  },
  {
   "q": "The electronic configuration of sodium (Z=11) is:",
   "opts": [
    "[Ne]3s¹",
    "1s²2s²2p⁶3s²",
    "[Ar]4s¹",
    "1s²2s²2p⁶3p¹"
   ],
   "correct": 0,
   "expl": "Sodium has one electron beyond the neon core."
  },
  {
   "q": "The atomic number of iron is:",
   "opts": [
    "24",
    "25",
    "26",
    "27"
   ],
   "correct": 2,
   "expl": "Iron (Fe) has 26 protons."
  },
  {
   "q": "An ionic bond involves:",
   "opts": [
    "Sharing of electron pairs",
    "Complete transfer of electrons",
    "One-sided sharing",
    "No electrons"
   ],
   "correct": 1,
   "expl": "One atom loses and another gains electrons completely."
  },
  {
   "q": "A coordinate (dative) bond is formed when:",
   "opts": [
    "Both atoms share equally",
    "One atom donates both shared electrons",
    "Electrons are transferred",
    "No sharing occurs"
   ],
   "correct": 1,
   "expl": "The shared pair comes entirely from one atom."
  },
  {
   "q": "VSEPR theory predicts molecular shape from:",
   "opts": [
    "Electron pair repulsions",
    "Nuclear charge",
    "Atomic mass",
    "Bond energy"
   ],
   "correct": 0,
   "expl": "Repulsion between electron pairs decides geometry."
  },
  {
   "q": "The shape of methane (CH₄) is:",
   "opts": [
    "Linear",
    "Trigonal planar",
    "Tetrahedral",
    "Pyramidal"
   ],
   "correct": 2,
   "expl": "Four bond pairs arrange tetrahedrally at 109.5°."
  },
  {
   "q": "The shape of water (H₂O) is:",
   "opts": [
    "Linear",
    "Bent (angular)",
    "Tetrahedral",
    "Trigonal planar"
   ],
   "correct": 1,
   "expl": "Two lone pairs bend the molecule to about 104.5°."
  },
  {
   "q": "The shape of ammonia (NH₃) is:",
   "opts": [
    "Tetrahedral",
    "Trigonal pyramidal",
    "Bent",
    "Linear"
   ],
   "correct": 1,
   "expl": "One lone pair makes the geometry pyramidal."
  },
  {
   "q": "The shape of carbon dioxide (CO₂) is:",
   "opts": [
    "Bent",
    "Linear",
    "Tetrahedral",
    "Trigonal planar"
   ],
   "correct": 1,
   "expl": "Two double bonds opposite each other give a linear molecule."
  },
  {
   "q": "The hybridization of carbon in methane is:",
   "opts": [
    "sp",
    "sp²",
    "sp³",
    "dsp²"
   ],
   "correct": 2,
   "expl": "Four sigma bonds need four sp³ hybrid orbitals."
  },
  {
   "q": "The hybridization of carbon in ethene is:",
   "opts": [
    "sp",
    "sp²",
    "sp³",
    "sp³d"
   ],
   "correct": 1,
   "expl": "The double bond uses sp² hybrids plus one p orbital."
  },
  {
   "q": "The hybridization of carbon in acetylene is:",
   "opts": [
    "sp",
    "sp²",
    "sp³",
    "dsp"
   ],
   "correct": 0,
   "expl": "The triple bond uses sp hybridization."
  },
  {
   "q": "Enthalpy H is defined as:",
   "opts": [
    "H = U - PV",
    "H = U + PV",
    "H = PV/U",
    "H = U/PV"
   ],
   "correct": 1,
   "expl": "Enthalpy adds pressure-volume work to internal energy."
  },
  {
   "q": "In an exothermic reaction, ΔH is:",
   "opts": [
    "Positive",
    "Negative",
    "Zero",
    "Infinite"
   ],
   "correct": 1,
   "expl": "Heat is released, so enthalpy of products is lower."
  },
  {
   "q": "Hess's law states that enthalpy change is:",
   "opts": [
    "Path dependent",
    "Independent of path",
    "Always zero",
    "Always positive"
   ],
   "correct": 1,
   "expl": "Enthalpy is a state function."
  },
  {
   "q": "For aA + bB ⇌ cC + dD, Kc equals:",
   "opts": [
    "[C]ᶜ[D]ᵈ/[A]ᵃ[B]ᵇ",
    "[A]ᵃ[B]ᵇ/[C]ᶜ[D]ᵈ",
    "[A][B]/[C][D]",
    "Products minus reactants"
   ],
   "correct": 0,
   "expl": "Kc is products' concentrations over reactants', raised to coefficients."
  },
  {
   "q": "Le Chatelier's principle says a system at equilibrium:",
   "opts": [
    "Collapses",
    "Opposes the imposed change",
    "Ignores the change",
    "Explodes"
   ],
   "correct": 1,
   "expl": "The equilibrium shifts to counteract the disturbance."
  },
  {
   "q": "Increasing pressure shifts equilibrium towards:",
   "opts": [
    "More moles of gas",
    "Fewer moles of gas",
    "No shift",
    "More solids"
   ],
   "correct": 1,
   "expl": "The system favours the side occupying less volume."
  },
  {
   "q": "A catalyst in a reversible reaction:",
   "opts": [
    "Shifts equilibrium right",
    "Lowers activation energy without shifting equilibrium",
    "Is consumed",
    "Increases ΔH"
   ],
   "correct": 1,
   "expl": "It speeds both directions equally, so Kc is unchanged."
  },
  {
   "q": "For rate = k[A]ᴾ[B]ⁿ, the order of reaction is:",
   "opts": [
    "m + n",
    "m × n",
    "m - n",
    "k"
   ],
   "correct": 0,
   "expl": "Overall order is the sum of the exponents."
  },
  {
   "q": "Activation energy is the:",
   "opts": [
    "Total energy of reactants",
    "Minimum energy barrier for reaction",
    "Energy released",
    "Average kinetic energy"
   ],
   "correct": 1,
   "expl": "Molecules must clear this barrier to react."
  },
  {
   "q": "Molarity is:",
   "opts": [
    "Moles per kg of solvent",
    "Moles per dm³ of solution",
    "Grams per dm³",
    "Moles per mole"
   ],
   "correct": 1,
   "expl": "Molarity = moles of solute per cubic decimetre of solution."
  },
  {
   "q": "Molality is:",
   "opts": [
    "Moles per dm³ of solution",
    "Moles per kg of solvent",
    "Grams per kg",
    "Moles per litre"
   ],
   "correct": 1,
   "expl": "Molality uses mass of solvent, independent of temperature."
  },
  {
   "q": "Mole fraction equals:",
   "opts": [
    "Moles of component / total moles",
    "Mass / total mass",
    "Volume / total volume",
    "Moles × total moles"
   ],
   "correct": 0,
   "expl": "It is the fraction of total moles contributed by one component."
  },
  {
   "q": "Colligative properties depend on the:",
   "opts": [
    "Nature of solute",
    "Number of solute particles",
    "Colour of solution",
    "Size of solvent"
   ],
   "correct": 1,
   "expl": "They depend on particle count, not identity."
  },
  {
   "q": "Raoult's law relates vapour pressure to:",
   "opts": [
    "Temperature only",
    "Mole fraction of solvent",
    "Molar mass",
    "Density"
   ],
   "correct": 1,
   "expl": "Vapour pressure lowering is proportional to solute mole fraction."
  },
  {
   "q": "The number of significant figures in 0.00450 is:",
   "opts": [
    "2",
    "3",
    "5",
    "4"
   ],
   "correct": 1,
   "expl": "Leading zeros are not significant; the trailing zero after the decimal is."
  }
 ],
 "BIOLOGY11": [
  {
   "q": "Carbohydrates contain C, H and O in the ratio:",
   "opts": [
    "1:1:1",
    "1:2:1",
    "2:1:1",
    "1:1:2"
   ],
   "correct": 1,
   "expl": "Most carbohydrates follow the general formula Cₓ(H₂O)ₓ."
  },
  {
   "q": "An example of a monosaccharide is:",
   "opts": [
    "Sucrose",
    "Glucose",
    "Starch",
    "Cellulose"
   ],
   "correct": 1,
   "expl": "Glucose is a single six-carbon sugar unit."
  },
  {
   "q": "An example of a disaccharide is:",
   "opts": [
    "Glucose",
    "Fructose",
    "Sucrose",
    "Starch"
   ],
   "correct": 2,
   "expl": "Sucrose combines glucose and fructose."
  },
  {
   "q": "The storage polysaccharide in plants is:",
   "opts": [
    "Glycogen",
    "Starch",
    "Cellulose",
    "Chitin"
   ],
   "correct": 1,
   "expl": "Plants store glucose as starch."
  },
  {
   "q": "The storage polysaccharide in animals is:",
   "opts": [
    "Starch",
    "Cellulose",
    "Glycogen",
    "Inulin"
   ],
   "correct": 2,
   "expl": "Animals store glucose as glycogen in liver and muscles."
  },
  {
   "q": "Plant cell walls are made of:",
   "opts": [
    "Chitin",
    "Cellulose",
    "Glycogen",
    "Starch"
   ],
   "correct": 1,
   "expl": "Cellulose fibres give plant walls strength."
  },
  {
   "q": "Proteins are polymers of:",
   "opts": [
    "Glucose",
    "Amino acids",
    "Fatty acids",
    "Nucleotides"
   ],
   "correct": 1,
   "expl": "Amino acids link by peptide bonds to form proteins."
  },
  {
   "q": "A peptide bond joins:",
   "opts": [
    "Two sugars",
    "Two amino acids",
    "Sugar and phosphate",
    "Two fatty acids"
   ],
   "correct": 1,
   "expl": "Condensation of amino and carboxyl groups forms it."
  },
  {
   "q": "Enzymes are:",
   "opts": [
    "Biological catalysts",
    "Energy stores",
    "Genetic material",
    "Hormones only"
   ],
   "correct": 0,
   "expl": "Enzymes speed up reactions without being consumed."
  },
  {
   "q": "The lock-and-key model of enzyme action was proposed by:",
   "opts": [
    "Koshland",
    "Emil Fischer",
    "Michaelis",
    "Sumner"
   ],
   "correct": 1,
   "expl": "Fischer suggested the substrate fits the active site like a key."
  },
  {
   "q": "The induced-fit model was proposed by:",
   "opts": [
    "Emil Fischer",
    "Koshland",
    "Watson",
    "Crick"
   ],
   "correct": 1,
   "expl": "Koshland said the active site moulds around the substrate."
  },
  {
   "q": "Pepsin works best at pH around:",
   "opts": [
    "7",
    "2",
    "10",
    "5"
   ],
   "correct": 1,
   "expl": "Stomach acid gives pepsin its acidic optimum."
  },
  {
   "q": "The optimum temperature for human enzymes is about:",
   "opts": [
    "20°C",
    "30°C",
    "37°C",
    "50°C"
   ],
   "correct": 2,
   "expl": "Human enzymes evolved to work at body temperature."
  },
  {
   "q": "A cofactor is a:",
   "opts": [
    "Protein part of enzyme",
    "Non-protein helper of enzyme",
    "Substrate",
    "Inhibitor"
   ],
   "correct": 1,
   "expl": "Metal ions or molecules assisting enzymes are cofactors."
  },
  {
   "q": "A coenzyme is:",
   "opts": [
    "An inorganic ion",
    "An organic non-protein cofactor",
    "The apoenzyme",
    "A competitive inhibitor"
   ],
   "correct": 1,
   "expl": "Vitamins often serve as organic coenzymes."
  },
  {
   "q": "The fluid-mosaic model of the cell membrane was given by:",
   "opts": [
    "Robertson",
    "Singer and Nicolson",
    "Davson and Danielli",
    "Overton"
   ],
   "correct": 1,
   "expl": "It describes proteins floating in a lipid bilayer."
  },
  {
   "q": "Mitochondria are the site of:",
   "opts": [
    "Photosynthesis",
    "Aerobic respiration",
    "Protein synthesis",
    "Lipid digestion"
   ],
   "correct": 1,
   "expl": "They release energy from food as ATP."
  },
  {
   "q": "Chloroplasts are the site of:",
   "opts": [
    "Respiration",
    "Photosynthesis",
    "Digestion",
    "Excretion"
   ],
   "correct": 1,
   "expl": "Their chlorophyll traps light energy."
  },
  {
   "q": "70S ribosomes are found in:",
   "opts": [
    "Human cytoplasm",
    "Prokaryotes, mitochondria and chloroplasts",
    "Plant vacuoles",
    "Animal nuclei"
   ],
   "correct": 1,
   "expl": "Smaller 70S ribosomes occur in bacteria and organelles."
  },
  {
   "q": "80S ribosomes are found in:",
   "opts": [
    "Bacteria",
    "Eukaryotic cytoplasm",
    "Mitochondria",
    "Chloroplasts"
   ],
   "correct": 1,
   "expl": "Eukaryotic cytosol has larger 80S ribosomes."
  },
  {
   "q": "The nucleolus produces:",
   "opts": [
    "mRNA",
    "Ribosomal RNA",
    "tRNA",
    "DNA"
   ],
   "correct": 1,
   "expl": "It assembles the RNA for ribosome subunits."
  },
  {
   "q": "Lysosomes are called suicide bags because they:",
   "opts": [
    "Store toxins",
    "Digest the cell's own worn parts",
    "Make ATP",
    "Copy DNA"
   ],
   "correct": 1,
   "expl": "Their enzymes can digest organelles and the cell itself."
  },
  {
   "q": "Plant cells typically have a:",
   "opts": [
    "Small vacuole",
    "Large central vacuole",
    "No vacuole",
    "Contractile vacuole"
   ],
   "correct": 1,
   "expl": "The central vacuole stores water and keeps turgidity."
  },
  {
   "q": "The light reactions of photosynthesis occur in the:",
   "opts": [
    "Stroma",
    "Thylakoid membranes (grana)",
    "Cytoplasm",
    "Matrix"
   ],
   "correct": 1,
   "expl": "Thylakoids hold chlorophyll and the electron transport chain."
  },
  {
   "q": "The Calvin cycle (dark reactions) occurs in the:",
   "opts": [
    "Grana",
    "Stroma",
    "Cytoplasm",
    "Thylakoid lumen"
   ],
   "correct": 1,
   "expl": "CO₂ fixation enzymes work in the stroma."
  },
  {
   "q": "Photolysis is the:",
   "opts": [
    "Splitting of water by light",
    "Fixation of CO₂",
    "Formation of glucose",
    "Release of oxygen only"
   ],
   "correct": 0,
   "expl": "Light splits water, releasing electrons, protons and O₂."
  },
  {
   "q": "Glycolysis takes place in the:",
   "opts": [
    "Mitochondria",
    "Cytoplasm",
    "Nucleus",
    "Chloroplast"
   ],
   "correct": 1,
   "expl": "Glucose is split into pyruvate in the cytosol."
  },
  {
   "q": "The Krebs cycle takes place in the:",
   "opts": [
    "Cytoplasm",
    "Mitochondrial matrix",
    "Inner membrane",
    "Nucleus"
   ],
   "correct": 1,
   "expl": "Acetyl-CoA is oxidized in the mitochondrial matrix."
  },
  {
   "q": "The electron transport chain is located in the:",
   "opts": [
    "Outer membrane",
    "Inner mitochondrial membrane (cristae)",
    "Matrix",
    "Cytoplasm"
   ],
   "correct": 1,
   "expl": "Cristae hold the carriers that pump protons."
  },
  {
   "q": "Net ATP gain from glycolysis is:",
   "opts": [
    "2",
    "4",
    "8",
    "36"
   ],
   "correct": 0,
   "expl": "Glycolysis yields 4 ATP but uses 2, netting 2."
  },
  {
   "q": "Total ATP from aerobic respiration of one glucose is about:",
   "opts": [
    "2",
    "8",
    "36",
    "100"
   ],
   "correct": 2,
   "expl": "Oxidative phosphorylation gives roughly 36 ATP."
  },
  {
   "q": "Alcoholic fermentation produces:",
   "opts": [
    "Lactic acid",
    "Ethanol and CO₂",
    "Acetic acid",
    "Methane"
   ],
   "correct": 1,
   "expl": "Yeast converts pyruvate to ethanol and carbon dioxide."
  },
  {
   "q": "Viruses are:",
   "opts": [
    "Cellular parasites",
    "Acellular obligate parasites",
    "Free-living cells",
    "Bacteria"
   ],
   "correct": 1,
   "expl": "They reproduce only inside host cells."
  },
  {
   "q": "A bacteriophage is a virus that attacks:",
   "opts": [
    "Plants",
    "Bacteria",
    "Animals",
    "Fungi"
   ],
   "correct": 1,
   "expl": "Phages infect bacterial cells."
  },
  {
   "q": "HIV is a:",
   "opts": [
    "DNA virus",
    "Retrovirus (RNA)",
    "Bacteriophage",
    "Prion"
   ],
   "correct": 1,
   "expl": "HIV carries RNA and reverse transcriptase."
  },
  {
   "q": "Bacteria are:",
   "opts": [
    "Eukaryotes",
    "Prokaryotes",
    "Viruses",
    "Fungi"
   ],
   "correct": 1,
   "expl": "They lack a membrane-bound nucleus."
  },
  {
   "q": "Cyanobacteria are:",
   "opts": [
    "Heterotrophic bacteria",
    "Photosynthetic bacteria",
    "Fungi",
    "Algae"
   ],
   "correct": 1,
   "expl": "They photosynthesize like plants but are prokaryotes."
  },
  {
   "q": "Bacteria commonly reproduce by:",
   "opts": [
    "Mitosis",
    "Binary fission",
    "Meiosis",
    "Budding"
   ],
   "correct": 1,
   "expl": "One cell splits into two identical cells."
  },
  {
   "q": "Protists are:",
   "opts": [
    "Multicellular prokaryotes",
    "Unicellular eukaryotes",
    "Acellular",
    "Multicellular fungi"
   ],
   "correct": 1,
   "expl": "Most protists are single-celled eukaryotes."
  },
  {
   "q": "Amoeba moves by:",
   "opts": [
    "Cilia",
    "Flagella",
    "Pseudopodia",
    "Contraction"
   ],
   "correct": 2,
   "expl": "It extends false feet of cytoplasm to crawl."
  },
  {
   "q": "Paramecium moves by:",
   "opts": [
    "Pseudopodia",
    "Cilia",
    "Flagella",
    "Gliding"
   ],
   "correct": 1,
   "expl": "Thousands of cilia beat to propel it."
  },
  {
   "q": "Euglena is:",
   "opts": [
    "Fully heterotrophic",
    "Mixotrophic",
    "A fungus",
    "A bacterium"
   ],
   "correct": 1,
   "expl": "It photosynthesizes in light and feeds otherwise."
  },
  {
   "q": "Fungi obtain nutrition by:",
   "opts": [
    "Photosynthesis",
    "Absorption",
    "Ingestion",
    "Chemosynthesis"
   ],
   "correct": 1,
   "expl": "They secrete enzymes and absorb digested food."
  },
  {
   "q": "Yeast is a:",
   "opts": [
    "Bacterium",
    "Unicellular fungus",
    "Alga",
    "Virus"
   ],
   "correct": 1,
   "expl": "This single-celled fungus ferments sugars."
  },
  {
   "q": "Mycorrhizae are:",
   "opts": [
    "Root diseases",
    "Fungi-roots symbiosis",
    "Bacterial nodules",
    "Parasitic plants"
   ],
   "correct": 1,
   "expl": "Fungi help roots absorb minerals in this mutualism."
  },
  {
   "q": "Bryophytes are called amphibians of the plant kingdom because they:",
   "opts": [
    "Live in deserts",
    "Need water for reproduction",
    "Have flowers",
    "Produce seeds"
   ],
   "correct": 1,
   "expl": "Their sperm swim in water like amphibians' reproduction."
  },
  {
   "q": "Ferns belong to:",
   "opts": [
    "Bryophytes",
    "Pteridophytes",
    "Gymnosperms",
    "Angiosperms"
   ],
   "correct": 1,
   "expl": "Pteridophytes are seedless vascular plants."
  },
  {
   "q": "Gymnosperms produce:",
   "opts": [
    "Enclosed seeds",
    "Naked seeds",
    "No seeds",
    "Spores only"
   ],
   "correct": 1,
   "expl": "Their seeds sit exposed on cones."
  },
  {
   "q": "Angiosperms are characterized by:",
   "opts": [
    "Naked seeds",
    "Flowers and enclosed seeds",
    "No vascular tissue",
    "Dominant gametophyte"
   ],
   "correct": 1,
   "expl": "Flowering plants enclose seeds in fruits."
  },
  {
   "q": "Double fertilization occurs in:",
   "opts": [
    "Gymnosperms",
    "Angiosperms",
    "Ferns",
    "Mosses"
   ],
   "correct": 1,
   "expl": "One sperm fuses with the egg, another with polar nuclei."
  }
 ],
 "MATH11": [
  {
   "q": "Which chain of number sets is correct?",
   "opts": [
    "N ⊂ W ⊂ Z ⊂ Q ⊂ R",
    "R ⊂ Q ⊂ Z ⊂ W ⊂ N",
    "Q ⊂ R ⊂ N ⊂ Z",
    "W ⊂ N ⊂ Q ⊂ R"
   ],
   "correct": 0,
   "expl": "Each set is contained in the next larger one."
  },
  {
   "q": "The set of irrational numbers is denoted by:",
   "opts": [
    "Q",
    "Q'",
    "Z",
    "N"
   ],
   "correct": 1,
   "expl": "Q' (Q prime) is the complement of rationals in reals."
  },
  {
   "q": "Commutative law of addition states:",
   "opts": [
    "a + b = b + a",
    "a + (b + c) = (a + b) + c",
    "a + 0 = a",
    "a + (-a) = 0"
   ],
   "correct": 0,
   "expl": "Order of addition does not change the sum."
  },
  {
   "q": "The additive identity in real numbers is:",
   "opts": [
    "1",
    "0",
    "-1",
    "a"
   ],
   "correct": 1,
   "expl": "Adding 0 leaves any number unchanged."
  },
  {
   "q": "The multiplicative identity in real numbers is:",
   "opts": [
    "0",
    "1",
    "-1",
    "a"
   ],
   "correct": 1,
   "expl": "Multiplying by 1 leaves any number unchanged."
  },
  {
   "q": "The additive inverse of a is:",
   "opts": [
    "1/a",
    "-a",
    "a²",
    "1 - a"
   ],
   "correct": 1,
   "expl": "a + (-a) = 0."
  },
  {
   "q": "The multiplicative inverse of a (a ≠ 0) is:",
   "opts": [
    "-a",
    "a²",
    "1/a",
    "a + 1"
   ],
   "correct": 2,
   "expl": "a × (1/a) = 1."
  },
  {
   "q": "(a + b)² expands to:",
   "opts": [
    "a² + b²",
    "a² + 2ab + b²",
    "a² - 2ab + b²",
    "2a² + 2b²"
   ],
   "correct": 1,
   "expl": "The middle term 2ab comes from the cross product."
  },
  {
   "q": "(a - b)(a + b) equals:",
   "opts": [
    "a² + b²",
    "a² - b²",
    "(a - b)²",
    "2ab"
   ],
   "correct": 1,
   "expl": "It is the difference of squares identity."
  },
  {
   "q": "(a + b)³ expands to:",
   "opts": [
    "a³ + b³",
    "a³ + 3a²b + 3ab² + b³",
    "a³ - 3a²b + 3ab² - b³",
    "3(a³ + b³)"
   ],
   "correct": 1,
   "expl": "Binomial coefficients 1, 3, 3, 1 give the expansion."
  },
  {
   "q": "x³ + y³ factorises as:",
   "opts": [
    "(x + y)(x² + xy + y²)",
    "(x + y)(x² - xy + y²)",
    "(x - y)(x² + xy + y²)",
    "(x + y)³"
   ],
   "correct": 1,
   "expl": "Sum of cubes: a³ + b³ = (a+b)(a²-ab+b²)."
  },
  {
   "q": "De Morgan's law: (A ∪ B)' equals:",
   "opts": [
    "A' ∪ B'",
    "A' ∩ B'",
    "A ∩ B",
    "A ∪ B"
   ],
   "correct": 1,
   "expl": "The complement of a union is the intersection of complements."
  },
  {
   "q": "n(A ∪ B) equals:",
   "opts": [
    "n(A) + n(B)",
    "n(A) + n(B) - n(A ∩ B)",
    "n(A) × n(B)",
    "n(A) - n(B)"
   ],
   "correct": 1,
   "expl": "Common elements counted twice must be subtracted once."
  },
  {
   "q": "A relation is a function if:",
   "opts": [
    "Each x has exactly one y",
    "Each y has one x",
    "It has two variables",
    "It is linear"
   ],
   "correct": 0,
   "expl": "Function definition requires a unique image for each input."
  },
  {
   "q": "A one-one (injective) function maps:",
   "opts": [
    "Many x to one y",
    "Distinct x to distinct y",
    "One x to many y",
    "Nothing"
   ],
   "correct": 1,
   "expl": "Injective means different inputs give different outputs."
  },
  {
   "q": "An onto (surjective) function covers:",
   "opts": [
    "Part of codomain",
    "The whole codomain",
    "Only domain",
    "Empty set"
   ],
   "correct": 1,
   "expl": "Every element of the codomain has a pre-image."
  },
  {
   "q": "(fog)(x) means:",
   "opts": [
    "f(x) × g(x)",
    "f(g(x))",
    "g(f(x))",
    "f(x) + g(x)"
   ],
   "correct": 1,
   "expl": "Composition applies g first, then f."
  },
  {
   "q": "A function has an inverse if it is:",
   "opts": [
    "One-one only",
    "Onto only",
    "Bijective",
    "Constant"
   ],
   "correct": 2,
   "expl": "Both injective and surjective are needed for invertibility."
  },
  {
   "q": "Matrix multiplication is:",
   "opts": [
    "Commutative",
    "Not commutative in general",
    "Always zero",
    "Always identity"
   ],
   "correct": 1,
   "expl": "In general AB ≠ BA."
  },
  {
   "q": "(AB)ᵗ equals:",
   "opts": [
    "AᵗBᵗ",
    "BᵗAᵗ",
    "AB",
    "(BA)ᵗᵗ"
   ],
   "correct": 1,
   "expl": "The transpose of a product reverses the order."
  },
  {
   "q": "det(AB) equals:",
   "opts": [
    "detA + detB",
    "detA × detB",
    "detA - detB",
    "detA / detB"
   ],
   "correct": 1,
   "expl": "Determinant of a product is the product of determinants."
  },
  {
   "q": "A singular matrix has determinant:",
   "opts": [
    "1",
    "0",
    "-1",
    "Infinite"
   ],
   "correct": 1,
   "expl": "Zero determinant means no inverse exists."
  },
  {
   "q": "A⁻¹ equals:",
   "opts": [
    "adjA × detA",
    "adjA / detA",
    "detA / adjA",
    "Aᵗ"
   ],
   "correct": 1,
   "expl": "Inverse is the adjoint divided by the determinant."
  },
  {
   "q": "Cramer's rule solves:",
   "opts": [
    "Quadratic equations",
    "Systems of linear equations",
    "Differential equations",
    "Inequalities"
   ],
   "correct": 1,
   "expl": "It uses determinants to solve linear systems."
  },
  {
   "q": "The quadratic formula is:",
   "opts": [
    "x = (-b ± √(b² - 4ac)) / 2a",
    "x = (b ± √(b² - 4ac)) / 2a",
    "x = (-b ± √(b² + 4ac)) / 2a",
    "x = (-b ± (b² - 4ac)) / a"
   ],
   "correct": 0,
   "expl": "It gives the roots of ax² + bx + c = 0."
  },
  {
   "q": "The discriminant of ax² + bx + c = 0 is:",
   "opts": [
    "b² + 4ac",
    "b² - 4ac",
    "4ac - b²",
    "(b + c)²"
   ],
   "correct": 1,
   "expl": "The expression under the square root decides root nature."
  },
  {
   "q": "If discriminant > 0, the roots are:",
   "opts": [
    "Equal",
    "Two real and distinct",
    "Complex",
    "Irrational always"
   ],
   "correct": 1,
   "expl": "A positive discriminant gives two different real roots."
  },
  {
   "q": "If discriminant = 0, the roots are:",
   "opts": [
    "Distinct",
    "Equal (repeated)",
    "Imaginary",
    "Zero"
   ],
   "correct": 1,
   "expl": "Zero discriminant means one repeated real root."
  },
  {
   "q": "If discriminant < 0, the roots are:",
   "opts": [
    "Real",
    "Equal",
    "Complex (non-real)",
    "Rational"
   ],
   "correct": 2,
   "expl": "A negative discriminant gives a conjugate complex pair."
  },
  {
   "q": "Sum of roots of ax² + bx + c = 0 is:",
   "opts": [
    "b/a",
    "-b/a",
    "c/a",
    "-c/a"
   ],
   "correct": 1,
   "expl": "By Vieta's formulas, α + β = -b/a."
  },
  {
   "q": "Product of roots of ax² + bx + c = 0 is:",
   "opts": [
    "-b/a",
    "b/a",
    "c/a",
    "-c/a"
   ],
   "correct": 2,
   "expl": "By Vieta's formulas, αβ = c/a."
  },
  {
   "q": "Partial fractions apply to a:",
   "opts": [
    "Proper rational function",
    "Irrational function",
    "Trigonometric function",
    "Exponential function"
   ],
   "correct": 0,
   "expl": "The fraction is split when numerator degree is less than denominator degree."
  },
  {
   "q": "In an arithmetic progression, the common difference is:",
   "opts": [
    "aₙ₊₁ + aₙ",
    "aₙ₊₁ - aₙ",
    "aₙ₊₁ × aₙ",
    "aₙ / aₙ₊₁"
   ],
   "correct": 1,
   "expl": "Each term exceeds the previous by the constant d."
  },
  {
   "q": "The nth term of an A.P. is:",
   "opts": [
    "a + nd",
    "a + (n-1)d",
    "arⁿ⁻¹",
    "a + (n+1)d"
   ],
   "correct": 1,
   "expl": "Starting from a, add d exactly (n-1) times."
  },
  {
   "q": "Sum of first n terms of an A.P.:",
   "opts": [
    "n/2 (a + l)",
    "n/2 (2a + (n-1)d)",
    "Both formulas",
    "n(a + d)"
   ],
   "correct": 2,
   "expl": "Both Sₙ forms are equivalent standard results."
  },
  {
   "q": "In a geometric progression, the common ratio is:",
   "opts": [
    "aₙ₊₁ - aₙ",
    "aₙ₊₁ / aₙ",
    "aₙ + aₙ₊₁",
    "aₙ × d"
   ],
   "correct": 1,
   "expl": "Each term is multiplied by the constant r."
  },
  {
   "q": "The nth term of a G.P. is:",
   "opts": [
    "a + (n-1)d",
    "arⁿ⁻¹",
    "arⁿ",
    "a/rⁿ"
   ],
   "correct": 1,
   "expl": "Starting from a, multiply by r exactly (n-1) times."
  },
  {
   "q": "Sum to infinity of a G.P. (|r| < 1) is:",
   "opts": [
    "a/(1+r)",
    "a/(1-r)",
    "a(1-r)",
    "ar/(1-r)"
   ],
   "correct": 1,
   "expl": "The infinite series converges to a/(1-r)."
  },
  {
   "q": "Harmonic mean of a and b is:",
   "opts": [
    "(a+b)/2",
    "√(ab)",
    "2ab/(a+b)",
    "(a-b)/2"
   ],
   "correct": 2,
   "expl": "H.M. is the reciprocal of the A.M. of reciprocals."
  },
  {
   "q": "For positive numbers, which inequality holds?",
   "opts": [
    "A.M. ≤ G.M. ≤ H.M.",
    "A.M. ≥ G.M. ≥ H.M.",
    "G.M. ≥ A.M.",
    "H.M. ≥ A.M."
   ],
   "correct": 1,
   "expl": "Arithmetic mean is largest, harmonic mean smallest."
  },
  {
   "q": "ⁿ P ᵣ equals:",
   "opts": [
    "n!/(n-r)!",
    "n!/(r!(n-r)!)",
    "n!/r!",
    "(n-r)!/n!"
   ],
   "correct": 0,
   "expl": "Permutations count ordered selections of r from n."
  },
  {
   "q": "ⁿ C ᵣ equals:",
   "opts": [
    "n!/(n-r)!",
    "n!/(r!(n-r)!)",
    "n!/r!",
    "r!/n!"
   ],
   "correct": 1,
   "expl": "Combinations count unordered selections of r from n."
  },
  {
   "q": "ⁿ C ᵣ equals:",
   "opts": [
    "ⁿ P ᵣ",
    "ⁿ C ₙ⁻ᵣ",
    "ⁿ P ₙ⁻ᵣ",
    "n!/r!"
   ],
   "correct": 1,
   "expl": "Choosing r is the same as leaving n-r."
  },
  {
   "q": "sin²θ + cos²θ equals:",
   "opts": [
    "0",
    "1",
    "2",
    "tan²θ"
   ],
   "correct": 1,
   "expl": "This is the fundamental Pythagorean identity."
  },
  {
   "q": "1 + tan²θ equals:",
   "opts": [
    "cos²θ",
    "sec²θ",
    "csc²θ",
    "cot²θ"
   ],
   "correct": 1,
   "expl": "Dividing sin²+cos²=1 by cos² gives this identity."
  },
  {
   "q": "1 + cot²θ equals:",
   "opts": [
    "tan²θ",
    "sec²θ",
    "csc²θ",
    "sin²θ"
   ],
   "correct": 2,
   "expl": "Dividing sin²+cos²=1 by sin² gives this identity."
  },
  {
   "q": "sin 2θ equals:",
   "opts": [
    "2sinθ",
    "2sinθcosθ",
    "sin²θ",
    "cos²θ"
   ],
   "correct": 1,
   "expl": "The double-angle formula for sine."
  },
  {
   "q": "cos 2θ equals:",
   "opts": [
    "cos²θ - sin²θ",
    "2sinθcosθ",
    "sin²θ",
    "1 + sinθ"
   ],
   "correct": 0,
   "expl": "The double-angle formula for cosine."
  },
  {
   "q": "tan(π/4) equals:",
   "opts": [
    "0",
    "1",
    "√3",
    "Undefined"
   ],
   "correct": 1,
   "expl": "At 45°, opposite equals adjacent."
  },
  {
   "q": "sin 30° equals:",
   "opts": [
    "1/2",
    "√3/2",
    "1",
    "√2/2"
   ],
   "correct": 0,
   "expl": "Sine of 30 degrees is one-half."
  }
 ],
 "ENGLISH11": [
  {
   "q": "Choose the correct first conditional:",
   "opts": [
    "If it rains, we will stay home.",
    "If it rained, we will stay home.",
    "If it rains, we would stay home.",
    "If it will rain, we stay home."
   ],
   "correct": 0,
   "expl": "Type 1 uses present simple + will."
  },
  {
   "q": "Choose the correct second conditional:",
   "opts": [
    "If I am rich, I will travel.",
    "If I were rich, I would travel.",
    "If I were rich, I will travel.",
    "If I was rich, I would have travelled."
   ],
   "correct": 1,
   "expl": "Type 2 uses past simple + would for unreal present."
  },
  {
   "q": "Choose the correct third conditional:",
   "opts": [
    "If he studied, he would pass.",
    "If he had studied, he would have passed.",
    "If he has studied, he would pass.",
    "If he would study, he passed."
   ],
   "correct": 1,
   "expl": "Type 3 uses past perfect + would have for unreal past."
  },
  {
   "q": "“Unless” means:",
   "opts": [
    "If",
    "If not",
    "Although",
    "Because"
   ],
   "correct": 1,
   "expl": "'Unless you hurry' = 'If you do not hurry'."
  },
  {
   "q": "Passive of “They will build a bridge”:",
   "opts": [
    "A bridge will be built by them.",
    "A bridge will be build by them.",
    "A bridge is built by them.",
    "A bridge would be built by them."
   ],
   "correct": 0,
   "expl": "Future passive uses will be + past participle."
  },
  {
   "q": "Choose the synonym of CANDID:",
   "opts": [
    "Rude",
    "Frank",
    "Cunning",
    "Shy"
   ],
   "correct": 1,
   "expl": "'Candid' means frank and honest."
  },
  {
   "q": "Choose the antonym of EXPAND:",
   "opts": [
    "Enlarge",
    "Extend",
    "Contract",
    "Swell"
   ],
   "correct": 2,
   "expl": "'Contract' is the opposite of 'expand'."
  },
  {
   "q": "Choose the synonym of ABUNDANT:",
   "opts": [
    "Scarce",
    "Plentiful",
    "Rare",
    "Meagre"
   ],
   "correct": 1,
   "expl": "'Abundant' means existing in large quantities."
  },
  {
   "q": "Choose the antonym of SCARCE:",
   "opts": [
    "Rare",
    "Abundant",
    "Short",
    "Limited"
   ],
   "correct": 1,
   "expl": "'Abundant' is the opposite of 'scarce'."
  },
  {
   "q": "He is junior ___ me.",
   "opts": [
    "than",
    "to",
    "from",
    "of"
   ],
   "correct": 1,
   "expl": "'Junior' takes 'to', not 'than'."
  },
  {
   "q": "She is married ___ him.",
   "opts": [
    "with",
    "to",
    "by",
    "for"
   ],
   "correct": 1,
   "expl": "'Married to' is the correct collocation."
  },
  {
   "q": "This is different ___ that.",
   "opts": [
    "than",
    "from",
    "to",
    "with"
   ],
   "correct": 1,
   "expl": "'Different from' is standard usage."
  },
  {
   "q": "You must comply ___ the rules.",
   "opts": [
    "to",
    "with",
    "for",
    "on"
   ],
   "correct": 1,
   "expl": "'Comply with' is the correct preposition."
  },
  {
   "q": "He insisted ___ going alone.",
   "opts": [
    "to",
    "on",
    "for",
    "at"
   ],
   "correct": 1,
   "expl": "'Insist on/upon' takes the -ing form."
  },
  {
   "q": "He died ___ hunger (not disease):",
   "opts": [
    "of",
    "from",
    "by",
    "with"
   ],
   "correct": 1,
   "expl": "'Die of' is for disease; 'die from' for external causes like hunger."
  },
  {
   "q": "___ is good exercise. (Swimming)",
   "opts": [
    "Swimming",
    "To swimming",
    "Swim",
    "Swam"
   ],
   "correct": 0,
   "expl": "The gerund 'swimming' works as the subject noun."
  },
  {
   "q": "“To err is human” uses:",
   "opts": [
    "A gerund",
    "An infinitive",
    "A participle",
    "A clause"
   ],
   "correct": 1,
   "expl": "'To err' is an infinitive acting as subject."
  },
  {
   "q": "In “broken window”, broken is a:",
   "opts": [
    "Gerund",
    "Infinitive",
    "Participle",
    "Adverb"
   ],
   "correct": 2,
   "expl": "The past participle works as an adjective."
  },
  {
   "q": "Neither the teacher nor the students ___ present.",
   "opts": [
    "was",
    "were",
    "is",
    "has"
   ],
   "correct": 1,
   "expl": "With nor, the verb agrees with the nearer subject."
  },
  {
   "q": "The committee ___ decided unanimously.",
   "opts": [
    "have",
    "has",
    "are",
    "were"
   ],
   "correct": 1,
   "expl": "A collective noun takes a singular verb when acting as one."
  },
  {
   "q": "Many a man ___ tried to climb it.",
   "opts": [
    "have",
    "has",
    "are",
    "were"
   ],
   "correct": 1,
   "expl": "'Many a' is singular and takes a singular verb."
  },
  {
   "q": "Choose the correctly spelt word:",
   "opts": [
    "Occurence",
    "Occurrence",
    "Ocurrence",
    "Occurrance"
   ],
   "correct": 1,
   "expl": "'Occurrence' has double c and double r."
  },
  {
   "q": "Choose the correctly spelt word:",
   "opts": [
    "Embarass",
    "Embarras",
    "Embarrass",
    "Embaress"
   ],
   "correct": 2,
   "expl": "'Embarrass' has double r and double s."
  },
  {
   "q": "Choose the correctly spelt word:",
   "opts": [
    "Necessary",
    "Neccessary",
    "Necesary",
    "Neccesary"
   ],
   "correct": 0,
   "expl": "'Necessary' has one c and double s."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "He accepted the invitation.",
    "He excepted the invitation.",
    "He acepted the invitation.",
    "He eccepted the invitation."
   ],
   "correct": 0,
   "expl": "'Accept' means to receive; 'except' means excluding."
  },
  {
   "q": "The ___ of the college delivered a speech.",
   "opts": [
    "principal",
    "principle",
    "prinsiple",
    "principaly"
   ],
   "correct": 0,
   "expl": "'Principal' is the head; 'principle' is a rule."
  },
  {
   "q": "The car remained ___ for years.",
   "opts": [
    "stationary",
    "stationery",
    "stashonary",
    "stasionary"
   ],
   "correct": 0,
   "expl": "'Stationary' means not moving; 'stationery' is paper."
  },
  {
   "q": "To “bite the dust” means:",
   "opts": [
    "Eat dirt",
    "Suffer defeat",
    "Work hard",
    "Travel far"
   ],
   "correct": 1,
   "expl": "The idiom means to fail or be defeated."
  },
  {
   "q": "“Once in a blue moon” means:",
   "opts": [
    "Every month",
    "Very rarely",
    "At night",
    "On festivals"
   ],
   "correct": 1,
   "expl": "It describes something happening very rarely."
  },
  {
   "q": "“Spill the beans” means:",
   "opts": [
    "Cook food",
    "Reveal a secret",
    "Waste money",
    "Drop something"
   ],
   "correct": 1,
   "expl": "The idiom means to disclose secret information."
  },
  {
   "q": "“Under the weather” means:",
   "opts": [
    "In the rain",
    "Slightly ill",
    "Very happy",
    "Outside"
   ],
   "correct": 1,
   "expl": "It means feeling unwell."
  },
  {
   "q": "“Hit the nail on the head” means:",
   "opts": [
    "Hurt someone",
    "Say exactly the right thing",
    "Do carpentry",
    "Miss the point"
   ],
   "correct": 1,
   "expl": "It means to be exactly correct."
  },
  {
   "q": "Fear of heights is called:",
   "opts": [
    "Hydrophobia",
    "Acrophobia",
    "Claustrophobia",
    "Agoraphobia"
   ],
   "correct": 1,
   "expl": "'Acro-' relates to heights."
  },
  {
   "q": "The study of stars and planets is:",
   "opts": [
    "Astrology",
    "Astronomy",
    "Geology",
    "Biology"
   ],
   "correct": 1,
   "expl": "Astronomy is the scientific study of celestial bodies."
  },
  {
   "q": "One who speaks many languages is a:",
   "opts": [
    "Orator",
    "Polyglot",
    "Linguist only",
    "Interpreter only"
   ],
   "correct": 1,
   "expl": "A polyglot knows several languages."
  },
  {
   "q": "Government by the people is:",
   "opts": [
    "Monarchy",
    "Democracy",
    "Oligarchy",
    "Autocracy"
   ],
   "correct": 1,
   "expl": "Democracy means rule by the people."
  },
  {
   "q": "She said, “I can swim.” (indirect):",
   "opts": [
    "She said she can swim.",
    "She said she could swim.",
    "She said I could swim.",
    "She says she could swim."
   ],
   "correct": 1,
   "expl": "'Can' shifts to 'could' in reported speech."
  },
  {
   "q": "He said, “I will come tomorrow.” (indirect):",
   "opts": [
    "He said he will come tomorrow.",
    "He said he would come the next day.",
    "He said I would come tomorrow.",
    "He says he would come yesterday."
   ],
   "correct": 1,
   "expl": "'Will' becomes 'would' and 'tomorrow' becomes 'the next day'."
  },
  {
   "q": "He said, “Halt!” (indirect):",
   "opts": [
    "He said to halt.",
    "He ordered them to halt.",
    "He asked to halt.",
    "He told that halt."
   ],
   "correct": 1,
   "expl": "Imperatives are reported with ordered/told + to-infinitive."
  },
  {
   "q": "Passive of “Open the door”:",
   "opts": [
    "The door is opened.",
    "Let the door be opened.",
    "The door be opened.",
    "Open the door."
   ],
   "correct": 1,
   "expl": "Imperative passives use 'let + object + be + past participle'."
  },
  {
   "q": "“You must obey” expresses:",
   "opts": [
    "Possibility",
    "Obligation",
    "Advice",
    "Permission"
   ],
   "correct": 1,
   "expl": "'Must' expresses strong obligation."
  },
  {
   "q": "“You should rest” expresses:",
   "opts": [
    "Order",
    "Advice",
    "Ability",
    "Threat"
   ],
   "correct": 1,
   "expl": "'Should' is used for advice."
  },
  {
   "q": "“It might rain” expresses:",
   "opts": [
    "Certainty",
    "Possibility",
    "Order",
    "Promise"
   ],
   "correct": 1,
   "expl": "'Might' expresses a weak possibility."
  },
  {
   "q": "Hardly had he left ___ it started raining.",
   "opts": [
    "than",
    "when",
    "then",
    "that"
   ],
   "correct": 1,
   "expl": "'Hardly/scarcely ... when' is the correct pairing."
  },
  {
   "q": "No sooner had he arrived ___ the bell rang.",
   "opts": [
    "when",
    "than",
    "then",
    "that"
   ],
   "correct": 1,
   "expl": "'No sooner ... than' is the fixed correlative."
  },
  {
   "q": "Scarcely had she spoken ___ he interrupted.",
   "opts": [
    "than",
    "when",
    "then",
    "so"
   ],
   "correct": 1,
   "expl": "'Scarcely ... when' is the correct pairing."
  },
  {
   "q": "Choose the synonym of RELUCTANT:",
   "opts": [
    "Willing",
    "Unwilling",
    "Eager",
    "Ready"
   ],
   "correct": 1,
   "expl": "'Reluctant' means unwilling or hesitant."
  },
  {
   "q": "Choose the antonym of TRANSPARENT:",
   "opts": [
    "Clear",
    "Opaque",
    "Obvious",
    "Thin"
   ],
   "correct": 1,
   "expl": "'Opaque' is the opposite of 'transparent'."
  },
  {
   "q": "He has been working here ___ 2015.",
   "opts": [
    "for",
    "since",
    "from",
    "by"
   ],
   "correct": 1,
   "expl": "'Since' is used with a point of time in perfect tenses."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "He is senior than me.",
    "He is senior to me.",
    "He is more senior than me.",
    "He is senior from me."
   ],
   "correct": 1,
   "expl": "'Senior' takes 'to', just like 'junior'."
  }
 ],
 "URDU11": [
  {
   "q": "غزل میں کم از کم کتنے اشعار ہوتے ہیں؟",
   "opts": [
    "تین",
    "پانچ",
    "سات",
    "دس"
   ],
   "correct": 1,
   "expl": "غزل میں کم از کم پانچ اشعار ہوتے ہیں۔"
  },
  {
   "q": "مطلع کہتے ہیں:",
   "opts": [
    "غزل کے پہلے شعر کو",
    "غزل کے آخری شعر کو",
    "درمیانی شعر کو",
    "ہر شعر کو"
   ],
   "correct": 0,
   "expl": "مطلع غزل کا پہلا شعر ہوتا ہے جس کے دونوں مصرعے ہم قافیہ ہوتے ہیں۔"
  },
  {
   "q": "مقطع وہ شعر ہے جس میں:",
   "opts": [
    "قافیہ نہ ہو",
    "شاعر کا تخلص ہو",
    "ردیف نہ ہو",
    "تین مصرعے ہوں"
   ],
   "correct": 1,
   "expl": "مقطع غزل کا آخری شعر ہوتا ہے جس میں تخلص آتا ہے۔"
  },
  {
   "q": "قافیہ کہتے ہیں:",
   "opts": [
    "ہم آواز الفاظ کو",
    "بار بار آنے والے لفظ کو",
    "پہلے مصرعے کو",
    "آخری شعر کو"
   ],
   "correct": 0,
   "expl": "قافیہ وہ ہم آواز الفاظ ہیں جو شعر کے آخر میں آتے ہیں۔"
  },
  {
   "q": "ردیف کہتے ہیں:",
   "opts": [
    "ہم آواز الفاظ کو",
    "قافیے کے بعد بار بار آنے والے لفظ کو",
    "پہلے مصرعے کو",
    "تخلص کو"
   ],
   "correct": 1,
   "expl": "ردیف قافیے کے بعد دہرایا جانے والا لفظ ہے۔"
  },
  {
   "q": "مثنوی میں ہر شعر کا قافیہ:",
   "opts": [
    "ایک جیسا ہوتا ہے",
    "الگ الگ ہوتا ہے",
    "نہیں ہوتا",
    "تین مصرعوں میں ہوتا ہے"
   ],
   "correct": 1,
   "expl": "مثنوی میں ہر شعر کا قافیہ الگ ہوتا ہے۔"
  },
  {
   "q": "مرثیہ کہتے ہیں:",
   "opts": [
    "خوشی کی نظم کو",
    "کسی کی موت پر غم کے اظہار کو",
    "اللہ کی تعریف کو",
    "وطن کی تعریف کو"
   ],
   "correct": 1,
   "expl": "مرثیہ میں مرحوم کے غم میں نوحہ خوانی کی جاتی ہے۔"
  },
  {
   "q": "قصیدہ کہتے ہیں:",
   "opts": [
    "غم کی نظم کو",
    "کسی کی تعریف میں نظم کو",
    "اللہ کی حمد کو",
    "حضور کی نعت کو"
   ],
   "correct": 1,
   "expl": "قصیدہ میں کسی بادشاہ یا بزرگ کی تعریف ہوتی ہے۔"
  },
  {
   "q": "حمد کہتے ہیں:",
   "opts": [
    "اللہ تعالیٰ کی تعریف کو",
    "حضور کی تعریف کو",
    "اہل بیت کی تعریف کو",
    "وطن کی تعریف کو"
   ],
   "correct": 0,
   "expl": "حمد میں اللہ تعالیٰ کی تعریف بیان ہوتی ہے۔"
  },
  {
   "q": "نعت کہتے ہیں:",
   "opts": [
    "اللہ کی تعریف کو",
    "حضور اکرم صلی اللہ علیہ وسلم کی تعریف کو",
    "اہل بیت کی تعریف کو",
    "صحابہ کی تعریف کو"
   ],
   "correct": 1,
   "expl": "نعت میں حضور اکرم کی مدح بیان ہوتی ہے۔"
  },
  {
   "q": "منقبت کہتے ہیں:",
   "opts": [
    "اللہ کی تعریف کو",
    "اہل بیت اطہار کی تعریف کو",
    "حضور کی تعریف کو",
    "وطن کی تعریف کو"
   ],
   "correct": 1,
   "expl": "منقبت میں اہل بیت کے فضائل بیان ہوتے ہیں۔"
  },
  {
   "q": "ترکیب اضافی میں استعمال ہوتا ہے:",
   "opts": [
    "کا، کے، کی",
    "نے، کو",
    "سے، پر",
    "میں، پر"
   ],
   "correct": 0,
   "expl": "ترکیب اضافی کا، کے، کی سے بنتی ہے۔"
  },
  {
   "q": "ترکیب توصیفی میں ہوتا ہے:",
   "opts": [
    "صفت + موصوف",
    "مضاف + مضاف الیہ",
    "فعل + فاعل",
    "حرف + اسم"
   ],
   "correct": 0,
   "expl": "ترکیب توصیفی میں صفت اپنے موصوف کی خوبی بیان کرتی ہے۔"
  },
  {
   "q": "دل کا درد ترکیب کی کون سی قسم ہے؟",
   "opts": [
    "ترکیب توصیفی",
    "ترکیب اضافی",
    "ترکیب عطفی",
    "ترکیب ندائی"
   ],
   "correct": 1,
   "expl": "دل کا درد میں کا سے اضافت ہوا ہے۔"
  },
  {
   "q": "استعارہ کہتے ہیں:",
   "opts": [
    "کسی کو کسی جیسا کہنا",
    "ایک چیز کو دوسری چیز قرار دینا",
    "حد سے بڑھا چڑھا کر بیان کرنا",
    "متضاد الفاظ کا استعمال"
   ],
   "correct": 1,
   "expl": "استعارے میں مشبہ بہ کو عین مشبہ قرار دیا جاتا ہے۔"
  },
  {
   "q": "تشبیہ کہتے ہیں:",
   "opts": [
    "ایک چیز کو دوسری چیز قرار دینا",
    "کسی کو کسی جیسا کہنا",
    "متضاد الفاظ لانا",
    "حد سے بڑھانا"
   ],
   "correct": 1,
   "expl": "تشبیہ میں ایک چیز کو دوسری چیز جیسا کہا جاتا ہے۔"
  },
  {
   "q": "مبالغہ کہتے ہیں:",
   "opts": [
    "حد سے بڑھا چڑھا کر بیان کرنے کو",
    "متضاد الفاظ کے استعمال کو",
    "چیز کو چیز قرار دینے کو",
    "سیدھی بات کہنے کو"
   ],
   "correct": 0,
   "expl": "مبالغے میں کسی بات کو حد سے بڑھا چڑھا کر بیان کیا جاتا ہے۔"
  },
  {
   "q": "صنعت تضاد کہتے ہیں:",
   "opts": [
    "ہم آواز الفاظ لانے کو",
    "متضاد الفاظ کے استعمال کو",
    "حد سے بڑھانے کو",
    "تشبیہ دینے کو"
   ],
   "correct": 1,
   "expl": "صنعت تضاد میں ایک ہی مصرع میں متضاد الفاظ آتے ہیں۔"
  },
  {
   "q": "روزمرہ کہتے ہیں:",
   "opts": [
    "محاورے کو",
    "اہل زبان کے مخصوص استعمال کو",
    "ضرب المثل کو",
    "اصطلاح کو"
   ],
   "correct": 1,
   "expl": "روزمرہ اہل زبان کا وہ استعمال ہے جو لغت سے ہٹ کر ہوتا ہے۔"
  },
  {
   "q": "آستین کا سانپ کا مطلب ہے:",
   "opts": [
    "دوست نما دشمن",
    "پالتو جانور",
    "زہریلا سانپ",
    "بہادر دوست"
   ],
   "correct": 0,
   "expl": "آستین کا سانپ اس دشمن کو کہتے ہیں جو دوست بنا ہوا ہو۔"
  },
  {
   "q": "اپنے منہ میاں مٹھو کا مطلب ہے:",
   "opts": [
    "دوسروں کی تعریف",
    "اپنی تعریف آپ کرنا",
    "میٹھا کھانا",
    "جھوٹ بولنا"
   ],
   "correct": 1,
   "expl": "یہ محاورہ اپنی تعریف خود کرنے والے کے لیے ہے۔"
  },
  {
   "q": "تھالی کا بینگن کا مطلب ہے:",
   "opts": [
    "بہت اچھا آدمی",
    "بے اصول آدمی",
    "سبزی خور",
    "مہمان نواز"
   ],
   "correct": 1,
   "expl": "تھالی کا بینگن اس شخص کو کہتے ہیں جس کا کوئی اصول نہ ہو۔"
  },
  {
   "q": "دال نہ گلنا کا مطلب ہے:",
   "opts": [
    "کھانا نہ پکنا",
    "کامیاب نہ ہونا",
    "دال پکانا",
    "بھوکا رہنا"
   ],
   "correct": 1,
   "expl": "دال نہ گلنا کامیاب نہ ہونے کو کہتے ہیں۔"
  },
  {
   "q": "پانی پانی ہونا کا مطلب ہے:",
   "opts": [
    "پیاسا لگنا",
    "شرمندہ ہونا",
    "نہانا",
    "تیرنا"
   ],
   "correct": 1,
   "expl": "پانی پانی ہونا شرمندہ ہونے کو کہتے ہیں۔"
  },
  {
   "q": "ہاتھ ملنا کا مطلب ہے:",
   "opts": [
    "تالیاں بجانا",
    "پچھتانا",
    "مدد کرنا",
    "کام کرنا"
   ],
   "correct": 1,
   "expl": "ہاتھ ملنا پچھتانے کو کہتے ہیں۔"
  },
  {
   "q": "سر پر سوار ہونا کا مطلب ہے:",
   "opts": [
    "سر پر بیٹھنا",
    "غالب آنا",
    "سر درد ہونا",
    "سونا"
   ],
   "correct": 1,
   "expl": "سر پر سوار ہونا غالب آنے کو کہتے ہیں۔"
  },
  {
   "q": "آنکھیں دکھانا کا مطلب ہے:",
   "opts": [
    "پیار کرنا",
    "ڈرانا دھمکانا",
    "دیکھنا",
    "رونا"
   ],
   "correct": 1,
   "expl": "آنکھیں دکھانا ڈرانے یا دھمکانے کو کہتے ہیں۔"
  },
  {
   "q": "بات بنانا کا مطلب ہے:",
   "opts": [
    "بات کرنا",
    "بہانہ کرنا",
    "سچ بولنا",
    "خاموش رہنا"
   ],
   "correct": 1,
   "expl": "بات بنانا بہانے بازی کو کہتے ہیں۔"
  },
  {
   "q": "جتنی چادر دیکھو اتنے پاؤں پھیلاؤ یہ ہے:",
   "opts": [
    "محاورہ",
    "ضرب المثل",
    "روزمرہ",
    "کہاوت"
   ],
   "correct": 1,
   "expl": "یہ مشہور ضرب المثل ہے کہ اپنی حیثیت کے مطابق خرچ کرو۔"
  },
  {
   "q": "خربوزے کو دیکھ کر خربوزہ رنگ پکڑتا ہے کا مطلب ہے:",
   "opts": [
    "پھل کھانا",
    "صحبت کا اثر",
    "رنگ کرنا",
    "باغبانی"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل صحبت کے اثر کو ظاہر کرتا ہے۔"
  },
  {
   "q": "سابقہ نا کا مطلب ہے:",
   "opts": [
    "اچھا",
    "نہیں",
    "برا",
    "نیا"
   ],
   "correct": 1,
   "expl": "نا سابقے میں نفی کے معنی میں آتا ہے جیسے ناکام۔"
  },
  {
   "q": "سابقہ بے کا مطلب ہے:",
   "opts": [
    "ساتھ",
    "بغیر",
    "بے",
    "نہیں"
   ],
   "correct": 1,
   "expl": "بے کا مطلب بغیر ہے جیسے بے وقوف۔"
  },
  {
   "q": "لاحقہ ی کا مطلب ہے:",
   "opts": [
    "والا",
    "نسبت",
    "جمع",
    "واحد"
   ],
   "correct": 1,
   "expl": "ی لاحقہ نسبت کے لیے آتا ہے جیسے دوستی۔"
  },
  {
   "q": "لاحقہ گار کا مطلب ہے:",
   "opts": [
    "کرنے والا",
    "دینے والا",
    "بنانے والا",
    "لینے والا"
   ],
   "correct": 0,
   "expl": "گار کا مطلب کرنے والا ہے جیسے مددگار۔"
  },
  {
   "q": "خیال کی جمع ہے:",
   "opts": [
    "خیالوں",
    "خیالات",
    "خیالیں",
    "خیالیات"
   ],
   "correct": 1,
   "expl": "خیال کی جمع خیالات ہے۔"
  },
  {
   "q": "سوال کی جمع ہے:",
   "opts": [
    "سوالوں",
    "سوالات",
    "سوالیات",
    "اسئلہ"
   ],
   "correct": 1,
   "expl": "سوال کی جمع سوالات ہے۔"
  },
  {
   "q": "جواب کی جمع ہے:",
   "opts": [
    "جوابوں",
    "جوابات",
    "جوابیں",
    "اجوبہ"
   ],
   "correct": 1,
   "expl": "جواب کی جمع جوابات ہے۔"
  },
  {
   "q": "عقل کی جمع ہے:",
   "opts": [
    "عقلیں",
    "عقول",
    "عقلوں",
    "عقلیات"
   ],
   "correct": 1,
   "expl": "عقل کی جمع عقول ہے۔"
  },
  {
   "q": "کتاب کی جمع ہے:",
   "opts": [
    "کتابیں",
    "کتب",
    "کتابوں",
    "کتابیات"
   ],
   "correct": 1,
   "expl": "کتاب کی جمع کتب ہے۔"
  },
  {
   "q": "ظاہر کا متضاد ہے:",
   "opts": [
    "علن",
    "باطن",
    "واضح",
    "صاف"
   ],
   "correct": 1,
   "expl": "ظاہر کا الٹ باطن ہے۔"
  },
  {
   "q": "حلال کا متضاد ہے:",
   "opts": [
    "جائز",
    "حرام",
    "طیب",
    "پاک"
   ],
   "correct": 1,
   "expl": "حلال کا الٹ حرام ہے۔"
  },
  {
   "q": "جائز کا متضاد ہے:",
   "opts": [
    "حلال",
    "ناجائز",
    "درست",
    "مباح"
   ],
   "correct": 1,
   "expl": "جائز کا الٹ ناجائز ہے۔"
  },
  {
   "q": "دوست کا متضاد ہے:",
   "opts": [
    "رفیق",
    "دشمن",
    "یار",
    "ساتھی"
   ],
   "correct": 1,
   "expl": "دوست کا الٹ دشمن ہے۔"
  },
  {
   "q": "امیر کا متضاد ہے:",
   "opts": [
    "دولت مند",
    "غریب",
    "بادشاہ",
    "نواب"
   ],
   "correct": 1,
   "expl": "امیر کا الٹ غریب ہے۔"
  },
  {
   "q": "سخی کا متضاد ہے:",
   "opts": [
    "فیاض",
    "بخیل",
    "کریم",
    "داتا"
   ],
   "correct": 1,
   "expl": "سخی کا الٹ بخیل ہے۔"
  },
  {
   "q": "عالم کا متضاد ہے:",
   "opts": [
    "فاضل",
    "جاہل",
    "دانشور",
    "متعلم"
   ],
   "correct": 1,
   "expl": "عالم کا الٹ جاہل ہے۔"
  },
  {
   "q": "وفادار کا متضاد ہے:",
   "opts": [
    "مخلص",
    "بے وفا",
    "دیانتدار",
    "سچا"
   ],
   "correct": 1,
   "expl": "وفادار کا الٹ بے وفا ہے۔"
  },
  {
   "q": "آزاد کا متضاد ہے:",
   "opts": [
    "خودمختار",
    "غلام",
    "حر",
    "مالک"
   ],
   "correct": 1,
   "expl": "آزاد کا الٹ غلام ہے۔"
  },
  {
   "q": "نفع کا متضاد ہے:",
   "opts": [
    "فائدہ",
    "نقصان",
    "بچت",
    "منافع"
   ],
   "correct": 1,
   "expl": "نفع کا الٹ نقصان ہے۔"
  },
  {
   "q": "غزل کے پہلے شعر کو مطلع کہتے ہیں۔ (صحیح/غلط)",
   "opts": [
    "صحیح",
    "غلط",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "مطلع غزل کا پہلا شعر ہوتا ہے جس کے دونوں مصرعے ہم قافیہ ہوتے ہیں۔"
  }
 ],
 "ISLAMIAT11": [
  {
   "q": "Ayat-ul-Kursi is verse ___ of Surah Al-Baqarah:",
   "opts": [
    "255",
    "256",
    "285",
    "286"
   ],
   "correct": 0,
   "expl": "Ayat-ul-Kursi is the 255th verse of Surah Al-Baqarah."
  },
  {
   "q": "The first revealed verses belong to Surah:",
   "opts": [
    "Al-Fatiha",
    "Al-Alaq",
    "Al-Muzzammil",
    "Al-Muddaththir"
   ],
   "correct": 1,
   "expl": "The first five verses of Surah Al-Alaq were revealed first."
  },
  {
   "q": "The last revealed verse is from Surah:",
   "opts": [
    "Al-Ma'idah",
    "Al-Baqarah",
    "Al-Imran",
    "An-Nisa"
   ],
   "correct": 1,
   "expl": "Surah Al-Baqarah verse 281 is regarded as the last revealed verse."
  },
  {
   "q": "The Holy Quran is the:",
   "opts": [
    "First divine book",
    "Last divine book",
    "Only divine book",
    "Oldest book"
   ],
   "correct": 1,
   "expl": "It is the final revelation confirming earlier books."
  },
  {
   "q": "The Taurat was revealed to:",
   "opts": [
    "Hazrat Dawud (A.S.)",
    "Hazrat Musa (A.S.)",
    "Hazrat Isa (A.S.)",
    "Hazrat Ibrahim (A.S.)"
   ],
   "correct": 1,
   "expl": "The Taurat (Torah) was given to Prophet Musa (A.S.)."
  },
  {
   "q": "The Zabur was revealed to:",
   "opts": [
    "Hazrat Musa (A.S.)",
    "Hazrat Dawud (A.S.)",
    "Hazrat Isa (A.S.)",
    "Hazrat Nuh (A.S.)"
   ],
   "correct": 1,
   "expl": "The Zabur (Psalms) was given to Prophet Dawud (A.S.)."
  },
  {
   "q": "The Injeel was revealed to:",
   "opts": [
    "Hazrat Musa (A.S.)",
    "Hazrat Dawud (A.S.)",
    "Hazrat Isa (A.S.)",
    "Hazrat Yahya (A.S.)"
   ],
   "correct": 2,
   "expl": "The Injeel (Gospel) was given to Prophet Isa (A.S.)."
  },
  {
   "q": "Hadith means:",
   "opts": [
    "Quranic verse",
    "Sayings, actions and approvals of the Prophet ﷻ",
    "History of caliphs",
    "Islamic poetry"
   ],
   "correct": 1,
   "expl": "Hadith records the Prophet's ﷻ words, deeds and tacit approvals."
  },
  {
   "q": "Sihah Sittah are the:",
   "opts": [
    "Four caliphs",
    "Six authentic Hadith books",
    "Five pillars",
    "Seven heavens"
   ],
   "correct": 1,
   "expl": "They are the six most authentic collections of Hadith."
  },
  {
   "q": "Sahih Bukhari was compiled by:",
   "opts": [
    "Imam Muslim",
    "Imam Bukhari",
    "Imam Abu Dawud",
    "Imam Tirmidhi"
   ],
   "correct": 1,
   "expl": "Muhammad ibn Ismail al-Bukhari compiled Sahih Bukhari."
  },
  {
   "q": "Sahih Muslim was compiled by:",
   "opts": [
    "Imam Bukhari",
    "Imam Muslim",
    "Imam Nasai",
    "Imam Ibn Majah"
   ],
   "correct": 1,
   "expl": "Muslim ibn al-Hajjaj compiled Sahih Muslim."
  },
  {
   "q": "The number of Khulafa-e-Rashideen is:",
   "opts": [
    "3",
    "4",
    "5",
    "6"
   ],
   "correct": 1,
   "expl": "The four rightly guided caliphs ruled after the Prophet ﷻ."
  },
  {
   "q": "The title of Hazrat Abu Bakr (R.A.) was:",
   "opts": [
    "Farooq",
    "Siddiq",
    "Zun-Nurain",
    "Asadullah"
   ],
   "correct": 1,
   "expl": "He was called Siddiq for his truthfulness."
  },
  {
   "q": "The title of Hazrat Umar (R.A.) was:",
   "opts": [
    "Siddiq",
    "Farooq",
    "Ghani",
    "Haider"
   ],
   "correct": 1,
   "expl": "He was called Farooq, the distinguisher of truth and falsehood."
  },
  {
   "q": "The title of Hazrat Usman (R.A.) was:",
   "opts": [
    "Farooq",
    "Siddiq",
    "Zun-Nurain",
    "Saifullah"
   ],
   "correct": 2,
   "expl": "He married two daughters of the Prophet ﷻ, hence Zun-Nurain."
  },
  {
   "q": "The title of Hazrat Ali (R.A.) was:",
   "opts": [
    "Siddiq",
    "Farooq",
    "Haider/Asadullah",
    "Amin"
   ],
   "correct": 2,
   "expl": "He was called the Lion of Allah for his bravery."
  },
  {
   "q": "Ashra Mubashra are the:",
   "opts": [
    "Ten promised Paradise",
    "Ten battles",
    "Ten Surahs",
    "Ten caliphs"
   ],
   "correct": 0,
   "expl": "Ten companions were given glad tidings of Paradise in their lifetime."
  },
  {
   "q": "The first martyr in Islam was:",
   "opts": [
    "Hazrat Hamza (R.A.)",
    "Hazrat Sumayya (R.A.)",
    "Hazrat Yasir (R.A.)",
    "Hazrat Bilal (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Sumayya (R.A.) was martyred for her faith in Makkah."
  },
  {
   "q": "The first adult male to accept Islam was:",
   "opts": [
    "Hazrat Ali (R.A.)",
    "Hazrat Abu Bakr (R.A.)",
    "Hazrat Umar (R.A.)",
    "Hazrat Usman (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Abu Bakr (R.A.) was the first free adult male believer."
  },
  {
   "q": "The first woman to accept Islam was:",
   "opts": [
    "Hazrat Aisha (R.A.)",
    "Hazrat Khadija (R.A.)",
    "Hazrat Fatima (R.A.)",
    "Hazrat Hafsa (R.A.)"
   ],
   "correct": 1,
   "expl": "Hazrat Khadija (R.A.) was the first believer."
  },
  {
   "q": "The Hijrah took place in:",
   "opts": [
    "620 A.D.",
    "621 A.D.",
    "622 A.D.",
    "623 A.D."
   ],
   "correct": 2,
   "expl": "The migration to Madinah in 622 A.D. starts the Islamic calendar."
  },
  {
   "q": "Mawakhat was the bond of brotherhood between:",
   "opts": [
    "Arabs and Persians",
    "Muhajireen and Ansar",
    "Quraish and Jews",
    "Romans and Arabs"
   ],
   "correct": 1,
   "expl": "The Prophet ﷻ paired each migrant with a Madinan helper."
  },
  {
   "q": "The Charter of Madinah is called:",
   "opts": [
    "Meesaq-e-Madinah",
    "Sulah Hudaibiya",
    "Fatah Makkah",
    "Khutba Hujjat-ul-Wida"
   ],
   "correct": 0,
   "expl": "It was the constitution establishing a pluralistic Madinan state."
  },
  {
   "q": "The number of Muslims at the Battle of Badr was:",
   "opts": [
    "313",
    "700",
    "1000",
    "3000"
   ],
   "correct": 0,
   "expl": "313 Muslims faced about a thousand Quraish."
  },
  {
   "q": "The Battle of Uhud was fought in:",
   "opts": [
    "2 Hijri",
    "3 Hijri",
    "4 Hijri",
    "5 Hijri"
   ],
   "correct": 1,
   "expl": "Uhud occurred in 3 A.H."
  },
  {
   "q": "The Battle of Khandaq (Ahzab) was fought in:",
   "opts": [
    "3 Hijri",
    "4 Hijri",
    "5 Hijri",
    "6 Hijri"
   ],
   "correct": 2,
   "expl": "The trench battle took place in 5 A.H."
  },
  {
   "q": "Sulah Hudaibiya was signed in:",
   "opts": [
    "5 Hijri",
    "6 Hijri",
    "7 Hijri",
    "8 Hijri"
   ],
   "correct": 1,
   "expl": "The treaty was concluded in 6 A.H."
  },
  {
   "q": "Fatah Makkah took place in:",
   "opts": [
    "6 Hijri",
    "7 Hijri",
    "8 Hijri",
    "9 Hijri"
   ],
   "correct": 2,
   "expl": "Makkah was conquered peacefully in 8 A.H."
  },
  {
   "q": "Ghazwa Tabuk took place in:",
   "opts": [
    "8 Hijri",
    "9 Hijri",
    "10 Hijri",
    "11 Hijri"
   ],
   "correct": 1,
   "expl": "The expedition to Tabuk was in 9 A.H."
  },
  {
   "q": "Hajjat-ul-Wida was performed in:",
   "opts": [
    "8 Hijri",
    "9 Hijri",
    "10 Hijri",
    "11 Hijri"
   ],
   "correct": 2,
   "expl": "The farewell pilgrimage was in 10 A.H."
  },
  {
   "q": "The Prophet ﷻ passed away in:",
   "opts": [
    "10 Hijri",
    "11 Hijri",
    "12 Hijri",
    "13 Hijri"
   ],
   "correct": 1,
   "expl": "He passed away in Madinah in 11 A.H. (632 A.D.)."
  },
  {
   "q": "Fasting is described in Hadith as a:",
   "opts": [
    "Burden",
    "Shield against sins",
    "Custom",
    "Tax"
   ],
   "correct": 1,
   "expl": "The Prophet ﷻ said fasting is a shield from evil."
  },
  {
   "q": "Namaz is called the:",
   "opts": [
    "Pillar of wealth",
    "Mi'raj of the believer",
    "Key of trade",
    "Light of business"
   ],
   "correct": 1,
   "expl": "Prayer elevates the believer like the Prophet's ﷻ ascension."
  },
  {
   "q": "Zakat:",
   "opts": [
    "Increases wealth spiritually",
    "Purifies wealth",
    "Is optional",
    "Is a tax on land only"
   ],
   "correct": 1,
   "expl": "Zakat cleanses wealth and helps the poor."
  },
  {
   "q": "Hajj is obligatory:",
   "opts": [
    "Every year",
    "Once in a lifetime if able",
    "Only for men",
    "Only for Arabs"
   ],
   "correct": 1,
   "expl": "It is due once for those with means and ability."
  },
  {
   "q": "The greater Jihad is the struggle against:",
   "opts": [
    "Enemies",
    "One's own self (nafs)",
    "Poverty",
    "Ignorance only"
   ],
   "correct": 1,
   "expl": "Hadith calls the inner struggle the greater Jihad."
  },
  {
   "q": "Parents' rights are stressed in Surah:",
   "opts": [
    "Al-Fatiha",
    "Bani Isra'il",
    "Al-Kausar",
    "Al-Fil"
   ],
   "correct": 1,
   "expl": "Surah Bani Isra'il commands kindness to parents."
  },
  {
   "q": "According to Hadith, Paradise lies under the feet of:",
   "opts": [
    "Fathers",
    "Mothers",
    "Teachers",
    "Kings"
   ],
   "correct": 1,
   "expl": "The Prophet ﷻ gave mothers this honoured status."
  },
  {
   "q": "Sidq means:",
   "opts": [
    "Patience",
    "Truthfulness",
    "Justice",
    "Charity"
   ],
   "correct": 1,
   "expl": "Sidq is honesty in speech and conduct."
  },
  {
   "q": "Amanat means:",
   "opts": [
    "Prayer",
    "Trust",
    "Fasting",
    "Pilgrimage"
   ],
   "correct": 1,
   "expl": "Amanat is fulfilling trusts and responsibilities."
  },
  {
   "q": "Adl means:",
   "opts": [
    "Kindness",
    "Justice",
    "Patience",
    "Courage"
   ],
   "correct": 1,
   "expl": "Adl is fairness and justice in dealings."
  },
  {
   "q": "Ihsan means:",
   "opts": [
    "Wealth",
    "Excellence and kindness",
    "Power",
    "Fame"
   ],
   "correct": 1,
   "expl": "Ihsan is worshipping Allah as if you see Him."
  },
  {
   "q": "Sabr means:",
   "opts": [
    "Gratitude",
    "Patience",
    "Prayer",
    "Wealth"
   ],
   "correct": 1,
   "expl": "Sabr is steadfast patience in hardship."
  },
  {
   "q": "Shukr means:",
   "opts": [
    "Patience",
    "Gratitude",
    "Justice",
    "Trust"
   ],
   "correct": 1,
   "expl": "Shukr is thankfulness to Allah for blessings."
  },
  {
   "q": "Tawakkul means:",
   "opts": [
    "Fear",
    "Trust in Allah",
    "Doubt",
    "Wealth"
   ],
   "correct": 1,
   "expl": "Tawakkul is relying on Allah after doing one's best."
  },
  {
   "q": "Taqwa means:",
   "opts": [
    "Fear of people",
    "God-consciousness and piety",
    "Wealth",
    "Knowledge"
   ],
   "correct": 1,
   "expl": "Taqwa is guarding oneself against sin out of Allah's awareness."
  },
  {
   "q": "Riba (interest) in Islam is:",
   "opts": [
    "Allowed",
    "Prohibited",
    "Optional",
    "Recommended"
   ],
   "correct": 1,
   "expl": "The Quran strictly forbids riba."
  },
  {
   "q": "Backbiting (gheebat) is compared in the Quran to:",
   "opts": [
    "Stealing",
    "Eating the flesh of one's dead brother",
    "Lying",
    "Cheating"
   ],
   "correct": 1,
   "expl": "Surah Al-Hujurat (49:12) gives this stark comparison."
  },
  {
   "q": "According to Hadith, cleanliness is:",
   "opts": [
    "A habit",
    "Half of faith",
    "Optional",
    "Only for prayer"
   ],
   "correct": 1,
   "expl": "The Prophet ﷻ said purity is half of faith."
  },
  {
   "q": "Seeking knowledge in Islam is:",
   "opts": [
    "Optional",
    "Obligatory on every Muslim",
    "Only for scholars",
    "Only for men"
   ],
   "correct": 1,
   "expl": "Hadith makes learning an obligation on all Muslims."
  }
 ],
 "PAKSTUDY11": [
  {
   "q": "The ideology of Pakistan is:",
   "opts": [
    "Secular",
    "Islamic",
    "Socialist",
    "Liberal"
   ],
   "correct": 1,
   "expl": "Pakistan was founded on the Islamic ideology of a separate Muslim homeland."
  },
  {
   "q": "The Two-Nation Theory declares that Hindus and Muslims are:",
   "opts": [
    "One nation",
    "Two separate nations",
    "Temporary rivals",
    "Economic partners"
   ],
   "correct": 1,
   "expl": "It holds that the two communities form distinct nations."
  },
  {
   "q": "Sir Syed Ahmad Khan lived during:",
   "opts": [
    "1717-1798",
    "1817-1898",
    "1917-1998",
    "1800-1857"
   ],
   "correct": 1,
   "expl": "His life (1817-1898) covered the post-1857 reform era."
  },
  {
   "q": "The Aligarh Movement aimed at:",
   "opts": [
    "Armed revolt",
    "Educational uplift of Muslims",
    "Partition",
    "Trade unions"
   ],
   "correct": 1,
   "expl": "Sir Syed promoted modern education for Muslims."
  },
  {
   "q": "The Urdu-Hindi controversy erupted in:",
   "opts": [
    "1857",
    "1867",
    "1877",
    "1887"
   ],
   "correct": 1,
   "expl": "The 1867 language dispute pushed Sir Syed towards the Two-Nation Theory."
  },
  {
   "q": "The Simla Deputation demanded:",
   "opts": [
    "Joint electorate",
    "Separate electorate for Muslims",
    "Adult franchise",
    "Provincial autonomy"
   ],
   "correct": 1,
   "expl": "The 1906 deputation secured the promise of separate electorates."
  },
  {
   "q": "The Muslim League was founded at:",
   "opts": [
    "Lahore",
    "Dhaka",
    "Lucknow",
    "Delhi"
   ],
   "correct": 1,
   "expl": "It was founded at Dhaka in December 1906."
  },
  {
   "q": "The Lucknow Pact is called a landmark of:",
   "opts": [
    "Hindu-Muslim unity",
    "Partition",
    "War",
    "Trade"
   ],
   "correct": 0,
   "expl": "The 1916 pact briefly united Congress and the League."
  },
  {
   "q": "The Khilafat Movement lasted from:",
   "opts": [
    "1916-1920",
    "1919-1924",
    "1924-1928",
    "1930-1934"
   ],
   "correct": 1,
   "expl": "It ran from 1919 until the Caliphate's abolition in 1924."
  },
  {
   "q": "The Jallianwala Bagh tragedy occurred on:",
   "opts": [
    "13 April 1919",
    "13 April 1920",
    "23 March 1940",
    "14 August 1947"
   ],
   "correct": 0,
   "expl": "British troops fired on a peaceful gathering at Amritsar."
  },
  {
   "q": "The Nehru Report was presented in:",
   "opts": [
    "1925",
    "1928",
    "1930",
    "1935"
   ],
   "correct": 1,
   "expl": "Its rejection of Muslim demands led to Jinnah's 14 Points."
  },
  {
   "q": "Quaid-e-Azam presented his 14 Points in:",
   "opts": [
    "1928",
    "1929",
    "1930",
    "1931"
   ],
   "correct": 1,
   "expl": "The 1929 points safeguarded Muslim political rights."
  },
  {
   "q": "The Allahabad Address demanded:",
   "opts": [
    "Complete independence",
    "A separate Muslim homeland",
    "Dominion status",
    "Joint electorate"
   ],
   "correct": 1,
   "expl": "Iqbal's 1930 address proposed Muslim-majority provinces as a state."
  },
  {
   "q": "The Round Table Conferences were held in:",
   "opts": [
    "Delhi",
    "London",
    "Lahore",
    "Karachi"
   ],
   "correct": 1,
   "expl": "Three conferences (1930-32) were held in London."
  },
  {
   "q": "The Communal Award was announced in:",
   "opts": [
    "1930",
    "1932",
    "1935",
    "1937"
   ],
   "correct": 1,
   "expl": "It granted separate electorates to minorities in 1932."
  },
  {
   "q": "The Government of India Act was passed in:",
   "opts": [
    "1929",
    "1932",
    "1935",
    "1937"
   ],
   "correct": 2,
   "expl": "The 1935 Act introduced provincial autonomy."
  },
  {
   "q": "In the 1937 elections, the Muslim League's performance was:",
   "opts": [
    "Excellent",
    "Poor",
    "Average",
    "Boycotted"
   ],
   "correct": 1,
   "expl": "Poor results taught the League to reorganize under Jinnah."
  },
  {
   "q": "The Day of Deliverance was observed on:",
   "opts": [
    "22 December 1939",
    "23 March 1940",
    "14 August 1947",
    "26 January 1950"
   ],
   "correct": 0,
   "expl": "Muslims celebrated the end of Congress ministries."
  },
  {
   "q": "The Lahore Resolution was moved by:",
   "opts": [
    "Quaid-e-Azam",
    "A.K. Fazlul Haq",
    "Liaquat Ali Khan",
    "Ch. Rehmat Ali"
   ],
   "correct": 1,
   "expl": "Sher-e-Bengal moved it on 23 March 1940."
  },
  {
   "q": "The Cripps Mission came to India in:",
   "opts": [
    "1940",
    "1942",
    "1945",
    "1946"
   ],
   "correct": 1,
   "expl": "Its 1942 proposals were rejected by both Congress and the League."
  },
  {
   "q": "The Quit India Movement was launched in:",
   "opts": [
    "1940",
    "1942",
    "1944",
    "1946"
   ],
   "correct": 1,
   "expl": "Gandhi launched it in August 1942."
  },
  {
   "q": "The Gandhi-Jinnah talks were held in:",
   "opts": [
    "1942",
    "1944",
    "1946",
    "1947"
   ],
   "correct": 1,
   "expl": "The 1944 talks failed over the Two-Nation Theory."
  },
  {
   "q": "The Simla Conference was held in:",
   "opts": [
    "1944",
    "1945",
    "1946",
    "1947"
   ],
   "correct": 1,
   "expl": "Wavell's 1945 conference failed on Muslim representation."
  },
  {
   "q": "In the 1945-46 elections, the Muslim League won:",
   "opts": [
    "Few seats",
    "Almost all Muslim seats",
    "No seats",
    "Half the seats"
   ],
   "correct": 1,
   "expl": "The sweeping win proved it was the sole Muslim representative."
  },
  {
   "q": "The Cabinet Mission Plan proposed:",
   "opts": [
    "Immediate partition",
    "A united India with groupings",
    "Dominion of Pakistan only",
    "British withdrawal in 1948"
   ],
   "correct": 1,
   "expl": "Its 1946 plan grouped provinces; the League first accepted, then rejected it."
  },
  {
   "q": "Direct Action Day was observed on:",
   "opts": [
    "16 August 1946",
    "14 August 1947",
    "23 March 1940",
    "3 June 1947"
   ],
   "correct": 0,
   "expl": "The League called it after the Cabinet Mission Plan collapsed."
  },
  {
   "q": "The Interim Government was formed in:",
   "opts": [
    "1945",
    "1946",
    "1947",
    "1948"
   ],
   "correct": 1,
   "expl": "It was formed in September 1946 with League participation."
  },
  {
   "q": "The 3rd June Plan was announced by:",
   "opts": [
    "Wavell",
    "Mountbatten",
    "Cripps",
    "Attlee"
   ],
   "correct": 1,
   "expl": "Lord Mountbatten announced the partition plan on 3 June 1947."
  },
  {
   "q": "The Indian Independence Act was passed in:",
   "opts": [
    "June 1947",
    "July 1947",
    "August 1947",
    "January 1948"
   ],
   "correct": 1,
   "expl": "The British Parliament passed it in July 1947."
  },
  {
   "q": "The Radcliffe Award decided the:",
   "opts": [
    "Capital",
    "Boundary between Pakistan and India",
    "National language",
    "Currency"
   ],
   "correct": 1,
   "expl": "Sir Cyril Radcliffe drew the partition boundary."
  },
  {
   "q": "Pakistan's independence was declared on:",
   "opts": [
    "14 August 1947",
    "15 August 1947",
    "23 March 1940",
    "26 January 1950"
   ],
   "correct": 0,
   "expl": "Pakistan came into being on 14 August 1947."
  },
  {
   "q": "The first Governor General of Pakistan was:",
   "opts": [
    "Liaquat Ali Khan",
    "Quaid-e-Azam",
    "Khawaja Nazimuddin",
    "Ghulam Muhammad"
   ],
   "correct": 1,
   "expl": "Quaid-e-Azam took office as Governor General."
  },
  {
   "q": "Which was NOT an early problem of Pakistan?",
   "opts": [
    "Refugee settlement",
    "Division of assets",
    "Canal water dispute",
    "Space programme"
   ],
   "correct": 3,
   "expl": "Refugees, assets and canal water were real immediate crises."
  },
  {
   "q": "The Kashmir issue arose in:",
   "opts": [
    "1947",
    "1948",
    "1965",
    "1971"
   ],
   "correct": 0,
   "expl": "The dispute began with the state's accession in 1947."
  },
  {
   "q": "Junagadh, Hyderabad and Manawadar were:",
   "opts": [
    "British colonies",
    "Princely states claimed by Pakistan",
    "Portuguese ports",
    "UN zones"
   ],
   "correct": 1,
   "expl": "Their accession disputes followed partition."
  },
  {
   "q": "The Objective Resolution was passed on:",
   "opts": [
    "23 March 1949",
    "12 March 1949",
    "14 August 1949",
    "25 December 1949"
   ],
   "correct": 1,
   "expl": "It set the Islamic-democratic basis of the constitution."
  },
  {
   "q": "The Liaquat-Nehru Pact of 1950 concerned:",
   "opts": [
    "Trade",
    "Protection of minorities",
    "Kashmir",
    "Water"
   ],
   "correct": 1,
   "expl": "It safeguarded minority rights in both countries."
  },
  {
   "q": "The Rawalpindi Conspiracy Case was in:",
   "opts": [
    "1949",
    "1951",
    "1953",
    "1955"
   ],
   "correct": 1,
   "expl": "The alleged 1951 coup plot led to arrests."
  },
  {
   "q": "The Bogra Formula was presented in:",
   "opts": [
    "1951",
    "1953",
    "1955",
    "1956"
   ],
   "correct": 1,
   "expl": "Prime Minister Bogra's 1953 formula proposed a bicameral legislature."
  },
  {
   "q": "One Unit was created in:",
   "opts": [
    "1954",
    "1955",
    "1956",
    "1958"
   ],
   "correct": 1,
   "expl": "West Pakistan's provinces merged into One Unit in 1955."
  },
  {
   "q": "The 1956 constitution declared Pakistan a/an:",
   "opts": [
    "Secular republic",
    "Islamic Republic",
    "Monarchy",
    "Federation of states"
   ],
   "correct": 1,
   "expl": "It was the first constitution naming the Islamic Republic."
  },
  {
   "q": "Martial Law was imposed in 1958 by:",
   "opts": [
    "Yahya Khan",
    "Ayub Khan",
    "Zia-ul-Haq",
    "Musharraf"
   ],
   "correct": 1,
   "expl": "General Ayub Khan took over in October 1958."
  },
  {
   "q": "The 1962 constitution introduced a:",
   "opts": [
    "Parliamentary system",
    "Presidential system",
    "Monarchy",
    "Direct democracy"
   ],
   "correct": 1,
   "expl": "Ayub's constitution made the president all-powerful."
  },
  {
   "q": "The 1965 war with India started on:",
   "opts": [
    "5 August",
    "6 September",
    "16 December",
    "3 December"
   ],
   "correct": 1,
   "expl": "India attacked Lahore on 6 September 1965."
  },
  {
   "q": "The Tashkent Declaration was signed in:",
   "opts": [
    "1965",
    "1966",
    "1967",
    "1971"
   ],
   "correct": 1,
   "expl": "It ended the 1965 war in January 1966."
  },
  {
   "q": "The 1970 general elections were won in East Pakistan by:",
   "opts": [
    "Muslim League",
    "Awami League",
    "PPP",
    "Jamaat-e-Islami"
   ],
   "correct": 1,
   "expl": "The Awami League swept East Pakistan's seats."
  },
  {
   "q": "Dhaka fell on:",
   "opts": [
    "6 September 1971",
    "16 December 1971",
    "3 December 1971",
    "25 March 1971"
   ],
   "correct": 1,
   "expl": "East Pakistan became Bangladesh on 16 December 1971."
  },
  {
   "q": "The 1973 constitution provides a:",
   "opts": [
    "Presidential system",
    "Parliamentary system",
    "Monarchy",
    "Military rule"
   ],
   "correct": 1,
   "expl": "It restored parliamentary democracy."
  },
  {
   "q": "The first martial law in Pakistan was imposed in:",
   "opts": [
    "1956",
    "1958",
    "1962",
    "1969"
   ],
   "correct": 1,
   "expl": "It was imposed in October 1958, ending the parliamentary era."
  },
  {
   "q": "The 1962 constitution introduced a:",
   "opts": [
    "Parliamentary system",
    "Presidential system",
    "Monarchy",
    "Direct democracy"
   ],
   "correct": 1,
   "expl": "Ayub Khan's constitution made the president all-powerful."
  }
 ],
 "MATH12": [
  {
   "q": "A limit describes the value a function:",
   "opts": [
    "Equals at a point",
    "Approaches near a point",
    "Never reaches",
    "Jumps over"
   ],
   "correct": 1,
   "expl": "The limit is the approaching value, which may differ from the function value."
  },
  {
   "q": "lim(x→a) c (constant) equals:",
   "opts": [
    "0",
    "c",
    "a",
    "1"
   ],
   "correct": 0,
   "expl": "A constant function always approaches its constant value."
  },
  {
   "q": "lim(x→0) sin x / x equals:",
   "opts": [
    "0",
    "1",
    "Infinite",
    "Undefined"
   ],
   "correct": 1,
   "expl": "This standard limit equals 1."
  },
  {
   "q": "A function is continuous at a if:",
   "opts": [
    "Limit exists",
    "f(a) exists",
    "Limit equals f(a)",
    "Derivative exists"
   ],
   "correct": 2,
   "expl": "Continuity needs the limit to match the function value."
  },
  {
   "q": "The derivative measures:",
   "opts": [
    "Area",
    "Rate of change (slope)",
    "Volume",
    "Average"
   ],
   "correct": 1,
   "expl": "dy/dx is the instantaneous rate of change."
  },
  {
   "q": "d/dx (xⁿ) equals:",
   "opts": [
    "nxⁿ",
    "nxⁿ⁻¹",
    "xⁿ/n",
    "nx"
   ],
   "correct": 1,
   "expl": "The power rule brings the exponent down."
  },
  {
   "q": "d/dx (sin x) equals:",
   "opts": [
    "-sin x",
    "cos x",
    "-cos x",
    "tan x"
   ],
   "correct": 1,
   "expl": "The derivative of sine is cosine."
  },
  {
   "q": "d/dx (cos x) equals:",
   "opts": [
    "sin x",
    "-sin x",
    "cos x",
    "-cos x"
   ],
   "correct": 1,
   "expl": "The derivative of cosine is negative sine."
  },
  {
   "q": "d/dx (eˣ) equals:",
   "opts": [
    "xeˣ⁻¹",
    "eˣ",
    "eˣ/x",
    "1"
   ],
   "correct": 0,
   "expl": "The exponential function is its own derivative."
  },
  {
   "q": "d/dx (ln x) equals:",
   "opts": [
    "1/x",
    "x",
    "eˣ",
    "-1/x²"
   ],
   "correct": 0,
   "expl": "The derivative of the natural log is the reciprocal."
  },
  {
   "q": "The product rule: (uv)' equals:",
   "opts": [
    "u'v'",
    "u'v + uv'",
    "u'v - uv'",
    "uv' + u"
   ],
   "correct": 1,
   "expl": "Differentiate each factor in turn and add."
  },
  {
   "q": "The quotient rule: (u/v)' equals:",
   "opts": [
    "(u'v - uv')/v²",
    "(u'v + uv')/v²",
    "u'/v'",
    "(uv')/v"
   ],
   "correct": 0,
   "expl": "It is (low×d(high) - high×d(low)) over low squared."
  },
  {
   "q": "The chain rule states:",
   "opts": [
    "dy/dx = dy/du + du/dx",
    "dy/dx = dy/du × du/dx",
    "dy/dx = du/dy",
    "dy/dx = u dy"
   ],
   "correct": 1,
   "expl": "Rates multiply through the intermediate variable."
  },
  {
   "q": "d/dx (tan x) equals:",
   "opts": [
    "sec²x",
    "csc²x",
    "-sec²x",
    "cot x"
   ],
   "correct": 0,
   "expl": "The derivative of tangent is secant squared."
  },
  {
   "q": "The second derivative describes:",
   "opts": [
    "Slope",
    "Concavity (curvature)",
    "Area",
    "Speed"
   ],
   "correct": 1,
   "expl": "f'' tells whether the graph bends up or down."
  },
  {
   "q": "At a local maximum:",
   "opts": [
    "f' = 0 and f'' > 0",
    "f' = 0 and f'' < 0",
    "f' > 0",
    "f'' = 0"
   ],
   "correct": 1,
   "expl": "The slope vanishes and the curve bends downward."
  },
  {
   "q": "At a local minimum:",
   "opts": [
    "f' = 0 and f'' < 0",
    "f' = 0 and f'' > 0",
    "f' < 0",
    "f'' < 0"
   ],
   "correct": 1,
   "expl": "The slope vanishes and the curve bends upward."
  },
  {
   "q": "A function is increasing where:",
   "opts": [
    "f' > 0",
    "f' < 0",
    "f' = 0",
    "f'' = 0"
   ],
   "correct": 0,
   "expl": "Positive slope means rising values."
  },
  {
   "q": "∫ xⁿ dx (n ≠ -1) equals:",
   "opts": [
    "xⁿ⁻¹/(n-1)",
    "xⁿ⁺¹/(n+1) + C",
    "nxⁿ⁻¹",
    "xⁿ + C"
   ],
   "correct": 1,
   "expl": "Integration reverses the power rule."
  },
  {
   "q": "∫ dx/x equals:",
   "opts": [
    "x + C",
    "ln|x| + C",
    "1/x² + C",
    "eˣ + C"
   ],
   "correct": 1,
   "expl": "The integral of the reciprocal is the natural log."
  },
  {
   "q": "∫ eˣ dx equals:",
   "opts": [
    "xeˣ + C",
    "eˣ + C",
    "eˣ/x + C",
    "ln x + C"
   ],
   "correct": 1,
   "expl": "eˣ integrates to itself."
  },
  {
   "q": "∫ sin x dx equals:",
   "opts": [
    "cos x + C",
    "-cos x + C",
    "sin x + C",
    "tan x + C"
   ],
   "correct": 1,
   "expl": "Differentiating -cos x gives sin x."
  },
  {
   "q": "∫ cos x dx equals:",
   "opts": [
    "-sin x + C",
    "sin x + C",
    "cos x + C",
    "sec x + C"
   ],
   "correct": 1,
   "expl": "Differentiating sin x gives cos x."
  },
  {
   "q": "A definite integral ∫ₐᵇ f(x)dx represents:",
   "opts": [
    "Slope",
    "Area under the curve",
    "Volume always",
    "Average value"
   ],
   "correct": 1,
   "expl": "It accumulates signed area between a and b."
  },
  {
   "q": "∫ₐᵇ f(x) dx equals:",
   "opts": [
    "F(a) - F(b)",
    "F(b) - F(a)",
    "F(a) + F(b)",
    "F(b)/F(a)"
   ],
   "correct": 1,
   "expl": "The Fundamental Theorem evaluates the antiderivative at the limits."
  },
  {
   "q": "Integration by parts: ∫ u dv equals:",
   "opts": [
    "uv + ∫ v du",
    "uv - ∫ v du",
    "u dv - v du",
    "∫ v du - uv"
   ],
   "correct": 1,
   "expl": "It comes from the product rule of differentiation."
  },
  {
   "q": "A vector has:",
   "opts": [
    "Magnitude only",
    "Direction only",
    "Magnitude and direction",
    "Neither"
   ],
   "correct": 2,
   "expl": "Both size and direction define a vector."
  },
  {
   "q": "|ai + bj + ck| equals:",
   "opts": [
    "√(a² + b² + c²)",
    "a + b + c",
    "√(abc)",
    "a² + b² + c²"
   ],
   "correct": 0,
   "expl": "Magnitude is the square root of the sum of squared components."
  },
  {
   "q": "a · b equals:",
   "opts": [
    "|a||b|sinθ",
    "|a||b|cosθ",
    "|a||b|tanθ",
    "|a| + |b|"
   ],
   "correct": 1,
   "expl": "The dot product uses the cosine of the angle."
  },
  {
   "q": "|a × b| equals:",
   "opts": [
    "|a||b|cosθ",
    "|a||b|sinθ",
    "|a||b|",
    "a·b"
   ],
   "correct": 1,
   "expl": "The cross product magnitude uses sine."
  },
  {
   "q": "Two non-zero vectors are perpendicular if:",
   "opts": [
    "a·b = 1",
    "a·b = 0",
    "a×b = 0",
    "|a| = |b|"
   ],
   "correct": 1,
   "expl": "Cos 90° = 0 makes the dot product zero."
  },
  {
   "q": "Two non-zero vectors are parallel if:",
   "opts": [
    "a·b = 0",
    "a×b = 0",
    "a·b = 1",
    "|a| = |b|"
   ],
   "correct": 1,
   "expl": "Sin 0° = 0 makes the cross product zero."
  },
  {
   "q": "The unit vector in the direction of a is:",
   "opts": [
    "a × |a|",
    "a / |a|",
    "|a| / a",
    "a + |a|"
   ],
   "correct": 1,
   "expl": "Dividing by its own magnitude normalizes the vector."
  },
  {
   "q": "A complex number z = a + ib has modulus:",
   "opts": [
    "√(a² + b²)",
    "a + b",
    "a² + b²",
    "√(a + b)"
   ],
   "correct": 0,
   "expl": "Modulus is the distance from the origin in the Argand plane."
  },
  {
   "q": "arg(a + ib) equals:",
   "opts": [
    "tan⁻¹(a/b)",
    "tan⁻¹(b/a)",
    "sin⁻¹(a)",
    "cos⁻¹(b)"
   ],
   "correct": 1,
   "expl": "The argument is the angle whose tangent is b/a."
  },
  {
   "q": "The conjugate of a + ib is:",
   "opts": [
    "-a + ib",
    "a - ib",
    "-a - ib",
    "b + ia"
   ],
   "correct": 1,
   "expl": "Conjugation flips the sign of the imaginary part."
  },
  {
   "q": "z × z̄ equals:",
   "opts": [
    "0",
    "|z|²",
    "2|z|",
    "z²"
   ],
   "correct": 1,
   "expl": "(a+ib)(a-ib) = a² + b² = |z|²."
  },
  {
   "q": "i⁴ⁿ equals (n integer):",
   "opts": [
    "i",
    "-1",
    "1",
    "-i"
   ],
   "correct": 2,
   "expl": "Every fourth power of i returns to 1."
  },
  {
   "q": "De Moivre's theorem: (cosθ + i sinθ)ⁿ equals:",
   "opts": [
    "cos nθ - i sin nθ",
    "cos nθ + i sin nθ",
    "cosⁿθ + i sinⁿθ",
    "n(cosθ + i sinθ)"
   ],
   "correct": 1,
   "expl": "Powers multiply the angle by n."
  },
  {
   "q": "The standard equation of a circle centred at origin is:",
   "opts": [
    "x² - y² = r²",
    "x² + y² = r²",
    "x + y = r",
    "xy = r²"
   ],
   "correct": 1,
   "expl": "All points at distance r satisfy x² + y² = r²."
  },
  {
   "q": "The standard parabola y² = 4ax opens:",
   "opts": [
    "Upward",
    "Right",
    "Left",
    "Downward"
   ],
   "correct": 1,
   "expl": "Positive x values satisfy it, so it opens right."
  },
  {
   "q": "The standard ellipse equation is:",
   "opts": [
    "x²/a² + y²/b² = 1",
    "x²/a² - y²/b² = 1",
    "y² = 4ax",
    "x² + y² = r²"
   ],
   "correct": 0,
   "expl": "The plus sign with different denominators gives an ellipse."
  },
  {
   "q": "The standard hyperbola equation is:",
   "opts": [
    "x²/a² + y²/b² = 1",
    "x²/a² - y²/b² = 1",
    "y² = 4ax",
    "(x/a)² = 1"
   ],
   "correct": 1,
   "expl": "The minus sign distinguishes the hyperbola."
  },
  {
   "q": "Eccentricity of a circle is:",
   "opts": [
    "1",
    "0",
    "Less than 1",
    "Greater than 1"
   ],
   "correct": 1,
   "expl": "A circle is the least eccentric conic."
  },
  {
   "q": "Eccentricity of a parabola is:",
   "opts": [
    "0",
    "1",
    "Less than 1",
    "Greater than 1"
   ],
   "correct": 1,
   "expl": "Parabolas have eccentricity exactly one."
  },
  {
   "q": "Eccentricity of an ellipse is:",
   "opts": [
    "0",
    "1",
    "Less than 1",
    "Greater than 1"
   ],
   "correct": 2,
   "expl": "Ellipses are flatter than circles but closed."
  },
  {
   "q": "Eccentricity of a hyperbola is:",
   "opts": [
    "Less than 1",
    "Equal to 1",
    "Greater than 1",
    "Zero"
   ],
   "correct": 2,
   "expl": "Hyperbolas open outward with e > 1."
  },
  {
   "q": "The focus of y² = 4ax is:",
   "opts": [
    "(0, a)",
    "(a, 0)",
    "(-a, 0)",
    "(0, -a)"
   ],
   "correct": 1,
   "expl": "The focus lies a units along the axis from the vertex."
  },
  {
   "q": "The directrix of y² = 4ax is:",
   "opts": [
    "x = a",
    "x = -a",
    "y = a",
    "y = -a"
   ],
   "correct": 1,
   "expl": "It is the vertical line x = -a."
  },
  {
   "q": "The integral of sec²x dx equals:",
   "opts": [
    "tan x + C",
    "-tan x + C",
    "sec x + C",
    "cot x + C"
   ],
   "correct": 0,
   "expl": "The derivative of tan x is sec²x."
  }
 ],
 "BIOLOGY12": [
  {
   "q": "Homeostasis is the maintenance of:",
   "opts": [
    "External environment",
    "Internal balance",
    "Body temperature only",
    "Blood pressure only"
   ],
   "correct": 1,
   "expl": "It keeps internal conditions stable despite outside changes."
  },
  {
   "q": "Thermoregulation in humans is controlled by the:",
   "opts": [
    "Cerebrum",
    "Hypothalamus",
    "Cerebellum",
    "Medulla"
   ],
   "correct": 1,
   "expl": "The hypothalamus acts as the body's thermostat."
  },
  {
   "q": "The main osmoregulatory organ in humans is the:",
   "opts": [
    "Liver",
    "Kidney",
    "Skin",
    "Lung"
   ],
   "correct": 1,
   "expl": "Kidneys regulate water and salt balance."
  },
  {
   "q": "The functional unit of the kidney is the:",
   "opts": [
    "Glomerulus",
    "Nephron",
    "Ureter",
    "Bladder"
   ],
   "correct": 1,
   "expl": "Each nephron filters blood and forms urine."
  },
  {
   "q": "Filtration of blood in the nephron occurs at the:",
   "opts": [
    "Loop of Henle",
    "Glomerulus",
    "Collecting duct",
    "Urethra"
   ],
   "correct": 1,
   "expl": "The glomerular capillaries filter plasma into Bowman's capsule."
  },
  {
   "q": "ADH hormone promotes:",
   "opts": [
    "Salt excretion",
    "Water reabsorption",
    "Glucose release",
    "Urine dilution"
   ],
   "correct": 1,
   "expl": "Anti-diuretic hormone makes collecting ducts permeable to water."
  },
  {
   "q": "A neuron is a:",
   "opts": [
    "Muscle cell",
    "Nerve cell",
    "Blood cell",
    "Bone cell"
   ],
   "correct": 1,
   "expl": "Neurons transmit electrical impulses."
  },
  {
   "q": "A synapse is the:",
   "opts": [
    "Cell body",
    "Junction between two neurons",
    "Axon covering",
    "Dendrite tip"
   ],
   "correct": 1,
   "expl": "Impulses cross the synaptic gap via neurotransmitters."
  },
  {
   "q": "An example of a neurotransmitter is:",
   "opts": [
    "Insulin",
    "Acetylcholine",
    "Thyroxine",
    "Haemoglobin"
   ],
   "correct": 1,
   "expl": "Acetylcholine carries signals across synapses."
  },
  {
   "q": "The largest part of the human brain is the:",
   "opts": [
    "Cerebellum",
    "Cerebrum",
    "Medulla",
    "Pons"
   ],
   "correct": 1,
   "expl": "The cerebrum handles thought, memory and voluntary action."
  },
  {
   "q": "The cerebellum coordinates:",
   "opts": [
    "Breathing",
    "Balance and muscular coordination",
    "Hunger",
    "Vision"
   ],
   "correct": 1,
   "expl": "It fine-tunes movement and posture."
  },
  {
   "q": "The medulla oblongata controls:",
   "opts": [
    "Thought",
    "Breathing and heartbeat",
    "Balance",
    "Memory"
   ],
   "correct": 1,
   "expl": "It runs involuntary vital functions."
  },
  {
   "q": "A reflex arc is completed through the:",
   "opts": [
    "Brain",
    "Spinal cord",
    "Cerebellum",
    "Hypothalamus"
   ],
   "correct": 1,
   "expl": "Reflexes bypass the brain for a faster response."
  },
  {
   "q": "Insulin:",
   "opts": [
    "Raises blood glucose",
    "Lowers blood glucose",
    "Raises blood pressure",
    "Lowers body temperature"
   ],
   "correct": 1,
   "expl": "It helps cells absorb glucose from blood."
  },
  {
   "q": "Glucagon:",
   "opts": [
    "Lowers blood glucose",
    "Raises blood glucose",
    "Lowers insulin",
    "Raises body heat"
   ],
   "correct": 1,
   "expl": "It triggers the liver to release stored glucose."
  },
  {
   "q": "Thyroxine regulates:",
   "opts": [
    "Blood sugar",
    "Metabolic rate",
    "Calcium",
    "Water balance"
   ],
   "correct": 1,
   "expl": "Thyroid hormone sets the pace of metabolism."
  },
  {
   "q": "Adrenaline is called the:",
   "opts": [
    "Sleep hormone",
    "Fight-or-flight hormone",
    "Growth hormone",
    "Calming hormone"
   ],
   "correct": 1,
   "expl": "It prepares the body for emergency action."
  },
  {
   "q": "Growth hormone is secreted by the:",
   "opts": [
    "Thyroid",
    "Pituitary gland",
    "Adrenal gland",
    "Pancreas"
   ],
   "correct": 1,
   "expl": "The anterior pituitary releases growth hormone."
  },
  {
   "q": "Testosterone is produced by the:",
   "opts": [
    "Ovaries",
    "Testes",
    "Adrenal cortex",
    "Pituitary"
   ],
   "correct": 1,
   "expl": "Testes secrete the male sex hormone."
  },
  {
   "q": "Estrogen and progesterone are produced by the:",
   "opts": [
    "Testes",
    "Ovaries",
    "Thyroid",
    "Liver"
   ],
   "correct": 1,
   "expl": "Ovaries secrete the female sex hormones."
  },
  {
   "q": "Mendel is called the father of:",
   "opts": [
    "Evolution",
    "Genetics",
    "Ecology",
    "Taxonomy"
   ],
   "correct": 1,
   "expl": "His pea-plant experiments founded genetics."
  },
  {
   "q": "Mendel's law of segregation states that:",
   "opts": [
    "Genes assort independently",
    "Allele pairs separate in gamete formation",
    "Dominance is complete",
    "Genes are linked"
   ],
   "correct": 1,
   "expl": "Each gamete receives only one allele of each pair."
  },
  {
   "q": "Mendel's law of independent assortment concerns:",
   "opts": [
    "One gene pair",
    "Two or more gene pairs",
    "Linked genes",
    "Mutations"
   ],
   "correct": 1,
   "expl": "Different gene pairs assort independently into gametes."
  },
  {
   "q": "A dominant allele:",
   "opts": [
    "Is always harmful",
    "Masks the recessive allele",
    "Disappears",
    "Is rare"
   ],
   "correct": 1,
   "expl": "Its trait appears even in heterozygous condition."
  },
  {
   "q": "Genotype refers to:",
   "opts": [
    "Physical appearance",
    "Genetic makeup",
    "Chromosome number",
    "Cell size"
   ],
   "correct": 1,
   "expl": "It is the set of alleles an organism carries."
  },
  {
   "q": "Phenotype refers to:",
   "opts": [
    "Genetic makeup",
    "Observable traits",
    "Gene sequence",
    "Protein structure"
   ],
   "correct": 1,
   "expl": "It is the physical expression of the genotype."
  },
  {
   "q": "Homozygous means having:",
   "opts": [
    "Different alleles",
    "Identical alleles",
    "No alleles",
    "Many genes"
   ],
   "correct": 1,
   "expl": "Both alleles of the pair are the same."
  },
  {
   "q": "Heterozygous means having:",
   "opts": [
    "Identical alleles",
    "Two different alleles",
    "One allele",
    "Three alleles"
   ],
   "correct": 1,
   "expl": "The pair carries two different alleles."
  },
  {
   "q": "A test cross is made with a:",
   "opts": [
    "Homozygous dominant",
    "Homozygous recessive",
    "Heterozygous",
    "Wild type"
   ],
   "correct": 1,
   "expl": "Crossing with a recessive reveals the unknown genotype."
  },
  {
   "q": "The F2 phenotypic ratio of a dihybrid cross is:",
   "opts": [
    "3:1",
    "1:2:1",
    "9:3:3:1",
    "1:1:1:1"
   ],
   "correct": 2,
   "expl": "Independent assortment gives the classic 9:3:3:1 ratio."
  },
  {
   "q": "The F2 phenotypic ratio of a monohybrid cross is:",
   "opts": [
    "9:3:3:1",
    "3:1",
    "1:2:1",
    "1:1"
   ],
   "correct": 1,
   "expl": "Three dominant to one recessive is the Mendelian ratio."
  },
  {
   "q": "Incomplete dominance gives an F2 ratio of:",
   "opts": [
    "3:1",
    "9:3:3:1",
    "1:2:1",
    "1:1"
   ],
   "correct": 2,
   "expl": "The heterozygote shows an intermediate trait, e.g. pink flowers."
  },
  {
   "q": "AB blood group is an example of:",
   "opts": [
    "Incomplete dominance",
    "Codominance",
    "Complete dominance",
    "Epistasis"
   ],
   "correct": 1,
   "expl": "Both IA and IB alleles express fully."
  },
  {
   "q": "ABO blood groups show:",
   "opts": [
    "One allele",
    "Multiple alleles",
    "No alleles",
    "Linked genes"
   ],
   "correct": 1,
   "expl": "Three alleles IA, IB and i control the groups."
  },
  {
   "q": "Haemophilia and colour blindness are:",
   "opts": [
    "Autosomal dominant",
    "Sex-linked (X chromosome)",
    "Y-linked",
    "Mitochondrial"
   ],
   "correct": 1,
   "expl": "Their genes lie on the X chromosome."
  },
  {
   "q": "Haemophilia is called:",
   "opts": [
    "Sweet blood disease",
    "Bleeder's disease",
    "Blue baby disease",
    "Night blindness"
   ],
   "correct": 1,
   "expl": "Blood fails to clot properly in haemophilia."
  },
  {
   "q": "DNA has the shape of a:",
   "opts": [
    "Single strand",
    "Double helix",
    "Triple helix",
    "Flat sheet"
   ],
   "correct": 1,
   "expl": "Two strands twist around each other."
  },
  {
   "q": "A gene is:",
   "opts": [
    "A whole chromosome",
    "A DNA segment coding for a protein",
    "A type of RNA",
    "A cell organelle"
   ],
   "correct": 1,
   "expl": "Genes are functional units of heredity on DNA."
  },
  {
   "q": "Transcription produces:",
   "opts": [
    "Protein from mRNA",
    "mRNA from DNA",
    "DNA from mRNA",
    "Amino acids"
   ],
   "correct": 1,
   "expl": "It copies the DNA code into messenger RNA in the nucleus."
  },
  {
   "q": "Translation occurs at the:",
   "opts": [
    "Nucleus",
    "Ribosome",
    "Mitochondria",
    "Chloroplast"
   ],
   "correct": 1,
   "expl": "Ribosomes read mRNA to build proteins."
  },
  {
   "q": "A codon consists of:",
   "opts": [
    "2 bases",
    "3 bases",
    "4 bases",
    "1 base"
   ],
   "correct": 1,
   "expl": "Three mRNA bases code for one amino acid."
  },
  {
   "q": "The start codon is:",
   "opts": [
    "UAA",
    "AUG",
    "UAG",
    "UGA"
   ],
   "correct": 1,
   "expl": "AUG initiates protein synthesis and codes methionine."
  },
  {
   "q": "Which is a stop codon?",
   "opts": [
    "AUG",
    "UAA",
    "UAC",
    "CUG"
   ],
   "correct": 1,
   "expl": "UAA, UAG and UGA terminate translation."
  },
  {
   "q": "A mutation is a:",
   "opts": [
    "Temporary change",
    "Sudden heritable change in DNA",
    "Cell division",
    "Protein folding"
   ],
   "correct": 1,
   "expl": "Mutations alter the genetic material permanently."
  },
  {
   "q": "Darwin explained evolution through:",
   "opts": [
    "Use and disuse",
    "Natural selection",
    "Inheritance of acquired traits",
    "Catastrophes"
   ],
   "correct": 1,
   "expl": "Fitter individuals survive and reproduce more."
  },
  {
   "q": "Lamarck proposed the theory of:",
   "opts": [
    "Natural selection",
    "Use and disuse of organs",
    "Genetic drift",
    "Punctuated equilibrium"
   ],
   "correct": 1,
   "expl": "He thought acquired traits are inherited."
  },
  {
   "q": "Homologous organs have:",
   "opts": [
    "Different origin, same function",
    "Same origin, different functions",
    "No relation",
    "Same function only"
   ],
   "correct": 1,
   "expl": "They show common ancestry despite different uses."
  },
  {
   "q": "Vestigial organs are:",
   "opts": [
    "Fully functional",
    "Reduced and functionless",
    "Newly evolved",
    "Always harmful"
   ],
   "correct": 1,
   "expl": "They are remnants of once-useful structures."
  },
  {
   "q": "Biotechnology means:",
   "opts": [
    "Study of fossils",
    "Using organisms to make useful products",
    "Cloning only",
    "Studying cells"
   ],
   "correct": 1,
   "expl": "It applies living systems in medicine, agriculture and industry."
  },
  {
   "q": "Human insulin is now produced by:",
   "opts": [
    "Cow pancreas",
    "Recombinant E. coli bacteria",
    "Yeast only",
    "Chemical synthesis"
   ],
   "correct": 1,
   "expl": "Genetically engineered bacteria make human insulin."
  }
 ],
 "ENGLISH12": [
  {
   "q": "Choose the correct inversion:",
   "opts": [
    "If I had known, I would help.",
    "Had I known, I would have helped.",
    "Had I know, I would helped.",
    "If I would know, I helped."
   ],
   "correct": 1,
   "expl": "Inversion drops 'if' and inverts had + subject for past unreal."
  },
  {
   "q": "Choose the correct inversion:",
   "opts": [
    "If I were rich, I travel.",
    "Were I rich, I would travel.",
    "Was I rich, I will travel.",
    "Were I rich, I will travel."
   ],
   "correct": 1,
   "expl": "'Were I' inverts the second conditional."
  },
  {
   "q": "Choose the correct subjunctive:",
   "opts": [
    "I suggest that he goes.",
    "I suggest that he go.",
    "I suggest that he went.",
    "I suggest him to go."
   ],
   "correct": 1,
   "expl": "Subjunctive uses the base verb after suggest/demand."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "It's time we go.",
    "It's time we went.",
    "It's time we gone.",
    "It's time we going."
   ],
   "correct": 1,
   "expl": "'It's time' takes the past simple for present urgency."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "I'd rather to stay.",
    "I'd rather stay.",
    "I'd rather stayed.",
    "I'd rather staying."
   ],
   "correct": 1,
   "expl": "'Would rather' is followed by the base verb."
  },
  {
   "q": "Choose the parallel sentence:",
   "opts": [
    "She likes reading, writing, and to jog.",
    "She likes reading, writing, and jogging.",
    "She likes to read, writing, and jogging.",
    "She likes reading, to write, and jog."
   ],
   "correct": 1,
   "expl": "Parallelism keeps all items in the same gerund form."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "Walking home, the rain started.",
    "Walking home, I got wet in the rain.",
    "Walking home, the rain was started.",
    "The rain started walking home."
   ],
   "correct": 1,
   "expl": "The modifier must attach to the logical subject 'I'."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "Between you and I, he is wrong.",
    "Between you and me, he is wrong.",
    "Between you and myself, he is wrong.",
    "Between me and you, he are wrong."
   ],
   "correct": 1,
   "expl": "Prepositions take the object pronoun 'me'."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "The man which came is my uncle.",
    "The man who came is my uncle.",
    "The man whom came is my uncle.",
    "The man whose came is my uncle."
   ],
   "correct": 1,
   "expl": "'Who' is the subject pronoun for people."
  },
  {
   "q": "Choose the correct sentence:",
   "opts": [
    "Whose going with you?",
    "Who's going with you?",
    "Whom going with you?",
    "Who going with you?"
   ],
   "correct": 1,
   "expl": "'Who's' is the contraction of 'who is'."
  },
  {
   "q": "Choose the synonym of METICULOUS:",
   "opts": [
    "Careless",
    "Careful",
    "Hasty",
    "Rough"
   ],
   "correct": 1,
   "expl": "'Meticulous' means showing great attention to detail."
  },
  {
   "q": "Choose the antonym of OBSCURE:",
   "opts": [
    "Dark",
    "Clear",
    "Vague",
    "Hidden"
   ],
   "correct": 1,
   "expl": "'Obscure' means unclear; its opposite is 'clear'."
  },
  {
   "q": "Choose the synonym of PRAGMATIC:",
   "opts": [
    "Idealistic",
    "Practical",
    "Theoretical",
    "Dogmatic"
   ],
   "correct": 1,
   "expl": "'Pragmatic' means dealing with things practically."
  },
  {
   "q": "Choose the antonym of AMBIGUOUS:",
   "opts": [
    "Vague",
    "Clear",
    "Doubtful",
    "Confusing"
   ],
   "correct": 1,
   "expl": "'Ambiguous' means open to interpretation; 'clear' is its opposite."
  },
  {
   "q": "Choose the synonym of DILIGENT:",
   "opts": [
    "Lazy",
    "Hardworking",
    "Careless",
    "Slow"
   ],
   "correct": 1,
   "expl": "'Diligent' means showing care in one's work."
  },
  {
   "q": "Choose the antonym of DILIGENT:",
   "opts": [
    "Industrious",
    "Lazy",
    "Careful",
    "Active"
   ],
   "correct": 1,
   "expl": "'Lazy' is the opposite of hardworking."
  },
  {
   "q": "Choose the synonym of FRUGAL:",
   "opts": [
    "Wasteful",
    "Thrifty",
    "Generous",
    "Rich"
   ],
   "correct": 1,
   "expl": "'Frugal' means careful with money."
  },
  {
   "q": "Choose the antonym of ARROGANT:",
   "opts": [
    "Proud",
    "Humble",
    "Haughty",
    "Vain"
   ],
   "correct": 1,
   "expl": "'Humble' is the opposite of 'arrogant'."
  },
  {
   "q": "Choose the synonym of BENEVOLENT:",
   "opts": [
    "Cruel",
    "Kind",
    "Selfish",
    "Strict"
   ],
   "correct": 1,
   "expl": "'Benevolent' means well-meaning and kindly."
  },
  {
   "q": "Choose the antonym of HOSTILE:",
   "opts": [
    "Unfriendly",
    "Friendly",
    "Aggressive",
    "Cold"
   ],
   "correct": 1,
   "expl": "'Friendly' is the opposite of 'hostile'."
  },
  {
   "q": "“Call off” means:",
   "opts": [
    "Summon",
    "Cancel",
    "Shout",
    "Continue"
   ],
   "correct": 1,
   "expl": "'Call off' means to cancel an event."
  },
  {
   "q": "“Put off” means:",
   "opts": [
    "Wear",
    "Postpone",
    "Remove",
    "Extinguish"
   ],
   "correct": 1,
   "expl": "'Put off' means to delay to a later time."
  },
  {
   "q": "“Bring up” means:",
   "opts": [
    "Carry upstairs",
    "Raise (a child or topic)",
    "Vomit",
    "Lift"
   ],
   "correct": 1,
   "expl": "It means to raise a child or mention a subject."
  },
  {
   "q": "“Look into” means:",
   "opts": [
    "Stare",
    "Investigate",
    "Enter",
    "Glance"
   ],
   "correct": 1,
   "expl": "'Look into' means to examine or investigate."
  },
  {
   "q": "“Run into” means:",
   "opts": [
    "Exercise",
    "Meet unexpectedly",
    "Collide always",
    "Escape"
   ],
   "correct": 1,
   "expl": "It means to meet someone by chance."
  },
  {
   "q": "“Come across” means:",
   "opts": [
    "Cross a road",
    "Find by chance",
    "Climb",
    "Return"
   ],
   "correct": 1,
   "expl": "It means to discover unexpectedly."
  },
  {
   "q": "“At the eleventh hour” means:",
   "opts": [
    "At 11 o'clock",
    "At the last moment",
    "Early morning",
    "On time"
   ],
   "correct": 1,
   "expl": "It means at the latest possible moment."
  },
  {
   "q": "“Beat around the bush” means:",
   "opts": [
    "Garden work",
    "Avoid saying directly",
    "Win a fight",
    "Clear land"
   ],
   "correct": 1,
   "expl": "It means to avoid the main point."
  },
  {
   "q": "“Cut corners” means:",
   "opts": [
    "Shape edges",
    "Do something cheaply",
    "Take shortcuts in driving",
    "Trim paper"
   ],
   "correct": 1,
   "expl": "It means to save effort or money, often badly."
  },
  {
   "q": "“The ball is in your court” means:",
   "opts": [
    "Play tennis",
    "It is your turn to act",
    "You lost",
    "Sports time"
   ],
   "correct": 1,
   "expl": "It means the next move is yours."
  },
  {
   "q": "“Burn the midnight oil” means:",
   "opts": [
    "Waste fuel",
    "Study/work late at night",
    "Cook at night",
    "Light lamps"
   ],
   "correct": 1,
   "expl": "It means working late into the night."
  },
  {
   "q": "“Through thick and thin” means:",
   "opts": [
    "In forests",
    "Through all difficulties",
    "In crowds",
    "Physically"
   ],
   "correct": 1,
   "expl": "It means staying loyal in good and bad times."
  },
  {
   "q": "That which cannot be read is:",
   "opts": [
    "Legible",
    "Illegible",
    "Audible",
    "Edible"
   ],
   "correct": 1,
   "expl": "'Illegible' means impossible to read."
  },
  {
   "q": "That which can be heard is:",
   "opts": [
    "Invisible",
    "Audible",
    "Legible",
    "Tangible"
   ],
   "correct": 1,
   "expl": "'Audible' means able to be heard."
  },
  {
   "q": "One who loves books is a:",
   "opts": [
    "Bibliophobe",
    "Bibliophile",
    "Orator",
    "Critic"
   ],
   "correct": 1,
   "expl": "'Biblio-' relates to books and '-phile' to loving."
  },
  {
   "q": "Fear of water is:",
   "opts": [
    "Acrophobia",
    "Hydrophobia",
    "Claustrophobia",
    "Pyrophobia"
   ],
   "correct": 1,
   "expl": "'Hydro-' relates to water."
  },
  {
   "q": "Government by a few is:",
   "opts": [
    "Democracy",
    "Oligarchy",
    "Monarchy",
    "Anarchy"
   ],
   "correct": 1,
   "expl": "'Oligarchy' means rule by a small group."
  },
  {
   "q": "The murder of a king is:",
   "opts": [
    "Homicide",
    "Regicide",
    "Suicide",
    "Patricide"
   ],
   "correct": 1,
   "expl": "'Regicide' is the killing of a monarch."
  },
  {
   "q": "He said, “I have been working.” (indirect):",
   "opts": [
    "He said he has been working.",
    "He said he had been working.",
    "He said I had been working.",
    "He says he had been working."
   ],
   "correct": 1,
   "expl": "Present perfect continuous shifts to past perfect continuous."
  },
  {
   "q": "She asked, “Where do you live?” (indirect):",
   "opts": [
    "She asked where do I live.",
    "She asked where I lived.",
    "She asked where did I live.",
    "She asks where I lived."
   ],
   "correct": 1,
   "expl": "Wh-questions keep the word and shift to past tense."
  },
  {
   "q": "He said, “Hurry up!” (indirect):",
   "opts": [
    "He said hurry up.",
    "He urged them to hurry up.",
    "He asked did hurry up.",
    "He told that hurry up."
   ],
   "correct": 1,
   "expl": "Urgent imperatives are reported with 'urged'."
  },
  {
   "q": "Passive of “People say he is rich”:",
   "opts": [
    "He is said to be rich.",
    "He was said to be rich.",
    "It is said he is rich only.",
    "People are said he is rich."
   ],
   "correct": 0,
   "expl": "Impersonal passives use 'is said to be'."
  },
  {
   "q": "Passive of “They elected him chairman”:",
   "opts": [
    "He was elected chairman by them.",
    "He is elected chairman.",
    "He elected chairman.",
    "They were elected chairman."
   ],
   "correct": 0,
   "expl": "The object 'him' becomes the subject 'he'."
  },
  {
   "q": "___ honest man would admit it.",
   "opts": [
    "A",
    "An",
    "The",
    "No article"
   ],
   "correct": 1,
   "expl": "'An' is used before the silent-h word 'honest'."
  },
  {
   "q": "It was ___ unique opportunity.",
   "opts": [
    "a",
    "an",
    "the",
    "no article"
   ],
   "correct": 0,
   "expl": "'A' is used before the 'yu' sound of 'unique'."
  },
  {
   "q": "He plays ___ cricket in the evening.",
   "opts": [
    "a",
    "the",
    "no article",
    "an"
   ],
   "correct": 2,
   "expl": "No article is used before names of games."
  },
  {
   "q": "He succeeded ___ hard work.",
   "opts": [
    "by",
    "through",
    "with",
    "from"
   ],
   "correct": 1,
   "expl": "Success came 'through' his hard work."
  },
  {
   "q": "Choose the correct pair: advice (noun) / advise (verb). “He gave me good ___”:",
   "opts": [
    "advise",
    "advice",
    "advises",
    "advised"
   ],
   "correct": 1,
   "expl": "'Advice' is the noun form needed here."
  },
  {
   "q": "“Eminent” means famous; “imminent” means:",
   "opts": [
    "Famous",
    "About to happen",
    "Eternal",
    "Moral"
   ],
   "correct": 1,
   "expl": "'Imminent' means approaching or about to occur."
  },
  {
   "q": "The jury ___ divided in its opinion.",
   "opts": [
    "was",
    "were",
    "is",
    "has"
   ],
   "correct": 1,
   "expl": "'Jury' takes a plural verb when members act individually."
  }
 ],
 "URDU12": [
  {
   "q": "میر تقی میر کو کہا جاتا ہے:",
   "opts": [
    "شاعر مشرق",
    "خدائے سخن",
    "مفکر پاکستان",
    "شاعر انقلاب"
   ],
   "correct": 1,
   "expl": "میر تقی میر کو خدائے سخن کہا جاتا ہے۔"
  },
  {
   "q": "مرزا اسد اللہ خاں کا تخلص تھا:",
   "opts": [
    "میر",
    "غالب",
    "ذوق",
    "مومن"
   ],
   "correct": 1,
   "expl": "مرزا اسد اللہ خاں غالب کے نام سے مشہور ہیں۔"
  },
  {
   "q": "علامہ اقبال کو کہا جاتا ہے:",
   "opts": [
    "شاعر مشرق و مفکر پاکستان",
    "خدائے سخن",
    "شاعر انقلاب",
    "نجم الدولہ"
   ],
   "correct": 0,
   "expl": "اقبال کو شاعر مشرق اور مفکر پاکستان کہا جاتا ہے۔"
  },
  {
   "q": "دیوان غالب میں شامل ہیں:",
   "opts": [
    "صرف اردو غزلیں",
    "اردو اور فارسی دونوں کلام",
    "صرف فارسی",
    "صرف نظمیں"
   ],
   "correct": 1,
   "expl": "غالب کا دیوان اردو اور فارسی دونوں زبانوں میں ہے۔"
  },
  {
   "q": "بانگ درا کس کی تصنیف ہے؟",
   "opts": [
    "غالب",
    "اقبال",
    "میر",
    "حالی"
   ],
   "correct": 1,
   "expl": "بانگ درا علامہ اقبال کا مشہور مجموعہ کلام ہے۔"
  },
  {
   "q": "بال جبریل کس کا مجموعہ کلام ہے؟",
   "opts": [
    "میر",
    "غالب",
    "اقبال",
    "جوش"
   ],
   "correct": 2,
   "expl": "بال جبریل اقبال کی تصنیف ہے۔"
  },
  {
   "q": "ضرب کلیم کس کی تصنیف ہے؟",
   "opts": [
    "اقبال",
    "غالب",
    "میر",
    "حالی"
   ],
   "correct": 0,
   "expl": "ضرب کلیم علامہ اقبال کی تصنیف ہے۔"
  },
  {
   "q": "ارمغان حجاز کس کی تصنیف ہے؟",
   "opts": [
    "غالب",
    "میر",
    "اقبال",
    "اکبر"
   ],
   "correct": 2,
   "expl": "ارمغان حجاز اقبال کا آخری مجموعہ کلام ہے۔"
  },
  {
   "q": "شاہنامہ اسلام کس کی تصنیف ہے؟",
   "opts": [
    "حفیظ جالندھری",
    "اقبال",
    "جوش ملیح آبادی",
    "فیض"
   ],
   "correct": 0,
   "expl": "شاہنامہ اسلام حفیظ جالندھری کی مثنوی ہے۔"
  },
  {
   "q": "مسدس حالی کے مصنف ہیں:",
   "opts": [
    "غالب",
    "الطاف حسین حالی",
    "میر",
    "اقبال"
   ],
   "correct": 1,
   "expl": "مسدس مدوجزر اسلام الطاف حسین حالی کی تصنیف ہے۔"
  },
  {
   "q": "صنعت لف و نشر کہتے ہیں:",
   "opts": [
    "متضاد الفاظ لانے کو",
    "چند امور کو ایک ساتھ لپیٹ کر پھر ان کی نشر کرنے کو",
    "حد سے بڑھانے کو",
    "تشبیہ دینے کو"
   ],
   "correct": 1,
   "expl": "لف و نشر میں چند چیزوں کو لپیٹ کر پھر ان کی تفصیل کی جاتی ہے۔"
  },
  {
   "q": "صنعت حسن تعلیل کہتے ہیں:",
   "opts": [
    "خوبصورت علت بیان کرنے کو",
    "متضاد الفاظ لانے کو",
    "تشبیہ دینے کو",
    "مبالغے کو"
   ],
   "correct": 0,
   "expl": "حسن تعلیل میں کسی بات کی خوبصورت وجہ بیان کی جاتی ہے۔"
  },
  {
   "q": "کنایہ کہتے ہیں:",
   "opts": [
    "سیدھے معنی میں بات کہنے کو",
    "اشارے میں بات کہنے کو",
    "حد سے بڑھا چڑھانے کو",
    "متضاد بات کہنے کو"
   ],
   "correct": 1,
   "expl": "کنایے میں بات اشارے کنایے میں کہی جاتی ہے۔"
  },
  {
   "q": "مجاز مرسل کہتے ہیں:",
   "opts": [
    "تشبیہ کو",
    "ایک لفظ کو دوسرے معنی میں استعمال کرنے کو",
    "مبالغے کو",
    "استعارے کو"
   ],
   "correct": 1,
   "expl": "مجاز مرسل میں لفظ اپنے حقیقی معنی کے بجائے مجازی معنی میں استعمال ہوتا ہے۔"
  },
  {
   "q": "ایہام کہتے ہیں:",
   "opts": [
    "دو معنوں والے لفظ کے استعمال کو",
    "متضاد الفاظ کو",
    "تشبیہ کو",
    "مبالغے کو"
   ],
   "correct": 0,
   "expl": "ایہام میں ایک لفظ سے دو معنی نکالے جاتے ہیں۔"
  },
  {
   "q": "تلمیح کہتے ہیں:",
   "opts": [
    "تاریخی یا قرآنی واقعے کی طرف اشارے کو",
    "متضاد الفاظ کو",
    "حد سے بڑھانے کو",
    "سیدھی بات کو"
   ],
   "correct": 0,
   "expl": "تلمیح میں کسی مشہور واقعے کی طرف اشارہ ہوتا ہے۔"
  },
  {
   "q": "تشبیہ کے ارکان ہیں:",
   "opts": [
    "تین",
    "چار",
    "پانچ",
    "دو"
   ],
   "correct": 1,
   "expl": "تشبیہ کے چار ارکان ہیں: مشبہ، مشبہ بہ، وجہ شبہ، حرف تشبیہ۔"
  },
  {
   "q": "استعارے میں حرف تشبیہ:",
   "opts": [
    "ہوتا ہے",
    "نہیں ہوتا",
    "کبھی ہوتا ہے",
    "دو بار ہوتا ہے"
   ],
   "correct": 1,
   "expl": "استعارے میں حرف تشبیہ حذف کر دیا جاتا ہے۔"
  },
  {
   "q": "قافیے کے بعد آنے والا لفظ کہلاتا ہے:",
   "opts": [
    "قافیہ",
    "ردیف",
    "مطلع",
    "مقطع"
   ],
   "correct": 1,
   "expl": "ردیف قافیے کے بعد بار بار دہرایا جاتا ہے۔"
  },
  {
   "q": "بحر کہتے ہیں:",
   "opts": [
    "قافیے کو",
    "شعر کے وزن کے پیمانے کو",
    "ردیف کو",
    "تخلص کو"
   ],
   "correct": 1,
   "expl": "بحر شعر کے وزن کا پیمانہ ہے۔"
  },
  {
   "q": "مطلع وہ شعر ہے جس میں:",
   "opts": [
    "تخلص ہو",
    "دونوں مصرعے ہم قافیہ ہوں",
    "قافیہ نہ ہو",
    "تین مصرعے ہوں"
   ],
   "correct": 1,
   "expl": "مطلع غزل کا پہلا شعر ہوتا ہے جس کے دونوں مصرعے ہم قافیہ ہوتے ہیں۔"
  },
  {
   "q": "مقطع میں ہوتا ہے:",
   "opts": [
    "قافیہ",
    "شاعر کا تخلص",
    "ردیف",
    "بحر"
   ],
   "correct": 1,
   "expl": "مقطع غزل کا آخری شعر ہوتا ہے جس میں تخلص آتا ہے۔"
  },
  {
   "q": "بیت کہتے ہیں:",
   "opts": [
    "ایک مصرعے کو",
    "دو مصرعوں کے شعر کو",
    "پوری غزل کو",
    "قافیے کو"
   ],
   "correct": 1,
   "expl": "بیت دو مصرعوں پر مشتمل شعر کو کہتے ہیں۔"
  },
  {
   "q": "مصرع کہتے ہیں:",
   "opts": [
    "پورے شعر کو",
    "شعر کی ایک لائن کو",
    "قافیے کو",
    "ردیف کو"
   ],
   "correct": 1,
   "expl": "مصرع شعر کی ایک لائن ہوتا ہے۔"
  },
  {
   "q": "آب آب ہونا کا مطلب ہے:",
   "opts": [
    "پیاسا لگنا",
    "شرمندہ ہونا",
    "نہانا",
    "پانی پینا"
   ],
   "correct": 1,
   "expl": "آب آب ہونا شرمندہ ہونے کو کہتے ہیں۔"
  },
  {
   "q": "آگ بگولا ہونا کا مطلب ہے:",
   "opts": [
    "خوش ہونا",
    "بہت غصہ آنا",
    "آگ لگانا",
    "بھاگ جانا"
   ],
   "correct": 1,
   "expl": "آگ بگولا ہونا شدید غصے کو ظاہر کرتا ہے۔"
  },
  {
   "q": "اپنا الو سیدھا کرنا کا مطلب ہے:",
   "opts": [
    "کھانا پکانا",
    "اپنا مطلب نکالنا",
    "سبزی اگانا",
    "دوسروں کی مدد"
   ],
   "correct": 1,
   "expl": "اپنا الو سیدھا کرنا اپنا مفاد حاصل کرنے کو کہتے ہیں۔"
  },
  {
   "q": "بھانڈا پھوٹنا کا مطلب ہے:",
   "opts": [
    "برتن ٹوٹنا",
    "راز کھلنا",
    "کھانا پکانا",
    "پانی پینا"
   ],
   "correct": 1,
   "expl": "بھانڈا پھوٹنا چھپا راز کھل جانے کو کہتے ہیں۔"
  },
  {
   "q": "پاپڑ بیلنا کا مطلب ہے:",
   "opts": [
    "روٹی پکانا",
    "سخت محنت کرنا",
    "کھانا کھانا",
    "آرام کرنا"
   ],
   "correct": 1,
   "expl": "پاپڑ بیلنا سخت محنت و مشقت کو کہتے ہیں۔"
  },
  {
   "q": "تین پانچ کرنا کا مطلب ہے:",
   "opts": [
    "حساب کرنا",
    "حیلہ بہانہ کرنا",
    "کھیلنا",
    "بات کرنا"
   ],
   "correct": 1,
   "expl": "تین پانچ کرنا حیلے بہانے بنانے کو کہتے ہیں۔"
  },
  {
   "q": "چھکے چھڑا دینا کا مطلب ہے:",
   "opts": [
    "کھیل جیتنا",
    "شکست دینا",
    "مدد کرنا",
    "حوصلہ بڑھانا"
   ],
   "correct": 1,
   "expl": "چھکے چھڑا دینا بری طرح شکست دینے کو کہتے ہیں۔"
  },
  {
   "q": "دم دبا کر بھاگنا کا مطلب ہے:",
   "opts": [
    "تیز بھاگنا",
    "ڈر کر بھاگنا",
    "آہستہ چلنا",
    "واپس آنا"
   ],
   "correct": 1,
   "expl": "دم دبا کر بھاگنا ڈر کر بھاگ جانے کو کہتے ہیں۔"
  },
  {
   "q": "رنگ لانا کا مطلب ہے:",
   "opts": [
    "رنگ کرنا",
    "کامیاب ہونا",
    "پینٹ کرنا",
    "ناکام ہونا"
   ],
   "correct": 1,
   "expl": "رنگ لانا محنت کا پھل لانے یعنی کامیاب ہونے کو کہتے ہیں۔"
  },
  {
   "q": "سر دھڑ کی بازی لگانا کا مطلب ہے:",
   "opts": [
    "کھیلنا",
    "جان کی بازی لگانا",
    "دوڑنا",
    "لڑنا"
   ],
   "correct": 1,
   "expl": "سر دھڑ کی بازی لگانا جان جوکھوں میں ڈالنے کو کہتے ہیں۔"
  },
  {
   "q": "کمر کسنا کا مطلب ہے:",
   "opts": [
    "آرام کرنا",
    "تیار ہونا",
    "سونا",
    "بیٹھنا"
   ],
   "correct": 1,
   "expl": "کمر کسنا کسی کام کے لیے تیار ہونے کو کہتے ہیں۔"
  },
  {
   "q": "میدان مارنا کا مطلب ہے:",
   "opts": [
    "جنگ لڑنا",
    "کامیاب ہونا",
    "دوڑنا",
    "کھیلنا"
   ],
   "correct": 1,
   "expl": "میدان مارنا مقابلے میں کامیاب ہونے کو کہتے ہیں۔"
  },
  {
   "q": "ہاتھ پاؤں مارنا کا مطلب ہے:",
   "opts": [
    "لڑنا",
    "کوشش کرنا",
    "تیرنا",
    "دوڑنا"
   ],
   "correct": 1,
   "expl": "ہاتھ پاؤں مارنا کوشش و تگ و دو کو کہتے ہیں۔"
  },
  {
   "q": "لوہا ماننا کا مطلب ہے:",
   "opts": [
    "لوہا خریدنا",
    "برتری تسلیم کرنا",
    "ہتھیار بنانا",
    "لڑنا"
   ],
   "correct": 1,
   "expl": "لوہا ماننا کسی کی برتری تسلیم کرنے کو کہتے ہیں۔"
  },
  {
   "q": "اونچی دکان پھیکا پکوان کا مطلب ہے:",
   "opts": [
    "اچھی دکان",
    "دکھاوا زیادہ اور معیار کم",
    "مہنگا کھانا",
    "بڑی دکان"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل دکھاوے کے برعکس حقیقت کو ظاہر کرتا ہے۔"
  },
  {
   "q": "جہاں چاہ وہاں راہ کا مطلب ہے:",
   "opts": [
    "سفر کرنا",
    "ارادے سے راستہ نکلتا ہے",
    "چاہ پینا",
    "راہ چلنا"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل پختہ عزم کی اہمیت بیان کرتا ہے۔"
  },
  {
   "q": "نیم حکیم خطرہ جان کا مطلب ہے:",
   "opts": [
    "حکیم سے علاج",
    "ناقص علم خطرناک ہے",
    "دوا کھانا",
    "بیمار ہونا"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل ناقص علم کے خطرے سے خبردار کرتا ہے۔"
  },
  {
   "q": "جس کی لاٹھی اس کی بھینس کا مطلب ہے:",
   "opts": [
    "جانور پالنا",
    "طاقتور کا اقتدار ہوتا ہے",
    "کیسان ہونا",
    "لاٹھی چلانا"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل طاقت کے بل بوتے پر حکومت کو ظاہر کرتا ہے۔"
  },
  {
   "q": "اندھوں میں کانا راجا کا مطلب ہے:",
   "opts": [
    "اندھا ہونا",
    "جاہلوں میں تھوڑا علم رکھنے والا بادشاہ ہے",
    "بادشاہت",
    "آنکھ کا علاج"
   ],
   "correct": 1,
   "expl": "یہ ضرب المثل ناقص علم والے کے غرور کو ظاہر کرتا ہے۔"
  },
  {
   "q": "ابتدا کا متضاد ہے:",
   "opts": [
    "آغاز",
    "انتہا",
    "شروع",
    "پہلا"
   ],
   "correct": 1,
   "expl": "ابتدا کا الٹ انتہا ہے۔"
  },
  {
   "q": "حاضر کا متضاد ہے:",
   "opts": [
    "موجود",
    "غائب",
    "سامنے",
    "قریب"
   ],
   "correct": 1,
   "expl": "حاضر کا الٹ غائب ہے۔"
  },
  {
   "q": "دلیر کا متضاد ہے:",
   "opts": [
    "بہادر",
    "بزدل",
    "شجاع",
    "نڈر"
   ],
   "correct": 1,
   "expl": "دلیر کا الٹ بزدل ہے۔"
  },
  {
   "q": "کریم کا متضاد ہے:",
   "opts": [
    "سخی",
    "بخیل",
    "فیاض",
    "داتا"
   ],
   "correct": 1,
   "expl": "کریم کا الٹ بخیل ہے۔"
  },
  {
   "q": "صاف کا متضاد ہے:",
   "opts": [
    "شفاف",
    "میلا",
    "ستھرا",
    "اجلا"
   ],
   "correct": 1,
   "expl": "صاف کا الٹ میلا ہے۔"
  },
  {
   "q": "اندھیرا کا متضاد ہے:",
   "opts": [
    "تاریکی",
    "اجالا",
    "روشنی",
    "شب"
   ],
   "correct": 2,
   "expl": "اندھیرا کا الٹ اجالا ہے۔"
  },
  {
   "q": "بانگ درا علامہ اقبال کا مجموعہ کلام ہے۔ (صحیح/غلط)",
   "opts": [
    "صحیح",
    "غلط",
    "--",
    "--"
   ],
   "correct": 0,
   "expl": "بانگ درا اقبال کا مشہور اردو مجموعہ کلام ہے۔"
  }
 ],
 "ISLAMIAT12": [
  {
   "q": "Surah Al-Hujurat mainly teaches:",
   "opts": [
    "Trade rules",
    "Brotherhood and social manners",
    "War tactics",
    "Fasting rules"
   ],
   "correct": 1,
   "expl": "It commands brotherhood, bans mockery and backbiting."
  },
  {
   "q": "The verse “believers are but brothers” is from Surah:",
   "opts": [
    "Al-Baqarah",
    "Al-Hujurat",
    "Al-Imran",
    "An-Nisa"
   ],
   "correct": 1,
   "expl": "Surah Al-Hujurat verse 10 declares Muslim brotherhood."
  },
  {
   "q": "Backbiting is condemned in Surah Al-Hujurat verse:",
   "opts": [
    "10",
    "11",
    "12",
    "13"
   ],
   "correct": 2,
   "expl": "Verse 12 compares it to eating a dead brother's flesh."
  },
  {
   "q": "Surah Al-Asr teaches that mankind is in loss except:",
   "opts": [
    "The rich",
    "Believers who do good and counsel truth and patience",
    "Kings",
    "Scholars only"
   ],
   "correct": 1,
   "expl": "The Surah lists faith, good deeds, truth and patience as salvation."
  },
  {
   "q": "Surah Al-Ikhlas describes:",
   "opts": [
    "Paradise",
    "The Oneness of Allah",
    "Hell",
    "Prophets"
   ],
   "correct": 1,
   "expl": "It purely affirms Allah's absolute oneness."
  },
  {
   "q": "Surah Al-Falaq and An-Nas are called:",
   "opts": [
    "Mu'awwidhatayn (the two protectors)",
    "Sab' al-Mathani",
    "Umm-ul-Kitab",
    "Az-Zahrawan"
   ],
   "correct": 0,
   "expl": "They seek Allah's protection from all evils."
  },
  {
   "q": "Ayat-ul-Kursi is described in Hadith as:",
   "opts": [
    "The longest verse",
    "The greatest verse of the Quran",
    "The first verse",
    "The last verse"
   ],
   "correct": 1,
   "expl": "The Prophet ﷻ called it the greatest verse."
  },
  {
   "q": "Surah Al-Baqarah verse 152 says:",
   "opts": [
    "“Remember Me, I will remember you”",
    "“Fasting is for Me”",
    "“Pray five times”",
    "“Give charity”"
   ],
   "correct": 0,
   "expl": "Allah promises remembrance to those who remember Him."
  },
  {
   "q": "Surah Al-Baqarah verse 153 advises seeking help through:",
   "opts": [
    "Wealth and power",
    "Patience and prayer",
    "War and trade",
    "Travel"
   ],
   "correct": 1,
   "expl": "Sabr and Salah are the believer's supports."
  },
  {
   "q": "Surah Al-Baqarah verse 286 teaches that Allah:",
   "opts": [
    "Punishes all",
    "Does not burden a soul beyond its capacity",
    "Forgives shirk",
    "Loves wealth"
   ],
   "correct": 1,
   "expl": "No soul is tasked beyond what it can bear."
  },
  {
   "q": "Surah Aal-e-Imran verse 103 commands:",
   "opts": [
    "Division",
    "“Hold fast to the rope of Allah”",
    "Migration",
    "Silence"
   ],
   "correct": 1,
   "expl": "It urges unity around the Quran and Sunnah."
  },
  {
   "q": "Surah An-Nisa verse 135 commands:",
   "opts": [
    "Trade",
    "Standing firm for justice",
    "Fasting",
    "Silence"
   ],
   "correct": 1,
   "expl": "It demands justice even against oneself or kin."
  },
  {
   "q": "Surah Al-Ma'idah verse 8 teaches justice:",
   "opts": [
    "Only for Muslims",
    "Even against hatred of others",
    "Only in courts",
    "Only for rulers"
   ],
   "correct": 1,
   "expl": "Hatred must never prevent just conduct."
  },
  {
   "q": "Surah Luqman (verses 13-19) contains:",
   "opts": [
    "War orders",
    "Luqman's advice to his son",
    "Trade laws",
    "Stories of kings"
   ],
   "correct": 1,
   "expl": "It teaches shirk avoidance, prayer, humility and good manners."
  },
  {
   "q": "Kindness to parents is commanded in Surah:",
   "opts": [
    "Al-Kausar",
    "Bani Isra'il (Al-Isra)",
    "Al-Fil",
    "Al-Lahab"
   ],
   "correct": 1,
   "expl": "Verses 23-24 forbid even saying “uff” to parents."
  },
  {
   "q": "Riba (interest) is prohibited in Surah Al-Baqarah verses:",
   "opts": [
    "2-5",
    "275-279",
    "280-286",
    "150-155"
   ],
   "correct": 1,
   "expl": "These verses declare war from Allah on interest dealings."
  },
  {
   "q": "Laws of inheritance are detailed in Surah An-Nisa verses:",
   "opts": [
    "1-5",
    "11-12",
    "50-55",
    "100-105"
   ],
   "correct": 1,
   "expl": "They fix shares for heirs precisely."
  },
  {
   "q": "The Hadith “actions are judged by intentions” is in:",
   "opts": [
    "Sahih Muslim only",
    "Sahih Bukhari (first Hadith)",
    "Sunan Abu Dawud only",
    "Jami Tirmidhi only"
   ],
   "correct": 1,
   "expl": "It opens Sahih Bukhari and bases deeds on niyyah."
  },
  {
   "q": "“None of you believes until he loves for his brother what he loves for himself” teaches:",
   "opts": [
    "Selfishness",
    "Mutual love",
    "Isolation",
    "Trade"
   ],
   "correct": 1,
   "expl": "True faith needs sincere goodwill for others."
  },
  {
   "q": "“Purity is half of faith” is a:",
   "opts": [
    "Quranic verse",
    "Hadith of the Prophet ﷻ",
    "Saying of a caliph",
    "Poem"
   ],
   "correct": 1,
   "expl": "Sahih Muslim records this teaching on cleanliness."
  },
  {
   "q": "“The strong is not the wrestler but one who controls anger” teaches:",
   "opts": [
    "Sports",
    "Anger control",
    "Wealth",
    "Fasting"
   ],
   "correct": 1,
   "expl": "Real strength is mastering one's temper."
  },
  {
   "q": "“Make things easy and do not make them difficult” teaches:",
   "opts": [
    "Leniency in religion",
    "Strictness",
    "Silence",
    "Wealth"
   ],
   "correct": 0,
   "expl": "The Prophet ﷻ urged facilitation, not hardship."
  },
  {
   "q": "“The best of you are the best to their families” stresses:",
   "opts": [
    "Business",
    "Good family conduct",
    "Travel",
    "Politics"
   ],
   "correct": 1,
   "expl": "Character at home measures true excellence."
  },
  {
   "q": "Seeking knowledge is:",
   "opts": [
    "Optional",
    "Obligatory on every Muslim",
    "Only for men",
    "Only for scholars"
   ],
   "correct": 1,
   "expl": "Hadith makes learning a duty for all Muslims."
  },
  {
   "q": "“He who believes in Allah and the Last Day, let him speak good or remain silent” teaches:",
   "opts": [
    "Silence always",
    "Careful speech",
    "Loudness",
    "Debate"
   ],
   "correct": 1,
   "expl": "It guards the tongue from harmful talk."
  },
  {
   "q": "A Muslim is one from whose ___ others are safe (Hadith):",
   "opts": [
    "Wealth only",
    "Tongue and hand",
    "Eyes only",
    "House only"
   ],
   "correct": 1,
   "expl": "True Islam means harmlessness to others."
  },
  {
   "q": "Zakat is due on:",
   "opts": [
    "Only gold",
    "Gold, silver, cash, trade goods, livestock and crops",
    "Only land",
    "Only salary"
   ],
   "correct": 1,
   "expl": "All growing wealth above nisab carries Zakat."
  },
  {
   "q": "Ushr is:",
   "opts": [
    "1/40 of wealth",
    "1/10 of rain-fed produce",
    "1/5 of spoils",
    "1/2 of crops"
   ],
   "correct": 1,
   "expl": "One-tenth is due on naturally irrigated harvest."
  },
  {
   "q": "Khums means:",
   "opts": [
    "1/10",
    "1/5 of war spoils/minerals",
    "1/40",
    "1/2"
   ],
   "correct": 1,
   "expl": "One-fifth of specified gains goes to state/poor."
  },
  {
   "q": "Sadaqah is:",
   "opts": [
    "Obligatory tax",
    "Voluntary charity",
    "Zakat on crops",
    "War booty"
   ],
   "correct": 1,
   "expl": "It is optional charity given for Allah's sake."
  },
  {
   "q": "Waqf means:",
   "opts": [
    "A loan",
    "A permanent endowment for good",
    "A tax",
    "A fine"
   ],
   "correct": 1,
   "expl": "Property dedicated forever for welfare is waqf."
  },
  {
   "q": "Nikah (marriage) in Islam is:",
   "opts": [
    "Forbidden",
    "A Sunnah and half of faith (Hadith)",
    "Only for rich",
    "A business deal"
   ],
   "correct": 1,
   "expl": "Marriage completes half one's religion per Hadith."
  },
  {
   "q": "Mahr is:",
   "opts": [
    "Dowry from bride's family",
    "Obligatory bridal gift from husband",
    "A tax",
    "Optional gift"
   ],
   "correct": 1,
   "expl": "The husband must give mahr to his wife."
  },
  {
   "q": "Divorce in Islam is described as:",
   "opts": [
    "Most beloved act",
    "Most hated of permissible acts",
    "Forbidden",
    "Encouraged"
   ],
   "correct": 1,
   "expl": "Hadith calls it the most disliked lawful thing to Allah."
  },
  {
   "q": "Iddat is the:",
   "opts": [
    "Marriage sermon",
    "Waiting period after divorce/widowhood",
    "Dowry amount",
    "Divorce deed"
   ],
   "correct": 1,
   "expl": "It is observed before remarriage."
  },
  {
   "q": "Khula is:",
   "opts": [
    "Husband-initiated divorce",
    "Wife-initiated separation",
    "A festival",
    "A prayer"
   ],
   "correct": 1,
   "expl": "A wife may seek separation through khula."
  },
  {
   "q": "Islamic banking is based on:",
   "opts": [
    "Interest",
    "Interest-free (riba-free) modes",
    "Gambling",
    "Speculation"
   ],
   "correct": 1,
   "expl": "It uses profit-sharing instead of interest."
  },
  {
   "q": "Hoarding (ihtekar) in Islam is:",
   "opts": [
    "Allowed",
    "Prohibited",
    "Encouraged",
    "Optional"
   ],
   "correct": 1,
   "expl": "Withholding goods to raise prices is forbidden."
  },
  {
   "q": "Bribery in Islam is:",
   "opts": [
    "Allowed",
    "Prohibited (cursed)",
    "Recommended",
    "Neutral"
   ],
   "correct": 1,
   "expl": "Both giver and taker of bribes are cursed in Hadith."
  },
  {
   "q": "False witness is:",
   "opts": [
    "A minor sin",
    "A major sin",
    "Allowed in need",
    "Praiseworthy"
   ],
   "correct": 1,
   "expl": "The Quran and Hadith condemn false testimony severely."
  },
  {
   "q": "Fulfilling promises in Islam is:",
   "opts": [
    "Optional",
    "Obligatory",
    "Discouraged",
    "Only for rulers"
   ],
   "correct": 1,
   "expl": "The Quran commands fulfilling covenants."
  },
  {
   "q": "Shura (consultation) is a:",
   "opts": [
    "Western idea",
    "Quranic principle of governance",
    "Banned practice",
    "Optional custom"
   ],
   "correct": 1,
   "expl": "The Quran praises deciding affairs by mutual consultation."
  },
  {
   "q": "“No compulsion in religion” is from Surah Al-Baqarah verse:",
   "opts": [
    "255",
    "256",
    "257",
    "258"
   ],
   "correct": 1,
   "expl": "Verse 256 guarantees freedom of faith."
  },
  {
   "q": "The word Islam means:",
   "opts": [
    "War",
    "Peace and submission to Allah",
    "Wealth",
    "Power"
   ],
   "correct": 1,
   "expl": "It comes from submission bringing peace."
  },
  {
   "q": "Jihad of the pen/knowledge means:",
   "opts": [
    "Armed war",
    "Striving through learning and writing",
    "Silence",
    "Trade"
   ],
   "correct": 1,
   "expl": "Intellectual struggle is a form of Jihad."
  },
  {
   "q": "Hadith about not wasting water even at a flowing river teaches:",
   "opts": [
    "Greed",
    "Conservation of resources",
    "Fear",
    "Haste"
   ],
   "correct": 1,
   "expl": "The Prophet ﷻ forbade waste even in abundance."
  },
  {
   "q": "Kindness to animals in Islam is:",
   "opts": [
    "Optional",
    "Rewarded and cruelty punished",
    "Forbidden",
    "Ignored"
   ],
   "correct": 1,
   "expl": "Hadith promises reward for kindness to every living creature."
  },
  {
   "q": "Women's rights in Islam include:",
   "opts": [
    "No rights",
    "Inheritance, education and dignity",
    "Only marriage",
    "Only worship"
   ],
   "correct": 1,
   "expl": "Islam granted women property, learning and honour 1400 years ago."
  },
  {
   "q": "The Farewell Sermon declared:",
   "opts": [
    "Arab superiority",
    "Equality: no Arab over non-Arab except by piety",
    "War",
    "Taxes"
   ],
   "correct": 1,
   "expl": "It proclaimed universal human equality."
  },
  {
   "q": "The Battle of Badr took place in:",
   "opts": [
    "1 Hijri",
    "2 Hijri",
    "3 Hijri",
    "5 Hijri"
   ],
   "correct": 1,
   "expl": "The first major battle of Islam was fought in 2 A.H."
  }
 ],
 "PAKSTUDY12": [
  {
   "q": "The 1973 constitution provides a:",
   "opts": [
    "Presidential system",
    "Parliamentary system",
    "Monarchy",
    "One-party rule"
   ],
   "correct": 1,
   "expl": "It restored a parliamentary democracy with a prime minister."
  },
  {
   "q": "Islam is the ___ under the 1973 constitution:",
   "opts": [
    "Official hobby",
    "State religion",
    "Banned",
    "Optional"
   ],
   "correct": 1,
   "expl": "Article 2 declares Islam the state religion."
  },
  {
   "q": "The head of state in Pakistan is the:",
   "opts": [
    "Prime Minister",
    "President",
    "Chief Justice",
    "Army Chief"
   ],
   "correct": 1,
   "expl": "The President is the constitutional head of state."
  },
  {
   "q": "The head of government in Pakistan is the:",
   "opts": [
    "President",
    "Prime Minister",
    "Speaker",
    "Governor"
   ],
   "correct": 1,
   "expl": "The Prime Minister heads the federal government."
  },
  {
   "q": "Pakistan's parliament is:",
   "opts": [
    "Unicameral",
    "Bicameral",
    "Tricameral",
    "Non-existent"
   ],
   "correct": 1,
   "expl": "It has the Senate (upper) and National Assembly (lower)."
  },
  {
   "q": "The upper house of parliament is the:",
   "opts": [
    "National Assembly",
    "Senate",
    "Provincial Assembly",
    "Majlis"
   ],
   "correct": 1,
   "expl": "The Senate represents the provinces equally."
  },
  {
   "q": "The lower house of parliament is the:",
   "opts": [
    "Senate",
    "National Assembly",
    "Provincial Assembly",
    "Council"
   ],
   "correct": 1,
   "expl": "The National Assembly is directly elected."
  },
  {
   "q": "The voting age in Pakistan is:",
   "opts": [
    "16 years",
    "18 years",
    "21 years",
    "25 years"
   ],
   "correct": 1,
   "expl": "Citizens aged 18 and above can vote."
  },
  {
   "q": "Fundamental rights are given in Articles:",
   "opts": [
    "1-7",
    "8-28",
    "29-40",
    "62-63"
   ],
   "correct": 1,
   "expl": "Articles 8-28 guarantee fundamental rights."
  },
  {
   "q": "The 18th Amendment (2010) gave:",
   "opts": [
    "Martial law",
    "Provincial autonomy",
    "Presidential rule",
    "One Unit"
   ],
   "correct": 1,
   "expl": "It devolved powers to the provinces."
  },
  {
   "q": "The NFC Award concerns:",
   "opts": [
    "Defence",
    "Distribution of resources between federation and provinces",
    "Elections",
    "Foreign loans"
   ],
   "correct": 1,
   "expl": "It shares divisible-pool revenues."
  },
  {
   "q": "The apex court of Pakistan is the:",
   "opts": [
    "High Court",
    "Supreme Court",
    "Shariat Court",
    "Session Court"
   ],
   "correct": 1,
   "expl": "The Supreme Court is the highest judicial authority."
  },
  {
   "q": "The Supreme Court is headed by the:",
   "opts": [
    "President",
    "Chief Justice",
    "Prime Minister",
    "Attorney General"
   ],
   "correct": 1,
   "expl": "The Chief Justice leads the apex court."
  },
  {
   "q": "There are ___ High Courts in Pakistan:",
   "opts": [
    "3",
    "4",
    "5",
    "6"
   ],
   "correct": 2,
   "expl": "Four provincial plus Islamabad High Court make five."
  },
  {
   "q": "The primary role of the armed forces is to:",
   "opts": [
    "Rule",
    "Defend the country's borders",
    "Collect taxes",
    "Make laws"
   ],
   "correct": 1,
   "expl": "Defence of territorial integrity is their constitutional role."
  },
  {
   "q": "Defence Day (6 September) honours the:",
   "opts": [
    "1948 war",
    "1965 war",
    "1971 war",
    "Kargil war"
   ],
   "correct": 1,
   "expl": "It marks the successful defence against the 1965 Indian attack."
  },
  {
   "q": "The 1965 war lasted about:",
   "opts": [
    "6 days",
    "17 days",
    "30 days",
    "100 days"
   ],
   "correct": 1,
   "expl": "Fighting ran from 6 to 23 September 1965."
  },
  {
   "q": "East Pakistan separated in:",
   "opts": [
    "1965",
    "1971",
    "1973",
    "1975"
   ],
   "correct": 1,
   "expl": "Bangladesh emerged on 16 December 1971."
  },
  {
   "q": "The Kargil conflict took place in:",
   "opts": [
    "1998",
    "1999",
    "2000",
    "2001"
   ],
   "correct": 1,
   "expl": "The 1999 Kargil conflict followed nuclear tests."
  },
  {
   "q": "Pakistan's nuclear tests were conducted on:",
   "opts": [
    "28 May 1998",
    "14 August 1998",
    "23 March 1999",
    "6 September 1998"
   ],
   "correct": 0,
   "expl": "Youm-e-Takbeer marks the Chaghi tests of 28 May 1998."
  },
  {
   "q": "Dr. A.Q. Khan is called the father of Pakistan's:",
   "opts": [
    "Space programme",
    "Nuclear programme",
    "Missile industry",
    "Steel industry"
   ],
   "correct": 1,
   "expl": "He led uranium enrichment for the nuclear programme."
  },
  {
   "q": "Pakistan's foreign policy is based on:",
   "opts": [
    "Aggression",
    "Peace and Islamic brotherhood",
    "Isolation",
    "Expansion"
   ],
   "correct": 1,
   "expl": "It seeks friendly ties with all nations, especially Muslim ones."
  },
  {
   "q": "China is described as Pakistan's:",
   "opts": [
    "Rival",
    "Iron brother / all-weather friend",
    "Neutral state",
    "Distant partner"
   ],
   "correct": 1,
   "expl": "The Pakistan-China friendship is exceptionally close."
  },
  {
   "q": "CPEC stands for:",
   "opts": [
    "Central Power Energy Cell",
    "China-Pakistan Economic Corridor",
    "Combined Port Export Company",
    "Cultural Pact of East Countries"
   ],
   "correct": 1,
   "expl": "It is the flagship connectivity project of both countries."
  },
  {
   "q": "Gwadar port is located in:",
   "opts": [
    "Sindh",
    "Balochistan",
    "Punjab",
    "Khyber Pakhtunkhwa"
   ],
   "correct": 1,
   "expl": "Gwadar is the deep-sea port of Balochistan."
  },
  {
   "q": "Pakistan is a member of the:",
   "opts": [
    "NATO",
    "OIC",
    "EU",
    "ASEAN"
   ],
   "correct": 1,
   "expl": "It is an active member of the Organisation of Islamic Cooperation."
  },
  {
   "q": "Pakistan is a member of:",
   "opts": [
    "SAARC",
    "NATO",
    "EU",
    "OPEC"
   ],
   "correct": 0,
   "expl": "It helped found the South Asian regional body SAARC."
  },
  {
   "q": "Pakistan joined the United Nations in:",
   "opts": [
    "1945",
    "1947",
    "1948",
    "1950"
   ],
   "correct": 1,
   "expl": "It became a UN member on 30 September 1947."
  },
  {
   "q": "The core issue between Pakistan and India is:",
   "opts": [
    "Trade",
    "Kashmir",
    "Water only",
    "Border pillars"
   ],
   "correct": 1,
   "expl": "Kashmir remains the central unresolved dispute."
  },
  {
   "q": "The Line of Control divides:",
   "opts": [
    "Punjab",
    "Kashmir",
    "Sindh",
    "Balochistan"
   ],
   "correct": 1,
   "expl": "The LoC separates Pakistani and Indian administered Kashmir."
  },
  {
   "q": "The Indus Waters Treaty was signed in:",
   "opts": [
    "1955",
    "1960",
    "1965",
    "1972"
   ],
   "correct": 1,
   "expl": "The World Bank-brokered treaty was signed in 1960."
  },
  {
   "q": "Under the treaty, Pakistan received the rivers:",
   "opts": [
    "Ravi, Beas, Sutlej",
    "Indus, Jhelum, Chenab",
    "All six rivers",
    "None"
   ],
   "correct": 1,
   "expl": "The three western rivers were allocated to Pakistan."
  },
  {
   "q": "Under the treaty, India received the rivers:",
   "opts": [
    "Indus, Jhelum, Chenab",
    "Ravi, Beas, Sutlej",
    "Kabul, Kurram",
    "None"
   ],
   "correct": 1,
   "expl": "The three eastern rivers went to India."
  },
  {
   "q": "Tarbela Dam is built on the river:",
   "opts": [
    "Jhelum",
    "Indus",
    "Chenab",
    "Ravi"
   ],
   "correct": 1,
   "expl": "Tarbela on the Indus is a major hydel project."
  },
  {
   "q": "Mangla Dam is built on the river:",
   "opts": [
    "Indus",
    "Jhelum",
    "Chenab",
    "Ravi"
   ],
   "correct": 1,
   "expl": "Mangla Dam stands on the Jhelum in Azad Kashmir."
  },
  {
   "q": "The backbone of Pakistan's economy is:",
   "opts": [
    "Industry",
    "Agriculture",
    "Tourism",
    "Mining"
   ],
   "correct": 1,
   "expl": "Agriculture employs the largest share of the workforce."
  },
  {
   "q": "Major crops of Pakistan include:",
   "opts": [
    "Tea and coffee",
    "Wheat, cotton, rice and sugarcane",
    "Rubber and cocoa",
    "Grapes and olives"
   ],
   "correct": 1,
   "expl": "These four are the principal crops."
  },
  {
   "q": "Cotton is called:",
   "opts": [
    "Black gold",
    "White gold",
    "Green gold",
    "Red gold"
   ],
   "correct": 1,
   "expl": "Cotton's export value earns it the name white gold."
  },
  {
   "q": "Pakistan's largest export industry is:",
   "opts": [
    "Steel",
    "Textile",
    "Pharma",
    "Autos"
   ],
   "correct": 1,
   "expl": "Textiles dominate Pakistan's exports."
  },
  {
   "q": "Sialkot is famous for:",
   "opts": [
    "Textiles",
    "Sports goods",
    "Steel",
    "Fertilizer"
   ],
   "correct": 1,
   "expl": "Sialkot's sports goods are exported worldwide."
  },
  {
   "q": "Faisalabad is known as the:",
   "opts": [
    "City of lights",
    "Manchester of Pakistan (textile city)",
    "City of saints",
    "Port city"
   ],
   "correct": 1,
   "expl": "Its huge textile industry gives it the title."
  },
  {
   "q": "Karachi is Pakistan's:",
   "opts": [
    "Capital",
    "Economic hub and largest port city",
    "Textile city",
    "Hill station"
   ],
   "correct": 1,
   "expl": "Karachi handles most trade and industry."
  },
  {
   "q": "Pakistan's population is about:",
   "opts": [
    "140 million",
    "Over 240 million",
    "340 million",
    "440 million"
   ],
   "correct": 1,
   "expl": "The 2023 census counted over 240 million people."
  },
  {
   "q": "Major sources of electricity in Pakistan include:",
   "opts": [
    "Only solar",
    "Hydel, thermal, nuclear and solar",
    "Only wind",
    "Only coal"
   ],
   "correct": 1,
   "expl": "The energy mix combines several sources."
  },
  {
   "q": "Thar coal reserves are in:",
   "opts": [
    "Punjab",
    "Sindh",
    "Balochistan",
    "KPK"
   ],
   "correct": 1,
   "expl": "Huge lignite deposits lie in Thar, Sindh."
  },
  {
   "q": "Sui gas field was discovered in:",
   "opts": [
    "1947",
    "1952",
    "1960",
    "1971"
   ],
   "correct": 1,
   "expl": "The 1952 Sui discovery is in Balochistan."
  },
  {
   "q": "Khewra is famous for its:",
   "opts": [
    "Coal mine",
    "Salt mine",
    "Gold mine",
    "Oil field"
   ],
   "correct": 1,
   "expl": "Khewra in Punjab is a historic salt mine."
  },
  {
   "q": "Reko Diq (Balochistan) is rich in:",
   "opts": [
    "Iron only",
    "Copper and gold",
    "Silver only",
    "Uranium"
   ],
   "correct": 1,
   "expl": "Reko Diq holds vast copper-gold reserves."
  },
  {
   "q": "Pakistan's northern areas attract tourists for:",
   "opts": [
    "Deserts",
    "Mountains like K-2 and Nanga Parbat",
    "Beaches",
    "Forests only"
   ],
   "correct": 1,
   "expl": "The Karakoram and Himalaya ranges draw mountaineers worldwide."
  },
  {
   "q": "The 18th Amendment was passed in:",
   "opts": [
    "2008",
    "2010",
    "2012",
    "2013"
   ],
   "correct": 1,
   "expl": "It was passed in 2010, granting provincial autonomy."
  }
 ]
}
BANK_TITLES = {
 "PHYSICS9": "Physics (9th)",
 "CHEMISTRY9": "Chemistry (9th)",
 "BIOLOGY9": "Biology (9th)",
 "MATH9": "Mathematics (9th)",
 "ENGLISH9": "English (9th)",
 "URDU9": "اردو (نہم)",
 "ISLAMIAT9": "اسلامیات (نہم)",
 "PAKSTUDY9": "مطالعہ پاکستان (نہم)",
 "PHYSICS11": "Physics (11th)",
 "CHEMISTRY11": "Chemistry (11th)",
 "BIOLOGY11": "Biology (11th)",
 "MATH11": "Mathematics (11th)",
 "ENGLISH11": "English (11th)",
 "URDU11": "اردو (گیارہویں)",
 "ISLAMIAT11": "اسلامیات (گیارہویں)",
 "PAKSTUDY11": "مطالعہ پاکستان (گیارہویں)",
 "MATH12": "Mathematics (12th)",
 "BIOLOGY12": "Biology (12th)",
 "ENGLISH12": "English (12th)",
 "URDU12": "اردو (بارہویں)",
 "ISLAMIAT12": "اسلامیات (بارہویں)",
 "PAKSTUDY12": "مطالعہ پاکستان (بارہویں)"
}
