@echo off
python main.py
if errorlevel 1 (
  echo.
  echo Python 3 is required. Download from https://www.python.org/downloads/
  pause
)
