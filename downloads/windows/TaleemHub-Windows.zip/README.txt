Taleem Hub v2.0 — Windows Portable App
=======================================
Study app for Pakistani board students (9th, 10th, 11th, 12th, BA/BSc).

Content: 590 chapters, 1265 MCQs, 274 formulas, 3518 vocabulary words,
61 grammar sections, scientific calculator.

HOW TO RUN:
1. Install Python 3 from https://www.python.org/downloads/ (if not installed)
2. Double-click run.bat

No internet required. No extra libraries needed.

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
