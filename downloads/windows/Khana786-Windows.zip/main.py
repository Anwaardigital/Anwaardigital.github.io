# -*- coding: utf-8 -*-
"""
Khana 786 — Windows Desktop App
Recipe app: 16 categories, 223 recipes with ingredients + method,
search, favorites (saved to favorites.json).
Theme: deep emerald + gold. Python 3 + Tkinter only (no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import json
import os
import tkinter as tk
from tkinter import ttk, messagebox

from khana_data import KHANA_DATA

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_FILE = os.path.join(APP_DIR, "khana786_config.json")
FAV_FILE = os.path.join(APP_DIR, "favorites.json")

BG = "#0A3D2E"        # deep emerald
BG_DARK = "#062B20"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
ACCENT = "#0E5C44"
RED = "#E63946"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

DIFF_UR = {0: "آسان", 1: "درمیانی", 2: "مشکل"}
DIFF_EN = {0: "Easy", 1: "Medium", 2: "Hard"}


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


class KhanaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Khana 786 — کھانا 786")
        self.root.geometry("1080x700")
        self.root.configure(bg=BG_DARK)
        try:
            self.root.state("zoomed")
        except Exception:
            pass

        self.cfg = load_json(CFG_FILE, {})
        self.urdu = self.cfg.get("lang", "ur") != "en"
        self.favs = set(load_json(FAV_FILE, []))
        self.show_favs_only = False

        self._style()
        self._build()

    # ------------------------------------------------------------ UI ---
    def _style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except Exception:
            pass
        s.configure("TFrame", background=BG_DARK)

    def _t(self, ur, en):
        return ur if self.urdu else en

    def _build(self):
        header = tk.Frame(self.root, bg=BG, height=70)
        header.pack(fill="x")
        tk.Label(header, text="🍲 Khana 786 — کھانا 786", bg=BG, fg=GOLD,
                 font=("Segoe UI", 20, "bold")).pack(side="left", padx=16, pady=10)
        btns = tk.Frame(header, bg=BG)
        btns.pack(side="right", padx=16)
        tk.Button(btns, text="⭐ " + self._t("پسندیدہ", "Favorites"),
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=12, pady=6,
                  command=self._toggle_favs_view).pack(side="left", padx=4)
        tk.Button(btns, text="English" if self.urdu else "اردو",
                  bg=CREAM, fg=BG_DARK, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=12, pady=6,
                  command=self._toggle_lang).pack(side="left", padx=4)

        bar = tk.Frame(self.root, bg=BG_DARK)
        bar.pack(fill="x", padx=12, pady=8)
        tk.Label(bar, text="🔍 " + ("تلاش کریں" if self.urdu else "Search"),
                 bg=BG_DARK, fg=CREAM, font=("Segoe UI", 12)).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self._refresh_recipes())
        tk.Entry(bar, textvariable=self.search_var, font=("Segoe UI", 12),
                 bg=WHITE, fg="#222", width=40,
                 relief="flat").pack(side="left", padx=8, ipady=4)

        body = tk.PanedWindow(self.root, orient="horizontal", bg=BG_DARK,
                              sashwidth=4, sashrelief="flat")
        body.pack(fill="both", expand=True, padx=12, pady=4)

        # categories
        left = tk.Frame(body, bg=BG)
        body.add(left, width=250)
        self.cat_label = tk.Label(left, text=self._t("📂 زمرے", "📂 Categories"),
                                  bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold"))
        self.cat_label.pack(pady=8)
        self.cat_list = tk.Listbox(left, exportselection=False, bg=BG_DARK, fg=CREAM,
                                   selectbackground=GOLD,
                                   selectforeground=BG_DARK,
                                   font=("Segoe UI", 12), relief="flat",
                                   highlightthickness=0, activestyle="none")
        self.cat_list.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.cat_list.bind("<<ListboxSelect>>", lambda e: self._refresh_recipes())

        # recipes
        mid = tk.Frame(body, bg=BG)
        body.add(mid, width=330)
        self.rec_label = tk.Label(mid, text=self._t("🍽️ ترکیبیں", "🍽️ Recipes"),
                                  bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold"))
        self.rec_label.pack(pady=8)
        self.rec_list = tk.Listbox(mid, exportselection=False, bg=BG_DARK, fg=CREAM,
                                   selectbackground=GOLD,
                                   selectforeground=BG_DARK,
                                   font=("Segoe UI", 11), relief="flat",
                                   highlightthickness=0, activestyle="none")
        self.rec_list.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.rec_list.bind("<<ListboxSelect>>", lambda e: self._show_detail())

        # detail
        right = tk.Frame(body, bg=BG)
        body.add(right, minsize=320)
        top = tk.Frame(right, bg=BG)
        top.pack(fill="x")
        self.det_label = tk.Label(top, text=self._t("📖 ترکیب", "📖 Recipe"),
                                  bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold"))
        self.det_label.pack(side="left", pady=8, padx=8)
        self.fav_btn = tk.Button(top, text="☆", bg=BG, fg=GOLD,
                                 font=("Segoe UI", 16, "bold"),
                                 relief="flat", activebackground=ACCENT,
                                 command=self._toggle_fav)
        self.fav_btn.pack(side="right", padx=8)
        self.detail = tk.Text(right, bg=BG_DARK, fg=CREAM,
                              font=("Segoe UI", 12), relief="flat",
                              wrap="word", padx=12, pady=12,
                              highlightthickness=0)
        self.detail.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.detail.tag_configure("title", foreground=GOLD,
                                  font=("Segoe UI", 16, "bold"))
        self.detail.tag_configure("head", foreground=GOLD,
                                  font=("Segoe UI", 13, "bold"))

        foot = tk.Frame(self.root, bg=BG, height=30)
        foot.pack(fill="x")
        tk.Label(foot, text=f"{DEVELOPER_LINE}  |  {WHATSAPP_LINE}",
                 bg=BG, fg=CREAM, font=("Segoe UI", 9)).pack(pady=6)

        self._fill_categories()

    # ------------------------------------------------------------ data ---
    def _cat_name(self, cat):
        return self._t(cat["tu"], cat["te"])

    def _fill_categories(self):
        self.cat_list.delete(0, "end")
        for c in KHANA_DATA["cats"]:
            n = sum(1 for r in KHANA_DATA["recipes"] if r["cat"] == c["key"])
            self.cat_list.insert("end", f"{c['icon']}  {self._cat_name(c)} ({n})")
        if KHANA_DATA["cats"]:
            self.cat_list.selection_set(0)
        self._refresh_recipes()

    def _selected_cat_key(self):
        sel = self.cat_list.curselection()
        if not sel:
            return None
        return KHANA_DATA["cats"][sel[0]]["key"]

    def _rec_key(self, r):
        return f"{r['cat']}::{r['te']}"

    def _refresh_recipes(self):
        self.rec_list.delete(0, "end")
        q = self.search_var.get().strip().lower()
        cat_key = self._selected_cat_key()
        self._current = []
        for r in KHANA_DATA["recipes"]:
            if self.show_favs_only and self._rec_key(r) not in self.favs:
                continue
            if q:
                if q not in r["tu"].lower() and q not in r["te"].lower():
                    continue
            elif cat_key and r["cat"] != cat_key:
                continue
            mark = "⭐ " if self._rec_key(r) in self.favs else ""
            self._current.append(r)
            self.rec_list.insert("end", mark + self._t(r["tu"], r["te"]))
        if self._current:
            self.rec_list.selection_set(0)
        self._show_detail()

    def _show_detail(self):
        sel = self.rec_list.curselection()
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        if sel and sel[0] < len(self._current):
            r = self._current[sel[0]]
            self._update_fav_btn(r)
            diff = (DIFF_UR if self.urdu else DIFF_EN).get(r["diff"], "")
            self.detail.insert("end", self._t(r["tu"], r["te"]) + "\n", "title")
            self.detail.insert(
                "end",
                f"⏱ {r['mins']} " + self._t("منٹ", "min") +
                f"   •   ⚙ {diff}   •   🍽 {r['serv']} " +
                self._t("افراد", "servings") + "\n\n")
            self.detail.insert("end", self._t("🧂 اجزاء", "🧂 Ingredients") + "\n", "head")
            for line in self._t(r["ingUr"], r["ingEn"]).split("\n"):
                line = line.strip()
                if line:
                    self.detail.insert("end", "• " + line + "\n")
            self.detail.insert("end", "\n" + self._t("👨‍🍳 ترکیب", "👨‍🍳 Method") + "\n", "head")
            for line in self._t(r["metUr"], r["metEn"]).split("\n"):
                line = line.strip()
                if line:
                    self.detail.insert("end", "• " + line + "\n")
        else:
            self.fav_btn.configure(text="☆")
            self.detail.insert("end", self._t("کوئی ترکیب منتخب کریں",
                                              "Select a recipe"))
        self.detail.configure(state="disabled")

    def _update_fav_btn(self, r):
        self.fav_btn.configure(
            text="★" if self._rec_key(r) in self.favs else "☆")

    def _toggle_fav(self):
        sel = self.rec_list.curselection()
        if not sel or sel[0] >= len(self._current):
            return
        r = self._current[sel[0]]
        k = self._rec_key(r)
        if k in self.favs:
            self.favs.discard(k)
        else:
            self.favs.add(k)
        save_json(FAV_FILE, sorted(self.favs))
        self._update_fav_btn(r)
        self._refresh_recipes()

    def _toggle_favs_view(self):
        self.show_favs_only = not self.show_favs_only
        if self.show_favs_only and not self.favs:
            messagebox.showinfo("Khana 786",
                                self._t("ابھی کوئی پسندیدہ ترکیب نہیں۔",
                                        "No favorite recipes yet."))
            self.show_favs_only = False
            return
        self.rec_label.configure(
            text=self._t("⭐ پسندیدہ ترکیبیں", "⭐ Favorite Recipes")
            if self.show_favs_only else self._t("🍽️ ترکیبیں", "🍽️ Recipes"))
        self._refresh_recipes()

    def _toggle_lang(self):
        self.urdu = not self.urdu
        self.cfg["lang"] = "ur" if self.urdu else "en"
        save_json(CFG_FILE, self.cfg)
        for w in self.root.winfo_children():
            w.destroy()
        self._build()


def main():
    root = tk.Tk()
    KhanaApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
