@echo off
title Khana 786
python main.py
pause
