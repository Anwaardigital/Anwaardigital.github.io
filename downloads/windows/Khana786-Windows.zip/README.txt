Khana 786 - Windows App
======================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features:
- 16 categories (Desi, Meetha, Sabzi, Chicken, Gosht, Machli,
  Roti, Salad, Daal, Snacks, Drinks, Ramzan, Eid, Kids, Diet, Quick)
- 223 recipes - Urdu + English, ajza + tarkeeb
- Search - koi bhi recipe foran dhoondein
- Favorites - pasandida recipes save karein (favorites.json mein)

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
