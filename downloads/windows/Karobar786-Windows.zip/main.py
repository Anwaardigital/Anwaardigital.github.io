# -*- coding: utf-8 -*-
"""
Karobar 786 — Windows Desktop App
Business tools: income/expense tracker (hisab.json), profit calculator,
invoice generator (saves .txt), business ideas + guides (206 articles).
Theme: deep emerald + gold. Python 3 + Tkinter only (no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import datetime
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from karobar_data import KAROBAR_DATA

APP_DIR = os.path.dirname(os.path.abspath(__file__))
HISAB_FILE = os.path.join(APP_DIR, "hisab.json")
CFG_FILE = os.path.join(APP_DIR, "karobar786_config.json")

BG = "#0A3D2E"        # deep emerald
BG_DARK = "#062B20"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
ACCENT = "#0E5C44"
GREEN = "#2ECC71"
RED = "#E63946"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

# feature keys that open the content reader (vs. built-in tools)
CONTENT_KEYS = {"ideas", "shop", "online", "freelance", "youtube", "bank",
                "digital", "plan", "marketing", "dealing", "legal", "tax",
                "agri", "faq"}


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        messagebox.showerror("Karobar 786", str(e))


class KarobarApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Karobar 786 — کاروبار 786")
        self.root.geometry("1080x700")
        self.root.configure(bg=BG_DARK)
        try:
            self.root.state("zoomed")
        except Exception:
            pass

        self.cfg = load_json(CFG_FILE, {})
        self.urdu = self.cfg.get("lang", "ur") != "en"
        self.hisab = load_json(HISAB_FILE, [])  # [{date, desc, amount, type}]

        self._build()

    # ------------------------------------------------------------ UI ---
    def _t(self, ur, en):
        return ur if self.urdu else en

    def _build(self):
        header = tk.Frame(self.root, bg=BG, height=70)
        header.pack(fill="x")
        tk.Label(header, text="💼 Karobar 786 — کاروبار 786", bg=BG, fg=GOLD,
                 font=("Segoe UI", 20, "bold")).pack(side="left", padx=16, pady=10)
        tk.Button(header, text="English" if self.urdu else "اردو",
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=14, pady=6,
                  command=self._toggle_lang).pack(side="right", padx=16)

        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=10, pady=8)
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("TNotebook", background=BG_DARK, borderwidth=0)
        st.configure("TNotebook.Tab", background=ACCENT, foreground=WHITE,
                     font=("Segoe UI", 11, "bold"), padding=(14, 8))
        st.map("TNotebook.Tab", background=[("selected", BG)])
        st.configure("TFrame", background=BG_DARK)

        self._build_home_tab(nb)
        self._build_hisab_tab(nb)
        self._build_profit_tab(nb)
        self._build_invoice_tab(nb)

        foot = tk.Frame(self.root, bg=BG, height=30)
        foot.pack(fill="x")
        tk.Label(foot, text=f"{DEVELOPER_LINE}  |  {WHATSAPP_LINE}",
                 bg=BG, fg=CREAM, font=("Segoe UI", 9)).pack(pady=6)

    # ------------------------------------------------------------ home ---
    def _build_home_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=self._t("🏠 ہوم", "🏠 Home"))
        tk.Label(tab, text=self._t("کاروباری رہنمائی اور ٹولز",
                                   "Business Guides & Tools"),
                 bg=BG_DARK, fg=GOLD, font=("Segoe UI", 15, "bold")).pack(pady=10)

        canvas = tk.Canvas(tab, bg=BG_DARK, highlightthickness=0)
        scroll = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        grid = tk.Frame(canvas, bg=BG_DARK)
        grid.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=grid, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True, padx=(10, 0))
        scroll.pack(side="right", fill="y", padx=(0, 10))

        col, row = 0, 0
        for f in KAROBAR_DATA["features"]:
            card = tk.Frame(grid, bg=BG, padx=14, pady=12,
                            highlightbackground=GOLD, highlightthickness=1)
            card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
            tk.Label(card, text=f["icon"], bg=BG,
                     font=("Segoe UI", 22)).pack()
            tk.Label(card, text=self._t(f["tu"], f["te"]), bg=BG, fg=GOLD,
                     font=("Segoe UI", 12, "bold"), wraplength=200).pack()
            tk.Label(card, text=self._t(f["descUr"], f["descEn"]), bg=BG,
                     fg=CREAM, font=("Segoe UI", 10), wraplength=200).pack()
            key = f["key"]
            tk.Button(card, text=self._t("کھولیں", "Open"),
                      bg=GOLD, fg=BG_DARK, font=("Segoe UI", 10, "bold"),
                      relief="flat", padx=16, pady=4,
                      command=lambda k=key: self._open_feature(k)).pack(pady=6)
            col += 1
            if col > 3:
                col, row = 0, row + 1
        for c in range(4):
            grid.columnconfigure(c, weight=1)

    def _open_feature(self, key):
        if key in CONTENT_KEYS:
            self._open_content(key)
        elif key == "hisab":
            messagebox.showinfo("Karobar 786",
                                self._t("حساب کتاب ٹیب استعمال کریں۔",
                                        "Use the Income/Expense tab."))
        elif key == "profit":
            messagebox.showinfo("Karobar 786",
                                self._t("منافع کیلکولیٹر ٹیب استعمال کریں۔",
                                        "Use the Profit Calculator tab."))
        elif key == "invoice":
            messagebox.showinfo("Karobar 786",
                                self._t("انوائس ٹیب استعمال کریں۔",
                                        "Use the Invoice tab."))
        else:
            self._open_content(key)

    def _open_content(self, key):
        feat = next((f for f in KAROBAR_DATA["features"]
                     if f["key"] == key), None)
        items = KAROBAR_DATA["content"].get(key, [])
        win = tk.Toplevel(self.root)
        win.title(self._t(feat["tu"], feat["te"]) if feat else "Karobar 786")
        win.geometry("800x600")
        win.configure(bg=BG_DARK)

        left = tk.Frame(win, bg=BG, width=250)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        lst = tk.Listbox(left, exportselection=False, bg=BG_DARK, fg=CREAM, selectbackground=GOLD,
                         selectforeground=BG_DARK, font=("Segoe UI", 11),
                         relief="flat", highlightthickness=0,
                         activestyle="none")
        lst.pack(fill="both", expand=True, padx=8, pady=8)

        txt = tk.Text(win, bg=BG_DARK, fg=CREAM, font=("Segoe UI", 12),
                      relief="flat", wrap="word", padx=12, pady=12,
                      highlightthickness=0)
        txt.pack(side="right", fill="both", expand=True)
        txt.tag_configure("title", foreground=GOLD,
                          font=("Segoe UI", 15, "bold"))

        for it in items:
            lst.insert("end", self._t(it["tu"], it["te"]))

        def show(ev=None):
            sel = lst.curselection()
            txt.configure(state="normal")
            txt.delete("1.0", "end")
            if sel:
                it = items[sel[0]]
                txt.insert("end", self._t(it["tu"], it["te"]) + "\n\n", "title")
                txt.insert("end", self._t(it["bu"], it["be"]))
            txt.configure(state="disabled")

        lst.bind("<<ListboxSelect>>", show)
        if items:
            lst.selection_set(0)
            show()

    # ------------------------------------------------------------ hisab ---
    def _build_hisab_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=self._t("📊 حساب کتاب", "📊 Income/Expense"))

        form = tk.Frame(tab, bg=BG, padx=12, pady=12)
        form.pack(fill="x", padx=10, pady=10)
        tk.Label(form, text=self._t("تفصیل:", "Description:"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).grid(row=0, column=0,
                                                             sticky="w")
        self.h_desc = tk.Entry(form, font=("Segoe UI", 11), width=30,
                               bg=WHITE, fg="#222", relief="flat")
        self.h_desc.grid(row=0, column=1, padx=8, pady=4, ipady=3)
        tk.Label(form, text=self._t("رقم (Rs):", "Amount (Rs):"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).grid(row=0, column=2,
                                                             sticky="w")
        self.h_amt = tk.Entry(form, font=("Segoe UI", 11), width=15,
                              bg=WHITE, fg="#222", relief="flat")
        self.h_amt.grid(row=0, column=3, padx=8, pady=4, ipady=3)
        self.h_type = tk.StringVar(value="income")
        tk.Radiobutton(form, text=self._t("💰 آمدن", "💰 Income"),
                       variable=self.h_type, value="income", bg=BG, fg=GREEN,
                       selectcolor=BG, font=("Segoe UI", 11, "bold"),
                       activebackground=BG).grid(row=1, column=1, sticky="w")
        tk.Radiobutton(form, text=self._t("💸 خرچ", "💸 Expense"),
                       variable=self.h_type, value="expense", bg=BG, fg=RED,
                       selectcolor=BG, font=("Segoe UI", 11, "bold"),
                       activebackground=BG).grid(row=1, column=2, sticky="w")
        tk.Button(form, text=self._t("➕ شامل کریں", "➕ Add"),
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=18, pady=5,
                  command=self._add_hisab).grid(row=1, column=3, pady=4)
        tk.Button(form, text=self._t("🗑 منتخب حذف کریں", "🗑 Delete selected"),
                  bg=RED, fg=WHITE, font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=12, pady=4,
                  command=self._del_hisab).grid(row=1, column=0, pady=4)

        self.hisab_list = tk.Listbox(tab, exportselection=False, bg=BG_DARK, fg=CREAM,
                                     selectbackground=GOLD,
                                     selectforeground=BG_DARK,
                                     font=("Segoe UI", 11), relief="flat",
                                     highlightthickness=0, activestyle="none")
        self.hisab_list.pack(fill="both", expand=True, padx=10, pady=(0, 6))
        self.hisab_total = tk.Label(tab, bg=BG_DARK, fg=GOLD,
                                    font=("Segoe UI", 14, "bold"))
        self.hisab_total.pack(pady=6)
        self._refresh_hisab()

    def _add_hisab(self):
        desc = self.h_desc.get().strip()
        try:
            amt = float(self.h_amt.get().strip())
        except ValueError:
            messagebox.showwarning("Karobar 786",
                                   self._t("صحیح رقم لکھیں۔",
                                           "Enter a valid amount."))
            return
        if not desc:
            messagebox.showwarning("Karobar 786",
                                   self._t("تفصیل لکھیں۔",
                                           "Enter a description."))
            return
        self.hisab.append({
            "date": datetime.date.today().isoformat(),
            "desc": desc, "amount": amt, "type": self.h_type.get(),
        })
        save_json(HISAB_FILE, self.hisab)
        self.h_desc.delete(0, "end")
        self.h_amt.delete(0, "end")
        self._refresh_hisab()

    def _del_hisab(self):
        sel = self.hisab_list.curselection()
        if not sel:
            return
        del self.hisab[sel[0]]
        save_json(HISAB_FILE, self.hisab)
        self._refresh_hisab()

    def _refresh_hisab(self):
        self.hisab_list.delete(0, "end")
        inc = sum(e["amount"] for e in self.hisab if e["type"] == "income")
        exp = sum(e["amount"] for e in self.hisab if e["type"] == "expense")
        for e in self.hisab:
            sign = "+" if e["type"] == "income" else "-"
            col = "💰" if e["type"] == "income" else "💸"
            self.hisab_list.insert(
                "end", f"{col} {e['date']}  {e['desc']}  {sign}Rs {e['amount']:,.0f}")
        bal = inc - exp
        self.hisab_total.configure(
            text=self._t(f"کل آمدن: Rs {inc:,.0f}   |   کل خرچ: Rs {exp:,.0f}   |   بیلنس: Rs {bal:,.0f}",
                        f"Total Income: Rs {inc:,.0f}   |   Total Expense: Rs {exp:,.0f}   |   Balance: Rs {bal:,.0f}"))

    # ------------------------------------------------------------ profit ---
    def _build_profit_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=self._t("📈 منافع کیلکولیٹر", "📈 Profit Calculator"))
        form = tk.Frame(tab, bg=BG, padx=20, pady=20)
        form.pack(padx=20, pady=30)
        tk.Label(form, text=self._t("لاگت (Rs):", "Cost Price (Rs):"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 12)).grid(row=0, column=0,
                                                             sticky="w", pady=6)
        self.p_cost = tk.Entry(form, font=("Segoe UI", 12), width=20,
                               bg=WHITE, fg="#222", relief="flat")
        self.p_cost.grid(row=0, column=1, padx=10, pady=6, ipady=4)
        tk.Label(form, text=self._t("فروخت قیمت (Rs):", "Selling Price (Rs):"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 12)).grid(row=1, column=0,
                                                             sticky="w", pady=6)
        self.p_sell = tk.Entry(form, font=("Segoe UI", 12), width=20,
                               bg=WHITE, fg="#222", relief="flat")
        self.p_sell.grid(row=1, column=1, padx=10, pady=6, ipady=4)
        tk.Button(form, text=self._t("🧮 حساب کریں", "🧮 Calculate"),
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 12, "bold"),
                  relief="flat", padx=20, pady=6,
                  command=self._calc_profit).grid(row=2, column=0,
                                                 columnspan=2, pady=10)
        self.p_result = tk.Label(form, bg=BG, fg=CREAM,
                                 font=("Segoe UI", 13, "bold"), justify="left")
        self.p_result.grid(row=3, column=0, columnspan=2, pady=8)

    def _calc_profit(self):
        try:
            cost = float(self.p_cost.get().strip())
            sell = float(self.p_sell.get().strip())
        except ValueError:
            messagebox.showwarning("Karobar 786",
                                   self._t("صحیح رقمیں لکھیں۔",
                                           "Enter valid numbers."))
            return
        profit = sell - cost
        margin = (profit / sell * 100) if sell else 0
        markup = (profit / cost * 100) if cost else 0
        word = self._t("منافع", "Profit") if profit >= 0 else self._t("نقصان", "Loss")
        color = GREEN if profit >= 0 else RED
        self.p_result.configure(
            fg=color,
            text=self._t(f"{word}: Rs {profit:,.0f}\nمارجن: {margin:.1f}%   |   مارک اپ: {markup:.1f}%",
                        f"{word}: Rs {profit:,.0f}\nMargin: {margin:.1f}%   |   Markup: {markup:.1f}%"))

    # ------------------------------------------------------------ invoice ---
    def _build_invoice_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=self._t("🧾 انوائس", "🧾 Invoice"))
        form = tk.Frame(tab, bg=BG, padx=12, pady=12)
        form.pack(fill="x", padx=10, pady=10)
        tk.Label(form, text=self._t("گاہک کا نام:", "Customer Name:"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).grid(row=0, column=0,
                                                             sticky="w")
        self.i_cust = tk.Entry(form, font=("Segoe UI", 11), width=30,
                               bg=WHITE, fg="#222", relief="flat")
        self.i_cust.grid(row=0, column=1, padx=8, pady=4, ipady=3)
        tk.Label(form, text=self._t("فون:", "Phone:"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).grid(row=0, column=2,
                                                             sticky="w")
        self.i_phone = tk.Entry(form, font=("Segoe UI", 11), width=20,
                                bg=WHITE, fg="#222", relief="flat")
        self.i_phone.grid(row=0, column=3, padx=8, pady=4, ipady=3)

        itemf = tk.Frame(form, bg=BG)
        itemf.grid(row=1, column=0, columnspan=4, pady=6, sticky="w")
        tk.Label(itemf, text=self._t("چیز:", "Item:"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).pack(side="left")
        self.i_item = tk.Entry(itemf, font=("Segoe UI", 11), width=22,
                               bg=WHITE, fg="#222", relief="flat")
        self.i_item.pack(side="left", padx=6, ipady=3)
        tk.Label(itemf, text=self._t("تعداد:", "Qty:"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).pack(side="left")
        self.i_qty = tk.Entry(itemf, font=("Segoe UI", 11), width=6,
                              bg=WHITE, fg="#222", relief="flat")
        self.i_qty.pack(side="left", padx=6, ipady=3)
        tk.Label(itemf, text=self._t("قیمت:", "Price:"),
                 bg=BG, fg=CREAM, font=("Segoe UI", 11)).pack(side="left")
        self.i_price = tk.Entry(itemf, font=("Segoe UI", 11), width=10,
                                bg=WHITE, fg="#222", relief="flat")
        self.i_price.pack(side="left", padx=6, ipady=3)
        tk.Button(itemf, text=self._t("➕ چیز شامل کریں", "➕ Add Item"),
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=12, pady=4,
                  command=self._add_inv_item).pack(side="left", padx=8)

        self.i_items = []  # [(name, qty, price)]
        self.i_list = tk.Listbox(tab, exportselection=False, bg=BG_DARK, fg=CREAM,
                                 selectbackground=GOLD,
                                 selectforeground=BG_DARK,
                                 font=("Segoe UI", 11), relief="flat",
                                 highlightthickness=0, activestyle="none",
                                 height=10)
        self.i_list.pack(fill="both", expand=True, padx=10, pady=6)
        self.i_total = tk.Label(tab, bg=BG_DARK, fg=GOLD,
                                font=("Segoe UI", 14, "bold"),
                                text=self._t("کل: Rs 0", "Total: Rs 0"))
        self.i_total.pack(pady=4)
        btnf = tk.Frame(tab, bg=BG_DARK)
        btnf.pack(pady=6)
        tk.Button(btnf, text=self._t("🗑 منتخب حذف کریں", "🗑 Delete selected"),
                  bg=RED, fg=WHITE, font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=12, pady=5,
                  command=self._del_inv_item).pack(side="left", padx=6)
        tk.Button(btnf, text=self._t("💾 انوائس محفوظ کریں (.txt)", "💾 Save Invoice (.txt)"),
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=16, pady=5,
                  command=self._save_invoice).pack(side="left", padx=6)

    def _add_inv_item(self):
        name = self.i_item.get().strip()
        try:
            qty = float(self.i_qty.get().strip() or "1")
            price = float(self.i_price.get().strip())
        except ValueError:
            messagebox.showwarning("Karobar 786",
                                   self._t("صحیح تعداد اور قیمت لکھیں۔",
                                           "Enter valid quantity and price."))
            return
        if not name:
            messagebox.showwarning("Karobar 786",
                                   self._t("چیز کا نام لکھیں۔",
                                           "Enter the item name."))
            return
        self.i_items.append((name, qty, price))
        self.i_item.delete(0, "end")
        self.i_qty.delete(0, "end")
        self.i_price.delete(0, "end")
        self._refresh_inv()

    def _del_inv_item(self):
        sel = self.i_list.curselection()
        if sel:
            del self.i_items[sel[0]]
            self._refresh_inv()

    def _inv_total(self):
        return sum(q * p for _, q, p in self.i_items)

    def _refresh_inv(self):
        self.i_list.delete(0, "end")
        for name, qty, price in self.i_items:
            self.i_list.insert(
                "end", f"{name}  × {qty:g}  @ Rs {price:,.0f}  = Rs {qty * price:,.0f}")
        self.i_total.configure(
            text=self._t(f"کل: Rs {self._inv_total():,.0f}",
                        f"Total: Rs {self._inv_total():,.0f}"))

    def _save_invoice(self):
        if not self.i_items:
            messagebox.showwarning("Karobar 786",
                                   self._t("پہلے کوئی چیز شامل کریں۔",
                                           "Add at least one item first."))
            return
        cust = self.i_cust.get().strip() or "-"
        phone = self.i_phone.get().strip() or "-"
        date = datetime.date.today().strftime("%d-%m-%Y")
        lines = []
        lines.append("=" * 44)
        lines.append("KAROBAR 786 — INVOICE")
        lines.append("=" * 44)
        lines.append(f"Date: {date}")
        lines.append(f"Customer: {cust}")
        lines.append(f"Phone: {phone}")
        lines.append("-" * 44)
        lines.append(f"{'Item':<24}{'Qty':>6}{'Price':>10}{'Total':>12}")
        lines.append("-" * 44)
        for name, qty, price in self.i_items:
            lines.append(f"{name[:24]:<24}{qty:>6g}{price:>10,.0f}{(qty * price):>12,.0f}")
        lines.append("-" * 44)
        lines.append(f"{'TOTAL':<24}{'':>6}{'':>10}{self._inv_total():>12,.0f}")
        lines.append("=" * 44)
        lines.append(DEVELOPER_LINE)
        lines.append(WHATSAPP_LINE)
        text = "\n".join(lines)
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            initialfile=f"invoice_{date}.txt",
            title=self._t("انوائس محفوظ کریں", "Save Invoice"))
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text)
                messagebox.showinfo("Karobar 786",
                                    self._t("انوائس محفوظ ہو گئی۔",
                                            "Invoice saved."))
            except Exception as e:
                messagebox.showerror("Karobar 786", str(e))

    def _toggle_lang(self):
        self.urdu = not self.urdu
        self.cfg["lang"] = "ur" if self.urdu else "en"
        save_json(CFG_FILE, self.cfg)
        for w in self.root.winfo_children():
            w.destroy()
        self._build()


def main():
    root = tk.Tk()
    KarobarApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
