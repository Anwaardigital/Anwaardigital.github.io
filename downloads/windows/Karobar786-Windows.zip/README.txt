Karobar 786 - Windows App
========================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features:
- 14 karobari guides (Business Ideas, Shop Guide, Online Earning,
  Freelancing, YouTube, Bank Guide, Easypaisa/JazzCash, Business Plan,
  Marketing, Customer Dealing, Legal, Tax, Farming, FAQs)
- 206 articles - Urdu + English
- Aamad / Kharch tracker (hisab.json mein save hota hai)
- Munafa Calculator (profit, margin, markup)
- Invoice Maker (.txt file mein save)

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
