@echo off
title Karobar 786
python main.py
pause
