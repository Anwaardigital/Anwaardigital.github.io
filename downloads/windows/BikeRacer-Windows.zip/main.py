# -*- coding: utf-8 -*-
"""
Bike Racer 3D (concept) — Windows Desktop App
Top-down arcade racer: dodge traffic in 3 lanes, speed keeps increasing,
score for every dodge + distance. Python 3 + Tkinter only (no extra deps).
Theme: night highway, emerald bike + gold lane lines.
"""

import tkinter as tk
from tkinter import messagebox
import random

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#0B0F1A"
ROAD = "#141A26"
LINE = "#FFD700"
BIKE = "#10B981"
TRAFFIC = ["#FF3B3B", "#FF8C00", "#B537F2", "#38BDF8"]
TEXT = "#FFFFFF"
GOLD = "#FFD700"

WIDTH, HEIGHT = 480, 640
LANES = [110, 240, 370]
PLAYER_Y = HEIGHT - 120


class BikeRacer:
    def __init__(self, root):
        self.root = root
        root.title("Bike Racer 3D — Windows")
        root.geometry("%dx%d" % (WIDTH, HEIGHT + 70))
        root.configure(bg=BG)
        root.resizable(False, False)

        hud = tk.Frame(root, bg=BG)
        hud.pack(fill="x", padx=10, pady=5)
        self.score_var = tk.StringVar(value="Score: 0")
        self.speed_var = tk.StringVar(value="Speed: 0 km/h")
        tk.Label(hud, textvariable=self.score_var, fg=GOLD, bg=BG,
                 font=("Arial", 12, "bold")).pack(side="left")
        tk.Label(hud, textvariable=self.speed_var, fg=TEXT, bg=BG,
                 font=("Arial", 12)).pack(side="right")

        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT,
                                bg=ROAD, highlightthickness=0)
        self.canvas.pack()

        foot = tk.Frame(root, bg=BG)
        foot.pack(fill="x", pady=4)
        tk.Label(foot, text=DEVELOPER_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()
        tk.Label(foot, text=WHATSAPP_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()

        root.bind("<Left>", lambda e: self.move(-1))
        root.bind("<Right>", lambda e: self.move(1))
        root.bind("<a>", lambda e: self.move(-1))
        root.bind("<d>", lambda e: self.move(1))
        root.bind("<space>", lambda e: self.restart())
        root.bind("<Return>", lambda e: self.restart())

        self.best = 0
        self.restart()
        self.game_loop()

    def restart(self):
        self.lane = 1
        self.score = 0
        self.speed = 5.0
        self.traffic = []
        self.road_offset = 0
        self.alive = True
        self.spawn_timer = 0
        self.draw_hint()

    def draw_hint(self):
        self.canvas.delete("all")
        self.canvas.create_text(WIDTH // 2, HEIGHT // 2 - 60, text="BIKE RACER",
                               fill=GOLD, font=("Arial", 30, "bold"))
        self.canvas.create_text(WIDTH // 2, HEIGHT // 2 - 10,
                               text="Dodge the traffic!",
                               fill=BIKE, font=("Arial", 14, "bold"))
        self.canvas.create_text(WIDTH // 2, HEIGHT // 2 + 40,
                               text="<- -> / A D: lane change\nSPACE: restart",
                               fill=TEXT, font=("Arial", 12), justify="center")

    def move(self, direction):
        if not self.alive:
            return
        self.lane = max(0, min(2, self.lane + direction))

    def spawn_traffic(self):
        lane = random.choice([0, 1, 2])
        color = random.choice(TRAFFIC)
        kind = random.choice(["car", "truck"])
        self.traffic.append({"lane": lane, "y": -80, "color": color, "kind": kind})

    def draw_bike(self, x, y):
        w, h = 30, 64
        c = self.canvas
        # wheels
        c.create_rectangle(x - 8, y - h // 2 - 8, x + 8, y - h // 2 + 8,
                           fill="#111111", outline="#555555")
        c.create_rectangle(x - 8, y + h // 2 - 8, x + 8, y + h // 2 + 8,
                           fill="#111111", outline="#555555")
        # frame / body
        c.create_rectangle(x - w // 2, y - h // 2, x + w // 2, y + h // 2,
                           fill=BIKE, outline="#064E3B", width=2)
        # rider seat + handlebar
        c.create_rectangle(x - 8, y - 6, x + 8, y + 14, fill="#065F46", outline="")
        c.create_line(x - w // 2 - 4, y - h // 2 + 10, x + w // 2 + 4,
                      y - h // 2 + 10, fill="#064E3B", width=4)
        # headlight
        c.create_oval(x - 6, y - h // 2 - 2, x + 6, y - h // 2 + 10,
                      fill="#FEF9C3", outline="")

    def draw_vehicle(self, x, y, color, kind):
        w = 46
        h = 84 if kind == "truck" else 68
        c = self.canvas
        c.create_rectangle(x - w // 2, y - h // 2, x + w // 2, y + h // 2,
                           fill=color, outline="#000000", width=2)
        c.create_rectangle(x - w // 2 + 6, y - h // 2 + 12, x + w // 2 - 6, y - 8,
                           fill="#B0E0E6", outline="")
        for wx, wy in [(-w // 2 - 4, -h // 4), (w // 2 + 4, -h // 4),
                       (-w // 2 - 4, h // 4), (w // 2 + 4, h // 4)]:
            c.create_rectangle(x + wx - 5, y + wy - 10, x + wx + 5, y + wy + 10,
                               fill="#111111", outline="")
        if kind == "truck":
            c.create_rectangle(x - w // 2 + 4, y + 8, x + w // 2 - 4, y + h // 2 - 6,
                               fill="#000000", outline="", stipple="gray25")

    def game_loop(self):
        if self.alive:
            self.canvas.delete("all")
            # scrolling lane dashes
            self.road_offset = (self.road_offset + self.speed) % 60
            for lx in [175, 305]:
                for y in range(-60, HEIGHT + 60, 60):
                    yy = y + self.road_offset
                    self.canvas.create_rectangle(lx - 3, yy, lx + 3, yy + 30,
                                                 fill=LINE, outline="")
            # spawn
            self.spawn_timer += 1
            if self.spawn_timer > max(18, 48 - int(self.speed)):
                self.spawn_timer = 0
                self.spawn_traffic()

            px, py = LANES[self.lane], PLAYER_Y
            for v in self.traffic[:]:
                v["y"] += self.speed + 2
                if v["y"] > HEIGHT + 90:
                    self.traffic.remove(v)
                    self.score += 10
                    continue
                vx = LANES[v["lane"]]
                self.draw_vehicle(vx, v["y"], v["color"], v["kind"])
                if abs(vx - px) < 38 and abs(v["y"] - py) < 66:
                    self.alive = False

            self.draw_bike(px, py)

            self.speed = min(15.0, 5.0 + self.score / 250.0)
            self.score += 1
            self.score_var.set("Score: %d" % self.score)
            self.speed_var.set("Speed: %d km/h" % int(self.speed * 18))
        else:
            if self.score > self.best:
                self.best = self.score
            self.canvas.create_rectangle(60, HEIGHT // 2 - 80, WIDTH - 60,
                                         HEIGHT // 2 + 80, fill="#000000",
                                         outline=GOLD, width=2)
            self.canvas.create_text(WIDTH // 2, HEIGHT // 2 - 35, text="GAME OVER",
                                    fill="#FF3B3B", font=("Arial", 26, "bold"))
            self.canvas.create_text(WIDTH // 2, HEIGHT // 2,
                                    text="Score: %d   Best: %d" % (self.score, self.best),
                                    fill=TEXT, font=("Arial", 14))
            self.canvas.create_text(WIDTH // 2, HEIGHT // 2 + 40,
                                    text="Press SPACE to restart",
                                    fill=GOLD, font=("Arial", 11))

        self.root.after(40, self.game_loop)


def main():
    root = tk.Tk()
    BikeRacer(root)
    root.mainloop()


if __name__ == "__main__":
    main()
