Bike Racer 3D (concept) — Windows Version
==========================================

Ek top-down arcade bike racing game!

CHALANE KA TAREEQA:
1. Python 3 install karo (python.org se free download)
2. run.bat par double-click karo
   (ya: python main.py)

CONTROLS:
- LEFT/RIGHT arrow ya A/D: lane badlo
- SPACE: dobara start karo

GAME:
- Traffic (gaariyan aur trucks) se bacho!
- Har dodge par +10 score
- Jitna score barhe ga, speed barhti jayegi
- Takrao = GAME OVER

------------------------------------
App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
