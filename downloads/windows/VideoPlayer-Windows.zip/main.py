#!/usr/bin/env python3
"""
Video Player (Basic) - Windows Desktop App
Developed by Malik Muhammad Anwaar | WhatsApp: 923288317526

A clean media-library / playlist manager:
- Add video files to a playlist (mp4, mkv, avi, mov, wmv, webm, ...)
- Double-click a video (or press Play) to open it with your SYSTEM's
  default video player (e.g. VLC, Windows Media Player, Movies & TV).
  This app does NOT play video itself - it manages your playlist.
- Shows file info: name, size, type, last modified.
- Playlist is saved automatically between sessions.

Why the system player? Playing video inside Python needs heavy extras
(like VLC installed + python-vlc). Opening with the system player works
out of the box with zero installs - honest and simple.

Standard library only (tkinter).
"""

import json
import os
import platform
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from datetime import datetime

DEV_FOOTER = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PLAYLIST_FILE = os.path.join(APP_DIR, "playlist.json")

VIDEO_EXTS = (".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm",
              ".m4v", ".mpg", ".mpeg", ".3gp", ".ts")
FILETYPES = [("Video files", " ".join("*" + e for e in VIDEO_EXTS)),
             ("All files", "*.*")]

BG = "#1E2430"
BG_PANEL = "#2A3242"
WHITE = "#FFFFFF"
LIGHT = "#E8ECF3"
MUTED = "#9AA5B8"
ACCENT = "#3FB27F"      # emerald
ACCENT_DARK = "#2B7A58"
GOLD = "#C9A227"


def open_with_system_player(path: str):
    """Open a file with the OS default application. Returns (ok, message)."""
    system = platform.system()
    try:
        if system == "Windows":
            os.startfile(path)  # noqa: F821 - Windows only
        elif system == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        return True, "Opened with your system player."
    except Exception as e:  # noqa: BLE001 - report whatever the OS says
        return False, f"Could not open file:\n{e}"


def format_size(num_bytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if num_bytes < 1024 or unit == "GB":
            return f"{num_bytes:.1f} {unit}" if unit != "B" else f"{num_bytes} B"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} GB"


def file_info(path: str) -> str:
    if not os.path.exists(path):
        return "File not found (moved or deleted?)."
    size = os.path.getsize(path)
    mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M")
    ext = os.path.splitext(path)[1].lower() or "(no extension)"
    return (f"Name: {os.path.basename(path)}\n"
            f"Type: {ext}\n"
            f"Size: {format_size(size)}\n"
            f"Modified: {mtime}\n"
            f"Location:\n{path}")


def load_playlist() -> list:
    try:
        with open(PLAYLIST_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [p for p in data if isinstance(p, str)]
    except (OSError, ValueError):
        return []


def save_playlist(paths: list):
    try:
        with open(PLAYLIST_FILE, "w", encoding="utf-8") as f:
            json.dump(paths, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


class VideoPlayer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Video Player (Basic) - by Malik Muhammad Anwaar")
        self.geometry("920x620")
        self.configure(bg=BG)
        self.minsize(800, 540)

        self.paths = load_playlist()

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TLabel", background=BG, foreground=LIGHT, font=("Segoe UI", 10))
        style.configure("Panel.TFrame", background=BG_PANEL)
        style.configure("Green.TButton", background=ACCENT, foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Gold.TButton", background=GOLD, foreground="black",
                        font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Red.TButton", background="#B23B3B", foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=8)

        # ---- Header ----
        header = tk.Frame(self, bg=ACCENT_DARK, height=60)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  ▶  Video Player", bg=ACCENT_DARK, fg="white",
                 font=("Segoe UI", 17, "bold")).pack(side="left")
        tk.Label(header, text=" Basic Edition  ", bg=ACCENT_DARK, fg=GOLD,
                 font=("Segoe UI", 10, "italic")).pack(side="right", padx=10)

        # ---- Honest notice ----
        notice = tk.Frame(self, bg="#3A2F10", height=40)
        notice.pack(fill="x", padx=10, pady=(8, 0))
        notice.pack_propagate(False)
        tk.Label(notice,
                 text="ℹ  Plays with your SYSTEM player (VLC / Media Player / Movies & TV) — no extra installs needed.",
                 bg="#3A2F10", fg="#F0D98A", font=("Segoe UI", 10)).pack(pady=9)

        # ---- Toolbar ----
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=10, pady=8)
        ttk.Button(bar, text="＋ Add Videos", command=self.add_videos,
                   style="Green.TButton").pack(side="left", padx=3)
        ttk.Button(bar, text="▶ Play Selected", command=self.play_selected,
                   style="Gold.TButton").pack(side="left", padx=3)
        ttk.Button(bar, text="⏹ Remove Selected", command=self.remove_selected,
                   style="Red.TButton").pack(side="left", padx=3)
        ttk.Button(bar, text="Clear All", command=self.clear_all).pack(side="left", padx=3)

        # ---- Main split ----
        main = tk.PanedWindow(self, orient="horizontal", bg=BG, sashwidth=6)
        main.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        left = tk.Frame(main, bg=BG)
        tk.Label(left, text="Playlist — double-click to play", bg=BG, fg=LIGHT,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 4))
        self.listbox = tk.Listbox(left, font=("Segoe UI", 11), bg=BG_PANEL, fg=LIGHT,
                                  selectbackground=ACCENT, selectforeground="white",
                                  relief="flat", borderwidth=0, activestyle="none",
                                  highlightthickness=1, highlightbackground="#3A4356")
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<Double-Button-1>", lambda e: self.play_selected())
        self.listbox.bind("<<ListboxSelect>>", self.on_select)
        self.listbox.bind("<Delete>", lambda e: self.remove_selected())
        main.add(left, minsize=420)

        right = tk.Frame(main, bg=BG)
        tk.Label(right, text="File Info", bg=BG, fg=LIGHT,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 4))
        self.info = scrolledtext.ScrolledText(right, wrap="word", state="disabled",
                                              font=("Consolas", 10), bg=BG_PANEL,
                                              fg=LIGHT, relief="flat",
                                              highlightthickness=1,
                                              highlightbackground="#3A4356")
        self.info.pack(fill="both", expand=True)
        tk.Label(right, text="Tip: select a video, then press Play (or double-click).",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9),
                 wraplength=300, justify="left").pack(anchor="w", pady=(6, 0))
        main.add(right, minsize=280)

        # ---- Footer ----
        footer = tk.Frame(self, bg=ACCENT_DARK, height=28)
        footer.pack(fill="x")
        footer.pack_propagate(False)
        tk.Label(footer, text=DEV_FOOTER, bg=ACCENT_DARK, fg="white",
                 font=("Segoe UI", 9)).pack(side="left", padx=10)
        self.count_lbl = tk.Label(footer, text="", bg=ACCENT_DARK, fg=GOLD,
                                  font=("Segoe UI", 9, "bold"))
        self.count_lbl.pack(side="right", padx=10)

        self.refresh_list()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ----- playlist -----
    def refresh_list(self):
        self.listbox.delete(0, "end")
        for p in self.paths:
            marker = "" if os.path.exists(p) else "  [missing]"
            self.listbox.insert("end", f"  {os.path.basename(p)}{marker}")
        self.count_lbl.config(text=f"{len(self.paths)} video(s)")

    def add_videos(self):
        files = filedialog.askopenfilenames(title="Add videos to playlist",
                                            filetypes=FILETYPES)
        added = 0
        for f in files:
            if f not in self.paths:
                self.paths.append(f)
                added += 1
        if added:
            save_playlist(self.paths)
            self.refresh_list()
        if files and not added:
            messagebox.showinfo("Playlist", "Those videos are already in the playlist.")

    def selected_path(self):
        sel = self.listbox.curselection()
        return self.paths[sel[0]] if sel else None

    def play_selected(self):
        path = self.selected_path()
        if not path:
            messagebox.showinfo("Nothing selected", "Select a video from the playlist first.")
            return
        if not os.path.exists(path):
            messagebox.showwarning("Missing file",
                                   "This file was moved or deleted:\n" + path)
            return
        ok, msg = open_with_system_player(path)
        if not ok:
            messagebox.showerror("Cannot open", msg)

    def remove_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        del self.paths[sel[0]]
        save_playlist(self.paths)
        self.refresh_list()
        self.show_info("")

    def clear_all(self):
        if not self.paths:
            return
        if messagebox.askyesno("Confirm", "Remove ALL videos from the playlist?"):
            self.paths = []
            save_playlist(self.paths)
            self.refresh_list()
            self.show_info("")

    def on_select(self, event=None):
        path = self.selected_path()
        self.show_info(file_info(path) if path else "")

    def show_info(self, text):
        self.info.config(state="normal")
        self.info.delete("1.0", "end")
        self.info.insert("1.0", text)
        self.info.config(state="disabled")

    def on_close(self):
        save_playlist(self.paths)
        self.destroy()


def main():
    app = VideoPlayer()
    app.mainloop()


if __name__ == "__main__":
    main()
