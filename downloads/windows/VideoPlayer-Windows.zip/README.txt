Video Player (Basic) for Windows
===============================
App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526

IMPORTANT - PLEASE READ:
This is a playlist MANAGER, not a video decoder. It does not play video
inside the app (that would need heavy extras like VLC + python-vlc).
Instead, double-clicking a video opens it with your SYSTEM's default video
player (VLC, Windows Media Player, Movies & TV...). Zero installs needed.

HOW TO RUN (Windows):
1. Make sure Python 3 is installed (download from python.org if needed).
   During installation, tick "Add Python to PATH".
2. Double-click run.bat (or open a terminal in this folder and type: python main.py)

HOW TO USE:
- "Add Videos": pick video files (mp4, mkv, avi, mov, wmv...) - multi-select works.
- Playlist shows on the left; select a video to see its info (name, size,
  type, location) on the right.
- Double-click a video (or "Play Selected") to open it in your system player.
- "Remove Selected" (or Delete key) removes from playlist; "Clear All" empties it.
- Your playlist is saved automatically in playlist.json and restored next time.

No internet needed. No extra libraries to install.
