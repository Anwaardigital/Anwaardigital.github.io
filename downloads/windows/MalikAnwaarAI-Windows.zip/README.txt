==============================================
 MALIK ANWAAR AI v1.0 (Windows)
==============================================
Free AI chat — Urdu, English aur Roman Urdu mein
sawal poochein, jawab payen. Guftagu ki history
session ke dauran yaad rehti hai.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Double-click run.bat (or run: python main.py)

CONTROLS
--------
- Neeche box mein sawal likhen, Enter ya "Send" dabayen
- "New Chat" :  Nayi guftagu shuru karen (purani bhool jayegi)
- AI usi zuban mein jawab dega jis mein aap likhenge

IMPORTANT
---------
- INTERNET zaroori hai (free Pollinations AI API use hoti hai)
- Koi API key ya kharcha NAHI
- Guftagu sirf session ke dauran rehti hai (band karne par mit jati hai)

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
