"""
Malik Anwaar AI Windows v1.0
AI chat client calling the free Pollinations text API over HTTPS.
No extra packages needed — urllib only.
Runs on Windows with Python 3: python main.py
Needs an internet connection to talk to the AI.
"""
import json
import queue
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext
from urllib import request, error

API_URL = "https://text.pollinations.ai/"
MODEL = "openai"
TIMEOUT = 60

SYSTEM_PROMPT = (
    "You are 'Malik Anwaar AI', a friendly assistant. "
    "Answer in the SAME language the user writes in — Urdu (اردو script) for Urdu, "
    "English for English, Roman Urdu for Roman Urdu. "
    "Keep answers clear, helpful and concise."
)

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
GOLD = "#D4AF37"
CREAM = "#FAF8F0"
WHITE = "#FFFFFF"
TEXT_DARK = "#1E2B26"
MUTED = "#5A6B63"
AI_BG = "#F1F7F4"
USER_BG = "#FFF6DC"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"


def ask_ai(messages):
    """POST the conversation to the Pollinations text API. Returns reply text."""
    payload = json.dumps({"messages": messages, "model": MODEL, "private": True})
    req = request.Request(
        API_URL,
        data=payload.encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "User-Agent": "MalikAnwaarAI/1.0"},
        method="POST",
    )
    with request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode("utf-8", errors="replace").strip()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Malik Anwaar AI - Malik Muhammad Anwaar")
        self.geometry("760x640")
        self.configure(bg=CREAM)

        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.reply_queue = queue.Queue()
        self.waiting = False

        # ---- header ----
        header = tk.Frame(self, bg=DEEP_EMERALD, height=70)
        header.pack(fill="x")
        tk.Label(header, text="🤖 MALIK ANWAAR AI", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=18, pady=12)
        tk.Label(header, text="Urdu  •  English  •  Roman Urdu",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                     side="left", padx=6, pady=24)
        tk.Button(header, text="🗑 New Chat", font=("Segoe UI", 9, "bold"),
                  bg=GOLD, fg=DEEP_EMERALD, activebackground="#C19A2E",
                  relief="flat", padx=10, pady=6,
                  command=self.new_chat).pack(side="right", padx=18, pady=18)

        # ---- chat area ----
        chat_frame = tk.Frame(self, bg=WHITE)
        chat_frame.pack(fill="both", expand=True, padx=14, pady=(10, 4))
        chat_frame.configure(highlightbackground="#E3DCC8", highlightthickness=1)
        self.chat = scrolledtext.ScrolledText(
            chat_frame, wrap="word", font=("Segoe UI", 11),
            bg=WHITE, fg=TEXT_DARK, relief="flat", padx=10, pady=10,
            state="disabled", spacing1=6, spacing3=10)
        self.chat.pack(fill="both", expand=True)
        self.chat.tag_config("user", background=USER_BG, lmargin1=40,
                             lmargin2=40, rmargin=8, spacing1=4, spacing3=4)
        self.chat.tag_config("ai", background=AI_BG, lmargin1=8,
                             lmargin2=8, rmargin=40, spacing1=4, spacing3=4)
        self.chat.tag_config("sys", foreground=MUTED, justify="center",
                             font=("Segoe UI", 9, "italic"))

        self.add_message("sys", "👋 Assalam-o-Alaikum! Main Malik Anwaar AI hun.\n"
                                "Urdu, English ya Roman Urdu mein sawal poochein.")

        # ---- input bar ----
        bar = tk.Frame(self, bg=CREAM)
        bar.pack(fill="x", padx=14, pady=(4, 4))
        self.entry = tk.Entry(bar, font=("Segoe UI", 11), relief="solid", bd=1)
        self.entry.pack(side="left", fill="x", expand=True, ipady=8, padx=(0, 8))
        self.entry.bind("<Return>", lambda _e: self.send())
        self.send_btn = tk.Button(bar, text="➤ Send", font=("Segoe UI", 11, "bold"),
                                  bg=EMERALD, fg=WHITE,
                                  activebackground=DEEP_EMERALD, activeforeground=WHITE,
                                  relief="flat", padx=20, pady=6, command=self.send)
        self.send_btn.pack(side="right")

        self.status_lbl = tk.Label(self, text="Internet required — sawal bhejen",
                                   font=("Segoe UI", 9, "italic"), fg=MUTED, bg=CREAM,
                                   anchor="w")
        self.status_lbl.pack(fill="x", padx=16, pady=(0, 6))

        # ---- footer ----
        footer = tk.Frame(self, bg=DEEP_EMERALD, height=34)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 8),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

        self.after(100, self.check_replies)

    # ---------------- chat ----------------
    def add_message(self, tag, text):
        self.chat.config(state="normal")
        if tag == "user":
            self.chat.insert("end", "Aap:\n", "sys")
        elif tag == "ai":
            self.chat.insert("end", "Malik Anwaar AI:\n", "sys")
        self.chat.insert("end", text + "\n\n", tag)
        self.chat.config(state="disabled")
        self.chat.see("end")

    def new_chat(self):
        if self.waiting:
            messagebox.showinfo("Please wait", "AI jawab de raha hai — thora intezar karen.")
            return
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.chat.config(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.config(state="disabled")
        self.add_message("sys", "✨ Nayi guftagu shuru ho gayi.")
        self.status_lbl.config(text="New chat started")

    def send(self):
        if self.waiting:
            return
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self.add_message("user", text)
        self.messages.append({"role": "user", "content": text})
        self.waiting = True
        self.send_btn.config(state="disabled")
        self.status_lbl.config(text="⏳ AI soch raha hai…")
        threading.Thread(target=self.fetch_reply, daemon=True).start()

    def fetch_reply(self):
        try:
            reply = ask_ai(self.messages)
            self.reply_queue.put(("ok", reply))
        except error.HTTPError as e:
            self.reply_queue.put(("err", f"Server error (HTTP {e.code}) — dobara try karen."))
        except error.URLError:
            self.reply_queue.put(("err", "Internet se connect nahi ho saka. Connection check karen."))
        except Exception as e:
            self.reply_queue.put(("err", f"Error: {e}"))

    def check_replies(self):
        try:
            while True:
                kind, text = self.reply_queue.get_nowait()
                if kind == "ok":
                    self.messages.append({"role": "assistant", "content": text})
                    self.add_message("ai", text)
                    self.status_lbl.config(text="Internet required — sawal bhejen")
                else:
                    self.add_message("sys", "⚠ " + text)
                    self.status_lbl.config(text="Error — dobara koshish karen")
                self.waiting = False
                self.send_btn.config(state="normal")
        except queue.Empty:
            pass
        self.after(100, self.check_replies)


if __name__ == "__main__":
    App().mainloop()
