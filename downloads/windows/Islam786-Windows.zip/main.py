# -*- coding: utf-8 -*-
"""
Islam 786 — Windows Desktop App
Features: Prayer times (static Karachi table), Digital Tasbeeh counter,
Masnoon Duain (Arabic + Urdu), 99 Asma-ul-Husna, 6 Kalmas.
Theme: deep emerald + gold. Python 3 + Tkinter only (no extra deps).
"""

import tkinter as tk
from tkinter import ttk

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#0A3D2E"        # deep emerald
BG_DARK = "#062B20"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
ACCENT = "#0E5C44"


# ---------------------------------------------------------------- data ----
def get_prayer_times():
    """Static, approximate prayer times for Karachi. Returns list of (name, time)."""
    return [
        ("فجر", "5:00 AM"),
        ("طلوعِ آفتاب", "6:20 AM"),
        ("ظہر", "12:30 PM"),
        ("عصر", "4:15 PM"),
        ("مغرب", "6:05 PM"),
        ("عشاء", "7:30 PM"),
    ]


def get_kalimas():
    """List of (title, arabic, urdu_meaning)."""
    return [
        ("کلمہ طیب",
         "لَا إِلٰهَ إِلَّا اللّٰهُ مُحَمَّدٌ رَّسُوْلُ اللّٰهِ",
         "اللہ کے سوا کوئی معبود نہیں، محمد ﷺ اللہ کے رسول ہیں۔"),
        ("کلمہ شہادت",
         "اَشْهَدُ اَنْ لَّآ اِلٰهَ اِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ وَاَشْهَدُ اَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُوْلُهُ",
         "میں گواہی دیتا ہوں کہ اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے اس کا کوئی شریک نہیں، اور میں گواہی دیتا ہوں کہ محمد ﷺ اس کے بندے اور رسول ہیں۔"),
        ("کلمہ تمجید",
         "سُبْحَانَ اللّٰهِ وَالْحَمْدُ لِلّٰهِ وَلَآ اِلٰهَ اِلَّا اللّٰهُ وَاللّٰهُ اَكْبَرُ وَلَا حَوْلَ وَلَا قُوَّةَ اِلَّا بِاللّٰهِ الْعَلِيِّ الْعَظِيْمِ",
         "اللہ پاک ہے، تمام تعریفیں اللہ کے لیے ہیں، اللہ کے سوا کوئی معبود نہیں، اللہ سب سے بڑا ہے، اور گناہ سے بچنے کی طاقت اور نیکی کی قوت صرف اللہ کی مدد سے ہے۔"),
        ("کلمہ توحید",
         "لَا اِلٰهَ اِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ يُحْيِيْ وَيُمِيْتُ وَهُوَ حَيٌّ لَّا يَمُوْتُ اَبَدًا اَبَدًا ذُو الْجَلَالِ وَالْاِكْرَامِ بِيَدِهِ الْخَيْرُ وَهُوَ عَلٰي كُلِّ شَيْءٍ قَدِيْرٌ",
         "اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے اس کا کوئی شریک نہیں، اسی کی بادشاہت ہے اور اسی کے لیے تعریف ہے، وہ زندہ کرتا ہے اور مارتا ہے، وہ ہمیشہ زندہ رہنے والا ہے، ہر چیز پر قادر ہے۔"),
        ("کلمہ استغفار",
         "اَسْتَغْفِرُ اللّٰهَ رَبِّيْ مِنْ كُلِّ ذَنْبٍ اَذْنَبْتُهُ عَمَدًا اَوْ خَطَأً سِرًّا اَوْ عَلَانِيَةً وَاَتُوْبُ اِلَيْهِ مِنَ الذَّنْبِ الَّذِيْٓ اَعْلَمُ وَمِنَ الذَّنْبِ الَّذِيْ لَآ اَعْلَمُ اِنَّكَ اَنْتَ عَلَّامُ الْغُيُوْبِ وَسَتَّارُ الْعُيُوْبِ وَغَفَّارُ الذُّنُوْبِ وَلَا حَوْلَ وَلَا قُوَّةَ اِلَّا بِاللّٰهِ الْعَلِيِّ الْعَظِيْمِ",
         "میں اللہ سے اپنے ہر گناہ کی معافی مانگتا ہوں جو میں نے جان بوجھ کر یا بھول کر، چھپ کر یا کھلے عام کیا۔ اے اللہ تو پوشیدہ باتوں کا جاننے والا اور گناہوں کو معاف کرنے والا ہے۔"),
        ("کلمہ ردِّ کفر",
         "اَللّٰهُمَّ اِنِّيْٓ اَعُوْذُ بِكَ مِنْ اَنْ اُشْرِكَ بِكَ شَيْئًا وَّاَنَآ اَعْلَمُ بِهِ وَاَسْتَغْفِرُكَ لِمَا لَآ اَعْلَمُ بِهِ تُبْتُ عَنْهُ وَتَبَرَّأْتُ مِنَ الْكُفْرِ وَالشِّرْكِ وَالْكِذْبِ وَالْغِيْبَةِ وَالْبِدْعَةِ وَالنَّمِيْمَةِ وَالْفَوَاحِشِ وَالْبُهْتَانِ وَالْمَعَاصِيْ كُلِّهَا وَاَسْلَمْتُ وَاَقُوْلُ لَآ اِلٰهَ اِلَّا اللّٰهُ مُحَمَّدٌ رَّسُوْلُ اللّٰهِ",
         "اے اللہ! میں تیری پناہ مانگتا ہوں اس سے کہ میں جان بوجھ کر تیرے ساتھ کسی کو شریک ٹھہراؤں، اور جس کا مجھے علم نہیں اس سے معافی مانگتا ہوں۔ میں کفر، شرک، جھوٹ، غیبت اور تمام گناہوں سے بری ہوں، اور کہتا ہوں: اللہ کے سوا کوئی معبود نہیں، محمد ﷺ اللہ کے رسول ہیں۔"),
    ]


def get_duas():
    """List of (occasion, arabic, urdu)."""
    return [
        ("سونے کی دعا",
         "اَللّٰهُمَّ بِاسْمِكَ اَمُوْتُ وَاَحْيَا",
         "اے اللہ! تیرے نام سے میں مرتا ہوں اور تیرے ہی نام سے زندہ ہوتا ہوں۔"),
        ("جاگنے کی دعا",
         "اَلْحَمْدُ لِلّٰهِ الَّذِيْٓ اَحْيَانَا بَعْدَ مَآ اَمَاتَنَا وَاِلَيْهِ النُّشُوْرُ",
         "تمام تعریفیں اللہ کے لیے ہیں جس نے ہمیں موت کے بعد زندہ کیا اور اسی کی طرف لوٹ کر جانا ہے۔"),
        ("کھانے سے پہلے کی دعا",
         "بِسْمِ اللّٰهِ وَعَلٰى بَرَكَةِ اللّٰهِ",
         "اللہ کے نام سے اور اللہ کی برکت پر (کھانا شروع کرتا ہوں)۔"),
        ("کھانے کے بعد کی دعا",
         "اَلْحَمْدُ لِلّٰهِ الَّذِيْٓ اَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِيْنَ",
         "تمام تعریفیں اللہ کے لیے ہیں جس نے ہمیں کھلایا اور پلایا اور ہمیں مسلمان بنایا۔"),
        ("مسجد میں داخل ہونے کی دعا",
         "اَللّٰهُمَّ افْتَحْ لِيْٓ اَبْوَابَ رَحْمَتِكَ",
         "اے اللہ! میرے لیے اپنی رحمت کے دروازے کھول دے۔"),
        ("سفر کی دعا",
         "سُبْحَانَ الَّذِيْ سَخَّرَ لَنَا هٰذَا وَمَا كُنَّا لَهُ مُقْرِنِيْنَ وَاِنَّآ اِلٰى رَبِّنَا لَمُنْقَلِبُوْنَ",
         "پاک ہے وہ ذات جس نے اسے ہمارے تابع کر دیا، ورنہ ہم اس پر قابو نہ رکھتے، اور بے شک ہم اپنے رب کی طرف لوٹنے والے ہیں۔"),
        ("استغفار",
         "رَبِّ اغْفِرْ لِيْ وَتُبْ عَلَيَّ اِنَّكَ اَنْتَ التَّوَّابُ الرَّحِيْمُ",
         "اے میرے رب! مجھے بخش دے اور میری توبہ قبول فرما، بے شک تو بہت توبہ قبول کرنے والا، بہت رحم کرنے والا ہے۔"),
        ("مصیبت کے وقت",
         "اِنَّا لِلّٰهِ وَاِنَّآ اِلَيْهِ رَاجِعُوْنَ",
         "بے شک ہم اللہ کے ہیں اور بے شک ہم اسی کی طرف لوٹنے والے ہیں۔"),
    ]


def get_asma_ul_husna():
    """Returns list of (name_arabic, meaning_urdu) — 99 names."""
    return [
        ("اللہ", "اللہ"),
        ("الرحمن", "بڑا مہربان"),
        ("الرحیم", "بہت رحم کرنے والا"),
        ("الملک", "بادشاہ"),
        ("القدوس", "پاک ذات"),
        ("السلام", "سلامتی دینے والا"),
        ("المؤمن", "امن دینے والا"),
        ("المہیمن", "نگہبان"),
        ("العزیز", "غالب"),
        ("الجبار", "زبردست"),
        ("المتکبر", "بڑائی والا"),
        ("الخالق", "پیدا کرنے والا"),
        ("البارئ", "بنانے والا"),
        ("المصور", "صورت دینے والا"),
        ("الغفار", "بخشش کرنے والا"),
        ("القہار", "قہر کرنے والا"),
        ("الوہاب", "عطا کرنے والا"),
        ("الرزاق", "رزق دینے والا"),
        ("الفتاح", "کھولنے والا"),
        ("العلیم", "جاننے والا"),
        ("القابض", "تنگ کرنے والا"),
        ("الباسط", "کشادہ کرنے والا"),
        ("الخافض", "گرانے والا"),
        ("الرافع", "اٹھانے والا"),
        ("المعز", "عزت دینے والا"),
        ("المذل", "ذلیل کرنے والا"),
        ("السمیع", "سننے والا"),
        ("البصیر", "دیکھنے والا"),
        ("الحکم", "فیصلہ کرنے والا"),
        ("العدل", "انصاف کرنے والا"),
        ("اللطیف", "لطف کرنے والا"),
        ("الخبیر", "باخبر"),
        ("الحلیم", "بردبار"),
        ("العظیم", "عظیم"),
        ("الغفور", "معاف کرنے والا"),
        ("الشکور", "قدر دان"),
        ("العلی", "بلند"),
        ("الکبیر", "بڑا"),
        ("الحفیظ", "حفاظت کرنے والا"),
        ("المقیت", "روزی دینے والا"),
        ("الحسیب", "حساب لینے والا"),
        ("الجلیل", "جلالت والا"),
        ("الکریم", "کریم"),
        ("الرقیب", "نگران"),
        ("المجیب", "دعا قبول کرنے والا"),
        ("الواسع", "کشادہ"),
        ("الحکیم", "حکمت والا"),
        ("الودود", "محبت کرنے والا"),
        ("المجید", "بزرگی والا"),
        ("الباعث", "اٹھانے والا"),
        ("الشہید", "گواہ"),
        ("الحق", "حق"),
        ("الوکیل", "کارساز"),
        ("القوی", "طاقتور"),
        ("المتین", "مضبوط"),
        ("الولی", "دوست"),
        ("الحمید", "تعریف کے لائق"),
        ("المحصی", "شمار کرنے والا"),
        ("المبدئ", "آغاز کرنے والا"),
        ("المعید", "لوٹانے والا"),
        ("المحیی", "زندہ کرنے والا"),
        ("الممیت", "موت دینے والا"),
        ("الحی", "زندہ"),
        ("القیوم", "قائم رکھنے والا"),
        ("الواجد", "پانے والا"),
        ("الماجد", "بزرگی والا"),
        ("الواحد", "ایک"),
        ("الصمد", "بے نیاز"),
        ("القادر", "قدرت والا"),
        ("المقتدر", "اقتدار والا"),
        ("المقدم", "آگے کرنے والا"),
        ("المؤخر", "پیچھے کرنے والا"),
        ("الاول", "پہلا"),
        ("الاخر", "آخری"),
        ("الظاہر", "ظاہر"),
        ("الباطن", "پوشیدہ"),
        ("الوالی", "حاکم"),
        ("المتعالی", "بلند تر"),
        ("البر", "نیکی کرنے والا"),
        ("التواب", "توبہ قبول کرنے والا"),
        ("المنتقم", "انتقام لینے والا"),
        ("العفو", "درگزر کرنے والا"),
        ("الرؤوف", "مہربان"),
        ("مالک الملک", "بادشاہت کا مالک"),
        ("ذوالجلال والاکرام", "جلال و کرم والا"),
        ("المقسط", "انصاف کرنے والا"),
        ("الجامع", "جمع کرنے والا"),
        ("الغنی", "غنی"),
        ("المغنی", "غنی کرنے والا"),
        ("المانع", "روکنے والا"),
        ("الضار", "نقصان پہنچانے والا"),
        ("النافع", "نفع دینے والا"),
        ("النور", "نور"),
        ("الہادی", "ہدایت دینے والا"),
        ("البدیع", "ایجاد کرنے والا"),
        ("الباقی", "باقی رہنے والا"),
        ("الوارث", "وارث"),
        ("الرشید", "رہنمائی کرنے والا"),
        ("الصبور", "صبر کرنے والا"),
    ]


class TasbeehCounter:
    """Pure (GUI-independent) tasbeeh counter logic."""

    def __init__(self, target=100):
        self.count = 0
        self.target = int(target)

    def press(self):
        """One bead pressed. Returns True if the target was just reached."""
        self.count += 1
        return self.target > 0 and self.count == self.target

    def reset(self):
        self.count = 0

    def set_target(self, target):
        self.target = int(target)

    def progress(self):
        if self.target <= 0:
            return 0.0
        return min(1.0, self.count / self.target)


# ------------------------------------------------------------- GUI ----
class Islam786App:
    def __init__(self, root):
        self.root = root
        root.title("اسلام 786")
        root.geometry("900x640")
        root.minsize(760, 540)
        root.configure(bg=BG)

        style = ttk.Style(root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=ACCENT, foreground=WHITE,
                        padding=(18, 8), font=("Segoe UI", 11, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", GOLD)],
                  foreground=[("selected", "#062B20")])
        style.configure("TFrame", background=BG)
        style.configure("Gold.TButton", background=GOLD, foreground="#062B20",
                        font=("Segoe UI", 12, "bold"), padding=10)
        style.map("Gold.TButton", background=[("active", "#FFE55C")])
        style.configure("Green.TButton", background=ACCENT, foreground=WHITE,
                        font=("Segoe UI", 11, "bold"), padding=8)
        style.map("Green.TButton", background=[("active", "#12805B")])
        style.configure("Horizontal.TProgressbar", background=GOLD,
                        troughcolor=BG_DARK)

        header = tk.Frame(root, bg=BG_DARK)
        header.pack(fill="x")
        tk.Label(header, text="☪  اسلام 786  ☪", font=("Segoe UI", 22, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(pady=(10, 0))
        tk.Label(header, text="Islamic Guide for Windows", font=("Segoe UI", 10),
                 fg=CREAM, bg=BG_DARK).pack(pady=(0, 10))

        nb = ttk.Notebook(root)
        nb.pack(fill="both", expand=True, padx=10, pady=10)

        self._build_prayer_tab(nb)
        self._build_tasbeeh_tab(nb)
        self._build_dua_tab(nb)
        self._build_asma_tab(nb)
        self._build_kalima_tab(nb)

        footer = tk.Frame(root, bg=BG_DARK)
        footer.pack(fill="x")
        tk.Label(footer, text=DEVELOPER_LINE, font=("Segoe UI", 9),
                 fg=CREAM, bg=BG_DARK).pack(pady=(6, 0))
        tk.Label(footer, text=WHATSAPP_LINE, font=("Segoe UI", 9, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(pady=(0, 6))

    # ---------------- helpers ----------------
    def _scrollable(self, parent):
        canvas = tk.Canvas(parent, bg=BG, highlightthickness=0)
        vsb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=BG)
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        def _on_cfg(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win, width=canvas.winfo_width())
        inner.bind("<Configure>", _on_cfg)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=canvas.winfo_width()))
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
        return inner

    def _gold_heading(self, parent, text, size=16):
        tk.Label(parent, text=text, font=("Segoe UI", size, "bold"),
                 fg=GOLD, bg=BG).pack(pady=12, anchor="center")

    def _card(self, parent):
        f = tk.Frame(parent, bg=ACCENT, bd=2, relief="ridge")
        f.pack(fill="x", padx=24, pady=8)
        return f

    # ---------------- tabs ----------------
    def _build_prayer_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="نماز کے اوقات")
        inner = self._scrollable(tab)
        self._gold_heading(inner, "🕌  نماز کے اوقات  —  کراچی (تقریبی)")
        tk.Label(inner, text="Prayer Times — Karachi (approximate)",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG).pack(pady=(0, 10))

        box = tk.Frame(inner, bg=BG_DARK, bd=2, relief="ridge")
        box.pack(padx=60, pady=10, fill="x")
        for i, (name, t) in enumerate(get_prayer_times()):
            row = tk.Frame(box, bg=BG_DARK)
            row.pack(fill="x", padx=20, pady=8)
            tk.Label(row, text=t, font=("Segoe UI", 14), fg=WHITE, bg=BG_DARK).pack(side="left")
            tk.Label(row, text=name, font=("Segoe UI", 15, "bold"), fg=GOLD, bg=BG_DARK).pack(side="right")
            if i < len(get_prayer_times()) - 1:
                ttk.Separator(box, orient="horizontal").pack(fill="x", padx=20)

        tk.Label(inner,
                 text="نوٹ: یہ اوقات تقریبی ہیں۔ درست اوقات کے لیے اپنی مقامی مسجد سے رابطہ کریں۔",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG, wraplength=640,
                 justify="center").pack(pady=16)

    def _build_tasbeeh_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="ڈیجیٹل تسبیح")
        inner = self._scrollable(tab)
        self._gold_heading(inner, "📿  ڈیجیٹل تسبیح  —  Digital Tasbeeh")

        self.counter = TasbeehCounter(100)
        self.count_var = tk.StringVar(value="0")

        disp = tk.Frame(inner, bg=BG_DARK, bd=3, relief="ridge")
        disp.pack(pady=16, padx=120, fill="x")
        tk.Label(disp, textvariable=self.count_var, font=("Segoe UI", 64, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(pady=10)

        self.prog = ttk.Progressbar(inner, mode="determinate", maximum=100,
                                    style="Horizontal.TProgressbar", length=420)
        self.prog.pack(pady=6)
        self.prog_label = tk.Label(inner, text="ہدف: 100", font=("Segoe UI", 11),
                                   fg=CREAM, bg=BG)
        self.prog_label.pack()

        btn_row = tk.Frame(inner, bg=BG)
        btn_row.pack(pady=12)
        ttk.Button(btn_row, text="تسبیح دبائیں  +1", style="Gold.TButton",
                   command=self._on_press).pack(side="left", padx=8)
        ttk.Button(btn_row, text="ری سیٹ", style="Green.TButton",
                   command=self._on_reset).pack(side="left", padx=8)

        tk.Label(inner, text="ہدف منتخب کریں:", font=("Segoe UI", 11, "bold"),
                 fg=GOLD, bg=BG).pack(pady=(8, 4))
        tgt_row = tk.Frame(inner, bg=BG)
        tgt_row.pack()
        for t in (33, 100, 500, 1000):
            ttk.Button(tgt_row, text=str(t), style="Green.TButton",
                       command=lambda x=t: self._set_target(x)).pack(side="left", padx=6)

        tk.Label(inner, text="ٹپ: ہر تسبیح پر بڑا بٹن دبائیں۔ ہدف مکمل ہونے پر بیپ بجے گی۔",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG, wraplength=640,
                 justify="center").pack(pady=14)

    def _on_press(self):
        reached = self.counter.press()
        self.count_var.set(str(self.counter.count))
        self.prog["value"] = self.counter.progress() * 100
        self.prog_label.config(text=f"ہدف: {self.counter.target}  |  شمار: {self.counter.count}")
        if reached:
            self.root.bell()
            self.count_var.set(f"{self.counter.count}  ✓")

    def _on_reset(self):
        self.counter.reset()
        self.count_var.set("0")
        self.prog["value"] = 0
        self.prog_label.config(text=f"ہدف: {self.counter.target}  |  شمار: 0")

    def _set_target(self, t):
        self.counter.set_target(t)
        self.counter.reset()
        self.count_var.set("0")
        self.prog["value"] = 0
        self.prog_label.config(text=f"ہدف: {t}  |  شمار: 0")

    def _build_dua_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="مسنون دعائیں")
        inner = self._scrollable(tab)
        self._gold_heading(inner, "🤲  مسنون دعائیں  —  Masnoon Duas")
        for title, ar, ur in get_duas():
            card = self._card(inner)
            tk.Label(card, text=title, font=("Segoe UI", 13, "bold"),
                     fg=GOLD, bg=ACCENT).pack(pady=(10, 4))
            tk.Label(card, text=ar, font=("Segoe UI", 14), fg=WHITE, bg=ACCENT,
                     wraplength=620, justify="right").pack(padx=16, pady=4)
            tk.Label(card, text=ur, font=("Segoe UI", 11), fg=CREAM, bg=ACCENT,
                     wraplength=620, justify="center").pack(padx=16, pady=(4, 12))

    def _build_asma_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="اسمائے حسنیٰ")
        inner = self._scrollable(tab)
        self._gold_heading(inner, "✨  اسمائے حسنیٰ (99 نام)  —  Asma-ul-Husna")

        names = get_asma_ul_husna()
        grid = tk.Frame(inner, bg=BG)
        grid.pack(padx=16, pady=8, fill="x")
        cols = 3
        for i, (name, meaning) in enumerate(names):
            cell = tk.Frame(grid, bg=BG_DARK, bd=1, relief="solid", padx=6, pady=8)
            cell.grid(row=i // cols, column=i % cols, padx=6, pady=6, sticky="nsew")
            tk.Label(cell, text=str(i + 1), font=("Segoe UI", 9),
                     fg=GOLD, bg=BG_DARK).pack()
            tk.Label(cell, text=name, font=("Segoe UI", 14, "bold"),
                     fg=WHITE, bg=BG_DARK).pack()
            tk.Label(cell, text=meaning, font=("Segoe UI", 10),
                     fg=CREAM, bg=BG_DARK).pack()
        for c in range(cols):
            grid.grid_columnconfigure(c, weight=1)

    def _build_kalima_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="چھے کلمے")
        inner = self._scrollable(tab)
        self._gold_heading(inner, "📜  چھے کلمے  —  Six Kalmas")
        for title, ar, ur in get_kalimas():
            card = self._card(inner)
            tk.Label(card, text=title, font=("Segoe UI", 14, "bold"),
                     fg=GOLD, bg=ACCENT).pack(pady=(12, 4))
            tk.Label(card, text=ar, font=("Segoe UI", 15), fg=WHITE, bg=ACCENT,
                     wraplength=620, justify="right").pack(padx=16, pady=6)
            ttk.Separator(card, orient="horizontal").pack(fill="x", padx=40, pady=6)
            tk.Label(card, text="ترجمہ:", font=("Segoe UI", 11, "bold"),
                     fg=GOLD, bg=ACCENT).pack()
            tk.Label(card, text=ur, font=("Segoe UI", 11), fg=CREAM, bg=ACCENT,
                     wraplength=620, justify="center").pack(padx=16, pady=(2, 14))


def main():
    root = tk.Tk()
    Islam786App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
