@echo off
title Islam 786
python main.py
pause
