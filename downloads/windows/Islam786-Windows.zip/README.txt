Islam 786 - Windows App
=========================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features:
- Namaz ke auqaat (Karachi - taqreebi)
- Digital Tasbeeh counter (33/100/500/1000 ka hadaf)
- Masnoon Duain (Arabic + Urdu tarjuma)
- Asma-ul-Husna (99 naam)
- Chhay Kalme (Arabic + Urdu tarjuma)

Note: Namaz ke auqaat taqreebi hain - durust auqaat ke liye
apni maqami masjid se rabta karein.

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
