Urdu Notes for Windows (اردو نوٹس)
================================
App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526

HOW TO RUN (Windows):
1. Make sure Python 3 is installed (download from python.org if needed).
   During installation, tick "Add Python to PATH".
2. Double-click run.bat (or open a terminal in this folder and type: python main.py)

HOW TO USE:
- "نیا نوٹ / New": start a new note.
- Write the title, then write your note in Urdu or English in the big text box.
  The text box is right-aligned so Urdu reads naturally (RTL style).
- "محفوظ کریں / Save": saves the note as a .txt file in the "notes" folder
  next to main.py. Each note is its own file, so you can copy/backup them easily.
- Click a note in the list on the left to open it for reading/editing.
- "حذف کریں / Delete": deletes the selected note (asks for confirmation).
- "تلاش / Search": type to filter notes by title or content.

Your notes live in the "notes" subfolder - they are plain .txt files in UTF-8,
so any text editor can open them.

No internet needed. No extra libraries to install.
