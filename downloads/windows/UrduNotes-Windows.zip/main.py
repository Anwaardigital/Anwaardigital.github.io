#!/usr/bin/env python3
"""
Urdu Notes - Windows Desktop App
Developed by Malik Muhammad Anwaar | WhatsApp: 923288317526

Simple Urdu/English notes app:
- Notes list, new/edit/delete note
- Urdu text (right-aligned RTL-style text widget)
- Saves each note as a .txt file in the "notes" folder
- Search notes by title or content
Standard library only (tkinter).
"""

import os
import re
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

DEV_FOOTER = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

NOTES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "notes")

BG = "#F5F1E8"
WHITE = "#FFFFFF"
INK = "#2B2B2B"
GREEN = "#0E7C5B"
GREEN_DARK = "#0A5C44"
GOLD = "#C9A227"
GOLD_LIGHT = "#F7EDD4"


def ensure_notes_dir():
    os.makedirs(NOTES_DIR, exist_ok=True)


def note_path(title: str) -> str:
    safe = re.sub(r"[^\w\- .]", "_", (title or "note").strip())
    safe = re.sub(r"\s+", "_", safe)[:60] or "note"
    return os.path.join(NOTES_DIR, safe + ".txt")


def list_notes() -> list:
    ensure_notes_dir()
    notes = []
    for fname in sorted(os.listdir(NOTES_DIR)):
        if fname.lower().endswith(".txt"):
            path = os.path.join(NOTES_DIR, fname)
            try:
                with open(path, encoding="utf-8") as f:
                    content = f.read()
            except OSError:
                content = ""
            title = fname[:-4]
            first_line = content.strip().splitlines()[0] if content.strip() else ""
            notes.append({"title": title, "path": path, "content": content,
                          "snippet": first_line[:60]})
    return notes


def search_notes(query: str) -> list:
    query = query.strip().lower()
    if not query:
        return list_notes()
    return [n for n in list_notes()
            if query in n["title"].lower() or query in n["content"].lower()]


def save_note(title: str, content: str) -> str:
    """Save (create or overwrite) a note. Returns the file path."""
    ensure_notes_dir()
    path = note_path(title)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def delete_note_file(title: str) -> bool:
    path = note_path(title)
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def unique_title(base: str, existing: set) -> str:
    if base not in existing:
        return base
    i = 2
    while f"{base}_{i}" in existing:
        i += 1
    return f"{base}_{i}"


class UrduNotes(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Urdu Notes - by Malik Muhammad Anwaar")
        self.geometry("980x640")
        self.configure(bg=BG)
        self.minsize(860, 540)
        ensure_notes_dir()
        self.current_title = None

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TLabel", background=BG, font=("Segoe UI", 10))
        style.configure("Green.TButton", background=GREEN, foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=7)
        style.configure("Gold.TButton", background=GOLD, foreground="black",
                        font=("Segoe UI", 10, "bold"), padding=7)
        style.configure("Red.TButton", background="#B23B3B", foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=7)

        # ---- Header ----
        header = tk.Frame(self, bg=GREEN_DARK, height=60)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  اردو نوٹس  -  Urdu Notes", bg=GREEN_DARK, fg="white",
                 font=("Segoe UI", 17, "bold")).pack(side="left")
        tk.Label(header, text="آپ کے اردو اور انگریزی نوٹس  ", bg=GREEN_DARK, fg=GOLD_LIGHT,
                 font=("Segoe UI", 10)).pack(side="right", padx=10)

        # ---- Toolbar ----
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=10, pady=(8, 4))
        ttk.Button(bar, text="نیا نوٹ / New", command=self.new_note,
                   style="Green.TButton").pack(side="left", padx=3)
        ttk.Button(bar, text="محفوظ کریں / Save", command=self.save_current,
                   style="Gold.TButton").pack(side="left", padx=3)
        ttk.Button(bar, text="حذف کریں / Delete", command=self.delete_current,
                   style="Red.TButton").pack(side="left", padx=3)
        tk.Label(bar, text="تلاش / Search:", bg=BG, fg=INK,
                 font=("Segoe UI", 10)).pack(side="left", padx=(18, 4))
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(bar, textvariable=self.search_var, width=28)
        search_entry.pack(side="left", padx=4, ipady=3)
        search_entry.bind("<KeyRelease>", lambda e: self.refresh_list())
        ttk.Button(bar, text="صاف کریں / Clear", command=self.clear_search
                   ).pack(side="left", padx=3)

        # ---- Main split ----
        main = tk.PanedWindow(self, orient="horizontal", bg=BG, sashwidth=6)
        main.pack(fill="both", expand=True, padx=10, pady=6)

        left = tk.Frame(main, bg=BG)
        tk.Label(left, text="نوٹس کی فہرست / Notes List", bg=BG, fg=GREEN_DARK,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 4))
        self.listbox = tk.Listbox(left, font=("Segoe UI", 11), bg=WHITE, fg=INK,
                                  selectbackground=GREEN, selectforeground="white",
                                  relief="solid", borderwidth=1, activestyle="none")
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<<ListboxSelect>>", self.on_select)
        main.add(left, minsize=240)

        right = tk.Frame(main, bg=BG)
        title_row = tk.Frame(right, bg=BG)
        title_row.pack(fill="x", pady=(0, 6))
        tk.Label(title_row, text="عنوان / Title:", bg=BG, fg=INK,
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        self.title_var = tk.StringVar()
        self.title_entry = ttk.Entry(title_row, textvariable=self.title_var,
                                     font=("Segoe UI", 11), justify="right")
        self.title_entry.pack(side="left", fill="x", expand=True, padx=(6, 0), ipady=4)

        tk.Label(right, text="متن / Note text  (Urdu & English supported)",
                 bg=BG, fg=GREEN_DARK, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        # RTL: right-justified text widget so Urdu reads naturally.
        # (Tkinter does not do full bidirectional layout, but right alignment
        #  gives a proper RTL-style Urdu writing experience.)
        self.text = scrolledtext.ScrolledText(right, wrap="word", undo=True,
                                              font=("Segoe UI", 12), bg=WHITE,
                                              relief="solid", borderwidth=1)
        self.text.pack(fill="both", expand=True)
        self.text.tag_configure("rtl", justify="right")
        main.add(right, minsize=400)

        # ---- Footer ----
        footer = tk.Frame(self, bg=GREEN_DARK, height=28)
        footer.pack(fill="x")
        footer.pack_propagate(False)
        tk.Label(footer, text=DEV_FOOTER, bg=GREEN_DARK, fg=GOLD_LIGHT,
                 font=("Segoe UI", 9)).pack()
        self.status = tk.Label(footer, text="", bg=GREEN_DARK, fg="white",
                               font=("Segoe UI", 9))
        self.status.pack(side="right", padx=10)

        self.refresh_list()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ----- logic -----
    def refresh_list(self):
        query = self.search_var.get()
        self.notes = search_notes(query)
        self.listbox.delete(0, "end")
        for n in self.notes:
            self.listbox.insert("end", f"  {n['title']}")

    def on_select(self, event=None):
        sel = self.listbox.curselection()
        if not sel:
            return
        note = self.notes[sel[0]]
        if self.current_title is not None and self.current_title != note["title"]:
            # keep it simple: auto-save silently is risky; just switch
            pass
        self.current_title = note["title"]
        self.title_var.set(note["title"])
        self.text.delete("1.0", "end")
        self.text.insert("1.0", note["content"])
        self.apply_rtl_tag()

    def apply_rtl_tag(self):
        self.text.tag_add("rtl", "1.0", "end")

    def new_note(self):
        existing = {n["title"] for n in list_notes()}
        title = unique_title("نیا_نوٹ", existing)
        self.current_title = None
        self.title_var.set(title)
        self.text.delete("1.0", "end")
        self.apply_rtl_tag()
        self.set_status("نیا نوٹ تیار ہے — لکھیں اور Save دبائیں")

    def save_current(self):
        title = self.title_var.get().strip()
        if not title:
            messagebox.showwarning("خالی عنوان / Empty title",
                                   "براہ کرم نوٹ کا عنوان لکھیں۔\nPlease enter a note title.")
            return
        content = self.text.get("1.0", "end").rstrip() + "\n"
        try:
            path = save_note(title, content)
            self.current_title = title
            self.refresh_list()
            self.set_status(f"محفوظ ہو گیا / Saved: {os.path.basename(path)}")
        except OSError as e:
            messagebox.showerror("خرابی / Error", f"نوٹ محفوظ نہیں ہوا:\n{e}")

    def delete_current(self):
        title = self.title_var.get().strip()
        if not title:
            return
        if not messagebox.askyesno("تصدیق / Confirm",
                                    f"کیا آپ واقعی یہ نوٹ حذف کرنا چاہتے ہیں؟\nDelete note '{title}'?"):
            return
        if delete_note_file(title):
            self.current_title = None
            self.title_var.set("")
            self.text.delete("1.0", "end")
            self.refresh_list()
            self.set_status("نوٹ حذف کر دیا گیا / Note deleted")
        else:
            messagebox.showinfo("نہیں ملا / Not found", "یہ نوٹ فائل نہیں ملی۔")

    def clear_search(self):
        self.search_var.set("")
        self.refresh_list()

    def set_status(self, msg):
        self.status.config(text=msg)

    def on_close(self):
        self.destroy()


def main():
    app = UrduNotes()
    app.mainloop()


if __name__ == "__main__":
    main()
