Thumbnail Maker (Windows)
=========================

WHAT IT IS
Make 1280x720 YouTube thumbnails: pick a background (solid color or any
image), add big title + subtitle text with your own font size and color,
drop in simple shapes (rectangle, ellipse, line), drag elements around on
the live preview, then export a 1280x720 PNG.

FEATURES
- Background: solid color picker OR open any image (auto cover-cropped)
- Title text: custom text, size 20-220, any color (white/yellow classic)
- Subtitle text: custom text, size 16-120, any color
- Shapes: rectangle, ellipse, line with your color
- Click any element on the preview to select it, drag to move it
- Fine-tune X/Y position in the side panel; delete elements
- One-click export to 1280x720 PNG (YouTube thumbnail size)

REQUIREMENTS
- Windows 7 / 10 / 11
- Python 3.8 or newer
  Download from https://www.python.org/downloads/
  IMPORTANT: during install, tick "Add python.exe to PATH".
- Pillow (imaging library), install once with:
    pip install pillow

HOW TO RUN
1. Install Pillow once:  pip install pillow
2. Double-click run.bat
   (or open a terminal in this folder and run:  python main.py)
3. Pick a background color or open a background image.
4. Type your title, choose size + color, click "Add title".
   Do the same for the subtitle. Add shapes if you like.
5. Drag elements on the preview to arrange them.
6. Click "EXPORT 1280x720 PNG" and choose where to save.

TIPS
- Big bold titles (size 90-140) with a dark outline read best on YouTube.
- Text automatically gets a black outline so it pops on any background.
- The preview is half-size; the export is always full 1280x720.
