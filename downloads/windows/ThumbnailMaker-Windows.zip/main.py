#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Thumbnail Maker (Windows)
=========================
Build 1280x720 YouTube thumbnails:

* Pick a background: solid color or any image (auto cover-cropped).
* Add big title text + subtitle (custom font size and color).
* Add simple shapes (rectangle, ellipse, line).
* Click an element on the preview to select it, drag to move it,
  fine-tune X/Y in the side panel, delete it.
* Export as 1280x720 PNG.

Rendering: Pillow. UI: Tkinter.
"""

import os
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox

from PIL import Image, ImageDraw, ImageFont, ImageTk

APP_TITLE = "Thumbnail Maker"
BRANDING = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"
CANVAS_W, CANVAS_H = 1280, 720
PREVIEW_W, PREVIEW_H = 640, 360
FONT = "Segoe UI"


# ------------------------------------------------------------- core rendering
def get_font(size):
    """Best-effort bold-ish TrueType font; falls back to Pillow default."""
    size = max(8, int(size))
    candidates = [
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
        r"C:\Windows\Fonts\segoeui.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:  # noqa: BLE001 - try next candidate
                continue
    return ImageFont.load_default(size=size)


def cover_resize(img, size):
    """Resize + center-crop an image so it exactly covers `size`."""
    tw, th = size
    w, h = img.size
    scale = max(tw / w, th / h)
    img = img.resize((int(w * scale + 0.5), int(h * scale + 0.5)),
                     Image.LANCZOS)
    left = (img.size[0] - tw) // 2
    top = (img.size[1] - th) // 2
    return img.crop((left, top, left + tw, top + th))


def render_thumbnail(background, elements, size=(CANVAS_W, CANVAS_H)):
    """Pure rendering function (no GUI). Returns a PIL Image.

    background: {"kind": "color", "color": "#rrggbb"}
                or {"kind": "image", "path": <file>, "color": <fallback>}
    elements: list of dicts:
      text:  {"kind":"text","text","x","y","size","color",
              "stroke","stroke_color"}            (x,y = center)
      shape: {"kind":"shape","shape":"rectangle"|"ellipse"|"line",
              "x","y","w","h","fill","outline","width"}  (x,y = center)
    """
    w, h = size
    color = background.get("color", "#20203a")
    if background.get("kind") == "image" and background.get("path"):
        try:
            base = cover_resize(
                Image.open(background["path"]).convert("RGB"), size)
        except Exception:  # noqa: BLE001 - unreadable image -> fallback
            base = Image.new("RGB", size, color)
    else:
        base = Image.new("RGB", size, color)

    draw = ImageDraw.Draw(base)
    sx, sy = w / CANVAS_W, h / CANVAS_H

    for el in elements:
        x, y = el["x"] * sx, el["y"] * sy
        if el["kind"] == "text":
            font = get_font(int(el["size"] * sy))
            draw.text((x, y), el["text"], font=font, fill=el["color"],
                      anchor="mm", stroke_width=int(el.get("stroke", 2)),
                      stroke_fill=el.get("stroke_color", "black"))
        elif el["kind"] == "shape":
            sw, sh = el["w"] * sx, el["h"] * sy
            box = [x - sw / 2, y - sh / 2, x + sw / 2, y + sh / 2]
            st = el["shape"]
            fill = el.get("fill")
            outline = el.get("outline", "white")
            width = int(el.get("width", 4))
            if st == "rectangle":
                draw.rectangle(box, fill=fill, outline=outline, width=width)
            elif st == "ellipse":
                draw.ellipse(box, fill=fill, outline=outline, width=width)
            elif st == "line":
                draw.line([box[0], box[1], box[2], box[3]],
                          fill=fill or "white", width=int(el.get("width", 8)))
    return base


def element_bbox(el):
    """Bounding box of an element in 1280x720 space (for hit-testing)."""
    if el["kind"] == "text":
        font = get_font(int(el["size"]))
        probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))
        return probe.textbbox((el["x"], el["y"]), el["text"], font=font,
                              anchor="mm")
    sw, sh = el["w"], el["h"]
    return (el["x"] - sw / 2, el["y"] - sh / 2,
            el["x"] + sw / 2, el["y"] + sh / 2)


def element_label(el, i):
    if el["kind"] == "text":
        txt = el["text"].strip() or "(empty text)"
        return "%d. Text: %s" % (i + 1, txt[:28])
    return "%d. Shape: %s" % (i + 1, el["shape"].capitalize())


# ------------------------------------------------------------------------ GUI
def brand_footer(parent):
    tk.Label(parent, text=BRANDING, font=(FONT, 8), fg="#777777").pack(
        side="bottom", fill="x", pady=(8, 4))


class ThumbnailApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry("1040x640")
        root.resizable(False, False)

        self.background = {"kind": "color", "color": "#20203a"}
        self.elements = []
        self.selected = None
        self.photo = None
        self.dragging = False
        self.drag_off = (0, 0)

        main = tk.Frame(root)
        main.pack(fill="both", expand=True, padx=10, pady=10)

        # ---- left: preview ----
        left = tk.Frame(main)
        left.pack(side="left", padx=(0, 10))
        tk.Label(left, text="Preview (1280 x 720)",
                 font=(FONT, 10, "bold")).pack(anchor="w", pady=(0, 4))
        self.canvas = tk.Canvas(left, width=PREVIEW_W, height=PREVIEW_H,
                                bg="#111111", highlightthickness=1,
                                highlightbackground="#888888", cursor="hand2")
        self.canvas.pack()
        self.canvas_img = self.canvas.create_image(0, 0, anchor="nw")
        tk.Label(left, text="Tip: click an element to select it, drag to move.",
                 font=(FONT, 8), fg="#777777").pack(anchor="w", pady=(4, 0))
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)

        # ---- right: controls ----
        right = tk.Frame(main, width=330)
        right.pack(side="left", fill="y")
        right.pack_propagate(False)

        self._section(right, "Background")
        row = tk.Frame(right); row.pack(fill="x", pady=2)
        self.bg_color_btn = tk.Button(row, text="Pick color", width=11,
                                      command=self.pick_bg_color)
        self.bg_color_btn.pack(side="left", padx=(0, 6))
        tk.Button(row, text="Open image...", width=11,
                  command=self.open_bg_image).pack(side="left", padx=6)
        tk.Button(row, text="Solid color", width=11,
                  command=self.use_solid_color).pack(side="left", padx=6)
        self.bg_info = tk.Label(right, text="Solid: #20203a", font=(FONT, 8),
                                fg="#777777", anchor="w")
        self.bg_info.pack(fill="x", pady=(2, 6))

        self._section(right, "Title text")
        self.title_entry = tk.Entry(right, font=(FONT, 10))
        self.title_entry.pack(fill="x", pady=2)
        self.title_entry.insert(0, "YOUR TITLE HERE")
        row = tk.Frame(right); row.pack(fill="x", pady=2)
        tk.Label(row, text="Size:", font=(FONT, 9)).pack(side="left")
        self.title_size = tk.Spinbox(row, from_=20, to=220, width=6,
                                     font=(FONT, 9))
        self.title_size.pack(side="left", padx=4)
        self.title_size.delete(0, tk.END); self.title_size.insert(0, "96")
        self.title_color = tk.StringVar(value="#FFD500")
        tk.Button(row, text="Color", width=8,
                  command=lambda: self.pick_color(self.title_color)).pack(
                      side="left", padx=4)
        tk.Button(row, text="Add title", width=10,
                  command=self.add_title).pack(side="left", padx=4)

        self._section(right, "Subtitle text")
        self.sub_entry = tk.Entry(right, font=(FONT, 10))
        self.sub_entry.pack(fill="x", pady=2)
        self.sub_entry.insert(0, "subtitle goes here")
        row = tk.Frame(right); row.pack(fill="x", pady=2)
        tk.Label(row, text="Size:", font=(FONT, 9)).pack(side="left")
        self.sub_size = tk.Spinbox(row, from_=16, to=120, width=6,
                                   font=(FONT, 9))
        self.sub_size.pack(side="left", padx=4)
        self.sub_size.delete(0, tk.END); self.sub_size.insert(0, "44")
        self.sub_color = tk.StringVar(value="#FFFFFF")
        tk.Button(row, text="Color", width=8,
                  command=lambda: self.pick_color(self.sub_color)).pack(
                      side="left", padx=4)
        tk.Button(row, text="Add subtitle", width=10,
                  command=self.add_subtitle).pack(side="left", padx=4)

        self._section(right, "Shape")
        row = tk.Frame(right); row.pack(fill="x", pady=2)
        self.shape_var = tk.StringVar(value="Rectangle")
        tk.OptionMenu(row, self.shape_var, "Rectangle", "Ellipse",
                      "Line").pack(side="left")
        self.shape_color = tk.StringVar(value="#FF3B30")
        tk.Button(row, text="Color", width=8,
                  command=lambda: self.pick_color(self.shape_color)).pack(
                      side="left", padx=6)
        tk.Button(row, text="Add shape", width=10,
                  command=self.add_shape).pack(side="left", padx=4)

        self._section(right, "Elements")
        self.el_list = tk.Listbox(right, font=(FONT, 9), height=5)
        self.el_list.pack(fill="x", pady=2)
        self.el_list.bind("<<ListboxSelect>>", self.on_list_select)
        tk.Button(right, text="Delete selected element",
                  command=self.delete_selected).pack(fill="x", pady=2)

        self._section(right, "Selected element position")
        row = tk.Frame(right); row.pack(fill="x", pady=2)
        tk.Label(row, text="X:", font=(FONT, 9)).pack(side="left")
        self.pos_x = tk.Spinbox(row, from_=0, to=CANVAS_W, width=7,
                                font=(FONT, 9), command=self.apply_position)
        self.pos_x.pack(side="left", padx=4)
        tk.Label(row, text="Y:", font=(FONT, 9)).pack(side="left")
        self.pos_y = tk.Spinbox(row, from_=0, to=CANVAS_H, width=7,
                                font=(FONT, 9), command=self.apply_position)
        self.pos_y.pack(side="left", padx=4)
        tk.Button(row, text="Apply", width=8,
                  command=self.apply_position).pack(side="left", padx=4)

        tk.Button(right, text="EXPORT 1280x720 PNG", font=(FONT, 11, "bold"),
                  bg="#2e7d32", fg="white", activebackground="#1b5e20",
                  activeforeground="white",
                  command=self.export).pack(fill="x", pady=(10, 2))

        brand_footer(root)
        self.redraw()

    # ------------------------------------------------------------- ui helpers
    @staticmethod
    def _section(parent, title):
        tk.Label(parent, text=title, font=(FONT, 10, "bold"),
                 anchor="w").pack(fill="x", pady=(8, 2))

    @staticmethod
    def pick_color(var):
        c = colorchooser.askcolor(color=var.get(), title="Choose color")
        if c and c[1]:
            var.set(c[1])

    # ------------------------------------------------------------- background
    def pick_bg_color(self):
        c = colorchooser.askcolor(color=self.background.get("color", "#20203a"),
                                  title="Background color")
        if c and c[1]:
            self.background = {"kind": "color", "color": c[1]}
            self.bg_info.config(text="Solid: %s" % c[1])
            self.redraw()

    def open_bg_image(self):
        path = filedialog.askopenfilename(
            title="Choose background image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.webp"),
                       ("All files", "*.*")])
        if path:
            self.background = {"kind": "image", "path": path,
                               "color": self.background.get("color", "#20203a")}
            self.bg_info.config(text="Image: %s" % os.path.basename(path))
            self.redraw()

    def use_solid_color(self):
        self.background = {"kind": "color",
                           "color": self.background.get("color", "#20203a")}
        self.bg_info.config(text="Solid: %s" % self.background["color"])
        self.redraw()

    # --------------------------------------------------------------- elements
    def _add(self, el):
        self.elements.append(el)
        self.selected = len(self.elements) - 1
        self.refresh_list()
        self.redraw()

    def add_title(self):
        try:
            size = int(self.title_size.get())
        except ValueError:
            size = 96
        self._add({"kind": "text", "text": self.title_entry.get(),
                   "x": CANVAS_W // 2, "y": 300,
                   "size": max(20, min(220, size)),
                   "color": self.title_color.get(),
                   "stroke": 3, "stroke_color": "black"})

    def add_subtitle(self):
        try:
            size = int(self.sub_size.get())
        except ValueError:
            size = 44
        self._add({"kind": "text", "text": self.sub_entry.get(),
                   "x": CANVAS_W // 2, "y": 480,
                   "size": max(16, min(120, size)),
                   "color": self.sub_color.get(),
                   "stroke": 2, "stroke_color": "black"})

    def add_shape(self):
        st = self.shape_var.get().lower()
        if st == "line":
            el = {"kind": "shape", "shape": "line",
                  "x": CANVAS_W // 2, "y": CANVAS_H // 2,
                  "w": 600, "h": 0, "fill": self.shape_color.get(),
                  "outline": "white", "width": 8}
        else:
            el = {"kind": "shape", "shape": st,
                  "x": CANVAS_W // 2, "y": CANVAS_H // 2,
                  "w": 420, "h": 220, "fill": self.shape_color.get(),
                  "outline": "white", "width": 5}
        self._add(el)

    def refresh_list(self):
        self.el_list.delete(0, tk.END)
        for i, el in enumerate(self.elements):
            self.el_list.insert(tk.END, element_label(el, i))
        if self.selected is not None and 0 <= self.selected < len(self.elements):
            self.el_list.selection_set(self.selected)
            el = self.elements[self.selected]
            self.pos_x.delete(0, tk.END); self.pos_x.insert(0, str(int(el["x"])))
            self.pos_y.delete(0, tk.END); self.pos_y.insert(0, str(int(el["y"])))
        else:
            self.el_list.selection_clear(0, tk.END)

    def on_list_select(self, _event):
        sel = self.el_list.curselection()
        self.selected = sel[0] if sel else None
        self.refresh_list()

    def delete_selected(self):
        if self.selected is None or not (0 <= self.selected < len(self.elements)):
            messagebox.showinfo("No selection", "Select an element first.")
            return
        del self.elements[self.selected]
        self.selected = None
        self.refresh_list()
        self.redraw()

    def apply_position(self):
        if self.selected is None or not (0 <= self.selected < len(self.elements)):
            return
        try:
            x = max(0, min(CANVAS_W, int(self.pos_x.get())))
            y = max(0, min(CANVAS_H, int(self.pos_y.get())))
        except ValueError:
            return
        el = self.elements[self.selected]
        el["x"], el["y"] = x, y
        self.redraw()

    # ------------------------------------------------------- canvas interaction
    def _to_canvas_coords(self, event):
        # canvas is exactly PREVIEW_W x PREVIEW_H at (0,0)
        return event.x, event.y

    def _hit_test(self, cx, cy):
        x, y = cx * CANVAS_W / PREVIEW_W, cy * CANVAS_H / PREVIEW_H
        for i in range(len(self.elements) - 1, -1, -1):
            x0, y0, x1, y1 = element_bbox(self.elements[i])
            if x0 <= x <= x1 and y0 <= y <= y1:
                return i
        return None

    def on_click(self, event):
        cx, cy = self._to_canvas_coords(event)
        idx = self._hit_test(cx, cy)
        self.selected = idx
        if idx is not None:
            el = self.elements[idx]
            ex = el["x"] * PREVIEW_W / CANVAS_W
            ey = el["y"] * PREVIEW_H / CANVAS_H
            self.drag_off = (ex - cx, ey - cy)
            self.dragging = True
        else:
            self.dragging = False
        self.refresh_list()

    def on_drag(self, event):
        if not self.dragging or self.selected is None:
            return
        if not (0 <= self.selected < len(self.elements)):
            return
        cx, cy = self._to_canvas_coords(event)
        cx += self.drag_off[0]
        cy += self.drag_off[1]
        el = self.elements[self.selected]
        el["x"] = max(0, min(CANVAS_W, cx * CANVAS_W / PREVIEW_W))
        el["y"] = max(0, min(CANVAS_H, cy * CANVAS_H / PREVIEW_H))
        self.redraw()

    # ------------------------------------------------------------------ draw
    def redraw(self):
        img = render_thumbnail(self.background, self.elements,
                               size=(PREVIEW_W, PREVIEW_H))
        self.photo = ImageTk.PhotoImage(img)
        self.canvas.itemconfig(self.canvas_img, image=self.photo)

    def export(self):
        path = filedialog.asksaveasfilename(
            title="Save thumbnail",
            defaultextension=".png",
            initialfile="thumbnail.png",
            filetypes=[("PNG image", "*.png")])
        if not path:
            return
        try:
            render_thumbnail(self.background, self.elements).save(path, "PNG")
        except Exception as exc:  # noqa: BLE001 - show any save error
            messagebox.showerror("Export failed", str(exc))
            return
        messagebox.showinfo("Exported",
                            "Thumbnail saved as 1280x720 PNG:\n%s" % path)


def main():
    root = tk.Tk()
    ThumbnailApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
