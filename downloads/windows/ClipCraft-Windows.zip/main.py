"""
ClipCraft Windows v1.0
Video organizer: browse a folder, list video files with duration/size/resolution
(uses ffprobe when available, otherwise file stats), search, rename, play in
the system default player.
Runs on Windows with Python 3: python main.py  (no extra packages needed)
"""
import os
import subprocess
import shutil
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
GOLD = "#D4AF37"
CREAM = "#FAF8F0"
WHITE = "#FFFFFF"
TEXT_DARK = "#1E2B26"
MUTED = "#5A6B63"
ROW_EVEN = "#F7F5EC"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

VIDEO_EXTS = (".mp4", ".mkv", ".avi", ".mov", ".webm", ".3gp", ".flv", ".m4v", ".wmv")
FFPROBE = shutil.which("ffprobe")  # bundled with ffmpeg; optional


def open_with_default(path):
    """Open a file in the OS default player."""
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa: S606  (Windows only API)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def ffprobe_info(path):
    """Return (duration_str, resolution_str) via ffprobe, or (None, None)."""
    if not FFPROBE:
        return None, None
    try:
        cmd = [FFPROBE, "-v", "error", "-select_streams", "v:0",
               "-show_entries", "stream=width,height,duration:format=duration",
               "-of", "default=noprint_wrappers=1", path]
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        vals = {}
        for line in out.stdout.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                vals[k.strip()] = v.strip()
        w, h = vals.get("width"), vals.get("height")
        dur = vals.get("duration")
        if dur == "N/A":
            dur = None
        dur_s = fmt_duration(float(dur)) if dur else None
        res = f"{w}×{h}" if w and h and w != "N/A" else None
        return dur_s, res
    except Exception:
        return None, None


def fmt_duration(seconds):
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{s:02d}" if h else f"{m:d}:{s:02d}"


def fmt_size(num_bytes):
    for unit in ("B", "KB", "MB", "GB"):
        if num_bytes < 1024.0 or unit == "GB":
            return f"{num_bytes:,.1f} {unit}"
        num_bytes /= 1024.0


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ClipCraft - Malik Muhammad Anwaar")
        self.geometry("900x620")
        self.configure(bg=CREAM)
        self.resizable(True, True)

        self.folder = ""
        self.videos = []  # list of dicts: path, name, size, dur, res

        # ---- header ----
        header = tk.Frame(self, bg=DEEP_EMERALD, height=70)
        header.pack(fill="x")
        tk.Label(header, text="CLIPCRAFT", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=18, pady=12)
        tk.Label(header, text="Video Organizer  •  Info  •  Rename  •  Play",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                     side="left", padx=6, pady=24)
        tk.Label(header, text="🎬", font=("Segoe UI", 26),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="right", padx=20)

        # ---- toolbar ----
        bar = tk.Frame(self, bg=CREAM)
        bar.pack(fill="x", padx=14, pady=(10, 4))
        btn_style = dict(font=("Segoe UI", 9, "bold"), relief="flat",
                         padx=10, pady=6, cursor="hand2")
        tk.Button(bar, text="📁 Open Folder…", bg=EMERALD, fg=WHITE,
                  activebackground=DEEP_EMERALD, activeforeground=WHITE,
                  command=self.pick_folder, **btn_style).pack(side="left")
        tk.Button(bar, text="🔄 Refresh", bg=WHITE, fg=TEXT_DARK,
                  activebackground="#EEEAE0", command=self.refresh,
                  **btn_style).pack(side="left", padx=6)
        tk.Button(bar, text="▶ Play", bg=GOLD, fg=DEEP_EMERALD,
                  activebackground="#C19A2E", command=self.play_selected,
                  **btn_style).pack(side="left", padx=6)
        tk.Button(bar, text="✏ Rename", bg=WHITE, fg=TEXT_DARK,
                  activebackground="#EEEAE0", command=self.rename_selected,
                  **btn_style).pack(side="left")

        search_frame = tk.Frame(bar, bg=CREAM)
        search_frame.pack(side="right")
        tk.Label(search_frame, text="🔍", font=("Segoe UI", 11),
                 bg=CREAM).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self.apply_search())
        search_entry = tk.Entry(search_frame, textvariable=self.search_var,
                                font=("Segoe UI", 10), width=22, relief="solid", bd=1)
        search_entry.pack(side="left", padx=4)

        self.folder_lbl = tk.Label(self, text="No folder selected",
                                   font=("Segoe UI", 9, "italic"), fg=MUTED, bg=CREAM,
                                   anchor="w")
        self.folder_lbl.pack(fill="x", padx=16)

        # ---- table ----
        cols = ("name", "duration", "size", "resolution")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=16)
        self.tree.heading("name", text="File name")
        self.tree.heading("duration", text="Duration")
        self.tree.heading("size", text="Size")
        self.tree.heading("resolution", text="Resolution")
        self.tree.column("name", width=420, anchor="w")
        self.tree.column("duration", width=110, anchor="center")
        self.tree.column("size", width=110, anchor="center")
        self.tree.column("resolution", width=130, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=14, pady=8)
        self.tree.bind("<Double-1>", lambda _e: self.play_selected())

        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=26,
                        background=WHITE, fieldbackground=WHITE)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"),
                        background=DEEP_EMERALD, foreground=GOLD)
        style.map("Treeview", background=[("selected", EMERALD)],
                  foreground=[("selected", WHITE)])

        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        # ---- status + footer ----
        self.status_lbl = tk.Label(self, text="Ready — open a folder to list videos",
                                   font=("Segoe UI", 9), fg=MUTED, bg=CREAM, anchor="w")
        self.status_lbl.pack(fill="x", padx=16, pady=(0, 6))
        footer = tk.Frame(self, bg=DEEP_EMERALD, height=34)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 8),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

    # ---------------- actions ----------------
    def pick_folder(self):
        folder = filedialog.askdirectory(title="Choose a folder with videos")
        if folder:
            self.folder = folder
            self.folder_lbl.config(text=f"📁 {folder}")
            self.refresh()

    def refresh(self):
        if not self.folder:
            messagebox.showinfo("No folder", "Pehle “Open Folder…” se folder chunen.")
            return
        self.status_lbl.config(text="Scanning… (ffprobe videos ki duration nikaal raha hai)")
        self.update_idletasks()
        self.videos = []
        try:
            for entry in sorted(os.listdir(self.folder)):
                full = os.path.join(self.folder, entry)
                if os.path.isfile(full) and entry.lower().endswith(VIDEO_EXTS):
                    dur, res = ffprobe_info(full)
                    self.videos.append({
                        "path": full,
                        "name": entry,
                        "size": os.path.getsize(full),
                        "dur": dur or "—",
                        "res": res or "—",
                    })
        except Exception as e:
            messagebox.showerror("Scan failed", f"Folder scan nahi ho saka:\n{e}")
            return
        if not FFPROBE:
            self.status_lbl.config(
                text=f"{len(self.videos)} video(s) mili — duration ke liye ffmpeg/ffprobe install karen")
        else:
            self.status_lbl.config(text=f"{len(self.videos)} video(s) mili")
        self.apply_search()

    def apply_search(self):
        q = self.search_var.get().lower()
        self.tree.delete(*self.tree.get_children())
        for i, v in enumerate(self.videos):
            if q and q not in v["name"].lower():
                continue
            tag = "even" if i % 2 == 0 else "odd"
            self.tree.insert("", "end", iid=v["path"], tags=(tag,),
                             values=(v["name"], v["dur"], fmt_size(v["size"]), v["res"]))
        self.tree.tag_configure("even", background=ROW_EVEN)
        self.tree.tag_configure("odd", background=WHITE)

    def selected_video(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Select video", "Pehle list se aik video select karen.")
            return None
        return sel[0]

    def play_selected(self):
        path = self.selected_video()
        if not path:
            return
        try:
            open_with_default(path)
            self.status_lbl.config(text=f"Playing: {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Play failed", f"Video nahi chal saki:\n{e}")

    def rename_selected(self):
        path = self.selected_video()
        if not path:
            return
        old = os.path.basename(path)
        new = simpledialog.askstring("Rename video", "Naya naam likhen:",
                                     initialvalue=old, parent=self)
        if not new or new == old:
            return
        if not new.lower().endswith(VIDEO_EXTS):
            new += os.path.splitext(old)[1]
        new_path = os.path.join(os.path.dirname(path), new)
        if os.path.exists(new_path):
            messagebox.showerror("Rename failed", "Is naam ki file pehle se maujood hai.")
            return
        try:
            os.rename(path, new_path)
            self.refresh()
            self.status_lbl.config(text=f"Renamed → {new}")
        except Exception as e:
            messagebox.showerror("Rename failed", f"Rename nahi ho saka:\n{e}")


if __name__ == "__main__":
    App().mainloop()
