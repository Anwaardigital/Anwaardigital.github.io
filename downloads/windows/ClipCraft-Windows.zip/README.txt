==============================================
 CLIPCRAFT v1.0 (Windows)
==============================================
Video organizer — folder ki tamam videos ki list,
har video ki duration, size aur resolution dekhen,
search karen, rename karen, play karen.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Double-click run.bat (or run: python main.py)

CONTROLS
--------
- "Open Folder..." :  Videos wala folder chunen
- Search box       :  Naam se video talash karen
- Double-click ya "Play"  :  Video system player mein chalegi
- "Rename"         :  Video ka naam tabdeel karen
- "Refresh"        :  List dobara scan karen

DURATION / RESOLUTION
---------------------
Agar PC par ffmpeg/ffprobe installed hai to har video
ki duration aur resolution bhi nazar aayegi, warna
sirf file size dikhega. (ffprobe optional hai.)

Note: Internet ki zaroorat NAHI — sab kaam offline hota hai.

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
