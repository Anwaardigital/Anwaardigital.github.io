#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bachon ki Islamic Taleem v4.0 — Windows desktop app (Tkinter)
============================================================
Content matches the approved Android APK v4.0 (MalikAnwaar-KidsIslamic-v4.0.apk).
All content extracted programmatically from the Android Java sources
(DataA.java, DataB.java, QuizData.java).

TEXT ONLY — no TTS, no audio, exactly like the Android v4.0 pattern.

Requires: Python 3 (tkinter is built into standard Python on Windows).
Run: double-click run.bat

Developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
"""

import tkinter as tk
import random
import datetime

import data as D

# ---------------------------------------------------------------- theme ---
EM_DARK = "#065F46"     # deep emerald
EM = "#047857"          # emerald
EM_MID = "#10B981"      # bright emerald
GOLD = "#D4AF37"        # gold
GOLD_LT = "#FEF3C7"     # light gold
CREAM = "#FFFBEB"       # warm cream background
WHITE = "#FFFFFF"
INK = "#1F2937"
MUTED = "#6B7280"
GREEN_OK = "#047857"
RED_BAD = "#DC2626"

F_TITLE = ("Segoe UI", 26, "bold")
F_H1 = ("Segoe UI", 20, "bold")
F_H2 = ("Segoe UI", 16, "bold")
F_BODY = ("Segoe UI", 14)
F_AR = ("Segoe UI", 20)
F_AR_BIG = ("Segoe UI", 28)
F_LETTER = ("Segoe UI", 42, "bold")
F_BTN = ("Segoe UI", 15, "bold")
F_SMALL = ("Segoe UI", 12)
F_COUNT = ("Segoe UI", 72, "bold")

WRAP = 860  # text wrap width inside detail pages

CREDIT_LINE1 = "App developed by Malik Muhammad Anwaar"
CREDIT_LINE2 = "WhatsApp: 923288317526"


# ------------------------------------------------------------ widgets -----
class ScrollFrame(tk.Frame):
    """Vertically scrollable frame (mouse-wheel aware)."""

    def __init__(self, master, bg=CREAM):
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        self.vbar = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vbar.pack(side="right", fill="y")
        self.inner.bind("<Configure>",
                       lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfig(self._win, width=e.width))
        self.inner.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._wheel))
        self.inner.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

    def _wheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


def clear(frame):
    for w in frame.winfo_children():
        w.destroy()


def gold_button(master, text, command, font=F_BTN):
    return tk.Button(master, text=text, font=font, bg=GOLD, fg=INK,
                     activebackground=GOLD_LT, activeforeground=INK,
                     relief="raised", bd=2, padx=14, pady=8,
                     cursor="hand2", command=command)


def emerald_button(master, text, command, font=F_BTN):
    return tk.Button(master, text=text, font=font, bg=EM, fg=WHITE,
                     activebackground=EM_MID, activeforeground=WHITE,
                     relief="raised", bd=2, padx=14, pady=8,
                     cursor="hand2", command=command)


# ------------------------------------------------------------ content -----
# (key, icon, urdu title, subtitle) per section
SECTIONS = [
    ("📖  قرآن سیکھو", [
        ("SURAHS", "📖", "چھوٹی سورتیں", "15 سورتیں ترجمے کے ساتھ"),
        ("QAIDA", "📚", "نورانی قاعدہ", "10 آسان اسباق"),
        ("KALMAS", "🕋", "چھ کلمے", "ترجمے کے ساتھ"),
        ("AZAN", "🔔", "اذان سیکھو", "اذان کے 12 حصے"),
        ("ASMA", "💎", "اسماء الحسنیٰ", "اللہ کے 99 نام"),
        ("MONTHS", "📅", "اسلامی مہینے", "12 مہینے"),
    ]),
    ("🤲  دعائیں اور عبادت", [
        ("DUAS", "🤲", "مسنون دعائیں", "27 روزانہ دعائیں"),
        ("HADITH", "💡", "بچوں کی حدیثیں", "30 آسان حدیثیں"),
        ("WUDU", "💧", "وضو سیکھو", "8 آسان مرحلے"),
        ("TASBEEH", "📿", "تسبیح کاؤنٹر", "ڈیجیٹل تسبیح"),
        ("DAILY", "📆", "آج کا سبق", "روزانہ نیا سوال"),
    ]),
    ("📜  کہانیاں", [
        ("STORIES_ANBIYA", "📜", "قصص الانبیاء", "10 کہانیاں"),
        ("SEERAT", "🌙", "سیرت النبی ﷺ", "8 ابواب"),
        ("SAHABA", "⭐", "صحابہ کرام", "8 کہانیاں"),
        ("AKHLAQ", "🤝", "اخلاق و آداب", "6 سبق"),
        ("NAAT", "🎵", "حمد و نعت", "4 کلام (بغیر موسیقی)"),
    ]),
    ("🎮  سیکھو اور کھیلو", [
        ("ALPHABET", "🔤", "اردو حروف تہجی", "الف سے ے تک"),
        ("QUIZ_GENERAL", "🎮", "اسلامی کوئز", "20 سوالات"),
        ("QUIZ_QURAN", "🎯", "قرآن کوئز", "12 سوالات"),
        ("QUIZ_NAMAZ", "🕌", "نماز کوئز", "12 سوالات"),
        ("QUIZ_SEERAT", "🌟", "سیرت کوئز", "12 سوالات"),
        ("QUIZ_FAMILY", "👪", "فیملی کوئز", "20 سوالات"),
        ("MATHQ", "➕", "اسلامی میتھ", "15 سوالات"),
        ("HIFZ", "🧠", "حفظ گیم", "10 چیلنج"),
    ]),
    ("🎉  خاص مواقع", [
        ("RAMZAN", "🌙", "رمضان اسپیشل", "6 مضامین"),
        ("EID", "🎁", "عید اسپیشل", "5 مضامین"),
        ("HAJJ", "🕋", "حج اور عمرہ", "8 مراحل"),
        ("QADR", "✨", "شبِ قدر", "4 مضامین"),
        ("MASJIDS", "🕌", "مشہور مساجد", "10 مساجد"),
        ("COUNTRIES", "🌍", "اسلامی ممالک", "12 ممالک"),
        ("CHAND", "🌜", "چاند اور کیلنڈر", "5 مضامین"),
        ("ART", "🎨", "اسلامی آرٹ", "6 مضامین"),
        ("HIJAB", "🧕", "حجاب اور آداب", "5 مضامین"),
    ]),
]

CAT_TITLES = {key: title for _sec, cats in SECTIONS for key, _ic, title, _sub in cats}

QUIZ_TITLES = {
    "QUIZ_GENERAL": "اسلامی کوئز",
    "QUIZ_QURAN": "قرآن کوئز",
    "QUIZ_NAMAZ": "نماز کوئز",
    "QUIZ_SEERAT": "سیرت کوئز",
    "QUIZ_FAMILY": "فیملی کوئز",
    "MATHQ": "اسلامی میتھ",
}

# datasets rendered as a plain item list -> detail page
LIST_KEYS = ["SURAHS", "KALMAS", "DUAS", "HADITH", "AZAN", "MONTHS", "QAIDA",
             "STORIES_ANBIYA", "SEERAT", "SAHABA", "AKHLAQ", "NAAT",
             "RAMZAN", "EID", "HAJJ", "QADR", "MASJIDS", "COUNTRIES",
             "CHAND", "ART", "HIJAB"]


def list_title(key, idx, row):
    if key == "HADITH":
        return "حدیث نمبر %d" % (idx + 1)
    if key == "AZAN":
        return "اذان — حصہ %d" % (idx + 1)
    return row[0]


def list_subtitle(key, idx, row):
    if len(row) > 1 and key not in ("SURAHS", "KALMAS", "DUAS"):
        t = row[1].replace("\n", " ")
        return (t[:70] + "…") if len(t) > 70 else t
    if len(row) > 2:
        t = row[2].replace("\n", " ")
        return (t[:70] + "…") if len(t) > 70 else t
    return ""


def detail_blocks(key, idx, row):
    """Return list of (kind, text). kinds: h1, arabic, label, body."""
    if key == "SURAHS":
        return [("h1", row[0]), ("arabic", row[1]),
                ("label", "اردو ترجمہ:"), ("body", row[2])]
    if key == "KALMAS":
        return [("h1", row[1]), ("arabic", row[0]),
                ("label", "ترجمہ:"), ("body", row[2])]
    if key == "DUAS":
        return [("h1", row[0]), ("arabic", row[1]),
                ("label", "ترجمہ:"), ("body", row[2])]
    if key == "HADITH":
        return [("h1", "حدیث نمبر %d" % (idx + 1)), ("arabic", row[0]),
                ("label", "ترجمہ:"), ("body", row[1])]
    if key == "AZAN":
        return [("h1", "اذان — حصہ %d" % (idx + 1)), ("arabic", row[0]),
                ("label", "مطلب:"), ("body", row[1])]
    if key == "MONTHS":
        return [("h1", row[0]), ("body", row[1])]
    if key == "QAIDA":
        return [("h1", row[0]), ("arabic", row[1]),
                ("label", "ہدایات:"), ("body", row[2])]
    # generic: [title, body]
    return [("h1", row[0]), ("body", row[1])]


# ----------------------------------------------------------------- app ---
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("بچوں کی اسلامی تعلیم v4.0")
        self.geometry("1024x720")
        self.minsize(880, 620)
        self.configure(bg=EM_DARK)

        # top bar
        self.top = tk.Frame(self, bg=EM_DARK)
        self.top.pack(fill="x")
        tk.Button(self.top, text="🏠  ہوم", font=F_BTN, bg=GOLD, fg=INK,
                  activebackground=GOLD_LT, relief="flat", padx=18, pady=4,
                  cursor="hand2", command=self.show_home).pack(side="left", padx=10, pady=8)
        tk.Label(self.top, text="بچوں کی اسلامی تعلیم", font=F_H2,
                 bg=EM_DARK, fg=WHITE).pack(side="left", padx=6)
        tk.Label(self.top, text="v4.0", font=F_SMALL,
                 bg=EM_DARK, fg=GOLD_LT).pack(side="right", padx=14)

        self.body = tk.Frame(self, bg=CREAM)
        self.body.pack(fill="both", expand=True)

        self.show_home()

    # -- navigation -------------------------------------------------
    def _clear(self):
        self.unbind("<space>")
        clear(self.body)

    def show_home(self):
        self._clear()
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner

        banner = tk.Frame(inner, bg=EM)
        banner.pack(fill="x", padx=14, pady=(14, 6))
        tk.Label(banner, text="🕌", font=("Segoe UI", 44), bg=EM).pack(pady=(12, 0))
        tk.Label(banner, text="بچوں کی اسلامی تعلیم", font=F_TITLE,
                 bg=EM, fg=WHITE).pack()
        tk.Label(banner, text="قرآن • دعائیں • کہانیاں • کوئز — بچوں کے لیے مکمل اسلامی تعلیم",
                 font=F_BODY, bg=EM, fg=GOLD_LT).pack(pady=(2, 14))

        for sec_title, cats in SECTIONS:
            box = tk.LabelFrame(inner, text=sec_title, font=F_H2, bg=CREAM,
                                fg=EM_DARK, padx=10, pady=10)
            box.pack(fill="x", padx=14, pady=8)
            grid = tk.Frame(box, bg=CREAM)
            grid.pack(fill="x")
            cols = 4
            for i, (key, icon, title, sub) in enumerate(cats):
                b = tk.Button(grid, text="%s\n%s\n%s" % (icon, title, sub),
                              font=F_BTN, bg=WHITE, fg=INK,
                              activebackground=GOLD_LT, activeforeground=INK,
                              relief="raised", bd=2, padx=8, pady=12,
                              wraplength=210, justify="center", cursor="hand2",
                              command=lambda k=key: self.open_category(k))
                b.grid(row=i // cols, column=i % cols, padx=6, pady=6, sticky="nsew")
            for c in range(cols):
                grid.columnconfigure(c, weight=1, uniform="cats")

        tk.Label(inner, text=CREDIT_LINE1, font=F_H2,
                 bg=CREAM, fg=EM_DARK).pack(pady=(18, 0))
        tk.Label(inner, text=CREDIT_LINE2, font=F_BODY,
                 bg=CREAM, fg=MUTED).pack(pady=(0, 18))

    def open_category(self, key):
        if key in QUIZ_TITLES and key != "MATHQ":
            self.show_quiz(getattr(D, key), QUIZ_TITLES[key])
        elif key == "MATHQ":
            self.show_quiz(D.MATH, QUIZ_TITLES["MATHQ"])
        elif key == "TASBEEH":
            self.show_tasbeeh()
        elif key == "WUDU":
            self.show_wudu()
        elif key == "DAILY":
            self.show_daily(0)
        elif key == "HIFZ":
            self.show_hifz()
        elif key == "ALPHABET":
            self.show_alphabet()
        elif key == "ASMA":
            self.show_asma()
        else:
            self.show_list(key)

    # -- list + detail ----------------------------------------------
    def show_list(self, key):
        self._clear()
        rows = getattr(D, key)
        title = CAT_TITLES.get(key, key)
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner

        tk.Label(inner, text=title, font=F_H1, bg=EM, fg=WHITE,
                 pady=10).pack(fill="x", padx=14, pady=(14, 8))
        tk.Label(inner, text="%d عنوانات — پڑھنے کے لیے دبائیں" % len(rows),
                 font=F_SMALL, bg=CREAM, fg=MUTED).pack(pady=(0, 6))

        for idx, row in enumerate(rows):
            t = list_title(key, idx, row)
            sub = list_subtitle(key, idx, row)
            txt = t if not sub else "%s\n%s" % (t, sub)
            b = tk.Button(inner, text=txt, font=F_BTN, bg=WHITE, fg=INK,
                          activebackground=GOLD_LT, relief="raised", bd=1,
                          padx=16, pady=10, anchor="e", justify="right",
                          wraplength=WRAP, cursor="hand2",
                          command=lambda i=idx: self.show_detail(key, i))
            b.pack(fill="x", padx=24, pady=4)
        tk.Label(inner, text="", bg=CREAM).pack(pady=6)

    def show_detail(self, key, idx):
        self._clear()
        rows = getattr(D, key)
        row = rows[idx]
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner

        for kind, text in detail_blocks(key, idx, row):
            if kind == "h1":
                tk.Label(inner, text=text, font=F_H1, bg=EM, fg=WHITE,
                         pady=12, wraplength=WRAP, justify="center").pack(
                             fill="x", padx=14, pady=(14, 10))
            elif kind == "arabic":
                tk.Label(inner, text=text, font=F_AR_BIG, bg=GOLD_LT, fg=INK,
                         padx=18, pady=16, wraplength=WRAP, justify="right",
                         anchor="e", relief="groove", bd=2).pack(
                             fill="x", padx=24, pady=6)
            elif kind == "label":
                tk.Label(inner, text=text, font=F_H2, bg=CREAM,
                         fg=EM_DARK,
                         anchor="e", justify="right").pack(
                             fill="x", padx=30, pady=(10, 0))
            else:  # body
                tk.Label(inner, text=text, font=F_BODY, bg=CREAM, fg=INK,
                         wraplength=WRAP, justify="right", anchor="ne",
                         padx=6, pady=4).pack(fill="x", padx=30, pady=4)

        nav = tk.Frame(inner, bg=CREAM)
        nav.pack(fill="x", padx=24, pady=16)
        if idx > 0:
            gold_button(nav, "◀  پچھلا",
                        lambda: self.show_detail(key, idx - 1)).pack(side="left")
        tk.Label(nav, text="%d / %d" % (idx + 1, len(rows)),
                 font=F_H2, bg=CREAM, fg=MUTED).pack(side="left", expand=True)
        if idx < len(rows) - 1:
            gold_button(nav, "اگلا  ▶",
                        lambda: self.show_detail(key, idx + 1)).pack(side="right")
        tk.Label(inner, text="", bg=CREAM).pack(pady=4)

    # -- alphabet ----------------------------------------------------
    def show_alphabet(self):
        self._clear()
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner
        tk.Label(inner, text="اردو حروف تہجی", font=F_H1, bg=EM, fg=WHITE,
                 pady=10).pack(fill="x", padx=14, pady=(14, 8))
        tk.Label(inner, text="حرف دبائیں اور اس سے اسلامی لفظ سیکھیں",
                 font=F_SMALL, bg=CREAM, fg=MUTED).pack(pady=(0, 8))
        grid = tk.Frame(inner, bg=CREAM)
        grid.pack(padx=14)
        cols = 6
        for i, row in enumerate(D.ALPHABET):
            b = tk.Button(grid, text=row[0], font=F_LETTER, bg=WHITE, fg=EM_DARK,
                          activebackground=GOLD_LT, relief="raised", bd=2,
                          width=3, pady=6, cursor="hand2",
                          command=lambda r=row: self.show_alpha_detail(r))
            b.grid(row=i // cols, column=i % cols, padx=6, pady=6, sticky="nsew")
        for c in range(cols):
            grid.columnconfigure(c, weight=1, uniform="alpha")
        tk.Label(inner, text="", bg=CREAM).pack(pady=8)

    def show_alpha_detail(self, row):
        self._clear()
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner
        tk.Label(inner, text=row[0], font=("Segoe UI", 110, "bold"),
                 bg=EM, fg=GOLD, pady=10).pack(fill="x", padx=14, pady=(14, 8))
        tk.Label(inner, text=row[1], font=F_H1, bg=GOLD_LT, fg=INK,
                 pady=10).pack(fill="x", padx=24, pady=8)
        tk.Label(inner, text=row[2], font=F_BODY, bg=CREAM, fg=INK,
                 wraplength=WRAP, justify="center", pady=8).pack(
                     fill="x", padx=30, pady=6)
        gold_button(inner, "◀  واپس حروف تہجی",
                    self.show_alphabet).pack(pady=16)

    # -- asma ul husna ------------------------------------------------
    def show_asma(self):
        self._clear()
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner
        tk.Label(inner, text="اسماء الحسنیٰ — اللہ کے 99 نام",
                 font=F_H1, bg=EM, fg=WHITE, pady=10).pack(
                     fill="x", padx=14, pady=(14, 8))
        grid = tk.Frame(inner, bg=CREAM)
        grid.pack(padx=14)
        cols = 5
        for i, row in enumerate(D.ASMA):
            b = tk.Button(grid, text="%d\n%s" % (i + 1, row[0]), font=F_BTN,
                          bg=WHITE, fg=EM_DARK, activebackground=GOLD_LT,
                          relief="raised", bd=1, padx=6, pady=8, cursor="hand2",
                          command=lambda r=row, n=i + 1: self.show_asma_detail(r, n))
            b.grid(row=i // cols, column=i % cols, padx=5, pady=5, sticky="nsew")
        for c in range(cols):
            grid.columnconfigure(c, weight=1, uniform="asma")
        tk.Label(inner, text="", bg=CREAM).pack(pady=8)

    def show_asma_detail(self, row, n):
        self._clear()
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner
        tk.Label(inner, text="نام %d" % n, font=F_H2, bg=CREAM,
                 fg=MUTED).pack(pady=(16, 0))
        tk.Label(inner, text=row[0], font=("Segoe UI", 64, "bold"),
                 bg=EM, fg=GOLD, pady=14).pack(fill="x", padx=14, pady=8)
        tk.Label(inner, text=row[1], font=F_H1, bg=GOLD_LT, fg=INK,
                 pady=12).pack(fill="x", padx=24, pady=8)
        gold_button(inner, "◀  واپس 99 نام",
                    self.show_asma).pack(pady=16)

    # -- wudu ----------------------------------------------------------
    def show_wudu(self):
        self._clear()
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        inner = sf.inner
        tk.Label(inner, text="💧  وضو کے 8 مرحلے", font=F_H1, bg=EM, fg=WHITE,
                 pady=10).pack(fill="x", padx=14, pady=(14, 10))
        for i, row in enumerate(D.WUDU_STEPS):
            card = tk.Frame(inner, bg=WHITE, relief="raised", bd=1)
            card.pack(fill="x", padx=24, pady=5)
            tk.Label(card, text=str(i + 1), font=F_H1, bg=GOLD, fg=INK,
                     width=3, pady=8).pack(side="left", padx=8, pady=8)
            tk.Label(card, text=row[0], font=F_BTN, bg=WHITE, fg=INK,
                     wraplength=WRAP - 120, justify="right", anchor="e",
                     pady=8).pack(side="left", fill="x", expand=True, padx=8)
        tk.Label(inner, text="وضو کے بعد کی دعا یاد رکھیں!", font=F_BODY,
                 bg=CREAM, fg=EM_DARK).pack(pady=14)

    # -- tasbeeh --------------------------------------------------------
    def show_tasbeeh(self):
        self._clear()
        dhikrs = ["سُبْحَانَ اللّٰہ", "اَلْحَمْدُ لِلّٰہ",
                  "اَللّٰہُ اَکْبَر", "لَا إِلٰہَ إِلَّا اللّٰہ"]
        st = {"count": 0, "target": 100}
        wrap = tk.Frame(self.body, bg=CREAM)
        wrap.pack(fill="both", expand=True)

        tk.Label(wrap, text="📿  تسبیح کاؤنٹر", font=F_H1, bg=EM, fg=WHITE,
                 pady=10).pack(fill="x", padx=14, pady=(14, 8))

        dhikr_var = tk.StringVar(value=dhikrs[0])
        tk.OptionMenu(wrap, dhikr_var, *dhikrs).pack(pady=6)
        tk.Label(wrap, textvariable=dhikr_var, font=F_AR_BIG,
                 bg=CREAM, fg=EM_DARK).pack(pady=4)

        count_lbl = tk.Label(wrap, text="0", font=F_COUNT, bg=CREAM, fg=INK)
        count_lbl.pack(pady=6)
        prog_lbl = tk.Label(wrap, text="ہدف: 0 / 100", font=F_H2,
                            bg=CREAM, fg=MUTED)
        prog_lbl.pack(pady=2)

        def refresh():
            count_lbl.config(text=str(st["count"]))
            prog_lbl.config(text="ہدف: %d / %d" % (st["count"], st["target"]))
            if st["count"] >= st["target"] and st["target"] > 0:
                prog_lbl.config(text="🎉 ماشاء اللہ! ہدف مکمل (%d)" % st["target"])

        def tap():
            st["count"] += 1
            refresh()

        def reset():
            st["count"] = 0
            refresh()

        def set_target(t):
            st["target"] = t
            refresh()

        big = tk.Button(wrap, text="دبائیں  🤲", font=("Segoe UI", 22, "bold"),
                        bg=EM, fg=WHITE, activebackground=EM_MID,
                        relief="raised", bd=3, padx=40, pady=18,
                        cursor="hand2", command=tap)
        big.pack(pady=10)
        self.bind("<space>", lambda e: tap())

        trow = tk.Frame(wrap, bg=CREAM)
        trow.pack(pady=6)
        tk.Label(trow, text="ہدف:", font=F_BODY, bg=CREAM,
                 fg=MUTED).pack(side="left", padx=6)
        for t in (33, 100, 500, 1000):
            tk.Button(trow, text=str(t), font=F_BTN, bg=GOLD_LT, fg=INK,
                      relief="raised", bd=1, padx=10, pady=4, cursor="hand2",
                      command=lambda v=t: set_target(v)).pack(side="left", padx=4)
        gold_button(wrap, "↺  صفر کریں", reset).pack(pady=8)
        tk.Label(wrap, text="(اسپیس بٹن بھی دبایا جا سکتا ہے)",
                 font=F_SMALL, bg=CREAM, fg=MUTED).pack(pady=4)
        refresh()

    # -- daily -----------------------------------------------------------
    def show_daily(self, offset):
        self._clear()
        n = len(D.DAILY)
        idx = (datetime.date.today().timetuple().tm_yday + offset) % n
        row = D.DAILY[idx]
        wrap = tk.Frame(self.body, bg=CREAM)
        wrap.pack(fill="both", expand=True)
        head = "📆  آج کا سبق" if offset == 0 else "📆  سبق %d / %d" % (idx + 1, n)
        tk.Label(wrap, text=head, font=F_H1, bg=EM, fg=WHITE,
                 pady=10).pack(fill="x", padx=14, pady=(14, 10))
        tk.Label(wrap, text=row[0], font=F_H1, bg=GOLD_LT, fg=INK,
                 wraplength=WRAP, justify="center", pady=18).pack(
                     fill="x", padx=24, pady=10)
        tk.Label(wrap, text="جواب:", font=F_H2, bg=CREAM,
                 fg=MUTED).pack(pady=(6, 0))
        tk.Label(wrap, text=row[1], font=F_AR, bg=CREAM, fg=EM_DARK,
                 wraplength=WRAP, justify="center", pady=8).pack(
                     fill="x", padx=30)
        nav = tk.Frame(wrap, bg=CREAM)
        nav.pack(pady=18)
        gold_button(nav, "◀  پچھلا سبق",
                    lambda: self.show_daily(offset - 1)).pack(side="left", padx=8)
        gold_button(nav, "اگلا سبق  ▶",
                    lambda: self.show_daily(offset + 1)).pack(side="right", padx=8)

    # -- quiz -------------------------------------------------------------
    def show_quiz(self, rows, title):
        self._clear()
        order = list(range(len(rows)))
        random.shuffle(order)
        st = {"pos": 0, "score": 0}

        wrap = tk.Frame(self.body, bg=CREAM)
        wrap.pack(fill="both", expand=True)
        thead = tk.Label(wrap, text="🎮  " + title, font=F_H1, bg=EM, fg=WHITE,
                         pady=10)
        thead.pack(fill="x", padx=14, pady=(14, 6))
        qframe = tk.Frame(wrap, bg=CREAM)
        qframe.pack(fill="both", expand=True, padx=20, pady=8)

        def render():
            clear(qframe)
            if st["pos"] >= len(order):
                tk.Label(qframe, text="🏆  کوئز مکمل!", font=F_TITLE,
                         bg=CREAM, fg=EM_DARK).pack(pady=(30, 8))
                tk.Label(qframe,
                         text="آپ کا اسکور: %d / %d" % (st["score"], len(order)),
                         font=F_H1, bg=GOLD_LT, fg=INK, pady=14).pack(
                             fill="x", padx=60, pady=10)
                if st["score"] == len(order):
                    msg = "🌟 سبحان اللہ! مکمل نمبر — بہترین!"
                elif st["score"] >= len(order) * 0.7:
                    msg = "👏 بہت خوب! تھوڑی اور محنت کریں۔"
                else:
                    msg = "💪 ہمت نہ ہاریں — دوبارہ کوشش کریں!"
                tk.Label(qframe, text=msg, font=F_H2,
                         bg=CREAM, fg=INK).pack(pady=8)
                gold_button(qframe, "🔄  دوبارہ کھیلیں",
                            lambda: self.show_quiz(rows, title)).pack(pady=10)
                return

            r = rows[order[st["pos"]]]
            q, correct = r[0], r[1]
            opts = [r[1], r[2], r[3], r[4]]
            random.shuffle(opts)

            tk.Label(qframe, text="سوال %d / %d   •   اسکور: %d" % (
                st["pos"] + 1, len(order), st["score"]),
                font=F_SMALL, bg=CREAM, fg=MUTED).pack(pady=(6, 2))
            tk.Label(qframe, text=q, font=F_H1, bg=WHITE, fg=INK,
                     wraplength=WRAP, justify="center", pady=16,
                     relief="groove", bd=2).pack(fill="x", padx=30, pady=10)

            btns = []

            def answer(chosen, btn):
                for b in btns:
                    b.config(state="disabled")
                if chosen == correct:
                    st["score"] += 1
                    btn.config(bg=GREEN_OK, fg=WHITE, disabledforeground=WHITE)
                    fb = tk.Label(qframe, text="✅ صحیح جواب! ماشاء اللہ",
                                  font=F_H2, bg=CREAM, fg=GREEN_OK)
                else:
                    btn.config(bg=RED_BAD, fg=WHITE, disabledforeground=WHITE)
                    for b, o in zip(btns, opts):
                        if o == correct:
                            b.config(bg=GREEN_OK, fg=WHITE,
                                     disabledforeground=WHITE)
                    fb = tk.Label(qframe, text="❌ صحیح جواب: %s" % correct,
                                  font=F_H2, bg=CREAM, fg=RED_BAD)
                fb.pack(pady=8)
                gold_button(qframe, "اگلا سوال  ▶", nxt).pack(pady=6)

            def nxt():
                st["pos"] += 1
                render()

            for o in opts:
                b = tk.Button(qframe, text=o, font=F_BTN, bg=WHITE, fg=INK,
                              activebackground=GOLD_LT, relief="raised", bd=2,
                              padx=14, pady=10, wraplength=WRAP - 160,
                              justify="center", cursor="hand2")
                b.config(command=lambda oo=o, bb=b: answer(oo, bb))
                b.pack(fill="x", padx=60, pady=5)
                btns.append(b)

        render()

    # -- hifz game ----------------------------------------------------------
    def show_hifz(self):
        self._clear()
        st = {"pos": 0, "score": 0}
        wrap = tk.Frame(self.body, bg=CREAM)
        wrap.pack(fill="both", expand=True)
        tk.Label(wrap, text="🧠  حفظ گیم", font=F_H1, bg=EM, fg=WHITE,
                 pady=10).pack(fill="x", padx=14, pady=(14, 6))
        tk.Label(wrap, text="خالی جگہ میں صحیح لفظ لکھیں",
                 font=F_SMALL, bg=CREAM, fg=MUTED).pack(pady=(0, 4))
        qframe = tk.Frame(wrap, bg=CREAM)
        qframe.pack(fill="both", expand=True, padx=20, pady=8)

        def render():
            clear(qframe)
            if st["pos"] >= len(D.HIFZ):
                tk.Label(qframe, text="🏆  گیم مکمل!", font=F_TITLE,
                         bg=CREAM, fg=EM_DARK).pack(pady=(30, 8))
                tk.Label(qframe,
                         text="آپ کا اسکور: %d / %d" % (st["score"], len(D.HIFZ)),
                         font=F_H1, bg=GOLD_LT, fg=INK, pady=14).pack(
                             fill="x", padx=60, pady=10)
                gold_button(qframe, "🔄  دوبارہ کھیلیں",
                            self.show_hifz).pack(pady=10)
                return

            surah, blanked, missing, hint = D.HIFZ[st["pos"]]
            tk.Label(qframe, text="چیلنج %d / %d   •   اسکور: %d" % (
                st["pos"] + 1, len(D.HIFZ), st["score"]),
                font=F_SMALL, bg=CREAM, fg=MUTED).pack(pady=(6, 2))
            tk.Label(qframe, text=surah, font=F_H2, bg=CREAM,
                     fg=EM_DARK).pack(pady=4)
            tk.Label(qframe, text=blanked, font=F_AR_BIG, bg=WHITE, fg=INK,
                     wraplength=WRAP, justify="center", pady=18,
                     relief="groove", bd=2).pack(fill="x", padx=30, pady=10)

            entry = tk.Entry(qframe, font=F_AR, justify="center", width=24,
                             relief="solid", bd=2)
            entry.pack(pady=8)
            entry.focus_set()
            fb = tk.Label(qframe, text="", font=F_H2, bg=CREAM)
            fb.pack(pady=4)

            def check():
                if entry.get().strip() == missing:
                    st["score"] += 1
                    fb.config(text="✅ صحیح! ماشاء اللہ", fg=GREEN_OK)
                    entry.config(state="disabled")
                    check_btn.pack_forget()
                    gold_button(qframe, "اگلا چیلنج  ▶", nxt).pack(pady=8)
                else:
                    fb.config(text="❌ دوبارہ کوشش کریں — اشارہ: %s" % hint,
                              fg=RED_BAD)

            def reveal():
                fb.config(text="جواب: %s" % missing, fg=EM_DARK)

            def nxt():
                st["pos"] += 1
                render()

            brow = tk.Frame(qframe, bg=CREAM)
            brow.pack(pady=6)
            check_btn = emerald_button(brow, "✓  چیک کریں", check)
            check_btn.pack(side="left", padx=6)
            tk.Button(brow, text="👁 جواب دیکھیں", font=F_BTN, bg=WHITE,
                      fg=MUTED, relief="flat", cursor="hand2",
                      command=reveal).pack(side="left", padx=6)
            entry.bind("<Return>", lambda e: check())

        render()


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
