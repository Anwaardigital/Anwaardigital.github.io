================================================================
  Bachon ki Islamic Taleem v4.0 - Windows App
  (Android APK v4.0 "Perfect done" wala content - same to same)
  Developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
================================================================

CHALANE KA TAREEQA (bohat aasan):
  1. Apke computer par Python 3 install hona chahie (muft):
     https://www.python.org/downloads/
     (Install ke waqt "Add python.exe to PATH" tick zaroor karein)
  2. Is folder mein "run.bat" par DOUBLE-CLICK karein. Bas!

KOI INSTALL NAHI - KOI INTERNET NAHI:
  Ye portable Python app hai (.exe nahi). run.bat dabate hi
  app khul jati hai. Internet ki zaroorat nahi - sab content
  offline app ke andar hai.

KYA KYA HAI (Android v4.0 jaisa):
  * Chhoti Surtein (15) - Urdu tarjume ke sath
  * Noorani Qaida (10 asbaq)
  * Chhe Kalme - tarjume ke sath
  * Azan seekho (12 hisse)
  * Asma-ul-Husna (Allah ke 99 naam)
  * Islami maheene (12)
  * Masnoon Duain (27)
  * Bachon ki Hadithen (30)
  * Wuzu seekho (8 marhale) + Digital Tasbeeh Counter
  * Aaj ka Sabaq (rozana naya - 30)
  * Qasas-ul-Anbiya (10), Seerat-un-Nabi (8),
    Sahaba Karam (8), Akhlaq-o-Aadab (6), Hamd-o-Naat (4)
  * Urdu Haroof-e-Tahajji (Alif se Ye)
  * 5 Quiz (76 sawalat), Islami Math (15), Hifz Game (10)
  * Ramadan, Eid, Hajj, Shab-e-Qadr, Mashhoor Masajid,
    Islami Mumalik, Chand, Islami Art, Hijab

NOTE: Android app ki tarah ye bhi TEXT-ONLY hai -
koi awaz/TTS nahi, taake bache khud parhna seekhein.

FILES:
  main.py  - app ka code (Python + tkinter)
  data.py  - sara taleemi content
  run.bat  - app chalane ke liye (double-click)
  README.txt - ye file
