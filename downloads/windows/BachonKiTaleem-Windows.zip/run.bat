@echo off
REM ============================================================
REM  Bachon ki Islamic Taleem v4.0 - Windows App Launcher
REM  Developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
REM ============================================================
title Bachon ki Islamic Taleem v4.0
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Python 3 install nahi hai!
    echo  Python yahan se muft install karein: https://www.python.org/downloads/
    echo  (Install ke waqt "Add python.exe to PATH" zaroor tick karein)
    echo.
    pause
    exit /b 1
)

python main.py
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] App start nahi ho saki. Python dobara install karke dekhein.
    echo.
    pause
)
