"""
PDF Master Windows v1.0
Merge PDFs, split page ranges, rotate pages, view PDF info.
Dependencies: pypdf (pip install pypdf)
Runs on Windows with Python 3: python main.py
"""
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from pypdf import PdfReader, PdfWriter
    PYPDF_AVAILABLE = True
except ImportError:
    PdfReader = PdfWriter = None
    PYPDF_AVAILABLE = False

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
EMERALD_LIGHT = "#12976F"
GOLD = "#D4AF37"
GOLD_DARK = "#A8842A"
CREAM = "#FAF8F0"
TEXT_DARK = "#1E2B26"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"


def parse_page_ranges(spec, total_pages):
    """Parse '1-3,5,8-10' (1-based) into sorted unique 0-based page indices."""
    pages = set()
    if not spec:
        return []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a.strip()), int(b.strip())
            if start > end:
                start, end = end, start
            for p in range(start, end + 1):
                if 1 <= p <= total_pages:
                    pages.add(p - 1)
        else:
            p = int(part)
            if 1 <= p <= total_pages:
                pages.add(p - 1)
    return sorted(pages)


def merge_pdfs(inputs, output):
    writer = PdfWriter()
    for path in inputs:
        reader = PdfReader(path)
        for page in reader.pages:
            writer.add_page(page)
    with open(output, "wb") as f:
        writer.write(f)
    return len(inputs)


def split_pdf(input_path, pages, output):
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for i in pages:
        writer.add_page(reader.pages[i])
    with open(output, "wb") as f:
        writer.write(f)
    return len(pages)


def rotate_pdf(input_path, pages, angle, output):
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for idx, page in enumerate(reader.pages):
        if idx in pages:
            page.rotate(angle)
        writer.add_page(page)
    with open(output, "wb") as f:
        writer.write(f)
    return len(pages)


def pdf_info_text(path):
    reader = PdfReader(path)
    meta = reader.metadata or {}
    lines = [
        "File: %s" % os.path.basename(path),
        "Size: %.1f KB" % (os.path.getsize(path) / 1024.0),
        "Pages: %d" % len(reader.pages),
        "Title: %s" % (meta.get("/Title") or "-"),
        "Author: %s" % (meta.get("/Author") or "-"),
    ]
    return "\n".join(lines)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PDF Master - Malik Muhammad Anwaar")
        self.geometry("680x560")
        self.configure(bg=CREAM)
        self.resizable(False, False)

        header = tk.Frame(self, bg=DEEP_EMERALD, height=64)
        header.pack(fill="x")
        tk.Label(header, text="PDF MASTER", font=("Segoe UI", 18, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=16, pady=12)
        tk.Label(header, text="Merge  •  Split  •  Rotate  •  Info",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                 side="left", padx=8, pady=12)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self._build_merge_tab()
        self._build_split_tab()
        self._build_rotate_tab()
        self._build_info_tab()

        footer = tk.Frame(self, bg=DEEP_EMERALD)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 9, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

        if not PYPDF_AVAILABLE:
            messagebox.showwarning(
                "Missing dependency",
                "The 'pypdf' library is not installed.\n"
                "Run: pip install -r requirements.txt\n"
                "then restart the app.")

    # ---------- small helpers ----------
    def _style_buttons(self, parent):
        style = ttk.Style(self)
        style.configure("Emerald.TButton", font=("Segoe UI", 10, "bold"),
                        foreground=TEXT_DARK)
        for child in parent.winfo_children():
            if isinstance(child, ttk.Button):
                child.configure(style="Emerald.TButton")

    def _output_path(self, default_name):
        return filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            initialfile=default_name)

    # ---------- MERGE tab ----------
    def _build_merge_tab(self):
        tab = tk.Frame(self.notebook, bg=CREAM)
        self.notebook.add(tab, text="  Merge  ")
        self.merge_files = []

        tk.Label(tab, text="Select PDF files to merge (in order):",
                 font=("Segoe UI", 10, "bold"), bg=CREAM,
                 fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(12, 4))
        self.merge_list = tk.Listbox(tab, height=10, font=("Segoe UI", 10),
                                     bg="white", fg=TEXT_DARK,
                                     selectmode=tk.EXTENDED)
        self.merge_list.pack(fill="both", expand=True, padx=14)

        btns = tk.Frame(tab, bg=CREAM)
        btns.pack(pady=10)
        ttk.Button(btns, text="Add PDFs", command=self._merge_add).pack(
            side="left", padx=6)
        ttk.Button(btns, text="Remove selected",
                   command=self._merge_remove).pack(side="left", padx=6)
        ttk.Button(btns, text="Clear all", command=self._merge_clear).pack(
            side="left", padx=6)
        self._style_buttons(btns)

        merge_bar = tk.Frame(tab, bg=CREAM)
        merge_bar.pack(pady=4)
        ttk.Button(merge_bar, text="MERGE → Save As…",
                   command=self._do_merge).pack(padx=6)
        self._style_buttons(merge_bar)

    def _merge_add(self):
        paths = filedialog.askopenfilenames(
            filetypes=[("PDF files", "*.pdf")])
        for p in paths:
            if p not in self.merge_files:
                self.merge_files.append(p)
                self.merge_list.insert("end", p)

    def _merge_remove(self):
        for i in sorted(self.merge_list.curselection(), reverse=True):
            self.merge_list.delete(i)
            del self.merge_files[i]

    def _merge_clear(self):
        self.merge_files.clear()
        self.merge_list.delete(0, "end")

    def _do_merge(self):
        if not PYPDF_AVAILABLE:
            return messagebox.showerror(
                "Error", "pypdf is not installed. Run: pip install pypdf")
        if len(self.merge_files) < 2:
            return messagebox.showinfo(
                "Merge", "Add at least two PDF files to merge.")
        out = self._output_path("merged.pdf")
        if not out:
            return
        try:
            n = merge_pdfs(self.merge_files, out)
            messagebox.showinfo(
                "Done", "Merged %d files successfully!\nSaved to:\n%s"
                % (n, out))
        except Exception as e:
            messagebox.showerror("Merge failed", str(e))

    # ---------- SPLIT tab ----------
    def _build_split_tab(self):
        tab = tk.Frame(self.notebook, bg=CREAM)
        self.notebook.add(tab, text="  Split  ")
        self.split_path = tk.StringVar()

        tk.Label(tab, text="Source PDF:", font=("Segoe UI", 10, "bold"),
                 bg=CREAM, fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(12, 2))
        row = tk.Frame(tab, bg=CREAM)
        row.pack(fill="x", padx=14)
        tk.Entry(row, textvariable=self.split_path, font=("Segoe UI", 10),
                 width=52).pack(side="left", padx=(0, 6))
        ttk.Button(row, text="Browse…",
                   command=lambda: self._browse_into(self.split_path)
                   ).pack(side="left")
        self._style_buttons(row)

        tk.Label(tab, text="Pages to extract (e.g. 1-3,5,8-10):",
                 font=("Segoe UI", 10, "bold"), bg=CREAM,
                 fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(10, 2))
        self.split_spec = tk.Entry(tab, font=("Segoe UI", 11), width=40)
        self.split_spec.pack(anchor="w", padx=14)
        self.split_spec.insert(0, "1-3")

        tk.Frame(tab, bg=CREAM, height=20).pack()
        ttk.Button(tab, text="SPLIT → Save As…",
                   command=self._do_split).pack(pady=10)
        self._style_buttons(tab)

    def _browse_into(self, var):
        path = filedialog.askopenfilename(
            filetypes=[("PDF files", "*.pdf")])
        if path:
            var.set(path)

    def _do_split(self):
        if not PYPDF_AVAILABLE:
            return messagebox.showerror(
                "Error", "pypdf is not installed. Run: pip install pypdf")
        src = self.split_path.get().strip()
        if not os.path.isfile(src):
            return messagebox.showinfo("Split", "Choose a valid PDF file.")
        try:
            total = len(PdfReader(src).pages)
            pages = parse_page_ranges(self.split_spec.get(), total)
        except ValueError:
            return messagebox.showerror(
                "Invalid input",
                "Page range must look like: 1-3,5,8-10")
        if not pages:
            return messagebox.showinfo(
                "Split", "No valid pages found in that range.")
        out = self._output_path("split.pdf")
        if not out:
            return
        try:
            n = split_pdf(src, pages, out)
            messagebox.showinfo(
                "Done", "Extracted %d page(s).\nSaved to:\n%s" % (n, out))
        except Exception as e:
            messagebox.showerror("Split failed", str(e))

    # ---------- ROTATE tab ----------
    def _build_rotate_tab(self):
        tab = tk.Frame(self.notebook, bg=CREAM)
        self.notebook.add(tab, text="  Rotate  ")
        self.rot_path = tk.StringVar()
        self.rot_angle = tk.IntVar(value=90)

        tk.Label(tab, text="Source PDF:", font=("Segoe UI", 10, "bold"),
                 bg=CREAM, fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(12, 2))
        row = tk.Frame(tab, bg=CREAM)
        row.pack(fill="x", padx=14)
        tk.Entry(row, textvariable=self.rot_path, font=("Segoe UI", 10),
                 width=52).pack(side="left", padx=(0, 6))
        ttk.Button(row, text="Browse…",
                   command=lambda: self._browse_into(self.rot_path)
                   ).pack(side="left")
        self._style_buttons(row)

        tk.Label(tab, text="Rotation angle:", font=("Segoe UI", 10, "bold"),
                 bg=CREAM, fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(10, 2))
        angles = tk.Frame(tab, bg=CREAM)
        angles.pack(anchor="w", padx=14)
        for a in (90, 180, 270):
            tk.Radiobutton(angles, text="%d°" % a, variable=self.rot_angle,
                           value=a, font=("Segoe UI", 10), bg=CREAM,
                           fg=TEXT_DARK).pack(side="left", padx=8)

        tk.Label(tab, text="Pages (leave blank = all, or e.g. 1-3,5):",
                 font=("Segoe UI", 10, "bold"), bg=CREAM,
                 fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(10, 2))
        self.rot_spec = tk.Entry(tab, font=("Segoe UI", 11), width=40)
        self.rot_spec.pack(anchor="w", padx=14)

        tk.Frame(tab, bg=CREAM, height=20).pack()
        ttk.Button(tab, text="ROTATE → Save As…",
                   command=self._do_rotate).pack(pady=10)
        self._style_buttons(tab)

    def _do_rotate(self):
        if not PYPDF_AVAILABLE:
            return messagebox.showerror(
                "Error", "pypdf is not installed. Run: pip install pypdf")
        src = self.rot_path.get().strip()
        if not os.path.isfile(src):
            return messagebox.showinfo("Rotate", "Choose a valid PDF file.")
        try:
            total = len(PdfReader(src).pages)
            spec = self.rot_spec.get().strip()
            pages = parse_page_ranges(spec, total) if spec else list(
                range(total))
        except ValueError:
            return messagebox.showerror(
                "Invalid input",
                "Page range must look like: 1-3,5 (or leave blank for all)")
        out = self._output_path("rotated.pdf")
        if not out:
            return
        try:
            n = rotate_pdf(src, pages, self.rot_angle.get(), out)
            messagebox.showinfo(
                "Done", "Rotated %d page(s) by %d°.\nSaved to:\n%s"
                % (n, self.rot_angle.get(), out))
        except Exception as e:
            messagebox.showerror("Rotate failed", str(e))

    # ---------- INFO tab ----------
    def _build_info_tab(self):
        tab = tk.Frame(self.notebook, bg=CREAM)
        self.notebook.add(tab, text="  PDF Info  ")
        self.info_path = tk.StringVar()

        tk.Label(tab, text="Source PDF:", font=("Segoe UI", 10, "bold"),
                 bg=CREAM, fg=TEXT_DARK).pack(anchor="w", padx=14, pady=(12, 2))
        row = tk.Frame(tab, bg=CREAM)
        row.pack(fill="x", padx=14)
        tk.Entry(row, textvariable=self.info_path, font=("Segoe UI", 10),
                 width=52).pack(side="left", padx=(0, 6))
        ttk.Button(row, text="Browse…",
                   command=lambda: self._browse_into(self.info_path)
                   ).pack(side="left")
        self._style_buttons(row)

        ttk.Button(tab, text="Show Info", command=self._do_info).pack(pady=12)
        self._style_buttons(tab)

        self.info_box = tk.Text(tab, height=10, font=("Consolas", 10),
                                bg="white", fg=TEXT_DARK, state="disabled")
        self.info_box.pack(fill="both", expand=True, padx=14, pady=(0, 14))

    def _do_info(self):
        if not PYPDF_AVAILABLE:
            return messagebox.showerror(
                "Error", "pypdf is not installed. Run: pip install pypdf")
        src = self.info_path.get().strip()
        if not os.path.isfile(src):
            return messagebox.showinfo("Info", "Choose a valid PDF file.")
        try:
            text = pdf_info_text(src)
        except Exception as e:
            return messagebox.showerror("Read failed", str(e))
        self.info_box.configure(state="normal")
        self.info_box.delete("1.0", "end")
        self.info_box.insert("1.0", text)
        self.info_box.configure(state="disabled")


if __name__ == "__main__":
    App().mainloop()
