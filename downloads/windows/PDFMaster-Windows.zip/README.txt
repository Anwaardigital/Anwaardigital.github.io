==============================================
 PDF MASTER v1.0 (Windows)
==============================================
Merge PDFs, split page ranges, rotate pages,
and view PDF information.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Open a Command Prompt in this folder and run:
       pip install -r requirements.txt
3. Double-click run.bat (or run: python main.py)

FEATURES
--------
- Merge: add 2+ PDF files in order, merge into one PDF
- Split: extract pages using ranges like 1-3,5,8-10
- Rotate: rotate all or selected pages by 90/180/270 degrees
- PDF Info: page count, title, author, file size

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
