#!/usr/bin/env python3
"""
CV Maker - Windows Desktop App
Developed by Malik Muhammad Anwaar | WhatsApp: 923288317526

Create a professional CV from a simple form.
Exports to .txt and styled .html.
Standard library only (tkinter).
"""

import os
import re
import html as htmlmod
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

DEV_FOOTER = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

EMERALD = "#0E7C5B"
EMERALD_DARK = "#0A5C44"
GOLD = "#C9A227"
GOLD_LIGHT = "#F3E6BE"
CREAM = "#FAF7F0"
WHITE = "#FFFFFF"
INK = "#1F2A24"
MUTED = "#5B6B63"


def sanitize_filename(name: str) -> str:
    name = (name or "cv").strip()
    name = re.sub(r"[^\w\- .]", "_", name)
    name = re.sub(r"\s+", "_", name)
    return name[:60] or "cv"


def build_cv_text(data: dict) -> str:
    line = "=" * 60
    thin = "-" * 60
    parts = [line, f"{data['name']}".upper().center(60), line, ""]
    contact = []
    if data["phone"]:
        contact.append(f"Phone: {data['phone']}")
    if data["email"]:
        contact.append(f"Email: {data['email']}")
    if data["address"]:
        contact.append(f"Address: {data['address']}")
    if contact:
        parts.append(" | ".join(contact))
        parts.append("")

    sections = [
        ("OBJECTIVE", data["objective"]),
        ("EDUCATION", data["education"]),
        ("EXPERIENCE", data["experience"]),
        ("SKILLS", data["skills"]),
    ]
    for title, body in sections:
        if body.strip():
            parts += [title, thin, body.strip(), ""]
    if data["extra"].strip():
        parts += ["ADDITIONAL INFORMATION", thin, data["extra"].strip(), ""]
    return "\n".join(parts).rstrip() + "\n"


def build_cv_html(data: dict) -> str:
    esc = htmlmod.escape
    contact_bits = []
    if data["phone"]:
        contact_bits.append(f"&#9742; {esc(data['phone'])}")
    if data["email"]:
        contact_bits.append(f"&#9993; {esc(data['email'])}")
    if data["address"]:
        contact_bits.append(f"&#9758; {esc(data['address'])}")
    contact_html = " &nbsp;|&nbsp; ".join(contact_bits)

    def para(text):
        text = esc(text.strip()).replace("\n", "<br>")
        return f"<p>{text}</p>"

    sections = [
        ("Objective", data["objective"]),
        ("Education", data["education"]),
        ("Experience", data["experience"]),
        ("Skills", data["skills"]),
        ("Additional Information", data["extra"]),
    ]
    body_sections = ""
    for title, content in sections:
        if content.strip():
            body_sections += f"<h2>{title}</h2>\n{para(content)}\n"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>CV - {esc(data['name'])}</title>
<style>
  body {{ font-family: Georgia, 'Times New Roman', serif; color: #222; max-width: 800px; margin: 40px auto; padding: 0 24px; background: #faf7f0; }}
  .card {{ background: #fff; border-top: 8px solid #0E7C5B; border-bottom: 6px solid #C9A227; padding: 36px 44px; box-shadow: 0 2px 12px rgba(0,0,0,.08); }}
  h1 {{ color: #0A5C44; margin: 0 0 6px; font-size: 34px; letter-spacing: 1px; }}
  .contact {{ color: #5B6B63; margin-bottom: 24px; font-size: 14px; }}
  h2 {{ color: #0E7C5B; border-bottom: 2px solid #C9A227; padding-bottom: 4px; font-size: 19px; margin-top: 26px; }}
  p {{ line-height: 1.7; font-size: 15px; }}
  .footer {{ text-align: center; color: #888; font-size: 12px; margin-top: 28px; }}
</style>
</head>
<body>
<div class="card">
  <h1>{esc(data['name'])}</h1>
  <div class="contact">{contact_html}</div>
  {body_sections}
</div>
<div class="footer">App developed by Malik Muhammad Anwaar &nbsp;|&nbsp; WhatsApp: 923288317526</div>
</body>
</html>
"""


class CVMaker(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CV Maker - by Malik Muhammad Anwaar")
        self.geometry("1080x720")
        self.configure(bg=CREAM)
        self.minsize(960, 640)

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Header.TLabel", background=EMERALD_DARK, foreground="white",
                        font=("Segoe UI", 16, "bold"))
        style.configure("Gold.TButton", background=GOLD, foreground="black",
                        font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Em.TButton", background=EMERALD, foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("TLabel", background=CREAM, font=("Segoe UI", 10))

        # ---- Header ----
        header = tk.Frame(self, bg=EMERALD_DARK, height=64)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  CV Maker", bg=EMERALD_DARK, fg="white",
                 font=("Segoe UI", 18, "bold")).pack(side="left")
        tk.Label(header, text="Emerald & Gold Edition  ", bg=EMERALD_DARK, fg=GOLD_LIGHT,
                 font=("Segoe UI", 10, "italic")).pack(side="right", padx=10)

        # ---- Main split: form (left) + preview (right) ----
        main = tk.PanedWindow(self, orient="horizontal", bg=CREAM, sashwidth=6)
        main.pack(fill="both", expand=True, padx=8, pady=8)

        form_frame = tk.Frame(main, bg=CREAM)
        prev_frame = tk.Frame(main, bg=CREAM)
        main.add(form_frame, minsize=380)
        main.add(prev_frame, minsize=380)

        # ---- Form ----
        canvas = tk.Canvas(form_frame, bg=CREAM, highlightthickness=0)
        scrollbar = ttk.Scrollbar(form_frame, orient="vertical", command=canvas.yview)
        scrollable = tk.Frame(canvas, bg=CREAM)
        scrollable.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.fields = {}
        self.texts = {}

        def add_entry(label, key, multiline=False):
            row = tk.Frame(scrollable, bg=CREAM)
            row.pack(fill="x", padx=10, pady=5)
            tk.Label(row, text=label, bg=CREAM, fg=INK, font=("Segoe UI", 10, "bold"),
                     anchor="w").pack(fill="x")
            if multiline:
                t = scrolledtext.ScrolledText(row, height=5, wrap="word",
                                              font=("Segoe UI", 10), bg=WHITE,
                                              relief="solid", borderwidth=1)
                t.pack(fill="x")
                self.texts[key] = t
            else:
                e = ttk.Entry(row, font=("Segoe UI", 10))
                e.pack(fill="x", ipady=4)
                self.fields[key] = e

        add_entry("Full Name *", "name")
        add_entry("Phone", "phone")
        add_entry("Email", "email")
        add_entry("Address", "address")
        add_entry("Objective", "objective", multiline=True)
        add_entry("Education", "education", multiline=True)
        add_entry("Experience", "experience", multiline=True)
        add_entry("Skills", "skills", multiline=True)
        add_entry("Additional Information", "extra", multiline=True)

        btn_bar = tk.Frame(scrollable, bg=CREAM)
        btn_bar.pack(fill="x", padx=10, pady=12)
        ttk.Button(btn_bar, text="Update Preview", command=self.update_preview,
                   style="Em.TButton").pack(side="left", padx=4)
        ttk.Button(btn_bar, text="Save as .txt", command=lambda: self.save_file("txt"),
                   style="Gold.TButton").pack(side="left", padx=4)
        ttk.Button(btn_bar, text="Save as .html", command=lambda: self.save_file("html"),
                   style="Gold.TButton").pack(side="left", padx=4)

        # ---- Preview ----
        tk.Label(prev_frame, text="Live Preview", bg=CREAM, fg=EMERALD_DARK,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=10, pady=(4, 2))
        self.preview = scrolledtext.ScrolledText(prev_frame, wrap="word", state="disabled",
                                                 font=("Consolas", 10), bg=WHITE,
                                                 relief="solid", borderwidth=1)
        self.preview.pack(fill="both", expand=True, padx=10, pady=(0, 6))

        # ---- Footer ----
        footer = tk.Frame(self, bg=EMERALD_DARK, height=28)
        footer.pack(fill="x")
        footer.pack_propagate(False)
        tk.Label(footer, text=DEV_FOOTER, bg=EMERALD_DARK, fg=GOLD_LIGHT,
                 font=("Segoe UI", 9)).pack()

        self.update_preview()

    def collect(self) -> dict:
        data = {k: w.get().strip() for k, w in self.fields.items()}
        for k, w in self.texts.items():
            data[k] = w.get("1.0", "end").strip()
        return data

    def update_preview(self):
        data = self.collect()
        if not data["name"]:
            data["name"] = "Your Name"
        text = build_cv_text(data)
        self.preview.config(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", text)
        self.preview.config(state="disabled")

    def save_file(self, kind: str):
        data = self.collect()
        if not data["name"]:
            messagebox.showwarning("Missing name", "Please enter your full name first.")
            return
        base = sanitize_filename(data["name"]) + "_CV"
        if kind == "txt":
            content = build_cv_text(data)
            types = [("Text file", "*.txt")]
            fname = base + ".txt"
        else:
            content = build_cv_html(data)
            types = [("HTML file", "*.html")]
            fname = base + ".html"
        path = filedialog.asksaveasfilename(defaultextension=f".{kind}",
                                            initialfile=fname,
                                            filetypes=types)
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            messagebox.showinfo("Saved", f"CV saved successfully:\n{os.path.basename(path)}")
        except OSError as e:
            messagebox.showerror("Error", f"Could not save file:\n{e}")


def main():
    app = CVMaker()
    app.mainloop()


if __name__ == "__main__":
    main()
