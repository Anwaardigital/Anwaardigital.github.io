CV Maker for Windows
===================
App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526

HOW TO RUN (Windows):
1. Make sure Python 3 is installed (download from python.org if needed).
   During installation, tick "Add Python to PATH".
2. Double-click run.bat (or open a terminal in this folder and type: python main.py)

HOW TO USE:
1. Fill in the form on the left (name, phone, email, education, experience, skills...).
2. Click "Update Preview" to see your CV on the right.
3. Click "Save as .txt" for a plain-text CV, or "Save as .html" for a nicely
   styled CV you can open in any browser and print to PDF.

No internet connection needed. No extra libraries to install.
