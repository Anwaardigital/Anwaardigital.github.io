"""
Music Player Windows v1.0
Playlist manager: scan a folder for audio files, playlist with add/remove,
play via the system default player, track info (name, size, modified date).
Runs on Windows with Python 3: python main.py  (no extra packages needed)
"""
import os
import subprocess
import sys
import tkinter as tk
from tkinter import filedialog, messagebox

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
GOLD = "#D4AF37"
CREAM = "#FAF8F0"
WHITE = "#FFFFFF"
TEXT_DARK = "#1E2B26"
MUTED = "#5A6B63"
ROW_EVEN = "#F7F5EC"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

AUDIO_EXTS = (".mp3", ".wav", ".ogg", ".flac", ".m4a", ".aac", ".wma", ".opus")


def open_with_default(path):
    """Open a file in the OS default player."""
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa: S606  (Windows only API)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def fmt_size(num_bytes):
    for unit in ("B", "KB", "MB", "GB"):
        if num_bytes < 1024.0 or unit == "GB":
            return f"{num_bytes:,.1f} {unit}"
        num_bytes /= 1024.0


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Music Player - Malik Muhammad Anwaar")
        self.geometry("700x600")
        self.configure(bg=CREAM)
        self.resizable(False, False)

        self.tracks = []  # list of dicts: path, name, size, mtime
        self.now_playing = None

        # ---- header ----
        header = tk.Frame(self, bg=DEEP_EMERALD, height=70)
        header.pack(fill="x")
        tk.Label(header, text="MUSIC PLAYER", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=18, pady=12)
        tk.Label(header, text="Playlist  •  Add  •  Remove  •  Play",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                     side="left", padx=6, pady=24)
        tk.Label(header, text="🎵", font=("Segoe UI", 26),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="right", padx=20)

        # ---- toolbar ----
        bar = tk.Frame(self, bg=CREAM)
        bar.pack(fill="x", padx=14, pady=(10, 4))
        btn_style = dict(font=("Segoe UI", 9, "bold"), relief="flat",
                         padx=10, pady=6, cursor="hand2")
        tk.Button(bar, text="📁 Scan Folder…", bg=EMERALD, fg=WHITE,
                  activebackground=DEEP_EMERALD, activeforeground=WHITE,
                  command=self.scan_folder, **btn_style).pack(side="left")
        tk.Button(bar, text="＋ Add Files…", bg=WHITE, fg=TEXT_DARK,
                  activebackground="#EEEAE0", command=self.add_files,
                  **btn_style).pack(side="left", padx=6)
        tk.Button(bar, text="− Remove", bg=WHITE, fg=TEXT_DARK,
                  activebackground="#EEEAE0", command=self.remove_selected,
                  **btn_style).pack(side="left")
        tk.Button(bar, text="🗑 Clear", bg=WHITE, fg=TEXT_DARK,
                  activebackground="#EEEAE0", command=self.clear_all,
                  **btn_style).pack(side="left", padx=6)
        tk.Button(bar, text="▶ Play", bg=GOLD, fg=DEEP_EMERALD,
                  activebackground="#C19A2E", command=self.play_selected,
                  **btn_style).pack(side="right")

        # ---- now playing ----
        self.np_lbl = tk.Label(self, text="♪ Koi gana nahi chal raha",
                               font=("Segoe UI", 11, "bold"), fg=DEEP_EMERALD,
                               bg=CREAM, anchor="w")
        self.np_lbl.pack(fill="x", padx=16, pady=(2, 2))

        # ---- playlist ----
        pl_frame = tk.Frame(self, bg=WHITE)
        pl_frame.pack(fill="both", expand=True, padx=14, pady=6)
        pl_frame.configure(highlightbackground="#E3DCC8", highlightthickness=1)
        tk.Label(pl_frame, text="PLAYLIST", font=("Segoe UI", 11, "bold"),
                 fg=DEEP_EMERALD, bg=WHITE).pack(pady=(10, 2))
        self.listbox = tk.Listbox(pl_frame, font=("Segoe UI", 10), bg=WHITE,
                                  fg=TEXT_DARK, relief="flat",
                                  selectbackground=EMERALD, selectforeground=WHITE,
                                  activestyle="none", height=15)
        self.listbox.pack(fill="both", expand=True, padx=12, pady=6)
        self.listbox.bind("<Double-1>", lambda _e: self.play_selected())

        # ---- track info ----
        info_frame = tk.Frame(self, bg=WHITE)
        info_frame.pack(fill="x", padx=14, pady=(0, 6))
        info_frame.configure(highlightbackground="#E3DCC8", highlightthickness=1)
        self.info_lbl = tk.Label(info_frame, text="Track select karen — info yahan aayegi",
                                 font=("Segoe UI", 9), fg=MUTED, bg=WHITE,
                                 anchor="w", justify="left")
        self.info_lbl.pack(fill="x", padx=12, pady=8)
        self.listbox.bind("<<ListboxSelect>>", lambda _e: self.show_info())

        self.status_lbl = tk.Label(self, text="Ready",
                                   font=("Segoe UI", 9, "italic"), fg=MUTED, bg=CREAM,
                                   anchor="w")
        self.status_lbl.pack(fill="x", padx=16, pady=(0, 6))

        # ---- footer ----
        footer = tk.Frame(self, bg=DEEP_EMERALD, height=34)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 8),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

    # ---------------- playlist ops ----------------
    def add_tracks(self, paths):
        added = 0
        existing = {t["path"] for t in self.tracks}
        for p in paths:
            if p not in existing and os.path.isfile(p):
                st = os.stat(p)
                self.tracks.append({"path": p, "name": os.path.basename(p),
                                    "size": st.st_size, "mtime": st.st_mtime})
                existing.add(p)
                added += 1
        self.refresh_list()
        self.status_lbl.config(text=f"{added} track(s) add hue — kul {len(self.tracks)}")

    def scan_folder(self):
        folder = filedialog.askdirectory(title="Choose a music folder")
        if not folder:
            return
        found = []
        for root, _dirs, files in os.walk(folder):
            for f in sorted(files):
                if f.lower().endswith(AUDIO_EXTS):
                    found.append(os.path.join(root, f))
        self.add_tracks(found)

    def add_files(self):
        paths = filedialog.askopenfilenames(
            title="Add audio files",
            filetypes=[("Audio", "*.mp3 *.wav *.ogg *.flac *.m4a *.aac *.wma *.opus"),
                       ("All files", "*.*")])
        if paths:
            self.add_tracks(list(paths))

    def remove_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showinfo("Select track", "Pehle playlist se aik track select karen.")
            return
        idx = sel[0]
        del self.tracks[idx]
        self.refresh_list()
        self.status_lbl.config(text=f"Track hata diya — kul {len(self.tracks)}")

    def clear_all(self):
        if not self.tracks:
            return
        if messagebox.askyesno("Clear playlist", "Poori playlist saaf kar den?"):
            self.tracks = []
            self.now_playing = None
            self.np_lbl.config(text="♪ Koi gana nahi chal raha")
            self.refresh_list()
            self.info_lbl.config(text="Track select karen — info yahan aayegi")

    def refresh_list(self):
        self.listbox.delete(0, "end")
        for t in self.tracks:
            marker = "▶ " if t["path"] == self.now_playing else "  "
            self.listbox.insert("end", marker + t["name"])

    # ---------------- playback ----------------
    def play_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showinfo("Select track", "Pehle playlist se aik track select karen.")
            return
        t = self.tracks[sel[0]]
        try:
            open_with_default(t["path"])
            self.now_playing = t["path"]
            self.np_lbl.config(text=f"▶ Chal raha hai: {t['name']}")
            self.status_lbl.config(text="System default player mein khol diya")
            self.refresh_list()
            self.listbox.selection_set(sel[0])
        except Exception as e:
            messagebox.showerror("Play failed", f"Track nahi chal saka:\n{e}")

    def show_info(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        t = self.tracks[sel[0]]
        import datetime
        mtime = datetime.datetime.fromtimestamp(t["mtime"]).strftime("%d-%m-%Y %H:%M")
        self.info_lbl.config(
            text=f"🎵 {t['name']}   •   Size: {fmt_size(t['size'])}   •   Modified: {mtime}")


if __name__ == "__main__":
    App().mainloop()
