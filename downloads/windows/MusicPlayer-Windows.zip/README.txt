==============================================
 MUSIC PLAYER v1.0 (Windows)
==============================================
Playlist manager — folder se audio scan karen ya
files add karen, playlist banayen, aur system ke
default player mein gana chalayen.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Double-click run.bat (or run: python main.py)

CONTROLS
--------
- "Scan Folder..." :  Poore folder (sub-folders samet) se
                      MP3/WAV/OGG/FLAC/M4A waghera dhoonden
- "Add Files..."   :  Apne pasand ke tracks add karen
- Double-click ya "Play"  :  Track default music player mein chalega
- "Remove"         :  Selected track playlist se hatayen
- "Clear"          :  Poori playlist saaf karen
- Track select karne par neeche name, size aur date nazar aayegi

Note: Playback ke liye Windows ka default music player
(Music app / Windows Media Player) istemal hota hai.

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
