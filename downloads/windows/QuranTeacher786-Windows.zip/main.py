# -*- coding: utf-8 -*-
"""
Quran Teacher 786 — Windows Desktop App
Quran teacher directory: sample teacher profiles, search, filters
(subject / city / mode). Python 3 + Tkinter only (no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import os
import tkinter as tk
from tkinter import ttk, messagebox

BG = "#0A3D2E"        # deep emerald
BG_DARK = "#062B20"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
ACCENT = "#0E5C44"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

TEACHERS = [
    {"name": "Qari Muhammad Imran", "ur": "قاری محمد عمران", "subject": "Nazra Quran", "city": "Lahore",
     "exp": 12, "fee": "Rs. 2000/month", "mode": "Home + Online", "phone": "0300-0000001",
     "note": "Nazra with tajweed basics — kids & adults."},
    {"name": "Hafiz Abdul Rehman", "ur": "حافظ عبدالرحمن", "subject": "Hifz", "city": "Karachi",
     "exp": 15, "fee": "Rs. 3000/month", "mode": "Online", "phone": "0300-0000002",
     "note": "Hifz program with sabaq/sabqi/manzil system."},
    {"name": "Qaria Amina Siddiqah", "ur": "قاریہ آمنہ صدیقہ", "subject": "Nazra Quran", "city": "Islamabad",
     "exp": 8, "fee": "Rs. 2500/month", "mode": "Online", "phone": "0300-0000003",
     "note": "Female teacher — girls & ladies only."},
    {"name": "Mufti Bilal Ahmed", "ur": "مفتی بلال احمد", "subject": "Tajweed", "city": "Faisalabad",
     "exp": 18, "fee": "Rs. 3500/month", "mode": "Home", "phone": "0300-0000004",
     "note": "Advanced tajweed & qirat certificate holder."},
    {"name": "Qari Usman Tariq", "ur": "قاری عثمان طارق", "subject": "Qirat", "city": "Multan",
     "exp": 10, "fee": "Rs. 3000/month", "mode": "Online", "phone": "0300-0000005",
     "note": "Beautiful tilawat training, all ages."},
    {"name": "Hafiza Maryam Khan", "ur": "حافظہ مریم خان", "subject": "Hifz", "city": "Rawalpindi",
     "exp": 7, "fee": "Rs. 2500/month", "mode": "Online", "phone": "0300-0000006",
     "note": "Female hifz teacher — patient with kids."},
    {"name": "Molvi Shahid Mehmood", "ur": "مولوی شاہد محمود", "subject": "Tarjuma", "city": "Lahore",
     "exp": 20, "fee": "Rs. 4000/month", "mode": "Home + Online", "phone": "0300-0000007",
     "note": "Quran with Urdu tarjuma & tafseer basics."},
    {"name": "Qari Daniyal Raza", "ur": "قاری دانیال رضا", "subject": "Nazra Quran", "city": "Karachi",
     "exp": 5, "fee": "Rs. 1500/month", "mode": "Online", "phone": "0300-0000008",
     "note": "Affordable classes for beginners."},
    {"name": "Hafiz Zubair Anwar", "ur": "حافظ زبیر انور", "subject": "Tajweed", "city": "Peshawar",
     "exp": 11, "fee": "Rs. 2500/month", "mode": "Home", "phone": "0300-0000009",
     "note": "Tajweed correction sessions (islah)."},
    {"name": "Qaria Fatima Noor", "ur": "قاریہ فاطمہ نور", "subject": "Nazra Quran", "city": "Quetta",
     "exp": 9, "fee": "Rs. 2000/month", "mode": "Online", "phone": "0300-0000010",
     "note": "Female teacher — flexible timings."},
    {"name": "Qari Salman Farooq", "ur": "قاری سلمان فاروق", "subject": "Hifz", "city": "Sialkot",
     "exp": 13, "fee": "Rs. 3000/month", "mode": "Home + Online", "phone": "0300-0000011",
     "note": "Hifz + school subjects balance plan."},
    {"name": "Alima Sadia Aslam", "ur": "عالمہ سعدیہ اسلم", "subject": "Tarjuma", "city": "Hyderabad",
     "exp": 14, "fee": "Rs. 3500/month", "mode": "Online", "phone": "0300-0000012",
     "note": "Ladies tarjuma & masail classes."},
]

SUBJECTS = ["All", "Nazra Quran", "Hifz", "Tajweed", "Qirat", "Tarjuma"]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Quran Teacher 786 — قرآن ٹیچر")
        self.geometry("900x620")
        self.configure(bg=BG)
        self._build()

    def _build(self):
        head = tk.Frame(self, bg=BG_DARK, height=86)
        head.pack(fill="x")
        tk.Label(head, text="🕌 Quran Teacher 786", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(pady=(10, 0))
        tk.Label(head, text="Find Quran teachers — profiles & search (Urdu/English)",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG_DARK).pack(pady=(0, 8))

        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=12, pady=10)
        tk.Label(bar, text="🔎", font=("Segoe UI", 12), fg=GOLD, bg=BG).pack(side="left")
        self.q = tk.StringVar()
        qe = tk.Entry(bar, textvariable=self.q, font=("Segoe UI", 11), width=28)
        qe.pack(side="left", padx=6)
        qe.bind("<KeyRelease>", lambda e: self.refresh())

        tk.Label(bar, text="Subject:", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left", padx=(12, 4))
        self.sub = ttk.Combobox(bar, values=SUBJECTS, state="readonly",
                                width=13, font=("Segoe UI", 10))
        self.sub.set("All")
        self.sub.pack(side="left")
        self.sub.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        cities = ["All"] + sorted({t["city"] for t in TEACHERS})
        tk.Label(bar, text="City:", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left", padx=(12, 4))
        self.city = ttk.Combobox(bar, values=cities, state="readonly",
                                 width=12, font=("Segoe UI", 10))
        self.city.set("All")
        self.city.pack(side="left")
        self.city.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        tk.Button(bar, text="Clear", font=("Segoe UI", 10, "bold"),
                  bg=GOLD, fg=BG_DARK, relief="flat", padx=10,
                  command=self.clear).pack(side="left", padx=12)

        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True, padx=12)

        left = tk.Frame(mid, bg=BG)
        left.pack(side="left", fill="y", padx=(0, 10))
        tk.Label(left, text="Teachers", font=("Segoe UI", 11, "bold"),
                 fg=GOLD, bg=BG).pack(anchor="w")
        self.lb = tk.Listbox(left, font=("Segoe UI", 11), width=30, height=20,
                             bg=WHITE, fg=BG_DARK, selectbackground=GOLD,
                             selectforeground=BG_DARK, relief="flat")
        self.lb.pack(fill="y", expand=True)
        self.lb.bind("<<ListboxSelect>>", lambda e: self.show_detail())
        self.count = tk.Label(left, text="", font=("Segoe UI", 9),
                              fg=CREAM, bg=BG)
        self.count.pack(anchor="w", pady=4)

        right = tk.Frame(mid, bg=WHITE, relief="flat")
        right.pack(side="left", fill="both", expand=True)
        tk.Label(right, text="Teacher Profile", font=("Segoe UI", 12, "bold"),
                 fg=BG, bg=WHITE).pack(anchor="w", padx=14, pady=(10, 4))
        self.detail = tk.Text(right, font=("Segoe UI", 11), bg=WHITE, fg=BG_DARK,
                              wrap="word", relief="flat", padx=12, pady=8,
                              state="disabled", height=22)
        self.detail.pack(fill="both", expand=True)

        foot = tk.Frame(self, bg=BG_DARK)
        foot.pack(fill="x")
        tk.Label(foot, text=DEVELOPER_LINE, font=("Segoe UI", 9),
                 fg=GOLD, bg=BG_DARK).pack(pady=(6, 0))
        tk.Label(foot, text=WHATSAPP_LINE, font=("Segoe UI", 9),
                 fg=CREAM, bg=BG_DARK).pack(pady=(0, 6))

        self.filtered = TEACHERS[:]
        self.refresh()

    def clear(self):
        self.q.set("")
        self.sub.set("All")
        self.city.set("All")
        self.refresh()

    def refresh(self):
        q = self.q.get().strip().lower()
        s, c = self.sub.get(), self.city.get()
        self.filtered = [t for t in TEACHERS
                         if (s == "All" or t["subject"] == s)
                         and (c == "All" or t["city"] == c)
                         and (not q or q in t["name"].lower()
                              or q in t["ur"] or q in t["subject"].lower()
                              or q in t["city"].lower())]
        self.lb.delete(0, "end")
        for t in self.filtered:
            self.lb.insert("end", f" {t['name']}")
        self.count.config(text=f"{len(self.filtered)} teacher(s) found")
        if self.filtered:
            self.lb.select_set(0)
        self.show_detail()

    def show_detail(self):
        sel = self.lb.curselection()
        t = self.filtered[sel[0]] if sel else None
        self.detail.config(state="normal")
        self.detail.delete("1.0", "end")
        if t:
            self.detail.insert("end",
                f"{t['name']}\n{t['ur']}\n\n"
                f"📖 Subject:  {t['subject']}\n"
                f"📍 City:      {t['city']}\n"
                f"🎓 Experience: {t['exp']} years\n"
                f"💰 Fee:       {t['fee']}\n"
                f"🏠 Mode:      {t['mode']}\n"
                f"📞 Phone:     {t['phone']}\n\n"
                f"📝 {t['note']}\n")
        self.detail.config(state="disabled")


if __name__ == "__main__":
    App().mainloop()
