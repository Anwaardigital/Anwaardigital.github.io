Quran Teacher 786 - Windows App
=============================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features:
- 12 sample Quran teacher profiles (Urdu + English)
- Search by name, subject ya city
- Filters: subject (Nazra / Hifz / Tajweed / Qirat / Tarjuma) & city
- Har teacher ki detail: experience, fee, mode, phone, note

Note: ye demo version hai - sample data ke sath.
Asli teachers ki listing app ke full version mein milegi.

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
