@echo off
title Quran Teacher 786
python main.py
pause
