Hill Climb — Windows Version
==============================

2D side-view driving game: pahariyon par gaari chalao!

CHALANE KA TAREEQA:
1. Python 3 install karo (python.org se free download)
2. run.bat par double-click karo
   (ya: python main.py)

CONTROLS:
- RIGHT ya UP arrow: accelerate (race do)
- LEFT ya DOWN arrow: brake
- SPACE: dobara start karo

GAME:
- Jitni door jao ge, utna score (distance)
- Sunehre coins (sikkay) uthao = +1 coin
- Laal fuel can uthao = +40 fuel
- Fuel khatam = GAME OVER
- Bohat tez dhalan par gaari palat jayegi = GAME OVER
- Dheeli dhalanon par race do, tez charhai par sambhal kar!

------------------------------------
App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
