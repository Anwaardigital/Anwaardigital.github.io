# -*- coding: utf-8 -*-
"""
Hill Climb — Windows Desktop App
2D side-view driving: climb endless hills, manage fuel, grab coins.
Python 3 + Tkinter only (no extra deps).
Theme: desert dusk + emerald car + gold coins.
"""

import tkinter as tk
from tkinter import messagebox
import random
import math

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#101828"
SKY_TOP = "#1E2A4A"
SKY_BOT = "#3B2E5A"
GROUND = "#2A2118"
GROUND_TOP = "#6B4F2A"
CAR = "#10B981"
GOLD = "#FFD700"
FUEL_RED = "#EF4444"
TEXT = "#FFFFFF"

WIDTH, HEIGHT = 640, 480
GROUND_Y = 360          # screen y of terrain at car (roughly)
PX_PER_M = 22           # pixels per meter
GRAV = 9.8


class HillClimb:
    def __init__(self, root, seed=None):
        self.root = root
        root.title("Hill Climb — Windows")
        root.geometry("%dx%d" % (WIDTH, HEIGHT + 70))
        root.configure(bg=BG)
        root.resizable(False, False)

        hud = tk.Frame(root, bg=BG)
        hud.pack(fill="x", padx=10, pady=5)
        self.dist_var = tk.StringVar(value="Distance: 0 m")
        self.coin_var = tk.StringVar(value="Coins: 0")
        tk.Label(hud, textvariable=self.dist_var, fg=GOLD, bg=BG,
                 font=("Arial", 12, "bold")).pack(side="left")
        tk.Label(hud, textvariable=self.coin_var, fg=TEXT, bg=BG,
                 font=("Arial", 12)).pack(side="right")

        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT,
                                bg=SKY_TOP, highlightthickness=0)
        self.canvas.pack()

        # fuel bar
        fbar = tk.Frame(root, bg=BG)
        fbar.pack(fill="x", padx=10, pady=2)
        tk.Label(fbar, text="Fuel:", fg=TEXT, bg=BG,
                 font=("Arial", 10)).pack(side="left")
        self.fuel_canvas = tk.Canvas(fbar, width=300, height=14, bg="#222222",
                                     highlightthickness=0)
        self.fuel_canvas.pack(side="left", padx=6)

        foot = tk.Frame(root, bg=BG)
        foot.pack(fill="x", pady=2)
        tk.Label(foot, text=DEVELOPER_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()
        tk.Label(foot, text=WHATSAPP_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()

        self.keys = {"accel": False, "brake": False}
        root.bind("<KeyPress-Right>", lambda e: self._set("accel", True))
        root.bind("<KeyRelease-Right>", lambda e: self._set("accel", False))
        root.bind("<KeyPress-Up>", lambda e: self._set("accel", True))
        root.bind("<KeyRelease-Up>", lambda e: self._set("accel", False))
        root.bind("<KeyPress-Left>", lambda e: self._set("brake", True))
        root.bind("<KeyRelease-Left>", lambda e: self._set("brake", False))
        root.bind("<KeyPress-Down>", lambda e: self._set("brake", True))
        root.bind("<KeyRelease-Down>", lambda e: self._set("brake", False))
        root.bind("<space>", lambda e: self.restart())
        root.bind("<Return>", lambda e: self.restart())

        self.rng = random.Random(seed)
        self.restart()
        self.game_loop()

    def _set(self, k, v):
        self.keys[k] = v

    # ---------- terrain ----------
    def _make_terrain(self):
        # sum of sines with random phases -> smooth endless hills
        self.t_amp = [self.rng.uniform(2.0, 3.2),
                      self.rng.uniform(0.8, 1.6),
                      self.rng.uniform(0.6, 1.2)]
        self.t_freq = [0.045, 0.11, 0.31]
        self.t_phase = [self.rng.uniform(0, 6.28) for _ in range(3)]

    def terrain_y(self, x):
        return sum(a * math.sin(x * f + p)
                   for a, f, p in zip(self.t_amp, self.t_freq, self.t_phase))

    def terrain_slope(self, x):
        return sum(a * f * math.cos(x * f + p)
                   for a, f, p in zip(self.t_amp, self.t_freq, self.t_phase))

    def restart(self):
        self._make_terrain()
        self.px = 0.0          # position in meters
        self.vx = 0.0          # velocity m/s
        self.fuel = 100.0
        self.coins = 0
        self.alive = True
        self.death_reason = ""
        self.best = getattr(self, "best", 0)
        self.coin_at = {}      # meter -> collected?
        self.fuel_at = {}      # meter -> collected?
        self.wheel_spin = 0
        self._gen_pickups(0, 1200)

    def _gen_pickups(self, start_m, end_m):
        m = int(start_m) + 60
        while m < end_m:
            self.coin_at[m] = False
            m += self.rng.randint(45, 80)
        m = int(start_m) + 220
        while m < end_m:
            self.fuel_at[m] = False
            m += self.rng.randint(220, 300)

    # ---------- physics (testable without GUI) ----------
    def step_physics(self, dt=1.0 / 30):
        if not self.alive:
            return
        slope = self.terrain_slope(self.px)
        engine = 9.0 if self.keys["accel"] else 0.0
        brake = 14.0 if self.keys["brake"] else 0.0
        drag = 0.35 * self.vx
        grav = GRAV * slope
        acc = engine - brake * (1 if self.vx >= 0 else -1) - drag - grav
        # flip: terrain too steep to stay on wheels
        if abs(slope) > 1.6:
            self.alive = False
            self.death_reason = "FLIPPED!"
            return
        self.vx += acc * dt
        if self.vx < -4.0:      # limited reverse
            self.vx = -4.0
        self.px += self.vx * dt
        if self.px < 0:
            self.px = 0
            self.vx = 0
        # fuel
        burn = 0.9 if self.keys["accel"] else 0.12
        self.fuel -= burn * dt
        if self.fuel <= 0:
            self.fuel = 0
            self.alive = False
            self.death_reason = "OUT OF FUEL!"
            return
        # pickups
        m = int(self.px)
        for cm in list(self.coin_at):
            if not self.coin_at[cm] and abs(cm - m) < 2:
                self.coin_at[cm] = True
                self.coins += 1
        for fm in list(self.fuel_at):
            if not self.fuel_at[fm] and abs(fm - m) < 2:
                self.fuel_at[fm] = True
                self.fuel = min(100.0, self.fuel + 40.0)
        # generate more ahead
        far = max(list(self.coin_at) + [0])
        if self.px > far - 400:
            self._gen_pickups(far, far + 800)

    def draw_car(self, sx, sy, angle_deg):
        c = self.canvas
        L, Wd = 46, 30
        rad = math.radians(angle_deg)
        dx, dy = math.cos(rad), math.sin(rad)
        nx, ny = -dy, dx
        pts = []
        for s, t in [(-L / 2, -Wd / 2), (L / 2, -Wd / 2),
                     (L / 2, Wd / 2), (-L / 2, Wd / 2)]:
            pts.append(sx + s * dx + t * nx)
            pts.append(sy + s * dy + t * ny)
        c.create_polygon(pts, fill=CAR, outline="#064E3B", width=2)
        # cabin
        cx, cy = sx + 2 * dx, sy + 2 * dy - 8
        c.create_rectangle(cx - 12, cy - 10, cx + 12, cy + 6,
                           fill="#B0E0E6", outline="#064E3B")
        # wheels
        self.wheel_spin = (self.wheel_spin + self.vx * 2) % 360
        for s in (-L / 2 + 8, L / 2 - 8):
            wx = sx + s * dx
            wy = sy + s * dy + (Wd / 2 - 2) * ny
            c.create_oval(wx - 9, wy - 9, wx + 9, wy + 9,
                          fill="#111111", outline="#555555", width=2)
            sx2 = wx + 6 * math.cos(math.radians(self.wheel_spin))
            sy2 = wy + 6 * math.sin(math.radians(self.wheel_spin))
            c.create_line(wx, wy, sx2, sy2, fill="#888888", width=2)

    def game_loop(self):
        self.step_physics()
        c = self.canvas
        c.delete("all")
        # sky gradient
        for i in range(12):
            y0 = i * HEIGHT / 12
            r = int(30 + i * 3.5)
            g = int(42 + i * 1.2)
            b = int(74 - i * 1.0)
            c.create_rectangle(0, y0, WIDTH, y0 + HEIGHT / 12 + 1,
                               fill="#%02x%02x%02x" % (r, g, b), outline="")
        # sun
        c.create_oval(WIDTH - 110, 40, WIDTH - 40, 110, fill=GOLD, outline="")

        car_sx = WIDTH // 3
        car_sy = GROUND_Y - self.terrain_y(self.px) * PX_PER_M
        slope = self.terrain_slope(self.px)

        # terrain polyline
        pts = []
        for sx in range(0, WIDTH + 20, 20):
            wx = self.px + (sx - car_sx) / PX_PER_M
            sy = GROUND_Y - self.terrain_y(wx) * PX_PER_M
            pts += [sx, sy]
        c.create_polygon(pts + [WIDTH, HEIGHT, 0, HEIGHT],
                         fill=GROUND, outline="")
        c.create_line(pts, fill=GROUND_TOP, width=4)

        # pickups
        for cm, taken in self.coin_at.items():
            if taken:
                continue
            sx = car_sx + (cm - self.px) * PX_PER_M
            if -30 < sx < WIDTH + 30:
                sy = GROUND_Y - self.terrain_y(cm) * PX_PER_M - 26
                c.create_oval(sx - 9, sy - 9, sx + 9, sy + 9,
                              fill=GOLD, outline="#B45309", width=2)
                c.create_text(sx, sy, text="$", fill="#92400E",
                              font=("Arial", 9, "bold"))
        for fm, taken in self.fuel_at.items():
            if taken:
                continue
            sx = car_sx + (fm - self.px) * PX_PER_M
            if -30 < sx < WIDTH + 30:
                sy = GROUND_Y - self.terrain_y(fm) * PX_PER_M - 24
                c.create_rectangle(sx - 9, sy - 12, sx + 9, sy + 12,
                                   fill=FUEL_RED, outline="#7F1D1D", width=2)
                c.create_text(sx, sy, text="F", fill="white",
                              font=("Arial", 10, "bold"))

        # car
        angle = math.degrees(math.atan(slope))
        if self.alive:
            self.draw_car(car_sx, car_sy - 16, -angle)
        else:
            c.create_rectangle(WIDTH // 2 - 170, 120, WIDTH // 2 + 170, 260,
                               fill="#000000", outline=GOLD, width=2)
            c.create_text(WIDTH // 2, 150, text="GAME OVER", fill="#FF3B3B",
                          font=("Arial", 24, "bold"))
            c.create_text(WIDTH // 2, 185, text=self.death_reason, fill=GOLD,
                          font=("Arial", 14, "bold"))
            c.create_text(WIDTH // 2, 215,
                          text="Distance: %d m   Coins: %d" % (int(self.px), self.coins),
                          fill=TEXT, font=("Arial", 12))
            c.create_text(WIDTH // 2, 240, text="Press SPACE to restart",
                          fill=GOLD, font=("Arial", 11))

        # HUD
        self.dist_var.set("Distance: %d m" % int(self.px))
        self.coin_var.set("Coins: %d" % self.coins)
        self.fuel_canvas.delete("all")
        self.fuel_canvas.create_rectangle(0, 0, 300 * self.fuel / 100.0, 14,
                                          fill=CAR if self.fuel > 25 else FUEL_RED,
                                          outline="")
        if int(self.px) > self.best:
            self.best = int(self.px)

        self.root.after(33, self.game_loop)


def main():
    root = tk.Tk()
    HillClimb(root)
    root.mainloop()


if __name__ == "__main__":
    main()
