#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
App Locker (Windows concept version)
====================================
A password-protected launcher for Windows.

* Set a master PIN (4-8 digits), stored as salted SHA-256 (hashlib).
* Add "locked apps" (paths to .exe files).
* Launching a locked app asks for the master PIN first.

Concept version: this locks launching *through this app only* - it is not a
system-level lock and will not stop someone opening the .exe directly.
Honest and simple.
"""

import hashlib
import json
import os
import secrets
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox

APP_TITLE = "App Locker"
BRANDING = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "app_locker_data.json")
FONT = "Segoe UI"


# ------------------------------------------------------------------ storage
def load_data(path=None):
    """Load app data (PIN hash + locked apps). Missing/corrupt -> fresh."""
    path = path or DATA_FILE
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}
    data.setdefault("pin_hash", None)
    data.setdefault("salt", None)
    data.setdefault("apps", [])
    return data


def save_data(data, path=None):
    path = path or DATA_FILE
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _hash(pin, salt):
    return hashlib.sha256((salt + pin).encode("utf-8")).hexdigest()


def set_pin(data, pin):
    """Set a new master PIN. Raises ValueError when the PIN is invalid."""
    pin = str(pin).strip()
    if not pin.isdigit() or not 4 <= len(pin) <= 8:
        raise ValueError("PIN must be 4 to 8 digits.")
    salt = secrets.token_hex(16)
    data["salt"] = salt
    data["pin_hash"] = _hash(pin, salt)


def verify_pin(data, pin):
    """True when `pin` matches the stored master PIN."""
    if not data.get("pin_hash") or not data.get("salt"):
        return False
    return _hash(str(pin).strip(), data["salt"]) == data["pin_hash"]


def add_locked_app(data, name, path):
    data["apps"].append({"name": name, "path": path})


def remove_locked_app(data, index):
    del data["apps"][index]


def launch_app(path):
    """Open the executable. Windows: os.startfile, elsewhere: direct exec."""
    if hasattr(os, "startfile"):          # real Windows
        os.startfile(path)               # noqa: user-chosen path
    else:                                # concept fallback on other OSes
        subprocess.Popen([path])


# ---------------------------------------------------------------------- GUI
def brand_footer(parent):
    tk.Label(parent, text=BRANDING, font=(FONT, 8), fg="#777777").pack(
        side="bottom", fill="x", pady=(10, 6))


class PinDialog(tk.Toplevel):
    """Modal PIN entry dialog. `.result` is the typed PIN, or None."""

    def __init__(self, parent, title="Enter PIN", prompt="Enter master PIN:"):
        super().__init__(parent)
        self.title(title)
        self.result = None
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)
        tk.Label(self, text=prompt, font=(FONT, 10)).pack(padx=24, pady=(18, 4))
        self.entry = tk.Entry(self, show="*", width=26, font=(FONT, 12),
                              justify="center")
        self.entry.pack(padx=24, pady=6)
        self.entry.focus_set()
        row = tk.Frame(self)
        row.pack(pady=8)
        tk.Button(row, text="OK", width=10, command=self._ok).pack(
            side="left", padx=6)
        tk.Button(row, text="Cancel", width=10,
                  command=self.destroy).pack(side="left", padx=6)
        self.bind("<Return>", lambda _e: self._ok())
        self.bind("<Escape>", lambda _e: self.destroy())
        tk.Label(self, text=BRANDING, font=(FONT, 7),
                 fg="#999999").pack(pady=(4, 8))
        self.wait_window()

    def _ok(self):
        self.result = self.entry.get()
        self.destroy()


class NewPinDialog(tk.Toplevel):
    """Modal dialog to choose a new PIN (entered twice). `.result` or None."""

    def __init__(self, parent, title="Set master PIN"):
        super().__init__(parent)
        self.title(title)
        self.result = None
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)
        tk.Label(self, text="New PIN (4-8 digits):",
                 font=(FONT, 10)).pack(padx=24, pady=(18, 2))
        self.e1 = tk.Entry(self, show="*", width=26, font=(FONT, 12),
                           justify="center")
        self.e1.pack(padx=24, pady=4)
        tk.Label(self, text="Confirm PIN:", font=(FONT, 10)).pack(pady=(6, 2))
        self.e2 = tk.Entry(self, show="*", width=26, font=(FONT, 12),
                           justify="center")
        self.e2.pack(padx=24, pady=4)
        self.e1.focus_set()
        row = tk.Frame(self)
        row.pack(pady=10)
        tk.Button(row, text="Save", width=10, command=self._ok).pack(
            side="left", padx=6)
        tk.Button(row, text="Cancel", width=10,
                  command=self.destroy).pack(side="left", padx=6)
        self.bind("<Return>", lambda _e: self._ok())
        self.bind("<Escape>", lambda _e: self.destroy())
        tk.Label(self, text=BRANDING, font=(FONT, 7),
                 fg="#999999").pack(pady=(4, 8))
        self.wait_window()

    def _ok(self):
        p1, p2 = self.e1.get().strip(), self.e2.get().strip()
        if p1 != p2:
            messagebox.showerror("Mismatch", "PINs do not match.",
                                 parent=self)
            return
        if not p1.isdigit() or not 4 <= len(p1) <= 8:
            messagebox.showerror("Invalid PIN", "PIN must be 4 to 8 digits.",
                                 parent=self)
            return
        self.result = p1
        self.destroy()


class AppLockerGUI:
    def __init__(self, root):
        self.root = root
        self.data = load_data()
        root.title(APP_TITLE)
        root.geometry("580x470")
        root.resizable(False, False)
        self.body = tk.Frame(root)
        self.body.pack(fill="both", expand=True)
        brand_footer(root)
        if self.data["pin_hash"] is None:
            self.show_setup()
        else:
            self.show_main()

    # ------------------------------------------------------------ navigation
    def _clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    # ----------------------------------------------------------------- setup
    def show_setup(self):
        self._clear()
        f = tk.Frame(self.body, padx=30, pady=30)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="Welcome to App Locker",
                 font=(FONT, 16, "bold")).pack(pady=(10, 6))
        tk.Label(f, text="Set a master PIN (4-8 digits).\n"
                         "You will need it every time you launch a locked app.",
                 font=(FONT, 10), justify="center").pack(pady=6)
        tk.Label(f, text="New PIN:", font=(FONT, 10)).pack(pady=(12, 2))
        e1 = tk.Entry(f, show="*", width=26, font=(FONT, 12), justify="center")
        e1.pack()
        tk.Label(f, text="Confirm PIN:", font=(FONT, 10)).pack(pady=(8, 2))
        e2 = tk.Entry(f, show="*", width=26, font=(FONT, 12), justify="center")
        e2.pack()
        e1.focus_set()

        def save():
            p1, p2 = e1.get().strip(), e2.get().strip()
            if p1 != p2:
                messagebox.showerror("Mismatch", "PINs do not match.")
                return
            try:
                set_pin(self.data, p1)
            except ValueError as exc:
                messagebox.showerror("Invalid PIN", str(exc))
                return
            save_data(self.data)
            messagebox.showinfo("Done", "Master PIN saved.")
            self.show_main()

        tk.Button(f, text="Save PIN", width=18, font=(FONT, 11),
                  command=save).pack(pady=18)

    # ------------------------------------------------------------------ main
    def show_main(self):
        self._clear()
        f = tk.Frame(self.body, padx=20, pady=14)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="Locked apps", font=(FONT, 14, "bold")).pack(
            anchor="w", pady=(0, 8))

        list_frame = tk.Frame(f)
        list_frame.pack(fill="both", expand=True)
        self.listbox = tk.Listbox(list_frame, font=(FONT, 10), height=10)
        scroll = tk.Scrollbar(list_frame, command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.refresh_list()

        btns = tk.Frame(f)
        btns.pack(pady=10)
        tk.Button(btns, text="Add app", width=12,
                  command=self.add_app).pack(side="left", padx=5)
        tk.Button(btns, text="Remove", width=12,
                  command=self.remove_app).pack(side="left", padx=5)
        tk.Button(btns, text="Launch", width=12,
                  command=self.launch_selected).pack(side="left", padx=5)
        tk.Button(btns, text="Change PIN", width=12,
                  command=self.change_pin).pack(side="left", padx=5)

        tk.Label(f, text="Concept version: launching is locked through this "
                         "app only.",
                 font=(FONT, 8), fg="#888888").pack()

    def refresh_list(self):
        self.listbox.delete(0, tk.END)
        for app in self.data["apps"]:
            self.listbox.insert(tk.END, "%s  (%s)" % (app["name"], app["path"]))
        if not self.data["apps"]:
            self.listbox.insert(tk.END, "(no locked apps yet - click 'Add app')")

    def _selected_index(self):
        sel = self.listbox.curselection()
        if not sel or not self.data["apps"]:
            return None
        return sel[0]

    def add_app(self):
        path = filedialog.askopenfilename(
            title="Choose an application",
            filetypes=[("Windows executables", "*.exe"),
                       ("All files", "*.*")])
        if not path:
            return
        name = os.path.splitext(os.path.basename(path))[0]
        add_locked_app(self.data, name, path)
        save_data(self.data)
        self.refresh_list()

    def remove_app(self):
        idx = self._selected_index()
        if idx is None:
            messagebox.showinfo("No selection", "Select an app first.")
            return
        app = self.data["apps"][idx]
        if messagebox.askyesno("Remove",
                               "Remove '%s' from locked apps?" % app["name"]):
            remove_locked_app(self.data, idx)
            save_data(self.data)
            self.refresh_list()

    def launch_selected(self):
        idx = self._selected_index()
        if idx is None:
            messagebox.showinfo("No selection", "Select an app first.")
            return
        app = self.data["apps"][idx]
        if not os.path.exists(app["path"]):
            messagebox.showerror("Not found",
                                 "File not found:\n%s" % app["path"])
            return
        dlg = PinDialog(self.root, title="Unlock to launch",
                        prompt="Enter master PIN to launch '%s':" % app["name"])
        if dlg.result is None:
            return
        if not verify_pin(self.data, dlg.result):
            messagebox.showerror("Wrong PIN", "Incorrect PIN.")
            return
        try:
            launch_app(app["path"])
        except Exception as exc:  # noqa: BLE001 - show any launch error
            messagebox.showerror("Launch failed", str(exc))

    def change_pin(self):
        dlg = PinDialog(self.root, title="Change PIN",
                        prompt="Enter current PIN:")
        if dlg.result is None:
            return
        if not verify_pin(self.data, dlg.result):
            messagebox.showerror("Wrong PIN", "Incorrect current PIN.")
            return
        new = NewPinDialog(self.root)
        if new.result is None:
            return
        set_pin(self.data, new.result)
        save_data(self.data)
        messagebox.showinfo("Done", "Master PIN changed.")


def main():
    root = tk.Tk()
    AppLockerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
