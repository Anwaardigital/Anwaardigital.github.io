App Locker (Windows concept version)
=====================================

WHAT IT IS
A password-protected launcher for Windows. Set a master PIN, add the
programs you want to keep private (.exe files), and launch them through
this app - it asks for your PIN every time before opening the program.

FEATURES
- Set a master PIN (4-8 digits)
- Add / remove locked apps (any .exe path)
- Launch a locked app only after the correct PIN is entered
- Change the master PIN (needs the current PIN)

REQUIREMENTS
- Windows 7 / 10 / 11
- Python 3.8 or newer
  Download from https://www.python.org/downloads/
  IMPORTANT: during install, tick "Add python.exe to PATH".

HOW TO RUN
1. Double-click run.bat
   (or open a terminal in this folder and run:  python main.py)
2. First run: choose a master PIN (4-8 digits) and confirm it.
3. Click "Add app", pick an .exe file, then select it and click "Launch".
4. Enter your PIN when asked - the app opens.

YOUR DATA
- The PIN is stored as salted SHA-256 (never plain text) in
  app_locker_data.json, next to this program.
- Everything stays on your own computer.

HONEST NOTE (concept version)
This is a concept/demo launcher: it locks launching THROUGH THIS APP only.
It is not a system-level lock and will not stop someone who opens the .exe
file directly. It does not encrypt anything.
