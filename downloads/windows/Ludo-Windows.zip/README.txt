Ludo — Windows Version
======================

Classic Ludo board game: aap (Red) vs 3 computer players!

CHALANE KA TAREEQA:
1. Python 3 install karo (python.org se free download)
2. run.bat par double-click karo
   (ya: python main.py)

KESE KHELEIN:
1. "Roll Dice" button dabao
2. Agar koi goti chal sakti hai to wo sunehri (gold) chamkegi
3. Chamki hui goti par CLICK karo
4. Computer apni baari khud khelega

RULES:
- 6 aane par goti ghar (base) se nikalti hai
- 6 ya kaatne (capture) par extra baari milti hai
- Sitare (star) wale khane safe hain — wahan kaati nahi ja sakti
- Goti ko bilkul sahi (exact) number se ghar pahunchana hota hai
- Jis ki 4on gotiyan pehle ghar pahunchein = JEET!

------------------------------------
App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
