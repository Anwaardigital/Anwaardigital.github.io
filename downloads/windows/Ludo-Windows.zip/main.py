# -*- coding: utf-8 -*-
"""
Ludo — Windows Desktop App
Classic Ludo: human (Red) vs 3 simple AI players. Dice roll, token movement,
capture rules, safe squares, exact-roll finish, win detection.
Python 3 + Tkinter only (no extra deps).
Theme: deep slate board + emerald/gold accents.
"""

import tkinter as tk
from tkinter import messagebox
import random

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#0B0F1A"
BOARD_BG = "#111827"
GRID_LINE = "#374151"
GOLD = "#FFD700"
TEXT = "#FFFFFF"

PLAYERS = ["Red", "Green", "Yellow", "Blue"]
PCOLOR = {"Red": "#E11D48", "Green": "#10B981",
          "Yellow": "#FBBF24", "Blue": "#3B82F6"}

# 52-cell main track as (row, col) on a 15x15 board, path order starting at Red's start.
# Verified properties: 52 distinct cells, every consecutive pair (incl. last->first)
# orthogonally adjacent, 180-degree rotational symmetry, starts 13 apart.
PATH = [
    (6, 1), (6, 2), (6, 3), (6, 4), (6, 5),
    (5, 5), (4, 5), (3, 5), (2, 5), (1, 5),
    (0, 5), (0, 6), (0, 7), (0, 8),
    (1, 8), (2, 8), (3, 8), (4, 8), (5, 8),
    (6, 8), (6, 9), (6, 10), (6, 11), (6, 12), (6, 13),
    (7, 13),
    (8, 13), (8, 12), (8, 11), (8, 10), (8, 9),
    (9, 9), (10, 9), (11, 9), (12, 9), (13, 9), (14, 9),
    (14, 8), (14, 7), (14, 6),
    (13, 6), (12, 6), (11, 6), (10, 6), (9, 6), (8, 6),
    (8, 5), (8, 4), (8, 3), (8, 2), (8, 1),
    (7, 1),
]
assert len(PATH) == 52
assert len(set(PATH)) == 52
for _a, _b in zip(PATH, PATH[1:] + PATH[:1]):
    assert abs(_a[0] - _b[0]) + abs(_a[1] - _b[1]) == 1, (_a, _b)
del _a, _b

STARTS = {"Red": 0, "Green": 13, "Yellow": 26, "Blue": 39}
SAFE = {0, 8, 13, 21, 26, 34, 39, 47}

HOME = {
    "Red":    [(7, 2), (7, 3), (7, 4), (7, 5), (7, 6), (7, 7)],
    "Green":  [(1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7)],
    "Yellow": [(7, 12), (7, 11), (7, 10), (7, 9), (7, 8), (7, 7)],
    "Blue":   [(13, 7), (12, 7), (11, 7), (10, 7), (9, 7), (8, 7)],
}
# every home square must sit off the main track and chain adjacently from the
# square each player stands on after 51 steps ((STARTS[p]+51) % 52)
for _p in PLAYERS:
    _entry = PATH[(STARTS[_p] + 51) % 52]
    _prev = _entry
    for _sq in HOME[_p]:
        assert _sq not in PATH, (_p, _sq)
        assert abs(_sq[0] - _prev[0]) + abs(_sq[1] - _prev[1]) == 1, (_p, _sq)
        _prev = _sq
del _p, _entry, _prev, _sq
BASE_CELLS = {  # token "home yard" display cells (2x2) inside each corner
    "Red":    [(2, 2), (2, 3), (3, 2), (3, 3)],
    "Green":  [(2, 11), (2, 12), (3, 11), (3, 12)],
    "Yellow": [(11, 11), (11, 12), (12, 11), (12, 12)],
    "Blue":   [(11, 2), (11, 3), (12, 2), (12, 3)],
}
BASE_RECT = {"Red": (0, 0), "Green": (9, 0), "Yellow": (9, 9), "Blue": (0, 9)}

FINISHED = 57  # steps value for a finished token


class LudoEngine:
    """Pure game logic — no GUI. Testable headlessly."""

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.tokens = {p: [-1, -1, -1, -1] for p in PLAYERS}  # steps; -1 = in base
        self.turn = 0            # index into PLAYERS
        self.last_roll = None
        self.consec_sixes = 0
        self.turns_played = 0

    # ----- helpers -----
    def abs_cell(self, player, steps):
        """Absolute track index for a token with 0..50 steps, else None."""
        if 0 <= steps <= 50:
            return (STARTS[player] + steps) % 52
        return None

    def roll_dice(self):
        return self.rng.randint(1, 6)

    def movable(self, player, roll):
        """Token indices that can legally move with this roll."""
        out = []
        for i, s in enumerate(self.tokens[player]):
            if s == -1:
                if roll == 6:
                    out.append(i)
            elif s < FINISHED:
                if s + roll <= FINISHED:
                    out.append(i)
        return out

    def move(self, player, tok, roll):
        """Apply a move. Returns dict of events."""
        ev = {"captured": [], "finished": False, "extra_turn": False, "won": False}
        s = self.tokens[player][tok]
        if s == -1:
            assert roll == 6
            new = 0
        else:
            new = s + roll
            assert new <= FINISHED
        self.tokens[player][tok] = new

        if new == FINISHED:
            ev["finished"] = True
        elif new <= 50:
            cell = self.abs_cell(player, new)
            if cell not in SAFE:
                for opp in PLAYERS:
                    if opp == player:
                        continue
                    for j, os_ in enumerate(self.tokens[opp]):
                        if 0 <= os_ <= 50 and self.abs_cell(opp, os_) == cell:
                            self.tokens[opp][j] = -1
                            ev["captured"].append((opp, j))

        if all(t == FINISHED for t in self.tokens[player]):
            ev["won"] = True

        ev["extra_turn"] = (roll == 6 or bool(ev["captured"])) and not ev["won"]
        return ev

    def current(self):
        return PLAYERS[self.turn]

    def advance_turn(self):
        self.turn = (self.turn + 1) % 4
        self.turns_played += 1
        self.consec_sixes = 0

    def ai_choose(self, player, roll):
        """Simple AI: leave base on 6 > finish a token > capture > furthest token."""
        moves = self.movable(player, roll)
        if not moves:
            return None
        # 1. leave base
        for i in moves:
            if self.tokens[player][i] == -1:
                return i
        # 2. finishing move
        for i in moves:
            if self.tokens[player][i] + roll == FINISHED:
                return i
        # 3. capture
        for i in moves:
            s = self.tokens[player][i]
            new = s + roll
            if new <= 50:
                cell = self.abs_cell(player, new)
                if cell not in SAFE:
                    for opp in PLAYERS:
                        if opp == player:
                            continue
                        for os_ in self.tokens[opp]:
                            if 0 <= os_ <= 50 and self.abs_cell(opp, os_) == cell:
                                return i
        # 4. furthest along
        return max(moves, key=lambda i: self.tokens[player][i])

    def play_turn(self, player, choose=None):
        """Roll + move for one turn. Returns (roll, events, next_player_same)."""
        roll = self.roll_dice()
        self.last_roll = roll
        if roll == 6:
            self.consec_sixes += 1
            if self.consec_sixes >= 3:
                # three sixes in a row: turn forfeited
                self.advance_turn()
                return roll, {"forfeit": True}, False
        else:
            self.consec_sixes = 0
        moves = self.movable(player, roll)
        if not moves:
            self.advance_turn()
            return roll, {"no_move": True}, False
        pick = (choose or self.ai_choose)(player, roll)
        ev = self.move(player, pick, roll)
        if ev["won"] or not ev["extra_turn"]:
            self.advance_turn()
        return roll, ev, ev["extra_turn"]


class LudoGUI:
    CELL = 34
    MARGIN = 10

    def __init__(self, root):
        self.root = root
        root.title("Ludo — Windows")
        w = 15 * self.CELL + 2 * self.MARGIN + 210
        h = 15 * self.CELL + 2 * self.MARGIN + 60
        root.geometry("%dx%d" % (w, h))
        root.configure(bg=BG)
        root.resizable(False, False)

        self.eng = LudoEngine()
        self.rolled = False
        self.pending_roll = None
        self.selected = []   # highlighted token ids clickable now

        top = tk.Frame(root, bg=BG)
        top.pack(fill="x", padx=8, pady=4)
        self.turn_var = tk.StringVar(value="Red's turn — roll the dice!")
        tk.Label(top, textvariable=self.turn_var, fg=GOLD, bg=BG,
                 font=("Arial", 13, "bold")).pack(side="left")

        main = tk.Frame(root, bg=BG)
        main.pack()
        bsize = 15 * self.CELL + 2 * self.MARGIN
        self.canvas = tk.Canvas(main, width=bsize, height=bsize,
                                bg=BOARD_BG, highlightthickness=0)
        self.canvas.pack(side="left", padx=6)
        self.canvas.bind("<Button-1>", self.on_click)

        side = tk.Frame(main, bg=BG, width=190)
        side.pack(side="left", fill="y", padx=6)
        self.dice_var = tk.StringVar(value="🎲")
        tk.Label(side, textvariable=self.dice_var, fg=TEXT, bg=BG,
                 font=("Arial", 44)).pack(pady=8)
        self.roll_btn = tk.Button(side, text="Roll Dice", command=self.human_roll,
                                  bg=GOLD, fg="#000000", font=("Arial", 12, "bold"),
                                  width=14)
        self.roll_btn.pack(pady=4)
        self.msg_var = tk.StringVar(value="Red (you) starts!")
        tk.Label(side, textvariable=self.msg_var, fg=TEXT, bg=BG,
                 font=("Arial", 10), wraplength=180, justify="left").pack(pady=8)
        tk.Button(side, text="New Game", command=self.new_game,
                  bg="#374151", fg=TEXT, font=("Arial", 10),
                  width=14).pack(pady=4)

        foot = tk.Frame(root, bg=BG)
        foot.pack(fill="x", pady=4)
        tk.Label(foot, text=DEVELOPER_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()
        tk.Label(foot, text=WHATSAPP_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()

        self.draw_board()
        self.schedule_ai()

    def new_game(self):
        self.eng = LudoEngine()
        self.rolled = False
        self.pending_roll = None
        self.turn_var.set("Red's turn — roll the dice!")
        self.msg_var.set("Red (you) starts!")
        self.dice_var.set("🎲")
        self.draw_board()

    # ---------- drawing ----------
    def cell_xy(self, r, c):
        return (self.MARGIN + c * self.CELL, self.MARGIN + r * self.CELL)

    def draw_board(self):
        c = self.canvas
        c.delete("all")
        M, S = self.MARGIN, self.CELL
        # base corners
        for p, (br, bc) in BASE_RECT.items():
            x0, y0 = self.cell_xy(br, bc)
            x1, y1 = x0 + 6 * S, y0 + 6 * S
            c.create_rectangle(x0, y0, x1, y1, fill=PCOLOR[p], outline="")
            c.create_rectangle(x0 + S, y0 + S, x1 - S, y1 - S,
                               fill=BOARD_BG, outline="")
            c.create_text(x0 + 3 * S, y0 + S // 2, text=p.upper(), fill="#FFFFFF",
                          font=("Arial", 9, "bold"))
        # track cells
        for idx, (r, cc) in enumerate(PATH):
            x0, y0 = self.cell_xy(r, cc)
            fill = BOARD_BG
            if idx in SAFE:
                fill = "#1F2937"
            c.create_rectangle(x0, y0, x0 + S, y0 + S, fill=fill,
                               outline=GRID_LINE)
            if idx in SAFE:
                c.create_text(x0 + S / 2, y0 + S / 2, text="★", fill=GOLD,
                              font=("Arial", 10))
        # home stretches
        for p, cells in HOME.items():
            for (r, cc) in cells:
                x0, y0 = self.cell_xy(r, cc)
                c.create_rectangle(x0, y0, x0 + S, y0 + S, fill=PCOLOR[p],
                                   outline=GRID_LINE)
        # center home triangle area
        x0, y0 = self.cell_xy(6, 6)
        c.create_rectangle(x0, y0, x0 + 3 * S, y0 + 3 * S,
                           fill="#0F172A", outline=GOLD, width=2)
        c.create_text(x0 + 1.5 * S, y0 + 1.5 * S, text="🏠", fill=GOLD,
                      font=("Arial", 18))
        self.draw_tokens()

    def token_pos(self, player, tok):
        """Pixel center of a token."""
        s = self.eng.tokens[player][tok]
        M, S = self.MARGIN, self.CELL
        if s == -1:
            r, cc = BASE_CELLS[player][tok]
            x0, y0 = self.cell_xy(r, cc)
            return x0 + S / 2, y0 + S / 2, S * 0.32
        if s == FINISHED:
            x0, y0 = self.cell_xy(6, 6)
            off = [(0.7, 0.7), (1.5, 0.7), (0.7, 1.5), (1.5, 1.5)][tok]
            return x0 + off[0] * S, y0 + off[1] * S, S * 0.26
        if s >= 51:
            r, cc = HOME[player][s - 51]
        else:
            r, cc = PATH[self.eng.abs_cell(player, s)]
        x0, y0 = self.cell_xy(r, cc)
        # stack offset so multiple tokens on same cell are visible
        same = [j for j in range(4)
                if self._cell_key(player, j) == self._cell_key(player, tok) and j < tok]
        ox = (len(same) % 2) * 9 - 4
        oy = (len(same) // 2) * 9 - 4
        return x0 + S / 2 + ox, y0 + S / 2 + oy, S * 0.30

    def _cell_key(self, player, tok):
        s = self.eng.tokens[player][tok]
        if s == -1:
            return ("base", tok)
        if s == FINISHED:
            return ("done", tok)
        if s >= 51:
            return ("home", s)
        return ("track", self.eng.abs_cell(player, s))

    def draw_tokens(self):
        c = self.canvas
        c.delete("tokens")
        for p in PLAYERS:
            for t in range(4):
                x, y, rad = self.token_pos(p, t)
                s = self.eng.tokens[p][t]
                outline = GOLD if (p, t) in self.selected else "#000000"
                width = 3 if (p, t) in self.selected else 1
                c.create_oval(x - rad, y - rad, x + rad, y + rad,
                              fill=PCOLOR[p], outline=outline, width=width,
                              tags="tokens")
                if s == FINISHED:
                    c.create_text(x, y, text="✓", fill="#FFFFFF",
                                  font=("Arial", 8, "bold"), tags="tokens")

    # ---------- gameplay ----------
    def human_roll(self):
        if self.eng.current() != "Red" or self.rolled:
            return
        roll = self.eng.roll_dice()
        self.eng.last_roll = roll
        self.dice_var.set("🎲 " + str(roll))
        moves = self.eng.movable("Red", roll)
        self.pending_roll = roll
        self.rolled = True
        if not moves:
            self.msg_var.set("Rolled %d — no move possible." % roll)
            self.root.after(900, self.end_human_turn)
        else:
            self.selected = [("Red", t) for t in moves]
            self.msg_var.set("Rolled %d — click a glowing token!" % roll)
            self.draw_tokens()

    def on_click(self, event):
        if not self.selected:
            return
        c = self.canvas
        x, y = event.x, event.y
        for (p, t) in self.selected:
            cx, cy, rad = self.token_pos(p, t)
            if (x - cx) ** 2 + (y - cy) ** 2 <= (rad + 6) ** 2:
                self.human_move(t)
                return

    def human_move(self, tok):
        roll = self.pending_roll
        ev = self.eng.move("Red", tok, roll)
        self.after_move("Red", roll, ev)
        if ev["won"]:
            return
        if ev["extra_turn"]:
            self.rolled = False
            self.selected = []
            self.turn_var.set("Red rolls again! (extra turn)")
        else:
            self.end_human_turn()

    def end_human_turn(self):
        self.rolled = False
        self.selected = []
        self.pending_roll = None
        self.eng.advance_turn()
        self.draw_tokens()
        self.update_turn_label()
        self.schedule_ai()

    def after_move(self, player, roll, ev):
        self.draw_tokens()
        msgs = ["%s rolled %d." % (player, roll)]
        if ev.get("forfeit"):
            msgs.append("Three 6s in a row — turn lost!")
        if ev.get("captured"):
            names = ", ".join("%s's token" % o for o, _ in ev["captured"])
            msgs.append("Captured %s!" % names)
        if ev.get("finished"):
            msgs.append("%s got a token home!" % player)
        self.msg_var.set(" ".join(msgs))
        if ev.get("won"):
            self.turn_var.set("🏆 %s WINS!" % player)
            self.draw_tokens()
            messagebox.showinfo("Ludo", "%s wins the game!" % player)
            self.new_game()

    def update_turn_label(self):
        p = self.eng.current()
        who = " (you)" if p == "Red" else " (AI)"
        self.turn_var.set("%s's turn%s" % (p, who))
        self.roll_btn.config(state="normal" if p == "Red" else "disabled")

    def schedule_ai(self):
        self.update_turn_label()
        p = self.eng.current()
        if p != "Red":
            self.roll_btn.config(state="disabled")
            self.root.after(800, self.ai_turn)
        else:
            self.roll_btn.config(state="normal")

    def ai_turn(self):
        p = self.eng.current()
        if p == "Red":
            return
        roll, ev, extra = self.eng.play_turn(p)
        self.dice_var.set("🎲 " + str(roll))
        self.after_move(p, roll, ev)
        if ev.get("won"):
            return
        if extra:
            self.root.after(800, self.ai_turn)
        else:
            self.schedule_ai()


def main():
    root = tk.Tk()
    LudoGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
