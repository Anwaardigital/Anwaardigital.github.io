==============================================
 LENSCRAFT v1.0 (Windows)
==============================================
Photo filter app — open a photo, apply filters,
preview the result and save it.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Open a Command Prompt in this folder and run:
       pip install -r requirements.txt
3. Double-click run.bat (or run: python main.py)

CONTROLS
--------
- "Open Image..."  :  Photo kholen (PNG, JPG, BMP, GIF, WebP)
- Filters menu     :  Original, Grayscale, Sepia, Invert,
                      Contrast, Brightness, Blur, B&W
- Intensity slider :  Contrast, Brightness, Blur aur B&W
                      filter ki taqat (0-100) set karen
- "Save Result..." :  Filter lagane ke baad tasveer save karen

Note: Internet ki zaroorat NAHI — sab kaam offline hota hai.

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
