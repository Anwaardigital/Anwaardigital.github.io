"""
LensCraft Windows v1.0
Photo filter app: open an image, apply filters, preview, save.
Dependencies: Pillow (pip install -r requirements.txt)
Runs on Windows with Python 3: python main.py
"""
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from PIL import Image, ImageTk, ImageOps, ImageFilter, ImageEnhance
    PIL_AVAILABLE = True
except ImportError:
    Image = ImageTk = ImageOps = ImageFilter = ImageEnhance = None
    PIL_AVAILABLE = False

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
GOLD = "#D4AF37"
CREAM = "#FAF8F0"
WHITE = "#FFFFFF"
TEXT_DARK = "#1E2B26"
MUTED = "#5A6B63"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

PREVIEW_MAX = 320  # preview box size in px
FILTERS = ["Original", "Grayscale", "Sepia", "Invert", "Contrast", "Brightness", "Blur", "B&W"]


def apply_filter(img, name, intensity):
    """Apply the named filter to a PIL image. intensity: 0-100 slider value."""
    if name == "Original":
        return img
    if name == "Grayscale":
        return ImageOps.grayscale(img)
    if name == "Sepia":
        gray = ImageOps.grayscale(img).convert("RGB")
        # classic sepia tone matrix
        sepia = Image.new("RGB", gray.size)
        px = gray.load()
        out = sepia.load()
        for y in range(gray.size[1]):
            for x in range(gray.size[0]):
                r, g, b = px[x, y]
                tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                out[x, y] = (min(255, tr), min(255, tg), min(255, tb))
        return sepia
    if name == "Invert":
        rgb = img.convert("RGB")
        return ImageOps.invert(rgb)
    if name == "Contrast":
        factor = 0.2 + (intensity / 100.0) * 2.6   # 0.2 .. 2.8
        return ImageEnhance.Contrast(img.convert("RGB")).enhance(factor)
    if name == "Brightness":
        factor = 0.2 + (intensity / 100.0) * 2.3   # 0.2 .. 2.5
        return ImageEnhance.Brightness(img.convert("RGB")).enhance(factor)
    if name == "Blur":
        radius = (intensity / 100.0) * 12.0        # 0 .. 12
        return img.convert("RGB").filter(ImageFilter.GaussianBlur(radius))
    if name == "B&W":
        gray = ImageOps.grayscale(img)
        threshold = int(255 * (intensity / 100.0))
        return gray.point(lambda p: 255 if p > threshold else 0, mode="1").convert("RGB")
    return img


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LensCraft - Malik Muhammad Anwaar")
        self.geometry("860x700")
        self.configure(bg=CREAM)
        self.resizable(False, False)

        if not PIL_AVAILABLE:
            messagebox.showerror(
                "Pillow missing",
                "Pillow is not installed.\n\n"
                "Open Command Prompt in this folder and run:\n"
                "    pip install -r requirements.txt\n\n"
                "Then start the app again.")
            self.destroy()
            return

        self.img_path = None
        self.original = None      # full-size PIL image
        self.filtered = None      # full-size filtered PIL image
        self.photo = None         # Tk preview reference

        # ---- header ----
        header = tk.Frame(self, bg=DEEP_EMERALD, height=70)
        header.pack(fill="x")
        tk.Label(header, text="LENSCRAFT", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=18, pady=12)
        tk.Label(header, text="Photo Filters  •  Grayscale  •  Sepia  •  B&W",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                     side="left", padx=6, pady=24)
        tk.Label(header, text="📷", font=("Segoe UI", 26),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="right", padx=20)

        # ---- main body ----
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=14, pady=10)

        # left: filters panel
        left = tk.Frame(body, bg=WHITE, relief="flat", bd=1)
        left.pack(side="left", fill="y", padx=(0, 10))
        left.configure(highlightbackground="#E3DCC8", highlightthickness=1)
        tk.Label(left, text="FILTERS", font=("Segoe UI", 11, "bold"),
                 fg=DEEP_EMERALD, bg=WHITE).pack(pady=(12, 6), padx=18)

        self.filter_var = tk.StringVar(value="Original")
        for f in FILTERS:
            rb = tk.Radiobutton(left, text=f, variable=self.filter_var, value=f,
                               font=("Segoe UI", 10), bg=WHITE, fg=TEXT_DARK,
                               activebackground=WHITE, anchor="w",
                               command=self.on_filter_change)
            rb.pack(fill="x", padx=18, pady=3)

        tk.Label(left, text="Intensity", font=("Segoe UI", 10, "bold"),
                 fg=DEEP_EMERALD, bg=WHITE).pack(pady=(14, 2))
        self.intensity = tk.Scale(left, from_=0, to=100, orient="horizontal",
                                 bg=WHITE, fg=TEXT_DARK, highlightthickness=0,
                                 length=180, command=lambda _e: self.on_filter_change())
        self.intensity.set(50)
        self.intensity.pack(padx=18, pady=4)

        tk.Button(left, text="Open Image…", font=("Segoe UI", 10, "bold"),
                  bg=EMERALD, fg=WHITE, activebackground=DEEP_EMERALD,
                  activeforeground=WHITE, relief="flat", padx=16, pady=8,
                  command=self.open_image).pack(pady=(16, 6), padx=18)
        tk.Button(left, text="💾 Save Result…", font=("Segoe UI", 10, "bold"),
                  bg=GOLD, fg=DEEP_EMERALD, activebackground="#C19A2E",
                  relief="flat", padx=16, pady=8,
                  command=self.save_image).pack(pady=6, padx=18)

        self.info_lbl = tk.Label(left, text="No image loaded",
                                 font=("Segoe UI", 8), fg=MUTED, bg=WHITE,
                                 wraplength=190, justify="left")
        self.info_lbl.pack(pady=(12, 10), padx=14)

        # right: preview panel
        right = tk.Frame(body, bg=WHITE)
        right.pack(side="right", fill="both", expand=True)
        right.configure(highlightbackground="#E3DCC8", highlightthickness=1)
        tk.Label(right, text="PREVIEW", font=("Segoe UI", 11, "bold"),
                 fg=DEEP_EMERALD, bg=WHITE).pack(pady=(12, 4))
        self.preview_lbl = tk.Label(right, bg="#F1EFE6",
                                    text="Click “Open Image…”\nto load a photo",
                                    font=("Segoe UI", 11), fg=MUTED,
                                    width=52, height=20, anchor="center")
        self.preview_lbl.pack(padx=16, pady=6, fill="both", expand=True)
        self.status_lbl = tk.Label(right, text="Ready",
                                   font=("Segoe UI", 9, "italic"), fg=MUTED, bg=WHITE)
        self.status_lbl.pack(pady=(0, 10))

        # ---- footer ----
        footer = tk.Frame(self, bg=DEEP_EMERALD, height=34)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 8),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

    # ---------------- actions ----------------
    def open_image(self):
        path = filedialog.askopenfilename(
            title="Open image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.webp"),
                       ("All files", "*.*")])
        if not path:
            return
        try:
            self.original = Image.open(path)
            self.img_path = path
            w, h = self.original.size
            kb = os.path.getsize(path) / 1024
            self.info_lbl.config(
                text=f"{os.path.basename(path)}\n{w} × {h} px  •  {kb:,.0f} KB")
            self.status_lbl.config(text="Image loaded — pick a filter")
            self.on_filter_change()
        except Exception as e:
            messagebox.showerror("Open failed", f"Could not open image:\n{e}")

    def on_filter_change(self):
        if self.original is None:
            return
        name = self.filter_var.get()
        intensity = self.intensity.get()
        try:
            self.filtered = apply_filter(self.original, name, intensity)
            preview = self.filtered.copy()
            preview.thumbnail((PREVIEW_MAX, PREVIEW_MAX), Image.LANCZOS)
            self.photo = ImageTk.PhotoImage(preview)
            self.preview_lbl.config(image=self.photo, text="")
            self.status_lbl.config(text=f"Filter: {name}  •  intensity {intensity}%")
        except Exception as e:
            messagebox.showerror("Filter failed", f"Could not apply filter:\n{e}")

    def save_image(self):
        if self.filtered is None:
            messagebox.showinfo("Nothing to save", "Open an image and pick a filter first.")
            return
        base, _ = os.path.splitext(os.path.basename(self.img_path))
        fname = self.filter_var.get().lower().replace(" ", "-")
        path = filedialog.asksaveasfilename(
            title="Save filtered image",
            initialfile=f"{base}_{fname}.png",
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg;*.jpeg")])
        if not path:
            return
        try:
            out = self.filtered
            if path.lower().endswith((".jpg", ".jpeg")) and out.mode in ("RGBA", "LA", "P", "1"):
                out = out.convert("RGB")
            out.save(path, quality=95)
            self.status_lbl.config(text=f"Saved → {os.path.basename(path)}")
            messagebox.showinfo("Saved", f"Image saved:\n{path}")
        except Exception as e:
            messagebox.showerror("Save failed", f"Could not save image:\n{e}")


if __name__ == "__main__":
    App().mainloop()
