Car Driving Sim — Windows Version
===================================

Top-down free-roam driving: sheher ki sarkon par gaari chalao!

CHALANE KA TAREEQA:
1. Python 3 install karo (python.org se free download)
2. run.bat par double-click karo
   (ya: python main.py)

CONTROLS:
- UP arrow (ya W): accelerate
- DOWN arrow (ya S): brake / reverse
- LEFT/RIGHT arrow (ya A/D): steering
- N: nayi drive (restart)

GAME:
- Speed meter upar dikhegi (km/h)
- Score = kitni door drive ki (meters)
- Sarkon par tez, kacchi zameen (grass) par slow
- Map ki deewar (gold border) se takrao = BUMP! (speed kam)

------------------------------------
App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
