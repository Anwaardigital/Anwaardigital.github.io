# -*- coding: utf-8 -*-
"""
Car Driving Sim — Windows Desktop App
Top-down free-roam driving on a simple road map. Arrow-key steering,
speed display, collisions with map borders (and slow off-road driving),
score = distance driven. Python 3 + Tkinter only (no extra deps).
Theme: night city grid + emerald car + gold road markings.
"""

import tkinter as tk
from tkinter import messagebox
import math

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#0B0F1A"
GRASS = "#0F1F16"
ROAD_C = "#232B3A"
ROAD_EDGE = "#FFD700"
CAR = "#10B981"
TEXT = "#FFFFFF"
GOLD = "#FFD700"

WIDTH, HEIGHT = 640, 480
ROAD_W = 64

# road network: (x1,y1,x2,y2) rectangles
ROADS = [
    (40, 118, 600, 182),    # top horizontal
    (40, 298, 600, 362),    # middle horizontal
    (40, 118, 104, 430),    # left vertical
    (288, 118, 352, 430),   # center vertical
    (536, 118, 600, 430),   # right vertical
    (40, 366, 600, 430),    # bottom horizontal
]


class CarDriving:
    def __init__(self, root):
        self.root = root
        root.title("Car Driving Sim — Windows")
        root.geometry("%dx%d" % (WIDTH, HEIGHT + 70))
        root.configure(bg=BG)
        root.resizable(False, False)

        hud = tk.Frame(root, bg=BG)
        hud.pack(fill="x", padx=10, pady=5)
        self.speed_var = tk.StringVar(value="Speed: 0 km/h")
        self.dist_var = tk.StringVar(value="Distance: 0 m")
        tk.Label(hud, textvariable=self.speed_var, fg=GOLD, bg=BG,
                 font=("Arial", 12, "bold")).pack(side="left")
        tk.Label(hud, textvariable=self.dist_var, fg=TEXT, bg=BG,
                 font=("Arial", 12)).pack(side="right")

        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT,
                                bg=GRASS, highlightthickness=0)
        self.canvas.pack()

        foot = tk.Frame(root, bg=BG)
        foot.pack(fill="x", pady=4)
        tk.Label(foot, text=DEVELOPER_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()
        tk.Label(foot, text=WHATSAPP_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()

        self.keys = {"up": False, "down": False, "left": False, "right": False}
        root.bind("<KeyPress-Up>", lambda e: self._set("up", True))
        root.bind("<KeyRelease-Up>", lambda e: self._set("up", False))
        root.bind("<KeyPress-Down>", lambda e: self._set("down", True))
        root.bind("<KeyRelease-Down>", lambda e: self._set("down", False))
        root.bind("<KeyPress-Left>", lambda e: self._set("left", True))
        root.bind("<KeyRelease-Left>", lambda e: self._set("left", False))
        root.bind("<KeyPress-Right>", lambda e: self._set("right", True))
        root.bind("<KeyRelease-Right>", lambda e: self._set("right", False))
        root.bind("<KeyPress-w>", lambda e: self._set("up", True))
        root.bind("<KeyRelease-w>", lambda e: self._set("up", False))
        root.bind("<KeyPress-s>", lambda e: self._set("down", True))
        root.bind("<KeyRelease-s>", lambda e: self._set("down", False))
        root.bind("<KeyPress-a>", lambda e: self._set("left", True))
        root.bind("<KeyRelease-a>", lambda e: self._set("left", False))
        root.bind("<KeyPress-d>", lambda e: self._set("right", True))
        root.bind("<KeyRelease-d>", lambda e: self._set("right", False))
        root.bind("<n>", lambda e: self.restart())
        root.bind("<N>", lambda e: self.restart())

        self.restart()
        self.game_loop()

    def _set(self, k, v):
        self.keys[k] = v

    def restart(self):
        self.x = 320.0
        self.y = 150.0
        self.angle = 0.0          # degrees, 0 = pointing right
        self.speed = 0.0          # px/s
        self.distance = 0.0
        self.bump_flash = 0
        self.show_help = True

    def on_road(self, x, y):
        for (x1, y1, x2, y2) in ROADS:
            if x1 <= x <= x2 and y1 <= y <= y2:
                return True
        return False

    # ---------- physics (testable without GUI) ----------
    def step(self, dt=1.0 / 40):
        onroad = self.on_road(self.x, self.y)
        max_speed = 280.0 if onroad else 90.0
        if self.keys["up"]:
            self.speed += 220.0 * dt
            self.show_help = False
        if self.keys["down"]:
            self.speed -= 260.0 * dt if self.speed > 0 else 60.0 * dt
            self.speed = max(self.speed, -70.0)
            self.show_help = False
        # drag
        self.speed -= self.speed * (0.6 if onroad else 1.6) * dt
        if abs(self.speed) < 2 and not self.keys["up"] and not self.keys["down"]:
            self.speed = 0
        self.speed = max(-70.0, min(max_speed, self.speed))
        # steering scales with speed
        steer_power = 150.0 * min(1.0, abs(self.speed) / 120.0)
        if self.keys["left"]:
            self.angle -= steer_power * dt * (1 if self.speed >= 0 else -1)
            self.show_help = False
        if self.keys["right"]:
            self.angle += steer_power * dt * (1 if self.speed >= 0 else -1)
            self.show_help = False
        rad = math.radians(self.angle)
        nx = self.x + math.cos(rad) * self.speed * dt
        ny = self.y + math.sin(rad) * self.speed * dt
        # border collision
        hit = False
        if nx < 14 or nx > WIDTH - 14:
            hit = True
            nx = max(14, min(WIDTH - 14, nx))
        if ny < 14 or ny > HEIGHT - 14:
            hit = True
            ny = max(14, min(HEIGHT - 14, ny))
        if hit:
            self.speed *= 0.25
            self.bump_flash = 12
        self.distance += math.hypot(nx - self.x, ny - self.y)
        self.x, self.y = nx, ny
        if self.bump_flash > 0:
            self.bump_flash -= 1

    def draw_car(self, x, y, angle):
        c = self.canvas
        L, Wd = 44, 24
        rad = math.radians(angle)
        dx, dy = math.cos(rad), math.sin(rad)
        nx, ny = -dy, dx
        pts = []
        for s, t in [(-L / 2, -Wd / 2), (L / 2, -Wd / 2),
                     (L / 2, Wd / 2), (-L / 2, Wd / 2)]:
            pts += [x + s * dx + t * nx, y + s * dy + t * ny]
        body = "#EF4444" if self.bump_flash else CAR
        c.create_polygon(pts, fill=body, outline="#064E3B", width=2)
        # windshield + roof
        wx, wy = x + 6 * dx, y + 6 * dy
        c.create_oval(wx - 8, wy - 8, wx + 8, wy + 8, fill="#B0E0E6", outline="")
        # headlights
        hx, hy = x + (L / 2) * dx, y + (L / 2) * dy
        c.create_oval(hx - 4 + nx * 8, hy - 4 + ny * 8,
                      hx + 4 + nx * 8, hy + 4 + ny * 8, fill="#FEF9C3", outline="")
        c.create_oval(hx - 4 - nx * 8, hy - 4 - ny * 8,
                      hx + 4 - nx * 8, hy + 4 - ny * 8, fill="#FEF9C3", outline="")

    def game_loop(self):
        self.step()
        c = self.canvas
        c.delete("all")
        # grass texture dots
        for gx in range(0, WIDTH, 40):
            for gy in range(0, HEIGHT, 40):
                if (gx + gy) % 80 == 0:
                    c.create_oval(gx, gy, gx + 4, gy + 4, fill="#14301F", outline="")
        # roads
        for (x1, y1, x2, y2) in ROADS:
            c.create_rectangle(x1, y1, x2, y2, fill=ROAD_C, outline="")
        # center dashes
        for (x1, y1, x2, y2) in ROADS:
            if x2 - x1 > y2 - y1:  # horizontal
                my = (y1 + y2) / 2
                x = x1 + 10
                while x < x2 - 10:
                    c.create_rectangle(x, my - 2, x + 16, my + 2,
                                       fill=ROAD_EDGE, outline="")
                    x += 32
            else:  # vertical
                mx = (x1 + x2) / 2
                y = y1 + 10
                while y < y2 - 10:
                    c.create_rectangle(mx - 2, y, mx + 2, y + 16,
                                       fill=ROAD_EDGE, outline="")
                    y += 32
        # border
        c.create_rectangle(4, 4, WIDTH - 4, HEIGHT - 4, outline=GOLD, width=3)

        self.draw_car(self.x, self.y, self.angle)

        if self.bump_flash:
            c.create_text(WIDTH // 2, 40, text="BUMP!", fill="#EF4444",
                          font=("Arial", 16, "bold"))
        if self.show_help:
            c.create_rectangle(WIDTH // 2 - 190, HEIGHT // 2 - 55,
                               WIDTH // 2 + 190, HEIGHT // 2 + 55,
                               fill="#000000", outline=GOLD, width=2)
            c.create_text(WIDTH // 2, HEIGHT // 2 - 20, text="CAR DRIVING SIM",
                          fill=GOLD, font=("Arial", 20, "bold"))
            c.create_text(WIDTH // 2, HEIGHT // 2 + 15,
                          text="↑ accelerate   ↓ brake\n← → steer   (WASD works too)\nN: restart",
                          fill=TEXT, font=("Arial", 11), justify="center")

        kmh = abs(self.speed) * 0.45
        self.speed_var.set("Speed: %d km/h" % int(kmh))
        self.dist_var.set("Distance: %d m" % int(self.distance / 12))

        self.root.after(25, self.game_loop)


def main():
    root = tk.Tk()
    CarDriving(root)
    root.mainloop()


if __name__ == "__main__":
    main()
