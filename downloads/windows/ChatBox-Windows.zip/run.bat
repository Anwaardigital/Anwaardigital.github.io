@echo off
title ChatBox
python main.py
pause
