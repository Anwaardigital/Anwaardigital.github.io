# -*- coding: utf-8 -*-
"""
ChatBox — Windows Desktop App
WhatsApp-style chat demo (local simulation): chat list,
conversation window, auto-replies. Python 3 + Tkinter only
(no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import json
import os
import random
import tkinter as tk
from tkinter import messagebox

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(APP_DIR, "chatbox_data.json")

BG = "#075E54"        # WhatsApp dark teal
BG_DARK = "#054A43"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
CHAT_BG = "#E5DDD5"
SENT = "#DCF8C6"
RECV = "#FFFFFF"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

CONTACTS = [
    {"name": "Malik Anwaar", "status": "online",
     "msgs": [("in", "Assalam o Alaikum! ChatBox mein khush aamdeed! 👋"),
              ("in", "Ye demo hai — kuch likhein, main jawab dunga 🙂")]},
    {"name": "Family Group", "status": "3 members",
     "msgs": [("in", "Ali: Eid Mubarak sab ko! 🌙"),
              ("in", "Ammi: Khana tayyar hai, sab aa jao"),
              ("out", "Main 5 min mein aaya!")]},
    {"name": "Awais Bhai", "status": "last seen today",
     "msgs": [("in", "Dost, kal match hai — aaoge?"),
              ("out", "InshaAllah zaroor!"),
              ("in", "Ground 4 baje, time par aa jana 👍")]},
]

REPLIES = [
    "Wah, zabardast! 😄",
    "Hmm, samajh gaya. Aur batao?",
    "Bilkul sahi keh rahe ho! 👍",
    "Ye to bohat achhi baat hai!",
    "Main demo bot hun — lekin aap ki baat samajh gaya 🙂",
    "Interesting! Aur detail batao?",
    "Theek hai dost, note kar liya ✅",
    "Haha, sahi kaha! 😂",
]


def default_data():
    return {"contacts": CONTACTS}


def load_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default_data()


def save_data(d):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ChatBox — چیٹ")
        self.geometry("960x640")
        self.configure(bg=BG)
        self.data = load_data()
        self.current = 0
        self._build()
        self.render_chat()

    def _build(self):
        head = tk.Frame(self, bg=BG_DARK, height=64)
        head.pack(fill="x")
        tk.Label(head, text="💬 ChatBox", font=("Segoe UI", 17, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(side="left", padx=14, pady=12)
        tk.Label(head, text="WhatsApp-style chat demo (local simulation)",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG_DARK).pack(
                 side="left", padx=6)

        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True)

        # ---- chat list ----
        left = tk.Frame(mid, bg=WHITE, width=280)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        tk.Label(left, text="Chats", font=("Segoe UI", 12, "bold"),
                 fg=BG, bg=WHITE).pack(anchor="w", padx=12, pady=(10, 4))
        self.clist = tk.Listbox(left, font=("Segoe UI", 11), bg=WHITE,
                                fg=BG_DARK, selectbackground=BG,
                                selectforeground=WHITE, relief="flat",
                                activestyle="none")
        self.clist.pack(fill="both", expand=True, padx=6, pady=4)
        self.clist.bind("<<ListboxSelect>>", self.pick_chat)
        for i, c in enumerate(self.data["contacts"]):
            self.clist.insert("end", f"  {c['name']}")
        self.clist.select_set(0)

        # ---- conversation ----
        right = tk.Frame(mid, bg=CHAT_BG)
        right.pack(side="left", fill="both", expand=True)

        top = tk.Frame(right, bg="#F0F0F0", height=52)
        top.pack(fill="x")
        self.cname = tk.Label(top, text="", font=("Segoe UI", 13, "bold"),
                              fg=BG_DARK, bg="#F0F0F0")
        self.cname.pack(side="left", padx=12, pady=6)
        self.cstatus = tk.Label(top, text="", font=("Segoe UI", 9),
                                fg="#666666", bg="#F0F0F0")
        self.cstatus.pack(side="left", padx=4)

        self.view = tk.Text(right, font=("Segoe UI", 11), bg=CHAT_BG,
                            wrap="word", relief="flat", padx=12, pady=10,
                            state="disabled")
        self.view.pack(fill="both", expand=True)
        self.view.tag_config("sent", background=SENT, justify="right",
                             lmargin1=120, rmargin=10, spacing1=4,
                             spacing3=4, borderwidth=6, relief="flat")
        self.view.tag_config("recv", background=RECV, justify="left",
                             lmargin1=10, rmargin=120, spacing1=4,
                             spacing3=4, borderwidth=6, relief="flat")

        bot = tk.Frame(right, bg="#F0F0F0")
        bot.pack(fill="x")
        self.entry = tk.Entry(bot, font=("Segoe UI", 11))
        self.entry.pack(side="left", fill="x", expand=True, padx=10, pady=10)
        self.entry.bind("<Return>", lambda e: self.send())
        tk.Button(bot, text="➤ Send", font=("Segoe UI", 11, "bold"),
                  bg=BG, fg=WHITE, relief="flat", padx=16,
                  command=self.send).pack(side="left", padx=(0, 10))

        foot = tk.Frame(self, bg=BG_DARK)
        foot.pack(fill="x")
        tk.Label(foot, text=DEVELOPER_LINE, font=("Segoe UI", 9),
                 fg=GOLD, bg=BG_DARK).pack(pady=(6, 0))
        tk.Label(foot, text=WHATSAPP_LINE, font=("Segoe UI", 9),
                 fg=CREAM, bg=BG_DARK).pack(pady=(0, 6))

    def pick_chat(self, _e=None):
        sel = self.clist.curselection()
        if sel:
            self.current = sel[0]
            self.render_chat()

    def render_chat(self):
        c = self.data["contacts"][self.current]
        self.cname.config(text="👤 " + c["name"])
        self.cstatus.config(text=c.get("status", ""))
        self.view.config(state="normal")
        self.view.delete("1.0", "end")
        for who, txt in c["msgs"]:
            self.view.insert("end", txt + "\n",
                             "sent" if who == "out" else "recv")
        self.view.config(state="disabled")
        self.view.see("end")

    def send(self):
        txt = self.entry.get().strip()
        if not txt:
            return
        c = self.data["contacts"][self.current]
        c["msgs"].append(("out", txt))
        self.entry.delete(0, "end")
        save_data(self.data)
        self.render_chat()
        # demo auto-reply
        self.after(1200, lambda: self.auto_reply(c))

    def auto_reply(self, c):
        c["msgs"].append(("in", random.choice(REPLIES)))
        save_data(self.data)
        self.render_chat()


if __name__ == "__main__":
    App().mainloop()
