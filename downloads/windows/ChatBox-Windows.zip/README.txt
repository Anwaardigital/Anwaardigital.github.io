ChatBox - Windows App (DEMO)
========================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features (demo - local simulation):
- WhatsApp-style chat interface
- 3 sample chats (Malik Anwaar, Family Group, Awais Bhai)
- Message bhejein - demo bot foran jawab dega
- Chats chatbox_data.json mein save hoti hain

Note: ye DEMO hai - messages sirf aap ke computer par
rehti hain, internet par nahi jatin.

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
