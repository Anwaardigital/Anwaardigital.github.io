Turbo Racer 3D — Windows Version
====================================

Ek simple top-down arcade racing game!

CHALANE KA TAREEQA:
1. Python 3 install karo (python.org se free download)
2. run.bat par double-click karo
   (ya: python main.py)

CONTROLS:
- LEFT/RIGHT arrow ya A/D: gaari move karo
- SPACE: dobara start karo

GAME:
- Traffic se bacho!
- Jitni door jao ge, speed barhe gi
- Score barhao!

------------------------------------
App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
