# -*- coding: utf-8 -*-
"""
Turbo Racer 3D — Windows Desktop App (2D top-down arcade racer)
Python 3 + Tkinter only (no extra deps).
Theme: dark asphalt + neon. Simple fun arcade racing.
"""

import tkinter as tk
from tkinter import messagebox
import random
import time

DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

BG = "#0B0F1A"
ROAD = "#1C2333"
LINE = "#FFD700"
PLAYER_COLOR = "#00E5FF"
ENEMY_COLORS = ["#FF3B3B", "#FF8C00", "#B537F2", "#7CFC00"]
TEXT = "#FFFFFF"
GOLD = "#FFD700"

WIDTH, HEIGHT = 480, 640
LANES = [110, 240, 370]
PLAYER_Y = HEIGHT - 120


class TurboRacer:
    def __init__(self, root):
        self.root = root
        root.title("Turbo Racer 3D — Windows")
        root.geometry(f"{WIDTH}x{HEIGHT+70}")
        root.configure(bg=BG)
        root.resizable(False, False)

        # HUD
        hud = tk.Frame(root, bg=BG)
        hud.pack(fill="x", padx=10, pady=5)
        self.score_var = tk.StringVar(value="Score: 0")
        self.speed_var = tk.StringVar(value="Speed: 0 km/h")
        tk.Label(hud, textvariable=self.score_var, fg=GOLD, bg=BG,
                 font=("Arial", 12, "bold")).pack(side="left")
        tk.Label(hud, textvariable=self.speed_var, fg=TEXT, bg=BG,
                 font=("Arial", 12)).pack(side="right")

        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT,
                                bg=ROAD, highlightthickness=0)
        self.canvas.pack()

        # Footer
        foot = tk.Frame(root, bg=BG)
        foot.pack(fill="x", pady=4)
        tk.Label(foot, text=DEVELOPER_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()
        tk.Label(foot, text=WHATSAPP_LINE, fg="#888888", bg=BG,
                 font=("Arial", 8)).pack()

        # Controls
        root.bind("<Left>", lambda e: self.move(-1))
        root.bind("<Right>", lambda e: self.move(1))
        root.bind("<a>", lambda e: self.move(-1))
        root.bind("<d>", lambda e: self.move(1))
        root.bind("<space>", lambda e: self.restart())
        root.bind("<Return>", lambda e: self.restart())

        self.restart()
        self.game_loop()

    def restart(self):
        self.lane = 1
        self.score = 0
        self.speed = 5
        self.enemies = []
        self.road_offset = 0
        self.alive = True
        self.spawn_timer = 0
        self.draw_hint()

    def draw_hint(self):
        self.canvas.delete("all")
        self.canvas.create_text(WIDTH//2, HEIGHT//2 - 40, text="TURBO RACER",
                               fill=GOLD, font=("Arial", 28, "bold"))
        self.canvas.create_text(WIDTH//2, HEIGHT//2 + 10,
                               text="← → / A D to steer\nSPACE to restart",
                               fill=TEXT, font=("Arial", 12), justify="center")

    def move(self, direction):
        if not self.alive:
            return
        self.lane = max(0, min(2, self.lane + direction))

    def spawn_enemy(self):
        lane = random.choice([0, 1, 2])
        color = random.choice(ENEMY_COLORS)
        self.enemies.append({"lane": lane, "y": -60, "color": color})

    def draw_car(self, x, y, color, is_player=False):
        w, h = 44, 70
        # body
        self.canvas.create_rectangle(x-w//2, y-h//2, x+w//2, y+h//2,
                                     fill=color, outline="#000000", width=2)
        # windshield
        self.canvas.create_rectangle(x-w//2+6, y-h//2+10, x+w//2-6, y-5,
                                     fill="#B0E0E6", outline="")
        # wheels
        for wx, wy in [(-w//2-4, -h//4), (w//2+4, -h//4),
                       (-w//2-4, h//4), (w//2+4, h//4)]:
            self.canvas.create_rectangle(x+wx-5, y+wy-10, x+wx+5, y+wy+10,
                                         fill="#111111", outline="")
        if is_player:
            # spoiler
            self.canvas.create_rectangle(x-w//2-6, y+h//2-6, x+w//2+6, y+h//2+2,
                                         fill="#333333", outline="")

    def game_loop(self):
        if self.alive:
            self.canvas.delete("all")
            # Road markings
            self.road_offset = (self.road_offset + self.speed) % 60
            for lx in [175, 305]:
                for y in range(-60, HEIGHT+60, 60):
                    yy = y + self.road_offset
                    self.canvas.create_rectangle(lx-3, yy, lx+3, yy+30,
                                                 fill=LINE, outline="")
            # Spawn enemies
            self.spawn_timer += 1
            if self.spawn_timer > max(20, 50 - self.speed):
                self.spawn_timer = 0
                self.spawn_enemy()

            # Move + draw enemies
            px, py = LANES[self.lane], PLAYER_Y
            for e in self.enemies[:]:
                e["y"] += self.speed + 2
                if e["y"] > HEIGHT + 80:
                    self.enemies.remove(e)
                    self.score += 10
                    continue
                ex = LANES[e["lane"]]
                self.draw_car(ex, e["y"], e["color"])
                # Collision
                if abs(ex - px) < 44 and abs(e["y"] - py) < 70:
                    self.alive = False

            # Player
            self.draw_car(px, py, PLAYER_COLOR, is_player=True)

            # Difficulty
            self.speed = min(14, 5 + self.score // 200)
            self.score += 1

            self.score_var.set(f"Score: {self.score}")
            self.speed_var.set(f"Speed: {self.speed*18} km/h")
        else:
            self.canvas.create_rectangle(60, HEIGHT//2-70, WIDTH-60, HEIGHT//2+70,
                                         fill="#000000", outline=GOLD, width=2)
            self.canvas.create_text(WIDTH//2, HEIGHT//2-25, text="GAME OVER",
                                    fill="#FF3B3B", font=("Arial", 24, "bold"))
            self.canvas.create_text(WIDTH//2, HEIGHT//2+10,
                                    text=f"Score: {self.score}",
                                    fill=TEXT, font=("Arial", 14))
            self.canvas.create_text(WIDTH//2, HEIGHT//2+40,
                                    text="Press SPACE to restart",
                                    fill=GOLD, font=("Arial", 11))

        self.root.after(40, self.game_loop)


def main():
    root = tk.Tk()
    TurboRacer(root)
    root.mainloop()


if __name__ == "__main__":
    main()
