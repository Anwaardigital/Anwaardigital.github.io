==============================================
 DOCUMENT SCANNER v1.0 (Windows, basic)
==============================================
Clean up photos of documents: grayscale,
black-and-white threshold, contrast enhance.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Open a Command Prompt in this folder and run:
       pip install -r requirements.txt
3. Double-click run.bat (or run: python main.py)

FEATURES
--------
- Open a photo of any document
- Grayscale filter
- Black & White filter with adjustable threshold slider
- Contrast enhancement with adjustable slider
- Side-by-side original vs scanned preview
- Save result as PNG or JPG

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
