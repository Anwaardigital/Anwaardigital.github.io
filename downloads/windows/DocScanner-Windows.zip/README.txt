==============================================
 DOCUMENT SCANNER v4.0 (Windows)
==============================================
Clean up photos of documents: adaptive B&W,
grayscale, manual threshold, contrast enhance.
Save as PDF, PNG or JPG.

HOW TO RUN ON WINDOWS
---------------------
1. Install Python 3 from https://www.python.org/downloads/
   (IMPORTANT: tick "Add python.exe to PATH" during setup)
2. Open a Command Prompt in this folder and run:
       pip install -r requirements.txt
3. Double-click run.bat (or run: python main.py)

FEATURES (v4.0)
---------------
- Open a photo of any document
- B&W Doc (Auto) — adaptive threshold, handles shadows
  (same smart filter as the Android v4.0 app)
- Grayscale filter
- Black & White with manual threshold slider
- Contrast enhancement with adjustable slider
- Side-by-side original vs scanned preview
- Save result as PDF, PNG or JPG

App developed by Malik Muhammad Anwaar | WhatsApp: 923288317526
