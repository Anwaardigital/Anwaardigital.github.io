"""
Document Scanner Windows v4.0
Open an image/photo of a document, then apply:
  - Grayscale
  - B&W Doc (Auto/Adaptive threshold)  <-- NEW in v4.0, matches Android
  - Black & White threshold (manual slider)
  - Enhance contrast (slider)
... save as PNG, JPG, or PDF.
Dependencies: Pillow (pip install Pillow)
Runs on Windows with Python 3: python main.py
"""
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from PIL import Image, ImageTk, ImageOps, ImageEnhance, ImageFilter, ImageChops
    PIL_AVAILABLE = True
except ImportError:
    Image = ImageTk = ImageOps = ImageEnhance = ImageFilter = ImageChops = None
    PIL_AVAILABLE = False

# ---------- Emerald / Gold theme ----------
DEEP_EMERALD = "#0B3D2E"
EMERALD = "#0E7C5B"
GOLD = "#D4AF37"
CREAM = "#FAF8F0"
TEXT_DARK = "#1E2B26"
FOOTER_TEXT = "App developed by Malik Muhammad Anwaar  |  WhatsApp: 923288317526"

PREVIEW_W = 300
PREVIEW_H = 400


def adaptive_bw(image, block_radius=25, offset=12):
    """Adaptive B&W threshold (like Android v4.0).

    Local threshold = blurred (local mean) minus offset.
    Handles shadows and uneven lighting far better than a fixed threshold.
    """
    gray = image.convert("L")
    # Local mean via box blur. Radius must exceed typical text stroke width
    # so the window is dominated by background, not the text itself.
    r = max(15, min(120, min(gray.size) // 12))
    local_mean = gray.filter(ImageFilter.BoxBlur(r))
    # pixel > local_mean - offset  -> white, else black.
    # subtract() clips at 0 (no absolute value), so result > 0 iff gray > shifted.
    shifted = local_mean.point(lambda p: max(0, p - offset))
    above = ImageChops.subtract(gray, shifted)
    return above.point(lambda p: 255 if p > 0 else 0, mode="L")


def apply_scan_filter(image, mode, threshold=128, contrast=1.0):
    """Apply the chosen scan filter and return a new PIL Image (grayscale-based)."""
    img = image.convert("L")
    if mode == "gray":
        return img
    if mode == "bw_auto":
        return adaptive_bw(image)
    if mode == "bw":
        return img.point(lambda p: 255 if p > threshold else 0, mode="L")
    if mode == "contrast":
        return ImageEnhance.Contrast(img).enhance(contrast)
    raise ValueError("Unknown mode: %s" % mode)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Document Scanner v4.0 - Malik Muhammad Anwaar")
        self.geometry("760x740")
        self.configure(bg=CREAM)
        self.resizable(False, False)

        self.src_image = None      # original PIL image
        self.result_image = None   # filtered PIL image
        self.before_photo = None   # keep references
        self.after_photo = None

        header = tk.Frame(self, bg=DEEP_EMERALD, height=64)
        header.pack(fill="x")
        tk.Label(header, text="DOCUMENT SCANNER  v4.0", font=("Segoe UI", 18, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(side="left", padx=16, pady=12)
        tk.Label(header, text="Auto B&W  •  Grayscale  •  Contrast",
                 font=("Segoe UI", 9), fg="#CFE8DD", bg=DEEP_EMERALD).pack(
                 side="left", padx=8, pady=12)

        # ---- before / after previews ----
        views = tk.Frame(self, bg=CREAM)
        views.pack(fill="x", padx=12, pady=8)

        left = tk.LabelFrame(views, text="Original", bg=CREAM, fg=TEXT_DARK,
                             font=("Segoe UI", 10, "bold"))
        left.pack(side="left", expand=True, fill="both", padx=(0, 6))
        self.before_lbl = tk.Label(left, bg="#E9EFEB", width=34, height=20,
                                   text="No image", font=("Segoe UI", 10),
                                   fg=TEXT_DARK)
        self.before_lbl.pack(padx=8, pady=8)

        right = tk.LabelFrame(views, text="Scanned result", bg=CREAM,
                              fg=EMERALD, font=("Segoe UI", 10, "bold"))
        right.pack(side="left", expand=True, fill="both", padx=(6, 0))
        self.after_lbl = tk.Label(right, bg="#E9EFEB", width=34, height=20,
                                  text="No result", font=("Segoe UI", 10),
                                  fg=TEXT_DARK)
        self.after_lbl.pack(padx=8, pady=8)

        # ---- filter options ----
        opts = tk.LabelFrame(self, text="Scan filters", bg=CREAM, fg=TEXT_DARK,
                             font=("Segoe UI", 10, "bold"))
        opts.pack(fill="x", padx=12, pady=(0, 8))

        self.mode = tk.StringVar(value="bw_auto")
        modes = [("B&W Doc (Auto — recommended)", "bw_auto"),
                 ("Grayscale", "gray"),
                 ("Black && White (manual threshold)", "bw"),
                 ("Enhance contrast", "contrast")]
        for text, val in modes:
            tk.Radiobutton(opts, text=text, variable=self.mode, value=val,
                           bg=CREAM, fg=TEXT_DARK, font=("Segoe UI", 10),
                           command=self._refresh).pack(anchor="w", padx=14)

        sl = tk.Frame(opts, bg=CREAM)
        sl.pack(fill="x", padx=14, pady=6)
        tk.Label(sl, text="B&W threshold:", bg=CREAM, fg=TEXT_DARK,
                 font=("Segoe UI", 10)).pack(side="left")
        self.threshold_var = tk.IntVar(value=140)
        tk.Scale(sl, from_=1, to=254, orient="horizontal",
                 variable=self.threshold_var, bg=CREAM, fg=TEXT_DARK,
                 length=200, command=lambda _e: self._refresh()
                 ).pack(side="left", padx=8)
        tk.Label(sl, text="Contrast:", bg=CREAM, fg=TEXT_DARK,
                 font=("Segoe UI", 10)).pack(side="left", padx=(14, 0))
        self.contrast_var = tk.DoubleVar(value=1.8)
        tk.Scale(sl, from_=1.0, to=4.0, resolution=0.1, orient="horizontal",
                 variable=self.contrast_var, bg=CREAM, fg=TEXT_DARK,
                 length=200, command=lambda _e: self._refresh()
                 ).pack(side="left", padx=8)

        # ---- buttons ----
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(pady=8)
        style = ttk.Style(self)
        style.configure("Emerald.TButton", font=("Segoe UI", 10, "bold"))
        ttk.Button(btns, text="Open Image…", command=self.open_image,
                   style="Emerald.TButton").pack(side="left", padx=8)
        ttk.Button(btns, text="Apply Filter", command=self._refresh,
                   style="Emerald.TButton").pack(side="left", padx=8)
        ttk.Button(btns, text="SAVE AS…", command=self.save_image,
                   style="Emerald.TButton").pack(side="left", padx=8)

        footer = tk.Frame(self, bg=DEEP_EMERALD)
        footer.pack(fill="x", side="bottom")
        tk.Label(footer, text=FOOTER_TEXT, font=("Segoe UI", 9, "bold"),
                 fg=GOLD, bg=DEEP_EMERALD).pack(pady=8)

        if not PIL_AVAILABLE:
            messagebox.showwarning(
                "Missing dependency",
                "Pillow is not installed.\n"
                "Run: pip install -r requirements.txt")

    def open_image(self):
        path = filedialog.askopenfilename(
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.webp"),
                       ("All files", "*.*")])
        if not path:
            return
        try:
            self.src_image = Image.open(path).convert("RGB")
        except Exception as e:
            return messagebox.showerror("Open failed", str(e))
        self._show(self.src_image, self.before_lbl, "before")
        self._refresh()

    def _show(self, img, widget, which):
        thumb = img.copy()
        thumb.thumbnail((PREVIEW_W, PREVIEW_H), Image.LANCZOS)
        photo = ImageTk.PhotoImage(thumb)
        widget.configure(image=photo, text="")
        if which == "before":
            self.before_photo = photo
        else:
            self.after_photo = photo

    def _refresh(self):
        if self.src_image is None or not PIL_AVAILABLE:
            return
        try:
            self.result_image = apply_scan_filter(
                self.src_image, self.mode.get(),
                threshold=self.threshold_var.get(),
                contrast=self.contrast_var.get())
        except Exception as e:
            return messagebox.showerror("Filter failed", str(e))
        self._show(self.result_image, self.after_lbl, "after")

    def save_image(self):
        if self.result_image is None:
            return messagebox.showinfo("Save", "Open an image first.")
        out = filedialog.asksaveasfilename(
            defaultextension=".pdf", initialfile="scanned.pdf",
            filetypes=[("PDF", "*.pdf"), ("PNG", "*.png"),
                       ("JPEG", "*.jpg *.jpeg"), ("All files", "*.*")])
        if not out:
            return
        try:
            img = self.result_image
            low = out.lower()
            if low.endswith(".pdf"):
                img.convert("RGB").save(out, "PDF", resolution=200.0)
            elif low.endswith((".jpg", ".jpeg")):
                img.convert("RGB").save(out, "JPEG", quality=95)
            else:
                img.save(out)
            messagebox.showinfo("Done", "Scanned file saved to:\n%s" % out)
        except Exception as e:
            messagebox.showerror("Save failed", str(e))


if __name__ == "__main__":
    App().mainloop()
