# -*- coding: utf-8 -*-
"""
Download Manager — Windows Desktop App
YouTube URL helper: detects yt-dlp if installed and can download,
otherwise shows easy install instructions (100% free).
Python 3 + Tkinter only (no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import os
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

BG = "#1A3C5E"        # deep blue
BG_DARK = "#0F2740"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
GREEN = "#2ECC71"
RED = "#E63946"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"


def have_ytdlp():
    """True if `yt-dlp` command or python module is available."""
    if shutil.which("yt-dlp"):
        return True
    try:
        import yt_dlp  # noqa: F401
        return True
    except Exception:
        return False


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Download Manager — ڈاؤنلوڈ")
        self.geometry("900x660")
        self.configure(bg=BG)
        self.save_dir = os.path.join(os.path.expanduser("~"), "Downloads")
        self._build()
        self.refresh_status()

    def _build(self):
        head = tk.Frame(self, bg=BG_DARK, height=86)
        head.pack(fill="x")
        tk.Label(head, text="⬇ Download Manager", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(pady=(10, 0))
        tk.Label(head, text="YouTube downloader helper — 100% free",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG_DARK).pack(pady=(0, 8))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=14, pady=10)

        self.status = tk.Label(body, text="", font=("Segoe UI", 11, "bold"),
                               fg=CREAM, bg=BG, anchor="w", justify="left")
        self.status.pack(fill="x", pady=(0, 8))

        tk.Label(body, text="YouTube video URL:", font=("Segoe UI", 11, "bold"),
                 fg=GOLD, bg=BG).pack(anchor="w")
        row = tk.Frame(body, bg=BG)
        row.pack(fill="x", pady=6)
        self.url = tk.Entry(row, font=("Segoe UI", 11))
        self.url.pack(side="left", fill="x", expand=True, ipady=4)

        row2 = tk.Frame(body, bg=BG)
        row2.pack(fill="x", pady=4)
        tk.Label(row2, text="Quality:", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left")
        self.quality = ttk.Combobox(row2, values=["Best", "720p", "480p",
                                                  "360p (small file)",
                                                  "Audio only (MP3)"],
                                    state="readonly", width=18,
                                    font=("Segoe UI", 10))
        self.quality.set("720p")
        self.quality.pack(side="left", padx=6)
        tk.Button(row2, text="📁 Save folder", font=("Segoe UI", 10, "bold"),
                  bg=GOLD, fg=BG_DARK, relief="flat", padx=8,
                  command=self.pick_dir).pack(side="left", padx=8)
        self.dir_lbl = tk.Label(row2, text=self.save_dir,
                                font=("Segoe UI", 9), fg=CREAM, bg=BG)
        self.dir_lbl.pack(side="left", padx=4)

        tk.Button(body, text="⬇ DOWNLOAD", font=("Segoe UI", 13, "bold"),
                  bg=GREEN, fg=WHITE, relief="flat", padx=30, pady=6,
                  command=self.download).pack(pady=10)

        tk.Label(body, text="Log:", font=("Segoe UI", 11, "bold"),
                 fg=GOLD, bg=BG).pack(anchor="w")
        self.log = tk.Text(body, font=("Consolas", 10), bg=WHITE, fg=BG_DARK,
                           wrap="word", relief="flat", height=10)
        self.log.pack(fill="both", expand=True, pady=4)

        tk.Label(body, text="Kaise use karein (How to use):",
                 font=("Segoe UI", 11, "bold"), fg=GOLD,
                 bg=BG).pack(anchor="w", pady=(8, 2))
        help_txt = (
            "1. YouTube app/website se video ka link copy karein.\n"
            "2. Upar box mein paste karein, quality chunein, DOWNLOAD dabayein.\n"
            "3. Agar yt-dlp install nahi — neeche 'Install yt-dlp' dabayein\n"
            "   (ek dafa internet se install hoga, phir hamesha kaam karega).\n"
            "4. Sirf apni ya ijazat-shuda videos download karein.")
        tk.Label(body, text=help_txt, font=("Segoe UI", 10), fg=CREAM, bg=BG,
                 justify="left", anchor="w").pack(anchor="w")

        tk.Button(body, text="⚙ Install yt-dlp (one time)",
                  font=("Segoe UI", 10, "bold"), bg=GOLD, fg=BG_DARK,
                  relief="flat", padx=10, command=self.install_ytdlp).pack(
                  anchor="w", pady=6)

        foot = tk.Frame(self, bg=BG_DARK)
        foot.pack(fill="x")
        tk.Label(foot, text=DEVELOPER_LINE, font=("Segoe UI", 9),
                 fg=GOLD, bg=BG_DARK).pack(pady=(6, 0))
        tk.Label(foot, text=WHATSAPP_LINE + " | 100% FREE — no license needed",
                 font=("Segoe UI", 9), fg=CREAM, bg=BG_DARK).pack(pady=(0, 6))

    # ---- helpers ----
    def say(self, msg):
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.update_idletasks()

    def refresh_status(self):
        if have_ytdlp():
            self.status.config(text="✅ yt-dlp ready — download kaam karega!",
                               fg=GREEN)
        else:
            self.status.config(text="⚠️ yt-dlp install nahi hai — neeche "
                                    "'Install yt-dlp' dabayein (one time).",
                               fg=GOLD)

    def pick_dir(self):
        d = filedialog.askdirectory(initialdir=self.save_dir)
        if d:
            self.save_dir = d
            self.dir_lbl.config(text=d)

    def install_ytdlp(self):
        self.say("Installing yt-dlp via pip... (internet required)")
        def work():
            try:
                subprocess.run([sys.executable, "-m", "pip", "install",
                                "-U", "yt-dlp"], check=True,
                               capture_output=True, text=True, timeout=300)
                self.say("✅ yt-dlp install ho gaya!")
            except Exception as e:
                self.say(f"❌ Install fail: {e}\n"
                         "Manual: command prompt mein likhein:\n"
                         "   pip install yt-dlp")
            self.refresh_status()
        threading.Thread(target=work, daemon=True).start()

    def download(self):
        url = self.url.get().strip()
        if not url:
            messagebox.showwarning("URL missing",
                                   "Pehle YouTube video ka URL paste karein!")
            return
        if not have_ytdlp():
            messagebox.showinfo(
                "yt-dlp chahiye",
                "Pehle 'Install yt-dlp' button dabayein (sirf ek dafa).")
            return
        q = self.quality.get()
        fmt = {"Best": "best", "720p": "best[height<=720]/best",
               "480p": "best[height<=480]/best",
               "360p (small file)": "best[height<=360]/best",
               "Audio only (MP3)": "bestaudio/best"}.get(q, "best")
        cmd = [sys.executable, "-m", "yt_dlp", "-f", fmt,
               "-o", os.path.join(self.save_dir, "%(title)s.%(ext)s")]
        if q == "Audio only (MP3)":
            cmd += ["--extract-audio", "--audio-format", "mp3"]
        cmd.append(url)
        self.say("⏳ Download shuru: " + url)
        self.say("Save folder: " + self.save_dir)
        def work():
            try:
                p = subprocess.run(cmd, capture_output=True, text=True,
                                   timeout=3600)
                tail = (p.stdout or "")[-1500:]
                if p.returncode == 0:
                    self.say("✅ Download complete!")
                else:
                    self.say("❌ Error:\n" + (p.stderr or tail)[-1500:])
            except Exception as e:
                self.say(f"❌ Error: {e}")
        threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    App().mainloop()
