Download Manager - Windows App
===========================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features:
- YouTube video URL paste karein, quality chunein, DOWNLOAD dabayein
- Qualities: Best, 720p, 480p, 360p, Audio only (MP3)
- Save folder khud chunein (default: Downloads)
- yt-dlp agar install nahi to app ke andar "Install yt-dlp"
  button se ek click mein install (sirf ek dafa, internet chahiye)
- 100% FREE - koi license ya key nahi chahiye

Note: Sirf apni ya ijazat-shuda videos download karein.
Copyright wali videos download karna qanoonan ghalat ho sakta hai.

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
