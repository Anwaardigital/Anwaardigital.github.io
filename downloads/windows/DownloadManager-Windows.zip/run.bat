@echo off
title Download Manager
python main.py
pause
