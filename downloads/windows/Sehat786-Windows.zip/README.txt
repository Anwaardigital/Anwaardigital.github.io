Sehat 786 - Windows App
=======================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features:
- 20 categories (Desi Totkay, Bimariyan, Jari Bootiyan, Ghiza,
  Wazan, Pani, Neend, Hamal, Bachon ki Sehat, Zehni Sehat,
  Warzish, BP, Sugar, Dil, Dant, Aankh, Hospital Directory,
  Emergency Numbers, FAQs)
- 478 sehat topics - Urdu + English (search bhi kar sakte hain)
- Shuru mein medical disclaimer dikhaya jata hai

Note: Ye app sirf maloomati maqasid ke liye hai - ilaj se pehle
doctor se mashwara zaroor karein.

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
