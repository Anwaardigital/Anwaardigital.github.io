@echo off
title Sehat 786
python main.py
pause
