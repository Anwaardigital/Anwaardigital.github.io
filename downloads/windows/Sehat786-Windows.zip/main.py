# -*- coding: utf-8 -*-
"""
Sehat 786 — Windows Desktop App
Health info: Desi Totkay, Bimariyan, Ghiza, Wazan, Neend, etc.
478 topics across 20 categories — Urdu + English, searchable.
Theme: deep emerald + gold. Python 3 + Tkinter only (no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import json
import os
import tkinter as tk
from tkinter import ttk, messagebox

from sehat_data import SEHAT_FEATURES

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_FILE = os.path.join(APP_DIR, "sehat786_config.json")

BG = "#0A3D2E"        # deep emerald
BG_DARK = "#062B20"
GOLD = "#FFD700"
CREAM = "#FFF8E1"
WHITE = "#FFFFFF"
ACCENT = "#0E5C44"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"


DISCLAIMER_UR = (
    "⚠️ طبی انتباہ\n\n"
    "یہ ایپ صرف معلوماتی اور تعلیمی مقاصد کے لیے ہے۔\n"
    "اس میں دی گئی معلومات کسی مستند ڈاکٹر کی رائے کا بدل نہیں ہیں۔\n"
    "کوئی بھی علاج یا ٹوٹکہ استعمال کرنے سے پہلے اپنے ڈاکٹر سے مشورہ ضرور کریں۔\n"
    "ایمرجنسی کی صورت میں فوراً ڈاکٹر یا ہسپتال سے رجوع کریں۔"
)
DISCLAIMER_EN = (
    "⚠️ Medical Disclaimer\n\n"
    "This app is for informational and educational purposes only.\n"
    "It is not a substitute for professional medical advice.\n"
    "Always consult your doctor before trying any remedy or treatment.\n"
    "In an emergency, contact a doctor or hospital immediately."
)


def load_config():
    try:
        with open(CFG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    try:
        with open(CFG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


class SehatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sehat 786 — صحت 786")
        self.root.geometry("1080x700")
        self.root.configure(bg=BG_DARK)
        try:
            self.root.state("zoomed")
        except Exception:
            pass

        self.cfg = load_config()
        self.urdu = self.cfg.get("lang", "ur") != "en"

        self._style()
        self._show_disclaimer()
        self._build()

    # ------------------------------------------------------------ UI ---
    def _style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except Exception:
            pass
        s.configure("TFrame", background=BG_DARK)
        s.configure("Card.TFrame", background=BG)
        s.configure("TLabel", background=BG_DARK, foreground=CREAM,
                    font=("Segoe UI", 11))
        s.configure("Gold.TLabel", background=BG_DARK, foreground=GOLD,
                    font=("Segoe UI", 16, "bold"))
        s.configure("Cat.TButton", background=ACCENT, foreground=WHITE,
                    font=("Segoe UI", 11), padding=8)
        s.map("Cat.TButton", background=[("active", "#147a5c")])
        s.configure("TEntry", font=("Segoe UI", 12), padding=6)

    def _show_disclaimer(self):
        msg = DISCLAIMER_UR if self.urdu else DISCLAIMER_EN
        messagebox.showwarning("Sehat 786 — طبی انتباہ / Disclaimer", msg,
                               parent=self.root)

    def _t(self, ur, en):
        return ur if self.urdu else en

    def _build(self):
        # ---- header ----
        header = tk.Frame(self.root, bg=BG, height=70)
        header.pack(fill="x")
        tk.Label(header, text="🌿 Sehat 786 — صحت 786", bg=BG, fg=GOLD,
                 font=("Segoe UI", 20, "bold")).pack(side="left", padx=16, pady=10)
        tk.Button(header, text="English" if self.urdu else "اردو",
                  bg=GOLD, fg=BG_DARK, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=14, pady=6,
                  command=self._toggle_lang).pack(side="right", padx=16)

        # ---- search ----
        bar = tk.Frame(self.root, bg=BG_DARK)
        bar.pack(fill="x", padx=12, pady=8)
        tk.Label(bar, text="🔍 " + ("تلاش کریں" if self.urdu else "Search"),
                 bg=BG_DARK, fg=CREAM, font=("Segoe UI", 12)).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self._refresh_topics())
        tk.Entry(bar, textvariable=self.search_var, font=("Segoe UI", 12),
                 bg=WHITE, fg="#222", width=40,
                 relief="flat").pack(side="left", padx=8, ipady=4)

        # ---- body: 3 panes ----
        body = tk.PanedWindow(self.root, orient="horizontal", bg=BG_DARK,
                              sashwidth=4, sashrelief="flat")
        body.pack(fill="both", expand=True, padx=12, pady=4)

        # categories
        left = tk.Frame(body, bg=BG)
        body.add(left, width=260)
        tk.Label(left, text=self._t("📂 زمرے", "📂 Categories"),
                 bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold")).pack(pady=8)
        self.cat_list = tk.Listbox(left, exportselection=False, bg=BG_DARK, fg=CREAM, selectbackground=GOLD,
                                   selectforeground=BG_DARK,
                                   font=("Segoe UI", 12), relief="flat",
                                   highlightthickness=0, activestyle="none")
        self.cat_list.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.cat_list.bind("<<ListboxSelect>>", lambda e: self._refresh_topics())

        # topics
        mid = tk.Frame(body, bg=BG)
        body.add(mid, width=320)
        tk.Label(mid, text=self._t("📝 موضوعات", "📝 Topics"),
                 bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold")).pack(pady=8)
        self.topic_list = tk.Listbox(mid, exportselection=False, bg=BG_DARK, fg=CREAM,
                                     selectbackground=GOLD,
                                     selectforeground=BG_DARK,
                                     font=("Segoe UI", 11), relief="flat",
                                     highlightthickness=0, activestyle="none")
        self.topic_list.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.topic_list.bind("<<ListboxSelect>>", lambda e: self._show_detail())

        # detail
        right = tk.Frame(body, bg=BG)
        body.add(right, minsize=300)
        tk.Label(right, text=self._t("📖 تفصیل", "📖 Details"),
                 bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold")).pack(pady=8)
        self.detail = tk.Text(right, bg=BG_DARK, fg=CREAM,
                              font=("Segoe UI", 12), relief="flat",
                              wrap="word", padx=12, pady=12,
                              highlightthickness=0)
        self.detail.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.detail.tag_configure("title", foreground=GOLD,
                                  font=("Segoe UI", 16, "bold"))

        # ---- footer ----
        foot = tk.Frame(self.root, bg=BG, height=30)
        foot.pack(fill="x")
        tk.Label(foot, text=f"{DEVELOPER_LINE}  |  {WHATSAPP_LINE}",
                 bg=BG, fg=CREAM, font=("Segoe UI", 9)).pack(pady=6)

        self._fill_categories()

    # ------------------------------------------------------------ data ---
    def _fill_categories(self):
        self.cat_list.delete(0, "end")
        for f in SEHAT_FEATURES:
            self.cat_list.insert("end", f"{f['icon']}  {self._t(f['tu'], f['te'])}")
        if SEHAT_FEATURES:
            self.cat_list.selection_set(0)
        self._refresh_topics()

    def _selected_cat(self):
        sel = self.cat_list.curselection()
        if not sel:
            return None
        return SEHAT_FEATURES[sel[0]]

    def _refresh_topics(self):
        self.topic_list.delete(0, "end")
        q = self.search_var.get().strip().lower()
        cat = self._selected_cat()
        self._current = []
        if q:
            for f in SEHAT_FEATURES:
                for it in f["items"]:
                    if (q in it["tu"].lower() or q in it["te"].lower()
                            or q in it["bu"].lower() or q in it["be"].lower()):
                        self._current.append((f, it))
                        self.topic_list.insert(
                            "end", f"{self._t(it['tu'], it['te'])}  ({self._t(f['tu'], f['te'])})")
        elif cat:
            for it in cat["items"]:
                self._current.append((cat, it))
                self.topic_list.insert("end", self._t(it["tu"], it["te"]))
        if self._current:
            self.topic_list.selection_set(0)
        self._show_detail()

    def _show_detail(self):
        sel = self.topic_list.curselection()
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        if sel and sel[0] < len(self._current):
            _f, it = self._current[sel[0]]
            self.detail.insert("end", self._t(it["tu"], it["te"]) + "\n\n", "title")
            body = self._t(it["bu"], it["be"])
            self.detail.insert("end", body)
        else:
            self.detail.insert("end", self._t("کوئی موضوع منتخب کریں",
                                              "Select a topic"))
        self.detail.configure(state="disabled")

    def _toggle_lang(self):
        self.urdu = not self.urdu
        self.cfg["lang"] = "ur" if self.urdu else "en"
        save_config(self.cfg)
        for w in self.root.winfo_children():
            w.destroy()
        self._show_disclaimer()
        self._build()


def main():
    root = tk.Tk()
    SehatApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
