# -*- coding: utf-8 -*-
"""
Rishta 786 — Windows Desktop App
Matrimonial profile browser (DEMO): sample profiles with
filters (gender / city / age / education). Python 3 + Tkinter
only (no extra deps).

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
"""

import tkinter as tk
from tkinter import ttk

BG = "#7B1E2B"        # deep maroon
BG_DARK = "#521018"
GOLD = "#FFD700"
CREAM = "#FFF3E0"
WHITE = "#FFFFFF"
ACCENT = "#A83246"
DEVELOPER_LINE = "App developed by Malik Muhammad Anwaar"
WHATSAPP_LINE = "WhatsApp: 923288317526"

PROFILES = [
    {"id": "R786-001", "gender": "Male", "age": 28, "city": "Lahore",
     "edu": "MBA", "job": "Bank Officer", "height": "5'10\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Deeni mizaj, namazi, simple family se."},
    {"id": "R786-002", "gender": "Female", "age": 24, "city": "Karachi",
     "edu": "BSc", "job": "Teacher", "height": "5'4\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Padhi-likhi, ghar-dar, shareef khandan."},
    {"id": "R786-003", "gender": "Male", "age": 31, "city": "Islamabad",
     "edu": "BTech", "job": "Software Engineer", "height": "5'9\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Settled job, apna ghar, deeni soch."},
    {"id": "R786-004", "gender": "Female", "age": 26, "city": "Faisalabad",
     "edu": "MA Urdu", "job": "Housewife-to-be", "height": "5'5\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Khush-akhlaq, deen-dar family."},
    {"id": "R786-005", "gender": "Male", "age": 27, "city": "Multan",
     "edu": "MBBS", "job": "Doctor", "height": "6'0\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Doctor, achhi family, jaldi shadi ka irada."},
    {"id": "R786-006", "gender": "Female", "age": 23, "city": "Rawalpindi",
     "edu": "BS CS", "job": "Freelancer", "height": "5'3\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Modern + deeni, work from home."},
    {"id": "R786-007", "gender": "Male", "age": 35, "city": "Peshawar",
     "edu": "MA", "job": "Businessman", "height": "5'11\"", "maslak": "Sunni",
     "status": "Divorced",
     "about": "Karobari, bache nahi, serious rishta."},
    {"id": "R786-008", "gender": "Female", "age": 29, "city": "Lahore",
     "edu": "MPhil", "job": "Lecturer", "height": "5'6\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Professor, deen-dar, shareef gharana."},
    {"id": "R786-009", "gender": "Male", "age": 26, "city": "Sialkot",
     "edu": "DAE", "job": "Technician (UAE)", "height": "5'8\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Gulf mein job, salana Pakistan ata hai."},
    {"id": "R786-010", "gender": "Female", "age": 25, "city": "Hyderabad",
     "edu": "BCom", "job": "Bank Staff", "height": "5'4\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Job-holder, simple shaadi chahti hain."},
    {"id": "R786-011", "gender": "Male", "age": 30, "city": "Quetta",
     "edu": "LLB", "job": "Advocate", "height": "5'10\"", "maslak": "Sunni",
     "status": "Never married",
     "about": "Wakeel, apna office, deeni mizaj."},
    {"id": "R786-012", "gender": "Female", "age": 27, "city": "Gujranwala",
     "edu": "FA", "job": "Beautician", "height": "5'5\"", "maslak": "Sunni",
     "status": "Widowed",
     "about": "Ek bacha, shareef aur mehnati."},
]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Rishta 786 — رشتہ (Demo)")
        self.geometry("940x640")
        self.configure(bg=BG)
        self._build()

    def _build(self):
        head = tk.Frame(self, bg=BG_DARK, height=86)
        head.pack(fill="x")
        tk.Label(head, text="💍 Rishta 786", font=("Segoe UI", 20, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(pady=(10, 0))
        tk.Label(head, text="Matrimonial profiles browser (DEMO — sample data)",
                 font=("Segoe UI", 10), fg=CREAM, bg=BG_DARK).pack(pady=(0, 8))

        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=12, pady=8)
        tk.Label(bar, text="Gender:", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left")
        self.gender = ttk.Combobox(bar, values=["All", "Male", "Female"],
                                   state="readonly", width=8,
                                   font=("Segoe UI", 10))
        self.gender.set("All")
        self.gender.pack(side="left", padx=4)
        self.gender.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        cities = ["All"] + sorted({p["city"] for p in PROFILES})
        tk.Label(bar, text="City:", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left", padx=(10, 0))
        self.city = ttk.Combobox(bar, values=cities, state="readonly",
                                 width=11, font=("Segoe UI", 10))
        self.city.set("All")
        self.city.pack(side="left", padx=4)
        self.city.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        tk.Label(bar, text="Age:", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left", padx=(10, 0))
        self.amin = ttk.Spinbox(bar, from_=18, to=60, width=4,
                                font=("Segoe UI", 10))
        self.amin.set(18)
        self.amin.pack(side="left", padx=2)
        tk.Label(bar, text="–", font=("Segoe UI", 10, "bold"),
                 fg=CREAM, bg=BG).pack(side="left")
        self.amax = ttk.Spinbox(bar, from_=18, to=60, width=4,
                                font=("Segoe UI", 10))
        self.amax.set(60)
        self.amax.pack(side="left", padx=2)
        tk.Button(bar, text="Apply", font=("Segoe UI", 10, "bold"),
                  bg=GOLD, fg=BG_DARK, relief="flat", padx=10,
                  command=self.refresh).pack(side="left", padx=8)

        tk.Label(bar, text="🔎", font=("Segoe UI", 12), fg=GOLD,
                 bg=BG).pack(side="left", padx=(6, 0))
        self.q = tk.StringVar()
        qe = tk.Entry(bar, textvariable=self.q, font=("Segoe UI", 10), width=18)
        qe.pack(side="left", padx=4)
        qe.bind("<KeyRelease>", lambda e: self.refresh())

        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True, padx=12)

        left = tk.Frame(mid, bg=BG)
        left.pack(side="left", fill="y", padx=(0, 10))
        tk.Label(left, text="Profiles", font=("Segoe UI", 11, "bold"),
                 fg=GOLD, bg=BG).pack(anchor="w")
        self.lb = tk.Listbox(left, font=("Segoe UI", 11), width=30, height=22,
                             bg=WHITE, fg=BG_DARK, selectbackground=GOLD,
                             selectforeground=BG_DARK, relief="flat")
        self.lb.pack(fill="y", expand=True)
        self.lb.bind("<<ListboxSelect>>", lambda e: self.show())
        self.count = tk.Label(left, text="", font=("Segoe UI", 9),
                              fg=CREAM, bg=BG)
        self.count.pack(anchor="w", pady=4)

        right = tk.Frame(mid, bg=WHITE)
        right.pack(side="left", fill="both", expand=True)
        self.view = tk.Text(right, font=("Segoe UI", 12), bg=WHITE, fg=BG_DARK,
                            wrap="word", relief="flat", padx=14, pady=10,
                            state="disabled")
        self.view.pack(fill="both", expand=True)

        foot = tk.Frame(self, bg=BG_DARK)
        foot.pack(fill="x")
        tk.Label(foot, text=DEVELOPER_LINE, font=("Segoe UI", 9),
                 fg=GOLD, bg=BG_DARK).pack(pady=(6, 0))
        tk.Label(foot, text=WHATSAPP_LINE, font=("Segoe UI", 9),
                 fg=CREAM, bg=BG_DARK).pack(pady=(0, 6))

        self.filtered = PROFILES[:]
        self.refresh()

    def refresh(self):
        g, c = self.gender.get(), self.city.get()
        try:
            a0, a1 = int(self.amin.get()), int(self.amax.get())
        except ValueError:
            a0, a1 = 18, 60
        q = self.q.get().strip().lower()
        self.filtered = [p for p in PROFILES
                         if (g == "All" or p["gender"] == g)
                         and (c == "All" or p["city"] == c)
                         and a0 <= p["age"] <= a1
                         and (not q or q in p["edu"].lower()
                              or q in p["job"].lower()
                              or q in p["city"].lower()
                              or q in p["about"].lower())]
        self.lb.delete(0, "end")
        for p in self.filtered:
            tag = "👨" if p["gender"] == "Male" else "👩"
            self.lb.insert("end", f"{tag} {p['id']} — {p['age']}y, {p['city']}")
        self.count.config(text=f"{len(self.filtered)} profile(s)")
        if self.filtered:
            self.lb.select_set(0)
        self.show()

    def show(self):
        sel = self.lb.curselection()
        self.view.config(state="normal")
        self.view.delete("1.0", "end")
        if sel:
            p = self.filtered[sel[0]]
            self.view.insert("end",
                f"🆔 Profile: {p['id']}\n\n"
                f"👤 Gender:   {p['gender']}\n"
                f"🎂 Age:      {p['age']} years\n"
                f"📍 City:     {p['city']}\n"
                f"🎓 Education:{p['edu']}\n"
                f"💼 Job:      {p['job']}\n"
                f"📏 Height:   {p['height']}\n"
                f"🕌 Maslak:   {p['maslak']}\n"
                f"💒 Status:   {p['status']}\n\n"
                f"📝 {p['about']}\n\n"
                f"⚠️ Demo data — contact via app's official channel.")
        self.view.config(state="disabled")


if __name__ == "__main__":
    App().mainloop()
