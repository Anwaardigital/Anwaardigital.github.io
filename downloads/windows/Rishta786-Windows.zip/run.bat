@echo off
title Rishta 786
python main.py
pause
