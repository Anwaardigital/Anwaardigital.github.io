Rishta 786 - Windows App (DEMO)
===========================

Chalane ka tareeqa (Windows par):
1. Python 3 install karein: https://www.python.org/downloads/
   (Install karte waqt "Add python.exe to PATH" zaroor tick karein)
2. Is folder mein "run.bat" par double-click karein. Bas!

Koi alag cheez install karne ki zaroorat nahi - sirf Python 3.

Features (demo version - sample data):
- 12 sample profiles (Male / Female)
- Filters: gender, city, age range
- Search: taleem, job, city ya detail se
- Har profile ki mukammal detail

Note: ye DEMO version hai. Asli profiles ke liye
Rishta 786 mobile app istemal karein.

App developed by Malik Muhammad Anwaar
WhatsApp: 923288317526
